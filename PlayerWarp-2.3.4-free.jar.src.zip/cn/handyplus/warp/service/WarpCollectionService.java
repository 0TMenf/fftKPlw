/*     */ package cn.handyplus.warp.service;
/*     */ 
/*     */ public class WarpCollectionService {
/*     */   public List<WarpCollection> findAll() {
/*   5 */     return Db.use(WarpCollection.class).execution().list();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(WarpCollection warpCollection) {
/*  18 */     Db.use(WarpCollection.class).execution().insert(warpCollection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delById(Integer integer) {
/*  30 */     Db.use(WarpCollection.class).execution().deleteById(integer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WarpCollectionService getInstance() {
/*  46 */     return M.oOoOOO();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean collection(Player player, Integer integer) {
/*     */     Optional<WarpCollection> optional;
/* 174 */     if (!(optional = findByPlayerUuid(player.getUniqueId(), integer)).isPresent()) {
/*     */       WarpCollection warpCollection = new WarpCollection();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       warpCollection.setWarpPlayerId(integer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 233 */       warpCollection.setPlayerName(player.getName());
/*     */       warpCollection.setPlayerUuid(player.getUniqueId());
/*     */       add(warpCollection);
/*     */       return true;
/*     */     } 
/*     */     delById(((WarpCollection)optional.get()).getId());
/*     */     return false;
/*     */   }
/*     */   
/*     */   public Optional<WarpCollection> findByPlayerUuid(UUID uUID, Integer integer) {
/*     */     Db db;
/*     */     (db = Db.use(WarpCollection.class)).where().eq(WarpCollection::getPlayerUuid, uUID).le(WarpCollection::getWarpPlayerId, Integer.valueOf(100)).eq(WarpCollection::getWarpPlayerId, integer);
/*     */     return db.execution().selectOne();
/*     */   }
/*     */   
/*     */   public void deleteByWarpIds(List list) {
/*     */     Db db;
/*     */     db.execution().delete();
/*     */   }
/*     */   
/*     */   public List<Integer> findByPlayerUuid(UUID uUID) {
/*     */     List list = db.execution().list();
/*     */     Db db;
/*     */     (db = Db.use(WarpCollection.class)).where().eq(WarpCollection::getPlayerUuid, uUID).le(WarpCollection::getWarpPlayerId, Integer.valueOf(100));
/*     */     if (CollUtil.isEmpty(list))
/*     */       return new ArrayList<>(); 
/*     */     return (List<Integer>)list.stream().map(WarpCollection::getWarpPlayerId).collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_3
/*     */     //   1: iconst_5
/*     */     //   2: ixor
/*     */     //   3: iconst_3
/*     */     //   4: ishl
/*     */     //   5: iconst_3
/*     */     //   6: iconst_5
/*     */     //   7: ixor
/*     */     //   8: ixor
/*     */     //   9: iconst_4
/*     */     //   10: iconst_3
/*     */     //   11: ishl
/*     */     //   12: iconst_3
/*     */     //   13: ixor
/*     */     //   14: iconst_4
/*     */     //   15: dup
/*     */     //   16: ishl
/*     */     //   17: iconst_2
/*     */     //   18: iconst_5
/*     */     //   19: ixor
/*     */     //   20: ixor
/*     */     //   21: aload_0
/*     */     //   22: checkcast java/lang/String
/*     */     //   25: dup
/*     */     //   26: astore_0
/*     */     //   27: invokevirtual length : ()I
/*     */     //   30: dup
/*     */     //   31: newarray char
/*     */     //   33: iconst_1
/*     */     //   34: dup
/*     */     //   35: pop2
/*     */     //   36: swap
/*     */     //   37: iconst_1
/*     */     //   38: isub
/*     */     //   39: dup_x2
/*     */     //   40: istore_3
/*     */     //   41: astore_1
/*     */     //   42: istore #4
/*     */     //   44: dup_x2
/*     */     //   45: pop2
/*     */     //   46: istore_2
/*     */     //   47: iflt -> 87
/*     */     //   50: aload_1
/*     */     //   51: aload_0
/*     */     //   52: iload_3
/*     */     //   53: dup_x1
/*     */     //   54: invokevirtual charAt : (I)C
/*     */     //   57: iinc #3, -1
/*     */     //   60: iload_2
/*     */     //   61: ixor
/*     */     //   62: i2c
/*     */     //   63: castore
/*     */     //   64: iload_3
/*     */     //   65: iflt -> 87
/*     */     //   68: aload_1
/*     */     //   69: aload_0
/*     */     //   70: iload_3
/*     */     //   71: iinc #3, -1
/*     */     //   74: dup_x1
/*     */     //   75: invokevirtual charAt : (I)C
/*     */     //   78: iload #4
/*     */     //   80: ixor
/*     */     //   81: i2c
/*     */     //   82: castore
/*     */     //   83: iload_3
/*     */     //   84: goto -> 47
/*     */     //   87: new java/lang/String
/*     */     //   90: dup
/*     */     //   91: aload_1
/*     */     //   92: invokespecial <init> : ([C)V
/*     */     //   95: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	96	0	a	Ljava/lang/String;
/*     */   }
/*     */   
/*     */   private static class WarpCollectionService {}
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\service\WarpCollectionService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */