/*     */ package cn.handyplus.warp.service;
/*     */ 
/*     */ import cn.handyplus.warp.enter.WarpChannel;
/*     */ import cn.handyplus.warp.lib.Db;
/*     */ import cn.handyplus.warp.lib.E;
/*     */ import cn.handyplus.warp.lib.StrUtil;
/*     */ import cn.handyplus.warp.lib.j;
/*     */ import java.lang.invoke.SerializedLambda;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WarpChannelService
/*     */ {
/*     */   public static WarpChannelService getInstance() {
/*  41 */     return j.IiiIII();
/*     */   } public void delById(Integer integer) {
/*  43 */     Db.use(WarpChannel.class).execution().deleteById(integer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(WarpChannel warpChannel) {
/*  61 */     Db.use(WarpChannel.class).execution().insert(warpChannel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<WarpChannel> findByPlayerUuidAndServerName(UUID uUID, String str) {
/*     */     Db db;
/* 186 */     (db = Db.use(WarpChannel.class))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 228 */       .where().eq(WarpChannel::getPlayerUuid, uUID).eq(WarpChannel::getServerName, str);
/*     */     return db.execution().selectOne();
/*     */   }
/*     */   
/*     */   public List<WarpChannel> findAll() {
/*     */     return Db.use(WarpChannel.class).execution().list();
/*     */   }
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_2
/*     */     //   1: iconst_5
/*     */     //   2: ixor
/*     */     //   3: iconst_4
/*     */     //   4: ishl
/*     */     //   5: iconst_1
/*     */     //   6: ixor
/*     */     //   7: iconst_5
/*     */     //   8: iconst_3
/*     */     //   9: ishl
/*     */     //   10: iconst_1
/*     */     //   11: ixor
/*     */     //   12: iconst_1
/*     */     //   13: iconst_3
/*     */     //   14: ishl
/*     */     //   15: iconst_3
/*     */     //   16: iconst_5
/*     */     //   17: ixor
/*     */     //   18: ixor
/*     */     //   19: aload_0
/*     */     //   20: checkcast java/lang/String
/*     */     //   23: dup
/*     */     //   24: astore_0
/*     */     //   25: invokevirtual length : ()I
/*     */     //   28: dup
/*     */     //   29: newarray char
/*     */     //   31: iconst_1
/*     */     //   32: dup
/*     */     //   33: pop2
/*     */     //   34: swap
/*     */     //   35: iconst_1
/*     */     //   36: isub
/*     */     //   37: dup_x2
/*     */     //   38: istore_3
/*     */     //   39: astore_1
/*     */     //   40: istore #4
/*     */     //   42: dup_x2
/*     */     //   43: pop
/*     */     //   44: istore_2
/*     */     //   45: pop
/*     */     //   46: iflt -> 86
/*     */     //   49: aload_1
/*     */     //   50: aload_0
/*     */     //   51: iload_3
/*     */     //   52: dup_x1
/*     */     //   53: invokevirtual charAt : (I)C
/*     */     //   56: iinc #3, -1
/*     */     //   59: iload_2
/*     */     //   60: ixor
/*     */     //   61: i2c
/*     */     //   62: castore
/*     */     //   63: iload_3
/*     */     //   64: iflt -> 86
/*     */     //   67: aload_1
/*     */     //   68: aload_0
/*     */     //   69: iload_3
/*     */     //   70: iinc #3, -1
/*     */     //   73: dup_x1
/*     */     //   74: invokevirtual charAt : (I)C
/*     */     //   77: iload #4
/*     */     //   79: ixor
/*     */     //   80: i2c
/*     */     //   81: castore
/*     */     //   82: iload_3
/*     */     //   83: goto -> 46
/*     */     //   86: new java/lang/String
/*     */     //   89: dup
/*     */     //   90: aload_1
/*     */     //   91: invokespecial <init> : ([C)V
/*     */     //   94: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	95	0	a	Ljava/lang/String;
/*     */   }
/*     */   
/*     */   private static class WarpChannelService {}
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\service\WarpChannelService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */