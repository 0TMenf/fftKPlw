/*     */ package cn.handyplus.warp.service;
/*     */ import cn.handyplus.warp.enter.WarpTpPlayer;
/*     */ import cn.handyplus.warp.lib.GameRuleUtil;
/*     */ import cn.handyplus.warp.util.WarpPermissionUtil;
/*     */ import java.lang.invoke.SerializedLambda;
/*     */ 
/*     */ public class WarpTpPlayerService {
/*     */   public void add(WarpTpPlayer warpTpPlayer) {
/*   9 */     Db.use(WarpTpPlayer.class).execution().insert(warpTpPlayer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<WarpTpPlayer> findByPlayerAndWarpId(UUID uUID, Integer integer) {
/*     */     Db db;
/*  94 */     (db = Db.use(WarpTpPlayer.class))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 178 */       .where().eq(WarpTpPlayer::getPlayerUuid, uUID).eq(WarpTpPlayer::getWarpPlayerId, integer).le(WarpTpPlayer::getWarpPlayerId, Integer.valueOf(100));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 224 */     return db.execution().selectOne();
/*     */   }
/*     */   
/*     */   public void deleteByWarpIds(List list) {
/*     */     Db db;
/*     */     db.execution().delete();
/*     */   }
/*     */   
/*     */   public void setTpTime(Date date) {
/*     */     Db db;
/*     */     db.execution().update();
/*     */   }
/*     */   
/*     */   public List<WarpTpPlayer> findAll() {
/*     */     return Db.use(WarpTpPlayer.class).execution().list();
/*     */   }
/*     */   
/*     */   public static WarpTpPlayerService getInstance() {
/*     */     return I.AXfdVx();
/*     */   }
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_2
/*     */     //   1: iconst_5
/*     */     //   2: ixor
/*     */     //   3: iconst_4
/*     */     //   4: ishl
/*     */     //   5: iconst_5
/*     */     //   6: iconst_3
/*     */     //   7: ishl
/*     */     //   8: iconst_3
/*     */     //   9: ixor
/*     */     //   10: iconst_3
/*     */     //   11: aload_0
/*     */     //   12: checkcast java/lang/String
/*     */     //   15: dup
/*     */     //   16: astore_0
/*     */     //   17: invokevirtual length : ()I
/*     */     //   20: dup
/*     */     //   21: newarray char
/*     */     //   23: iconst_1
/*     */     //   24: dup
/*     */     //   25: pop2
/*     */     //   26: swap
/*     */     //   27: iconst_1
/*     */     //   28: isub
/*     */     //   29: dup_x2
/*     */     //   30: istore_3
/*     */     //   31: astore_1
/*     */     //   32: istore #4
/*     */     //   34: dup_x2
/*     */     //   35: pop
/*     */     //   36: istore_2
/*     */     //   37: pop
/*     */     //   38: iflt -> 78
/*     */     //   41: aload_1
/*     */     //   42: aload_0
/*     */     //   43: iload_3
/*     */     //   44: dup_x1
/*     */     //   45: invokevirtual charAt : (I)C
/*     */     //   48: iinc #3, -1
/*     */     //   51: iload_2
/*     */     //   52: ixor
/*     */     //   53: i2c
/*     */     //   54: castore
/*     */     //   55: iload_3
/*     */     //   56: iflt -> 78
/*     */     //   59: aload_1
/*     */     //   60: aload_0
/*     */     //   61: iload_3
/*     */     //   62: iinc #3, -1
/*     */     //   65: dup_x1
/*     */     //   66: invokevirtual charAt : (I)C
/*     */     //   69: iload #4
/*     */     //   71: ixor
/*     */     //   72: i2c
/*     */     //   73: castore
/*     */     //   74: iload_3
/*     */     //   75: goto -> 38
/*     */     //   78: new java/lang/String
/*     */     //   81: dup
/*     */     //   82: aload_1
/*     */     //   83: invokespecial <init> : ([C)V
/*     */     //   86: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	87	0	a	Ljava/lang/String;
/*     */   }
/*     */   
/*     */   private static class WarpTpPlayerService {}
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\service\WarpTpPlayerService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */