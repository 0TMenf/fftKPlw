/*     */ package cn.handyplus.warp.service;
/*     */ 
/*     */ import cn.handyplus.warp.enter.WarpLikePlayer;
/*     */ import cn.handyplus.warp.lib.A;
/*     */ import cn.handyplus.warp.lib.CollUtil;
/*     */ import cn.handyplus.warp.lib.Db;
/*     */ import cn.handyplus.warp.lib.MapUtil;
/*     */ import cn.handyplus.warp.lib.RgbTextUtil;
/*     */ import cn.handyplus.warp.lib.StrUtil;
/*     */ import cn.handyplus.warp.lib.i;
/*     */ import java.lang.invoke.SerializedLambda;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.UUID;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WarpLikePlayerService
/*     */ {
/*     */   public void updateLikeById(Integer integer1, Integer integer2) {
/*     */     Db db;
/* 145 */     db.execution().updateById(integer1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WarpLikePlayerService getInstance() {
/*     */     return i.OOoOOO();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(WarpLikePlayer warpLikePlayer) {
/*     */     Optional<WarpLikePlayer> optional;
/*     */     if ((optional = findByWarpIdAndPlayerUuid(warpLikePlayer.getWarpPlayerId(), warpLikePlayer.getPlayerUuid())).isPresent()) {
/* 170 */       updateLikeById(((WarpLikePlayer)optional.get()).getId(), warpLikePlayer.getLike());
/*     */       return;
/*     */     } 
/*     */     Db.use(WarpLikePlayer.class).execution().insert(warpLikePlayer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteByWarpIds(List list) {
/*     */     Db db;
/* 222 */     db.execution().delete(); } public Map<Integer, Integer> findLikeByWarpIds(List<Integer> list) {
/* 223 */     if (CollUtil.isEmpty(list = (List)pPPPpP(list)))
/*     */       return MapUtil.of();  Map<?, ?> map; HashMap<Integer, Integer> hashMap = MapUtil.newHashMapWithExpectedSize((map = (Map<?, ?>)list.stream().collect(Collectors.groupingBy(WarpLikePlayer::getWarpPlayerId))).size()); Iterator<?> iterator; while ((iterator = (map = (Map<?, ?>)list.stream().collect(Collectors.groupingBy(WarpLikePlayer::getWarpPlayerId))).keySet().iterator()).hasNext()) {
/* 225 */       Integer integer = (Integer)iterator.next(); List<?> list1; int i = (list1 = (List)map.get(integer)).stream().mapToInt(WarpLikePlayer::getLike).sum();
/*     */     } 
/*     */     return hashMap;
/*     */   }
/*     */   
/*     */   public List<WarpLikePlayer> findAll() {
/*     */     return Db.use(WarpLikePlayer.class).execution().list();
/*     */   }
/*     */   
/*     */   public Optional<WarpLikePlayer> findByWarpIdAndPlayerUuid(Integer integer, UUID uUID) {
/*     */     Db db;
/*     */     (db = Db.use(WarpLikePlayer.class)).where().eq(WarpLikePlayer::getPlayerUuid, uUID).le(WarpLikePlayer::getWarpPlayerId, Integer.valueOf(100)).eq(WarpLikePlayer::getWarpPlayerId, integer);
/*     */     return db.execution().selectOne();
/*     */   }
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_3
/*     */     //   1: iconst_5
/*     */     //   2: ixor
/*     */     //   3: iconst_4
/*     */     //   4: ishl
/*     */     //   5: iconst_3
/*     */     //   6: iconst_2
/*     */     //   7: ishl
/*     */     //   8: iconst_3
/*     */     //   9: ixor
/*     */     //   10: ixor
/*     */     //   11: iconst_3
/*     */     //   12: iconst_5
/*     */     //   13: ixor
/*     */     //   14: iconst_3
/*     */     //   15: ishl
/*     */     //   16: iconst_3
/*     */     //   17: iconst_5
/*     */     //   18: ixor
/*     */     //   19: iconst_4
/*     */     //   20: ishl
/*     */     //   21: iconst_1
/*     */     //   22: dup
/*     */     //   23: ishl
/*     */     //   24: ixor
/*     */     //   25: aload_0
/*     */     //   26: checkcast java/lang/String
/*     */     //   29: dup
/*     */     //   30: astore_0
/*     */     //   31: invokevirtual length : ()I
/*     */     //   34: dup
/*     */     //   35: newarray char
/*     */     //   37: iconst_1
/*     */     //   38: dup
/*     */     //   39: pop2
/*     */     //   40: swap
/*     */     //   41: iconst_1
/*     */     //   42: isub
/*     */     //   43: dup_x2
/*     */     //   44: istore_3
/*     */     //   45: astore_1
/*     */     //   46: istore #4
/*     */     //   48: dup_x2
/*     */     //   49: pop2
/*     */     //   50: istore_2
/*     */     //   51: iflt -> 91
/*     */     //   54: aload_1
/*     */     //   55: aload_0
/*     */     //   56: iload_3
/*     */     //   57: dup_x1
/*     */     //   58: invokevirtual charAt : (I)C
/*     */     //   61: iinc #3, -1
/*     */     //   64: iload_2
/*     */     //   65: ixor
/*     */     //   66: i2c
/*     */     //   67: castore
/*     */     //   68: iload_3
/*     */     //   69: iflt -> 91
/*     */     //   72: aload_1
/*     */     //   73: aload_0
/*     */     //   74: iload_3
/*     */     //   75: iinc #3, -1
/*     */     //   78: dup_x1
/*     */     //   79: invokevirtual charAt : (I)C
/*     */     //   82: iload #4
/*     */     //   84: ixor
/*     */     //   85: i2c
/*     */     //   86: castore
/*     */     //   87: iload_3
/*     */     //   88: goto -> 51
/*     */     //   91: new java/lang/String
/*     */     //   94: dup
/*     */     //   95: aload_1
/*     */     //   96: invokespecial <init> : ([C)V
/*     */     //   99: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	100	0	a	Ljava/lang/String;
/*     */   }
/*     */   
/*     */   private static class WarpLikePlayerService {}
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\service\WarpLikePlayerService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */