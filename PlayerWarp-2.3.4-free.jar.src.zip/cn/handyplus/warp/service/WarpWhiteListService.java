/*     */ package cn.handyplus.warp.service;
/*     */ 
/*     */ import cn.handyplus.warp.enter.WarpWhiteList;
/*     */ import cn.handyplus.warp.lib.BcUtil;
/*     */ import cn.handyplus.warp.lib.Db;
/*     */ import cn.handyplus.warp.lib.F;
/*     */ import cn.handyplus.warp.lib.InventoryCheckParam;
/*     */ import cn.handyplus.warp.lib.J;
/*     */ import java.lang.invoke.SerializedLambda;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WarpWhiteListService
/*     */ {
/*     */   public void deleteByWarpIdAndPlayerUuid(Integer integer, UUID uUID) {
/*     */     Db db;
/* 218 */     db.execution().delete();
/*     */   }
/*     */   
/*     */   public Optional<WarpWhiteList> findByWarpIdAndPlayerUuid(Integer integer, UUID uUID) {
/*     */     Db db;
/*     */     (db = Db.use(WarpWhiteList.class)).where().eq(WarpWhiteList::getPlayerUuid, uUID).eq(WarpWhiteList::getWarpPlayerId, integer);
/*     */     return db.execution().selectOne();
/*     */   }
/*     */   
/*     */   public void deleteById(Integer integer) {
/* 228 */     Db.use(WarpWhiteList.class).execution().deleteById(integer);
/*     */   }
/*     */   
/*     */   public List<WarpWhiteList> findAll() {
/*     */     return Db.use(WarpWhiteList.class).execution().list();
/*     */   }
/*     */   
/*     */   public boolean add(WarpWhiteList warpWhiteList) {
/*     */     return (Db.use(WarpWhiteList.class).execution().insert(warpWhiteList) > 0);
/*     */   }
/*     */   
/*     */   public static WarpWhiteListService getInstance() {
/*     */     return J.IIiIiI();
/*     */   }
/*     */   
/*     */   private static class WarpWhiteListService {}
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\service\WarpWhiteListService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */