/*     */ package cn.handyplus.warp.service;
/*     */ import cn.handyplus.warp.enter.WarpPlayer;
/*     */ import cn.handyplus.warp.lib.CollUtil;
/*     */ import cn.handyplus.warp.lib.Db;
/*     */ import cn.handyplus.warp.lib.GameRuleUtil;
/*     */ import cn.handyplus.warp.lib.MapUtil;
/*     */ import cn.handyplus.warp.lib.Page;
/*     */ import cn.handyplus.warp.lib.StrUtil;
/*     */ import java.lang.invoke.SerializedLambda;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ public class WarpPlayerService {
/*     */   public static WarpPlayerService getInstance() {
/*  18 */     return D.IIiIiI();
/*     */   }
/*     */   
/*     */   public Page<WarpPlayer> viewPage(Integer integer1, Integer integer2) {
/*  22 */     return page(null, integer1, integer2, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int add(WarpPlayer warpPlayer) {
/*  31 */     return Db.use(WarpPlayer.class).execution().insert(warpPlayer); } public Integer findCount(String str) {
/*  32 */     return findCount(str, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Page<WarpPlayer> openPage(Integer integer1, Integer integer2, String str, List<Integer> list) {
/*  42 */     return page(null, integer1, integer2, str, list, Boolean.valueOf(true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer findCount() {
/*     */     Db db;
/*  65 */     (db = Db.use(WarpPlayer.class)).where().ge(WarpPlayer::getExpirationTime, new Date())
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 140 */       .le(WarpPlayer::getId, Integer.valueOf(100));
/*     */     return Integer.valueOf(db.execution().count());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addThermalValue(Integer integer1, Integer integer2) {
/*     */     Db db;
/*     */     db.execution().updateById(integer1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTpNumber(Integer integer1, Integer integer2) {
/*     */     Db db;
/*     */     db.execution().updateById(integer1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Page<WarpPlayer> page(UUID uUID, Integer integer1, Integer integer2, String str, List list, Boolean bool) {
/*     */     Db db;
/* 171 */     (db = Db.use(WarpPlayer.class)).where().eq((uUID != null), WarpPlayer::getPlayerUuid, uUID)
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 489 */       .eq((bool != null), WarpPlayer::getDisplay, bool)
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 628 */       .eq((StrUtil.isNotEmpty(str) && !WarpTypeEnum.ALL.getType().equals(str)), WarpPlayer::getType, str).limit(integer1.intValue(), integer2.intValue()).orderByDesc(WarpPlayer::getTpNumber).le(WarpPlayer::getId, Integer.valueOf(100)).ge(WarpPlayer::getExpirationTime, new Date())
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 646 */       .in(CollUtil.isNotEmpty(list), WarpPlayer::getId, list).orderByDesc(true, WarpPlayer::getThermalValue, WarpPlayer::getTpNumber);
/*     */     return db.execution().page();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer findCountByPlayerUuid(UUID uUID) {
/*     */     Db db;
/*     */     (db = Db.use(WarpPlayer.class)).where().eq(WarpPlayer::getPlayerUuid, uUID).ge(WarpPlayer::getExpirationTime, new Date()).le(WarpPlayer::getId, Integer.valueOf(100));
/*     */     return Integer.valueOf(db.execution().count());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer findCount(UUID uUID, String str, List list, Boolean bool) {
/*     */     Db db;
/*     */     (db = Db.use(WarpPlayer.class)).where().eq((uUID != null), WarpPlayer::getPlayerUuid, uUID).eq((bool != null), WarpPlayer::getDisplay, bool).eq((StrUtil.isNotEmpty(str) && !WarpTypeEnum.ALL.getType().equals(str)), WarpPlayer::getType, str).in(CollUtil.isNotEmpty(list), WarpPlayer::getId, list).ge(WarpPlayer::getExpirationTime, new Date()).le(WarpPlayer::getId, Integer.valueOf(100));
/*     */     return Integer.valueOf(db.execution().count());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setThermalValue(Integer integer) {
/*     */     Db db;
/*     */     db.execution().update();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void subtractThermalValue(Integer integer1, Integer integer2) {
/*     */     Db db;
/*     */     db.execution().updateById(integer1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTpNumber(Integer integer) {
/*     */     Db db;
/*     */     db.execution().update();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer findCount(String str, List<Integer> list) {
/*     */     return findCount(null, str, list, Boolean.valueOf(true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(WarpPlayer warpPlayer) {
/*     */     Db db;
/*     */     db.execution().updateById(warpPlayer.getId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteExpirationTime() {
/* 715 */     List<Integer> list = db.execution().list();
/*     */     MessageUtil.sendConsoleMessage((new StringBuilder()).insert(0, GameRuleUtil.qzlKeO("珼實坥桗掇亦y湕瑓辗杊坠桒")).append(list.size()).append(WarpLikePlayerService.qzlKeO("久N湪瑤料閖U")).append(DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss")).toString());
/*     */     Db db;
/*     */     (db = Db.use(WarpPlayer.class)).where().le(WarpPlayer::getExpirationTime, new Date());
/*     */     if (CollUtil.isEmpty(list)) {
/*     */       return;
/*     */     }
/*     */     list = (List)list.stream().map(WarpPlayer::getId).collect(Collectors.toList());
/*     */     Xxxxxx(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> listWorldName(String str) {
/*     */     List list = db.execution().list();
/*     */     Db db;
/*     */     (db = Db.use(WarpPlayer.class)).where().eq(WarpPlayer::getServerName, str).le(WarpPlayer::getId, Integer.valueOf(100));
/*     */     if (CollUtil.isEmpty(list)) {
/*     */       return new ArrayList<>();
/*     */     }
/*     */     return (List<String>)list.stream().map(WarpPlayer::getWorldName).distinct().collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteById(Integer integer) {
/*     */     Xxxxxx(Collections.singletonList(integer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<WarpPlayer> findByName(String str) {
/*     */     Db db;
/*     */     (db = Db.use(WarpPlayer.class)).where().eq(WarpPlayer::getName, str);
/*     */     return db.execution().list();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> listServerName() {
/*     */     List list;
/* 772 */     if (CollUtil.isEmpty(list = Db.use(WarpPlayer.class).execution().list()))
/*     */       return new ArrayList<>(); 
/*     */     return (List<String>)list.stream().map(WarpPlayer::getServerName).distinct().collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   public void updateTop(Integer integer1, Integer integer2, Date date) {
/*     */     Db db;
/*     */     db.execution().updateById(integer1);
/*     */   }
/*     */   
/*     */   public Optional<WarpPlayer> findById(Integer integer) {
/*     */     return Db.use(WarpPlayer.class).execution().selectById(integer);
/*     */   }
/*     */   
/*     */   public List<WarpPlayer> findAll() {
/*     */     return Db.use(WarpPlayer.class).execution().list();
/*     */   }
/*     */   
/*     */   public void updatePlayerName(Player player) {
/*     */     Db db;
/*     */     (db = Db.use(WarpPlayer.class)).update().set(WarpPlayer::getPlayerName, player.getName());
/*     */     db.execution().update();
/*     */   }
/*     */   
/*     */   public List<String> listWarpName() {
/*     */     List list = db.execution().list();
/*     */     Db db;
/*     */     (db = Db.use(WarpPlayer.class)).where().ge(WarpPlayer::getExpirationTime, new Date()).le(WarpPlayer::getId, Integer.valueOf(100));
/*     */     if (CollUtil.isEmpty(list))
/*     */       return new ArrayList<>(); 
/*     */     return (List<String>)list.stream().map(WarpPlayer::getName).distinct().collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   public List<String> listWarpId() {
/*     */     List list = db.execution().list();
/*     */     Db db;
/*     */     (db = Db.use(WarpPlayer.class)).where().ge(WarpPlayer::getExpirationTime, new Date()).le(WarpPlayer::getId, Integer.valueOf(100));
/*     */     if (CollUtil.isEmpty(list))
/*     */       return new ArrayList<>(); 
/*     */     return (List<String>)list.stream().map(a -> a.getId().toString()).distinct().collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   public void delete(String str1, String str2) {
/*     */     List<Integer> list = db.execution().list();
/*     */     Db db;
/*     */     (db = Db.use(WarpPlayer.class)).where().eq(StrUtil.isNotEmpty(str1), WarpPlayer::getServerName, str1).eq(StrUtil.isNotEmpty(str2), WarpPlayer::getWorldName, str2).le(WarpPlayer::getId, Integer.valueOf(100));
/*     */     if (CollUtil.isEmpty(list))
/*     */       return; 
/*     */     list = (List)list.stream().map(WarpPlayer::getId).collect(Collectors.toList());
/*     */     Xxxxxx(list);
/*     */   }
/*     */   
/*     */   public List<WarpPlayer> findNotExpirationByName(String str) {
/*     */     Db db;
/*     */     (db = Db.use(WarpPlayer.class)).where().eq(WarpPlayer::getName, str).le(WarpPlayer::getId, Integer.valueOf(100)).ge(WarpPlayer::getExpirationTime, new Date());
/*     */     return db.execution().list();
/*     */   }
/*     */   
/*     */   public Map<Integer, WarpPlayer> findByTopIndexList(List list) {
/*     */     if (CollUtil.isEmpty(list))
/*     */       return MapUtil.of(); 
/*     */     list = db.execution().list();
/*     */     Db db;
/*     */     (db = Db.use(WarpPlayer.class)).where().in(WarpPlayer::getTopIndex, list).ge(WarpPlayer::getTopTime, new Date()).le(WarpPlayer::getId, Integer.valueOf(100)).ge(WarpPlayer::getExpirationTime, new Date()).orderByDesc(WarpPlayer::getId);
/*     */     if (CollUtil.isEmpty(list))
/*     */       return MapUtil.of(); 
/*     */     return (Map<Integer, WarpPlayer>)list.stream().collect(Collectors.toMap(WarpPlayer::getTopIndex, a -> a, (a, warpPlayer1) -> warpPlayer1));
/*     */   }
/*     */   
/*     */   public void updateExpirationTime() {
/*     */     Db db;
/*     */     (db = Db.use(WarpPlayer.class)).update().set(WarpPlayer::getExpirationTime, DateUtil.getDate(Integer.valueOf(36500)));
/*     */     db.execution().update();
/*     */   }
/*     */   
/*     */   public void updateExpirationTime(Date date) {
/*     */     Db db;
/*     */     (db = Db.use(WarpPlayer.class)).update().set(WarpPlayer::getExpirationTime, date);
/*     */     db.execution().update();
/*     */   }
/*     */   
/*     */   private static class WarpPlayerService {}
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\service\WarpPlayerService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */