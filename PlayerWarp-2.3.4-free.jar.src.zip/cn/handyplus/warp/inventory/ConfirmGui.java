/*     */ package cn.handyplus.warp.inventory;
/*     */ import cn.handyplus.warp.constants.GuiTypeEnum;
/*     */ import cn.handyplus.warp.hook.PlaceholderApiUtil;
/*     */ import cn.handyplus.warp.lib.HandyInventory;
/*     */ import cn.handyplus.warp.lib.HandyInventoryUtil;
/*     */ import cn.handyplus.warp.lib.MapUtil;
/*     */ import cn.handyplus.warp.lib.StrUtil;
/*     */ import cn.handyplus.warp.param.OpenParam;
/*     */ import cn.handyplus.warp.util.ConfigUtil;
/*     */ import cn.handyplus.warp.util.WarpPermissionUtil;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ 
/*     */ public class ConfirmGui {
/*     */   public Inventory createGui(Player player, Integer integer, String str, OpenParam openParam) {
/*  16 */     String str1 = ConfigUtil.CONFIRM_CONFIG.getString(StrUtil.qzlKeO("/\\/Y>"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 170 */     String str2 = ConfigUtil.CONFIRM_CONFIG.getString(WarpPermissionUtil.qzlKeO("PFVGG"));
/*     */     int i = ConfigUtil.CONFIRM_CONFIG.getInt(StrUtil.qzlKeO("F2O>"), 27);
/*     */     str1 = PlaceholderApiUtil.set(player, str1);
/*     */     HandyInventory handyInventory = new HandyInventory(GuiTypeEnum.CONFIRM.getType(), str1, i, str2);
/*     */     handyInventory.setId(integer);
/*     */     handyInventory.setPlayer(player);
/*     */     handyInventory.setSearchType(str);
/*     */     handyInventory.setObj(openParam);
/*     */     l(handyInventory);
/*     */     return handyInventory.getInventory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final ConfirmGui OoOOoO = new ConfirmGui();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ConfirmGui getInstance() {
/* 202 */     return OoOOoO;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\inventory\ConfirmGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */