/*     */ package cn.handyplus.warp.inventory;
/*     */ 
/*     */ import cn.handyplus.warp.constants.GuiTypeEnum;
/*     */ import cn.handyplus.warp.constants.WarpTypeEnum;
/*     */ import cn.handyplus.warp.enter.WarpPlayer;
/*     */ import cn.handyplus.warp.hook.PlaceholderApiUtil;
/*     */ import cn.handyplus.warp.lib.BcUtil;
/*     */ import cn.handyplus.warp.lib.HandyInventory;
/*     */ import cn.handyplus.warp.lib.HandyInventoryUtil;
/*     */ import cn.handyplus.warp.lib.InventoryCheckParam;
/*     */ import cn.handyplus.warp.lib.MapUtil;
/*     */ import cn.handyplus.warp.param.OpenParam;
/*     */ import cn.handyplus.warp.util.ConfigUtil;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MeGui
/*     */ {
/*     */   public static MeGui getInstance() {
/*  30 */     return pppPPp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   private static final MeGui pppPPp = new MeGui();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Inventory createGui(Player player, OpenParam openParam) {
/*  94 */     String str1 = ConfigUtil.ME_CONFIG.getString(InventoryCheckParam.qzlKeO("v\"v'g"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 178 */     str1 = PlaceholderApiUtil.set(player, str1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int i = ConfigUtil.ME_CONFIG.getInt(BcUtil.qzlKeO("\013\"\002."), 54);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String str2 = ConfigUtil.ME_CONFIG.getString(InventoryCheckParam.qzlKeO("q$w%f"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 224 */     HandyInventory handyInventory = new HandyInventory(GuiTypeEnum.ME.getType(), str1, i, str2);
/*     */     handyInventory.setPlayer(player);
/*     */     handyInventory.setObj(openParam);
/*     */     handyInventory.setSearchType(WarpTypeEnum.ALL.getType());
/*     */     setInventoryDate(handyInventory);
/*     */     return handyInventory.getInventory();
/*     */   }
/*     */   
/*     */   public void setInventoryDate(HandyInventory handyInventory) {
/*     */     handyInventory.setGuiType(GuiTypeEnum.ME.getType());
/*     */     HandyInventoryUtil.refreshInventory(handyInventory.getInventory());
/*     */     XXxxxx(handyInventory);
/*     */     l(handyInventory);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\inventory\MeGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */