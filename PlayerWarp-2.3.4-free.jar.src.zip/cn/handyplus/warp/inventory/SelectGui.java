/*     */ package cn.handyplus.warp.inventory;
/*     */ import cn.handyplus.warp.constants.GuiTypeEnum;
/*     */ import cn.handyplus.warp.constants.WarpTypeEnum;
/*     */ import cn.handyplus.warp.enter.WarpPlayer;
/*     */ import cn.handyplus.warp.hook.PlaceholderApiUtil;
/*     */ import cn.handyplus.warp.lib.CollUtil;
/*     */ import cn.handyplus.warp.lib.HandyInventory;
/*     */ import cn.handyplus.warp.lib.HandyInventoryUtil;
/*     */ import cn.handyplus.warp.lib.MapUtil;
/*     */ import cn.handyplus.warp.lib.Page;
/*     */ import cn.handyplus.warp.lib.RgbTextUtil;
/*     */ import cn.handyplus.warp.lib.StrUtil;
/*     */ import cn.handyplus.warp.param.OpenParam;
/*     */ import cn.handyplus.warp.service.WarpLikePlayerService;
/*     */ import cn.handyplus.warp.service.WarpPlayerService;
/*     */ import cn.handyplus.warp.util.ConfigUtil;
/*     */ import cn.handyplus.warp.util.WarpPermissionUtil;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public class SelectGui {
/*     */   public static SelectGui getInstance() {
/*  31 */     return IiiiiI;
/*     */   }
/*     */   public void setInventoryDate(HandyInventory handyInventory) {
/*  34 */     handyInventory.setGuiType(GuiTypeEnum.SELECT.getType());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     HandyInventoryUtil.refreshInventory(handyInventory.getInventory());
/*     */     l(handyInventory);
/*     */     xXxxXx(handyInventory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Inventory createGui(Player player, OpenParam openParam, Integer integer) {
/*     */     String str1 = ConfigUtil.SELECT_CONFIG.getString(WarpPermissionUtil.qzlKeO("W@WEF"));
/*     */     str1 = PlaceholderApiUtil.set(player, str1);
/* 224 */     int i = ConfigUtil.SELECT_CONFIG.getInt(RgbTextUtil.qzlKeO("2U;Y"), 54);
/*     */     String str2 = ConfigUtil.SELECT_CONFIG.getString(WarpPermissionUtil.qzlKeO("PFVGG"));
/*     */     HandyInventory handyInventory = new HandyInventory(GuiTypeEnum.SELECT.getType(), str1, i, str2);
/*     */     handyInventory.setPlayer(player);
/*     */     handyInventory.setObj(openParam);
/*     */     handyInventory.setId(integer);
/*     */     handyInventory.setSearchType(WarpTypeEnum.ALL.getType());
/*     */     setInventoryDate(handyInventory);
/*     */     return handyInventory.getInventory();
/*     */   }
/*     */   
/*     */   private static final SelectGui IiiiiI = new SelectGui();
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\inventory\SelectGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */