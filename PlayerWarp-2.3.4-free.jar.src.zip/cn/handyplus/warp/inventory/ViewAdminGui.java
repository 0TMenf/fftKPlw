/*     */ package cn.handyplus.warp.inventory;
/*     */ import cn.handyplus.warp.lib.HandyInventory;
/*     */ import cn.handyplus.warp.lib.HandyInventoryUtil;
/*     */ import cn.handyplus.warp.service.WarpLikePlayerService;
/*     */ import cn.handyplus.warp.util.ConfigUtil;
/*     */ 
/*     */ public class ViewAdminGui {
/*     */   public static ViewAdminGui getInstance() {
/*   9 */     return pPPPPp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Inventory createGui(Player player, Integer integer) {
/*  30 */     String str1 = ConfigUtil.VIEW_ADMIN_CONFIG.getString(WarpChannelService.qzlKeO("]g]bL"), "");
/*  31 */     str1 = PlaceholderApiUtil.set(player, str1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  54 */     int i = ConfigUtil.VIEW_ADMIN_CONFIG.getInt(WarpLikePlayerService.qzlKeO("\021\006\030\n"), 54);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     String str2 = ConfigUtil.VIEW_ADMIN_CONFIG.getString(WarpChannelService.qzlKeO("Za\\`M"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     HandyInventory handyInventory = new HandyInventory(GuiTypeEnum.VIEW_ADMIN.getType(), str1, i, str2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     handyInventory.setPlayer(player); handyInventory.setId(integer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     setInventoryDate(handyInventory);
/*     */     return handyInventory.getInventory();
/*     */   }
/*     */   
/*     */   private static final ViewAdminGui pPPPPp = new ViewAdminGui();
/*     */   
/*     */   public void setInventoryDate(HandyInventory handyInventory) {
/*     */     handyInventory.setGuiType(GuiTypeEnum.VIEW_ADMIN.getType());
/*     */     HandyInventoryUtil.refreshInventory(handyInventory.getInventory());
/*     */     xXxxXx(handyInventory);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\inventory\ViewAdminGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */