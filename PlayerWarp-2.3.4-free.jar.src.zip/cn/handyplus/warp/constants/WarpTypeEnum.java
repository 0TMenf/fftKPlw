/*     */ package cn.handyplus.warp.constants;
/*     */ 
/*     */ import cn.handyplus.warp.lib.BaseUtil;
/*     */ import cn.handyplus.warp.lib.InventoryViewUtil;
/*     */ import cn.handyplus.warp.lib.SecureUtil;
/*     */ import java.util.List;
/*     */ import lombok.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum WarpTypeEnum
/*     */ {
/*     */   SHOP,
/*     */   ARCHITECT,
/* 165 */   ALL(SecureUtil.qzlKeO("GUJ"), InventoryViewUtil.qzlKeO("k\tn\030H\021l\r2\tp\004"), 1), BRUSH_MONSTER(SecureUtil.qzlKeO("GUJ"), InventoryViewUtil.qzlKeO("k\tn\030H\021l\r2\tp\004"), 1), RED_STONE(SecureUtil.qzlKeO("GUJ"), InventoryViewUtil.qzlKeO("k\tn\030H\021l\r2\tp\004"), 1), OTHER(SecureUtil.qzlKeO("GUJ"), InventoryViewUtil.qzlKeO("k\tn\030H\021l\r2\tp\004"), 1); private final int K;
/*     */   private final String j;
/*     */   
/*     */   public static String getDesc(WarpTypeEnum a) {
/*     */     return BaseUtil.getLangMsg(a.getDesc());
/*     */   }
/*     */   
/*     */   @Generated
/*     */   public int getId() {
/*     */     return this.K;
/*     */   }
/*     */   
/*     */   public static WarpTypeEnum getEnum(String a) {
/*     */     // Byte code:
/*     */     //   0: invokestatic values : ()[Lcn/handyplus/warp/constants/WarpTypeEnum;
/*     */     //   3: dup
/*     */     //   4: astore_1
/*     */     //   5: arraylength
/*     */     //   6: istore_2
/*     */     //   7: iconst_0
/*     */     //   8: dup
/*     */     //   9: istore_3
/*     */     //   10: iload_2
/*     */     //   11: if_icmpge -> 42
/*     */     //   14: aload_1
/*     */     //   15: iload_3
/*     */     //   16: aaload
/*     */     //   17: dup
/*     */     //   18: astore #4
/*     */     //   20: invokevirtual getType : ()Ljava/lang/String;
/*     */     //   23: aload_0
/*     */     //   24: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
/*     */     //   27: ifeq -> 34
/*     */     //   30: aload #4
/*     */     //   32: areturn
/*     */     //   33: athrow
/*     */     //   34: iinc #3, 1
/*     */     //   37: iload_3
/*     */     //   38: goto -> 10
/*     */     //   41: athrow
/*     */     //   42: getstatic cn/handyplus/warp/constants/WarpTypeEnum.ALL : Lcn/handyplus/warp/constants/WarpTypeEnum;
/*     */     //   45: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #16	-> 0
/*     */     //   #170	-> 20
/*     */     //   #26	-> 30
/*     */     //   #16	-> 34
/*     */     //   #124	-> 42
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	46	0	a	Ljava/lang/String;
/*     */   }
/*     */   
/*     */   @Generated
/*     */   public String getDesc() {
/* 183 */     return this.OOOoOo;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public String getType() {
/*     */     return this.j;
/*     */   }
/*     */ 
/*     */   
/*     */   @Generated
/*     */   WarpTypeEnum(String str1, String str2, int i) {
/*     */     this.j = str1;
/*     */     this.OOOoOo = str2;
/*     */     this.K = i;
/*     */   }
/*     */ 
/*     */   
/*     */   public static WarpTypeEnum getNotAllNextEnum(String a) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokestatic getEnum : (Ljava/lang/String;)Lcn/handyplus/warp/constants/WarpTypeEnum;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: ifnonnull -> 14
/*     */     //   9: getstatic cn/handyplus/warp/constants/WarpTypeEnum.ARCHITECT : Lcn/handyplus/warp/constants/WarpTypeEnum;
/*     */     //   12: areturn
/*     */     //   13: athrow
/*     */     //   14: aload_1
/*     */     //   15: invokevirtual getId : ()I
/*     */     //   18: iconst_1
/*     */     //   19: iadd
/*     */     //   20: dup
/*     */     //   21: istore_1
/*     */     //   22: bipush #6
/*     */     //   24: if_icmple -> 29
/*     */     //   27: iconst_2
/*     */     //   28: istore_1
/*     */     //   29: invokestatic values : ()[Lcn/handyplus/warp/constants/WarpTypeEnum;
/*     */     //   32: dup
/*     */     //   33: astore_2
/*     */     //   34: arraylength
/*     */     //   35: istore_3
/*     */     //   36: iconst_0
/*     */     //   37: dup
/*     */     //   38: istore #4
/*     */     //   40: iload_3
/*     */     //   41: if_icmpge -> 70
/*     */     //   44: aload_2
/*     */     //   45: iload #4
/*     */     //   47: aaload
/*     */     //   48: dup
/*     */     //   49: astore #5
/*     */     //   51: invokevirtual getId : ()I
/*     */     //   54: iload_1
/*     */     //   55: if_icmpne -> 62
/*     */     //   58: aload #5
/*     */     //   60: areturn
/*     */     //   61: athrow
/*     */     //   62: iinc #4, 1
/*     */     //   65: iload #4
/*     */     //   67: goto -> 40
/*     */     //   70: getstatic cn/handyplus/warp/constants/WarpTypeEnum.ARCHITECT : Lcn/handyplus/warp/constants/WarpTypeEnum;
/*     */     //   73: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #78	-> 0
/*     */     //   #203	-> 6
/*     */     //   #222	-> 9
/*     */     //   #149	-> 14
/*     */     //   #194	-> 22
/*     */     //   #176	-> 27
/*     */     //   #5	-> 29
/*     */     //   #11	-> 51
/*     */     //   #217	-> 58
/*     */     //   #5	-> 62
/*     */     //   #70	-> 70
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	74	0	a	Ljava/lang/String;
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<String> getNotAllList() {
/*     */     // Byte code:
/*     */     //   0: new java/util/ArrayList
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: astore_0
/*     */     //   8: invokestatic values : ()[Lcn/handyplus/warp/constants/WarpTypeEnum;
/*     */     //   11: dup
/*     */     //   12: astore_1
/*     */     //   13: arraylength
/*     */     //   14: istore_2
/*     */     //   15: iconst_0
/*     */     //   16: dup
/*     */     //   17: istore_3
/*     */     //   18: iload_2
/*     */     //   19: if_icmpge -> 67
/*     */     //   22: aload_1
/*     */     //   23: iload_3
/*     */     //   24: aaload
/*     */     //   25: dup
/*     */     //   26: astore #4
/*     */     //   28: invokevirtual getType : ()Ljava/lang/String;
/*     */     //   31: getstatic cn/handyplus/warp/constants/WarpTypeEnum.ALL : Lcn/handyplus/warp/constants/WarpTypeEnum;
/*     */     //   34: invokevirtual getType : ()Ljava/lang/String;
/*     */     //   37: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   40: ifeq -> 47
/*     */     //   43: goto -> 59
/*     */     //   46: athrow
/*     */     //   47: aload_0
/*     */     //   48: aload #4
/*     */     //   50: invokevirtual getType : ()Ljava/lang/String;
/*     */     //   53: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   58: pop
/*     */     //   59: iinc #3, 1
/*     */     //   62: iload_3
/*     */     //   63: goto -> 18
/*     */     //   66: athrow
/*     */     //   67: aload_0
/*     */     //   68: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #121	-> 0
/*     */     //   #225	-> 8
/*     */     //   #191	-> 28
/*     */     //   #166	-> 43
/*     */     //   #47	-> 47
/*     */     //   #225	-> 59
/*     */     //   #34	-> 67
/*     */   }
/*     */ 
/*     */   
/*     */   private final String OOOoOo;
/*     */ 
/*     */   
/*     */   public static WarpTypeEnum getNextEnum(String a) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokestatic getEnum : (Ljava/lang/String;)Lcn/handyplus/warp/constants/WarpTypeEnum;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: ifnonnull -> 14
/*     */     //   9: getstatic cn/handyplus/warp/constants/WarpTypeEnum.ALL : Lcn/handyplus/warp/constants/WarpTypeEnum;
/*     */     //   12: areturn
/*     */     //   13: athrow
/*     */     //   14: aload_1
/*     */     //   15: invokevirtual getId : ()I
/*     */     //   18: iconst_1
/*     */     //   19: iadd
/*     */     //   20: dup
/*     */     //   21: istore_1
/*     */     //   22: bipush #6
/*     */     //   24: if_icmple -> 29
/*     */     //   27: iconst_1
/*     */     //   28: istore_1
/*     */     //   29: invokestatic values : ()[Lcn/handyplus/warp/constants/WarpTypeEnum;
/*     */     //   32: dup
/*     */     //   33: astore_2
/*     */     //   34: arraylength
/*     */     //   35: istore_3
/*     */     //   36: iconst_0
/*     */     //   37: dup
/*     */     //   38: istore #4
/*     */     //   40: iload_3
/*     */     //   41: if_icmpge -> 70
/*     */     //   44: aload_2
/*     */     //   45: iload #4
/*     */     //   47: aaload
/*     */     //   48: dup
/*     */     //   49: astore #5
/*     */     //   51: invokevirtual getId : ()I
/*     */     //   54: iload_1
/*     */     //   55: if_icmpne -> 62
/*     */     //   58: aload #5
/*     */     //   60: areturn
/*     */     //   61: athrow
/*     */     //   62: iinc #4, 1
/*     */     //   65: iload #4
/*     */     //   67: goto -> 40
/*     */     //   70: getstatic cn/handyplus/warp/constants/WarpTypeEnum.ALL : Lcn/handyplus/warp/constants/WarpTypeEnum;
/*     */     //   73: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #174	-> 0
/*     */     //   #81	-> 6
/*     */     //   #161	-> 9
/*     */     //   #159	-> 14
/*     */     //   #138	-> 22
/*     */     //   #131	-> 27
/*     */     //   #198	-> 29
/*     */     //   #214	-> 51
/*     */     //   #50	-> 58
/*     */     //   #198	-> 62
/*     */     //   #184	-> 70
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	74	0	a	Ljava/lang/String;
/*     */   }
/*     */ 
/*     */   
/*     */   static {
/* 221 */     ARCHITECT = new WarpTypeEnum(SecureUtil.qzlKeO("gkeqomczr"), 1, InventoryViewUtil.qzlKeO("\tn\013t\001h\r\034"), SecureUtil.qzlKeO("NGKVm_IC\027GKEQOMCZR"), 2);
/*     */     SHOP = new WarpTypeEnum(InventoryViewUtil.qzlKeO("O S8"), 2, SecureUtil.qzlKeO("JNVV"), InventoryViewUtil.qzlKeO("\037}\032l<e\030yFo\000s\030"), 3);
/*     */     RED_STONE = new WarpTypeEnum(SecureUtil.qzlKeO("t|bfumiwc"), 3, InventoryViewUtil.qzlKeO("\032y\fC\033h\007r\r"), SecureUtil.qzlKeO("NGKVm_IC\027T\\BfUMIWC"), 4);
/*     */     BRUSH_MONSTER = new WarpTypeEnum(InventoryViewUtil.qzlKeO("*N=O C%S&O<Y:"), 4, SecureUtil.qzlKeO("DKSJNfKVHJR\\T"), InventoryViewUtil.qzlKeO("k\tn\030H\021l\r2\nn\035o\000C\005s\006o\034y\032"), 5);
/*     */     OTHER = new WarpTypeEnum(SecureUtil.qzlKeO("imn|t"), 5, InventoryViewUtil.qzlKeO("\007h\000y\032"), SecureUtil.qzlKeO("NGKVm_IC\027IMN\\T"), 6);
/*     */     L = PpppPP();
/*     */   } public static String getDesc(String a) {
/* 228 */     return getDesc(getEnum(a));
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\constants\WarpTypeEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */