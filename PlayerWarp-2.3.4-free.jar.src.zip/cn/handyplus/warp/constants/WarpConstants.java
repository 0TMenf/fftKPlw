/*     */ package cn.handyplus.warp.constants;
/*     */ 
/*     */ import cn.handyplus.warp.lib.Pair;
/*     */ import cn.handyplus.warp.param.CreateFlagParam;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WarpConstants
/*     */ {
/*     */   public static final String POINT = "point";
/*     */   public static final String VAULT = "vault";
/*     */   public static final String PLY = "ply";
/*     */   public static final String SET_LOGO = "plw setLogo ";
/*     */   public static final String DEL = "delConfirm";
/*     */   public static final String TP = "tpConfirm";
/*     */   public static final Map<UUID, Boolean> DELAY_TIME;
/*     */   public static final Map<UUID, CreateFlagParam> CREATE_FLAG;
/*     */   public static final Map<UUID, Pair<String, Integer>> VIEW_ADMIN_CHAT_CACHE_MAP;
/*     */   
/*     */   static {
/*  41 */     VIEW_ADMIN_CHAT_CACHE_MAP = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 183 */     WAIT_TIME = new HashMap<>();
/*     */     DELAY_TIME = new HashMap<>();
/*     */     CREATE_FLAG = new HashMap<>();
/*     */   }
/*     */   
/*     */   public static final Map<UUID, Pair<String, Integer>> CHAT_CACHE_MAP = new HashMap<>();
/*     */   public static final Map<UUID, Long> WAIT_TIME;
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\constants\WarpConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */