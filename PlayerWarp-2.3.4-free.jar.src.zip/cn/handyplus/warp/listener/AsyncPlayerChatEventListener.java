/*     */ package cn.handyplus.warp.listener;
/*     */ 
/*     */ import cn.handyplus.warp.constants.WarpConstants;
/*     */ import cn.handyplus.warp.lib.HandyListener;
/*     */ import cn.handyplus.warp.lib.InventoryViewUtil;
/*     */ import cn.handyplus.warp.lib.MessageUtil;
/*     */ import cn.handyplus.warp.lib.Pair;
/*     */ import cn.handyplus.warp.util.ConfigUtil;
/*     */ import cn.handyplus.warp.util.WarpUtil;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.AsyncPlayerChatEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @HandyListener
/*     */ public class AsyncPlayerChatEventListener
/*     */   implements Listener
/*     */ {
/*     */   @EventHandler(priority = EventPriority.LOWEST)
/*     */   public void onEvent(AsyncPlayerChatEvent asyncPlayerChatEvent) {
/* 183 */     Player player = asyncPlayerChatEvent.getPlayer();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Pair<String, Integer> pair1 = (Pair)WarpConstants.CHAT_CACHE_MAP.get(player.getUniqueId());
/*     */ 
/*     */ 
/*     */     
/*     */     Pair<String, Integer> pair2 = (Pair)WarpConstants.VIEW_ADMIN_CHAT_CACHE_MAP.get(player.getUniqueId());
/*     */ 
/*     */ 
/*     */     
/* 196 */     if (pair1 == null && pair2 == null)
/*     */       return; 
/*     */     asyncPlayerChatEvent.setCancelled(true);
/*     */     String str = asyncPlayerChatEvent.getMessage();
/*     */     if (MessageUtil.qzlKeO("S").equalsIgnoreCase(str)) {
/*     */       MessageUtil.sendMessage(player, ConfigUtil.CREATE_CONFIG.getString(InventoryViewUtil.qzlKeO("\013}\006\rp%o\000")));
/*     */       WarpConstants.VIEW_ADMIN_CHAT_CACHE_MAP.remove(player.getUniqueId());
/*     */       return;
/*     */     } 
/*     */     if (pair2 != null) {
/*     */       fKIZKg(player, str, pair2);
/*     */       WarpConstants.VIEW_ADMIN_CHAT_CACHE_MAP.remove(player.getUniqueId());
/*     */     } 
/*     */     if (xxxXXX(player, str, pair1))
/*     */       WarpConstants.CHAT_CACHE_MAP.remove(player.getUniqueId()); 
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\listener\AsyncPlayerChatEventListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */