/*     */ package cn.handyplus.warp.listener.gui;
/*     */ 
/*     */ import cn.handyplus.warp.constants.GuiTypeEnum;
/*     */ import cn.handyplus.warp.constants.WarpTypeEnum;
/*     */ import cn.handyplus.warp.inventory.AdminGui;
/*     */ import cn.handyplus.warp.inventory.MeGui;
/*     */ import cn.handyplus.warp.inventory.OpenGui;
/*     */ import cn.handyplus.warp.lib.HandyInventory;
/*     */ import cn.handyplus.warp.lib.HandyInventoryUtil;
/*     */ import cn.handyplus.warp.lib.IHandyClickEvent;
/*     */ import cn.handyplus.warp.lib.InventoryViewUtil;
/*     */ import cn.handyplus.warp.lib.PlayerSchedulerUtil;
/*     */ import cn.handyplus.warp.lib.StrUtil;
/*     */ import cn.handyplus.warp.param.OpenParam;
/*     */ import cn.handyplus.warp.service.WarpPlayerService;
/*     */ import cn.handyplus.warp.util.ConfigUtil;
/*     */ import cn.handyplus.warp.util.WarpPermissionUtil;
/*     */ import java.util.Map;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ 
/*     */ public class MeClickEvent
/*     */   implements IHandyClickEvent
/*     */ {
/*     */   public void rawSlotClick(HandyInventory handyInventory, InventoryClickEvent inventoryClickEvent) {
/*  26 */     int i = inventoryClickEvent.getRawSlot();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  43 */     Integer integer2 = handyInventory.getPageNum();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     Player player = handyInventory.getPlayer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 124 */     Integer integer3 = handyInventory.getPageCount();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Map map1 = handyInventory.getIntMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     OpenParam openParam = (OpenParam)handyInventory.getObj();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.ME_CONFIG, "previousPage")) {
/*     */       if (integer2.intValue() > 1) {
/*     */         handyInventory.setPageNum(Integer.valueOf(handyInventory.getPageNum().intValue() - 1));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         MeGui.getInstance().setInventoryDate(handyInventory);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.ME_CONFIG, "nextPage")) {
/*     */       if (integer2.intValue() + 1 <= integer3.intValue()) {
/* 178 */         handyInventory.setPageNum(Integer.valueOf(handyInventory.getPageNum().intValue() + 1));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         MeGui.getInstance().setInventoryDate(handyInventory);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.ME_CONFIG, WarpPermissionUtil.qzlKeO("KBJH"))) {
/* 201 */       handyInventory.syncOpen(OpenGui.getInstance().createGui(player, openParam)); return;
/*     */     }  if (HandyInventoryUtil.isIndex(i, ConfigUtil.ME_CONFIG, InventoryViewUtil.qzlKeO("o\r}\032\000"))) {
/*     */       WarpTypeEnum warpTypeEnum; handyInventory.setSearchType((warpTypeEnum = WarpTypeEnum.getNextEnum(handyInventory.getSearchType())).getType()); MeGui.getInstance().setInventoryDate(handyInventory); return;
/*     */     } 
/*     */     String str;
/*     */     Map<?, String> map;
/*     */     if (StrUtil.isNotEmpty(str = (map = HandyInventoryUtil.getCustomButton(ConfigUtil.ME_CONFIG, WarpPermissionUtil.qzlKeO("JVZWFN"))).get(Integer.valueOf(i)))) {
/* 208 */       PlayerSchedulerUtil.syncPerformReplaceCommand(player, str);
/*     */       return;
/*     */     } 
/*     */     Integer integer1;
/*     */     if ((integer1 = (Integer)map1.get(Integer.valueOf(i))) != null) {
/*     */       if (!WarpPlayerService.getInstance().findById(integer1).isPresent())
/*     */         return; 
/*     */       handyInventory.syncOpen(AdminGui.getInstance().createGui(player, integer1, openParam));
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isAsync() {
/*     */     return true;
/*     */   }
/*     */   
/*     */   public String guiType() {
/*     */     return GuiTypeEnum.ME.getType();
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\listener\gui\MeClickEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */