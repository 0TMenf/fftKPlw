/*     */ package cn.handyplus.warp.listener.gui;
/*     */ 
/*     */ import cn.handyplus.warp.constants.GuiTypeEnum;
/*     */ import cn.handyplus.warp.lib.HandyInventory;
/*     */ import cn.handyplus.warp.lib.IHandyClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CreateClickEvent
/*     */   implements IHandyClickEvent
/*     */ {
/*     */   public boolean isAsync() {
/*  18 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rawSlotClick(HandyInventory handyInventory, InventoryClickEvent inventoryClickEvent) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: aload_2
/*     */     //   2: invokevirtual getRawSlot : ()I
/*     */     //   5: istore_2
/*     */     //   6: aload_1
/*     */     //   7: invokevirtual getPlayer : ()Lorg/bukkit/entity/Player;
/*     */     //   10: astore_3
/*     */     //   11: invokevirtual getObj : ()Ljava/lang/Object;
/*     */     //   14: checkcast cn/handyplus/warp/param/OpenParam
/*     */     //   17: astore #4
/*     */     //   19: iload_2
/*     */     //   20: getstatic cn/handyplus/warp/util/ConfigUtil.CREATE_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   23: ldc '!A K'
/*     */     //   25: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   28: invokestatic isIndex : (ILorg/bukkit/configuration/file/FileConfiguration;Ljava/lang/String;)Z
/*     */     //   31: ifeq -> 49
/*     */     //   34: aload_1
/*     */     //   35: invokestatic getInstance : ()Lcn/handyplus/warp/inventory/OpenGui;
/*     */     //   38: aload_3
/*     */     //   39: aload #4
/*     */     //   41: invokevirtual createGui : (Lorg/bukkit/entity/Player;Lcn/handyplus/warp/param/OpenParam;)Lorg/bukkit/inventory/Inventory;
/*     */     //   44: invokevirtual syncOpen : (Lorg/bukkit/inventory/Inventory;)V
/*     */     //   47: return
/*     */     //   48: athrow
/*     */     //   49: getstatic cn/handyplus/warp/util/ConfigUtil.CREATE_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   52: ldc '3 #!?8'
/*     */     //   54: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   57: invokestatic getCustomButton : (Lorg/bukkit/configuration/file/FileConfiguration;Ljava/lang/String;)Ljava/util/Map;
/*     */     //   60: iload_2
/*     */     //   61: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   64: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   69: checkcast java/lang/String
/*     */     //   72: dup
/*     */     //   73: astore #4
/*     */     //   75: invokestatic isNotEmpty : (Ljava/lang/CharSequence;)Z
/*     */     //   78: ifeq -> 89
/*     */     //   81: aload_3
/*     */     //   82: aload #4
/*     */     //   84: invokestatic syncPerformReplaceCommand : (Lorg/bukkit/entity/Player;Ljava/lang/String;)V
/*     */     //   87: return
/*     */     //   88: athrow
/*     */     //   89: iconst_0
/*     */     //   90: istore #4
/*     */     //   92: iload_2
/*     */     //   93: getstatic cn/handyplus/warp/util/ConfigUtil.CREATE_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   96: ldc 'point'
/*     */     //   98: invokestatic isIndex : (ILorg/bukkit/configuration/file/FileConfiguration;Ljava/lang/String;)Z
/*     */     //   101: ifeq -> 133
/*     */     //   104: aload_3
/*     */     //   105: invokestatic checkWarpNumber : (Lorg/bukkit/entity/Player;)Z
/*     */     //   108: ifeq -> 112
/*     */     //   111: return
/*     */     //   112: getstatic cn/handyplus/warp/util/ConfigUtil.CREATE_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   115: ldc 'P,I-TmP1I E'
/*     */     //   117: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   120: invokevirtual getInt : (Ljava/lang/String;)I
/*     */     //   123: istore #5
/*     */     //   125: aload_3
/*     */     //   126: iload #5
/*     */     //   128: invokestatic take : (Lorg/bukkit/entity/Player;I)Z
/*     */     //   131: istore #4
/*     */     //   133: iload_2
/*     */     //   134: getstatic cn/handyplus/warp/util/ConfigUtil.CREATE_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   137: ldc 'vault'
/*     */     //   139: invokestatic isIndex : (ILorg/bukkit/configuration/file/FileConfiguration;Ljava/lang/String;)Z
/*     */     //   142: ifeq -> 174
/*     */     //   145: aload_3
/*     */     //   146: invokestatic checkWarpNumber : (Lorg/bukkit/entity/Player;)Z
/*     */     //   149: ifeq -> 153
/*     */     //   152: return
/*     */     //   153: getstatic cn/handyplus/warp/util/ConfigUtil.CREATE_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   156: ldc '#1 <!~%"<30'
/*     */     //   158: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   161: invokevirtual getInt : (Ljava/lang/String;)I
/*     */     //   164: istore #5
/*     */     //   166: aload_3
/*     */     //   167: iload #5
/*     */     //   169: invokestatic take : (Lorg/bukkit/entity/Player;I)Z
/*     */     //   172: istore #4
/*     */     //   174: iload_2
/*     */     //   175: getstatic cn/handyplus/warp/util/ConfigUtil.CREATE_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   178: ldc 'ply'
/*     */     //   180: invokestatic isIndex : (ILorg/bukkit/configuration/file/FileConfiguration;Ljava/lang/String;)Z
/*     */     //   183: ifeq -> 244
/*     */     //   186: aload_3
/*     */     //   187: invokestatic checkWarpNumber : (Lorg/bukkit/entity/Player;)Z
/*     */     //   190: ifeq -> 194
/*     */     //   193: return
/*     */     //   194: getstatic cn/handyplus/warp/util/ConfigUtil.CREATE_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   197: ldc '3L:7Y3E'
/*     */     //   199: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   202: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   205: astore #5
/*     */     //   207: getstatic cn/handyplus/warp/util/ConfigUtil.CREATE_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   210: ldc '%<,~%"<30'
/*     */     //   212: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   215: invokevirtual getInt : (Ljava/lang/String;)I
/*     */     //   218: istore_2
/*     */     //   219: getstatic cn/handyplus/warp/util/ConfigUtil.CREATE_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   222: ldc 'T*T/E'
/*     */     //   224: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   227: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   230: astore #6
/*     */     //   232: aload_3
/*     */     //   233: aload #5
/*     */     //   235: iload_2
/*     */     //   236: i2l
/*     */     //   237: aload #6
/*     */     //   239: invokestatic take : (Lorg/bukkit/entity/Player;Ljava/lang/String;JLjava/lang/String;)Z
/*     */     //   242: istore #4
/*     */     //   244: iload #4
/*     */     //   246: ifne -> 265
/*     */     //   249: aload_3
/*     */     //   250: getstatic cn/handyplus/warp/util/ConfigUtil.CREATE_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   253: ldc '>:$?;5,499%'5#2'
/*     */     //   255: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   258: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   261: invokestatic sendMessage : (Lorg/bukkit/entity/Player;Ljava/lang/String;)V
/*     */     //   264: return
/*     */     //   265: getstatic cn/handyplus/warp/constants/WarpConstants.CHAT_CACHE_MAP : Ljava/util/Map;
/*     */     //   268: aload_3
/*     */     //   269: invokeinterface getUniqueId : ()Ljava/util/UUID;
/*     */     //   274: ldc 'A'D'
/*     */     //   276: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   279: aconst_null
/*     */     //   280: invokestatic of : (Ljava/lang/Object;Ljava/lang/Object;)Lcn/handyplus/warp/lib/Pair;
/*     */     //   283: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   288: aload_1
/*     */     //   289: aload_3
/*     */     //   290: getstatic cn/handyplus/warp/util/ConfigUtil.CREATE_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   293: ldc ';185#2'
/*     */     //   295: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   298: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   301: invokestatic sendMessage : (Lorg/bukkit/entity/Player;Ljava/lang/String;)V
/*     */     //   304: invokevirtual syncClose : ()V
/*     */     //   307: pop
/*     */     //   308: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #43	-> 1
/*     */     //   #55	-> 6
/*     */     //   #124	-> 11
/*     */     //   #30	-> 19
/*     */     //   #31	-> 34
/*     */     //   #54	-> 47
/*     */     //   #86	-> 49
/*     */     //   #210	-> 60
/*     */     //   #186	-> 75
/*     */     //   #228	-> 81
/*     */     //   #136	-> 87
/*     */     //   #94	-> 89
/*     */     //   #48	-> 92
/*     */     //   #224	-> 104
/*     */     //   #58	-> 111
/*     */     //   #1	-> 112
/*     */     //   #201	-> 125
/*     */     //   #89	-> 133
/*     */     //   #137	-> 145
/*     */     //   #121	-> 153
/*     */     //   #225	-> 166
/*     */     //   #152	-> 174
/*     */     //   #208	-> 186
/*     */     //   #34	-> 193
/*     */     //   #192	-> 194
/*     */     //   #220	-> 207
/*     */     //   #56	-> 219
/*     */     //   #190	-> 232
/*     */     //   #106	-> 244
/*     */     //   #145	-> 249
/*     */     //   #59	-> 264
/*     */     //   #81	-> 265
/*     */     //   #161	-> 289
/*     */     //   #233	-> 304
/*     */     //   #159	-> 308
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	309	0	a	Lcn/handyplus/warp/listener/gui/CreateClickEvent;
/*     */     //   0	309	1	a	Lcn/handyplus/warp/lib/HandyInventory;
/*     */     //   0	309	2	a	Lorg/bukkit/event/inventory/InventoryClickEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String guiType() {
/* 196 */     return GuiTypeEnum.CREATE.getType();
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\listener\gui\CreateClickEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */