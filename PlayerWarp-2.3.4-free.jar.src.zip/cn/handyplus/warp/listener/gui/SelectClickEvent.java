/*     */ package cn.handyplus.warp.listener.gui;
/*     */ import cn.handyplus.warp.constants.WarpTypeEnum;
/*     */ import cn.handyplus.warp.inventory.SelectGui;
/*     */ import cn.handyplus.warp.lib.HandyInventory;
/*     */ import cn.handyplus.warp.lib.HandyInventoryUtil;
/*     */ import cn.handyplus.warp.lib.NumberUtil;
/*     */ import cn.handyplus.warp.param.OpenParam;
/*     */ import cn.handyplus.warp.util.ConfigUtil;
/*     */ import java.util.Map;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ 
/*     */ public class SelectClickEvent implements IHandyClickEvent {
/*     */   public void rawSlotClick(HandyInventory handyInventory, InventoryClickEvent inventoryClickEvent) {
/*  16 */     int i = inventoryClickEvent.getRawSlot();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 170 */     Integer integer2 = handyInventory.getPageNum(); Player player = handyInventory.getPlayer(); Integer integer3 = handyInventory.getPageCount(); Map map1 = handyInventory.getIntMap(); OpenParam openParam = (OpenParam)handyInventory.getObj(); Integer integer4 = handyInventory.getId(); if (HandyInventoryUtil.isIndex(i, ConfigUtil.SELECT_CONFIG, "previousPage")) {
/*     */       if (integer2.intValue() > 1) {
/*     */         handyInventory.setPageNum(Integer.valueOf(handyInventory.getPageNum().intValue() - 1)); SelectGui.getInstance().setInventoryDate(handyInventory);
/*     */       }  return;
/*     */     } 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.SELECT_CONFIG, "nextPage")) {
/*     */       if (integer2.intValue() + 1 <= integer3.intValue()) {
/*     */         handyInventory.setPageNum(Integer.valueOf(handyInventory.getPageNum().intValue() + 1));
/* 178 */         SelectGui.getInstance().setInventoryDate(handyInventory);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.SELECT_CONFIG, NumberUtil.qzlKeO(".7/="))) {
/*     */       Inventory inventory = OpenGui.getInstance().createGui(player, openParam);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 201 */       handyInventory.syncOpen(inventory); return;
/*     */     }  if (HandyInventoryUtil.isIndex(i, ConfigUtil.SELECT_CONFIG, WarpPermissionUtil.qzlKeO("ZFHQJK"))) {
/*     */       WarpTypeEnum warpTypeEnum; handyInventory.setSearchType((warpTypeEnum = WarpTypeEnum.getNextEnum(handyInventory.getSearchType())).getType()); SelectGui.getInstance().setInventoryDate(handyInventory); return;
/*     */     } 
/*     */     Map<?, String> map;
/*     */     String str;
/*     */     if (StrUtil.isNotEmpty(str = (map = HandyInventoryUtil.getCustomButton(ConfigUtil.SELECT_CONFIG, NumberUtil.qzlKeO("/#?\"#;"))).get(Integer.valueOf(i)))) {
/* 208 */       PlayerSchedulerUtil.syncPerformReplaceCommand(player, str);
/*     */       return;
/*     */     } 
/*     */     Integer integer1;
/*     */     if ((integer1 = (Integer)map1.get(Integer.valueOf(i))) != null) {
/*     */       Inventory inventory = SelectPayGui.getInstance().createGui(player, openParam, integer4, integer1);
/*     */       handyInventory.syncOpen(inventory);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isAsync() {
/*     */     return true;
/*     */   }
/*     */   
/*     */   public String guiType() {
/*     */     return GuiTypeEnum.SELECT.getType();
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\listener\gui\SelectClickEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */