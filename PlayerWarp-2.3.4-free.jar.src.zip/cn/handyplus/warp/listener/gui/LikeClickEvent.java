/*     */ package cn.handyplus.warp.listener.gui;
/*     */ import cn.handyplus.warp.lib.GameRuleUtil;
/*     */ import cn.handyplus.warp.lib.HandyInventory;
/*     */ import cn.handyplus.warp.lib.Pair;
/*     */ import cn.handyplus.warp.util.ConfigUtil;
/*     */ 
/*     */ public class LikeClickEvent implements IHandyClickEvent {
/*     */   public String guiType() {
/*   9 */     return GuiTypeEnum.LIKE.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rawSlotClick(HandyInventory handyInventory, InventoryClickEvent inventoryClickEvent) {
/*  44 */     int i = inventoryClickEvent.getRawSlot();
/*     */ 
/*     */ 
/*     */     
/*     */     Player player = handyInventory.getPlayer();
/*     */ 
/*     */     
/*     */     Integer integer = handyInventory.getId();
/*     */ 
/*     */     
/*  54 */     OpenParam openParam = (OpenParam)handyInventory.getObj();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.LIKE_CONFIG, GameRuleUtil.qzlKeO("243>"))) {
/*  86 */       handyInventory.syncOpen(OpenGui.getInstance().createGui(player, openParam));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     String str;
/*     */     
/*  94 */     if (StrUtil.isNotEmpty(
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 109 */         str = 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 136 */         (String)HandyInventoryUtil.getCustomButton(ConfigUtil.LIKE_CONFIG, Pair.qzlKeO("\0339\0138\027!")).get(Integer.valueOf(i)))) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 178 */       PlayerSchedulerUtil.syncPerformReplaceCommand(player, str);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.LIKE_CONFIG, GameRuleUtil.qzlKeO("3:<956$<?;"))) {
/*     */       boolean bool = WarpCollectionService.getInstance().collection(player, integer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 201 */       WarpLikeClickResultEvent.callBuffEvent(player, integer, Pair.qzlKeO("\033#\024 \035/\f%\027\""), bool);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 223 */       LikeGui.getInstance().setInventoryDate(handyInventory);
/*     */       return;
/*     */     } 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.LIKE_CONFIG, GameRuleUtil.qzlKeO("!?%"))) {
/*     */       OOOOoO(handyInventory, Pair.qzlKeO("8\027<"));
/*     */       return;
/*     */     } 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.LIKE_CONFIG, GameRuleUtil.qzlKeO("#!5%\037;"))) {
/*     */       OOOOoO(handyInventory, Pair.qzlKeO("\0138\035<7\""));
/*     */       return;
/*     */     } 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.LIKE_CONFIG, GameRuleUtil.qzlKeO(" :9;$\001?%"))) {
/*     */       OOOOoO(handyInventory, Pair.qzlKeO("\b#\021\"\f\030\027<"));
/*     */       return;
/*     */     } 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.LIKE_CONFIG, GameRuleUtil.qzlKeO("%?<>!\003!5%\037;"))) {
/*     */       OOOOoO(handyInventory, Pair.qzlKeO("<\027%\0268+8\035<7\""));
/*     */       return;
/*     */     } 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.LIKE_CONFIG, GameRuleUtil.qzlKeO(" 9)\001?%")))
/*     */       OOOOoO(handyInventory, Pair.qzlKeO("\b \001\030\027<")); 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.LIKE_CONFIG, GameRuleUtil.qzlKeO("%<,\003!5%\037;")))
/*     */       OOOOoO(handyInventory, Pair.qzlKeO("<\0245+8\035<7\"")); 
/*     */     WarpLikePlayer warpLikePlayer = new WarpLikePlayer();
/*     */     warpLikePlayer.setWarpPlayerId(integer);
/*     */     warpLikePlayer.setPlayerName(player.getName());
/*     */     warpLikePlayer.setPlayerUuid(player.getUniqueId());
/*     */     byte b = 0;
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.LIKE_CONFIG, GameRuleUtil.qzlKeO(":>0")))
/*     */       b = 1; 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.LIKE_CONFIG, Pair.qzlKeO("8\017#")))
/*     */       b = 2; 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.LIKE_CONFIG, GameRuleUtil.qzlKeO("!8'50")))
/*     */       b = 3; 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.LIKE_CONFIG, Pair.qzlKeO("\036#\r>")))
/*     */       b = 4; 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.LIKE_CONFIG, GameRuleUtil.qzlKeO("6<&0")))
/*     */       b = 5; 
/*     */     if (b < 1)
/*     */       return; 
/*     */     warpLikePlayer.setLike(Integer.valueOf(b));
/*     */     WarpLikePlayerService.getInstance().add(warpLikePlayer);
/*     */     MessageUtil.sendMessage(player, ConfigUtil.LIKE_CONFIG.getString(Pair.qzlKeO("\024%\023)+9\033/\035)\034\001\013+")));
/*     */     handyInventory.syncOpen(OpenGui.getInstance().createGui(player, openParam));
/*     */     WarpLikeClickResultEvent.callBuffEvent(player, integer, String.valueOf(b), true);
/*     */   }
/*     */   
/*     */   public boolean isAsync() {
/*     */     return true;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\listener\gui\LikeClickEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */