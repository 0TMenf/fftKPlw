/*     */ package cn.handyplus.warp.listener.gui;
/*     */ import cn.handyplus.warp.enter.WarpPlayer;
/*     */ import cn.handyplus.warp.lib.HandyInventory;
/*     */ import cn.handyplus.warp.lib.HandyInventoryUtil;
/*     */ import cn.handyplus.warp.lib.MessageUtil;
/*     */ import cn.handyplus.warp.lib.NetUtil;
/*     */ import cn.handyplus.warp.lib.NumberUtil;
/*     */ import cn.handyplus.warp.param.OpenParam;
/*     */ import cn.handyplus.warp.service.WarpPlayerService;
/*     */ import cn.handyplus.warp.util.ConfigUtil;
/*     */ import java.util.Optional;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class AdminClickEvent implements IHandyClickEvent {
/*     */   public String guiType() {
/*  16 */     return GuiTypeEnum.ADMIN.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rawSlotClick(HandyInventory handyInventory, InventoryClickEvent inventoryClickEvent) {
/*  64 */     int i = inventoryClickEvent.getRawSlot();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Integer integer = handyInventory.getId();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     Player player = handyInventory.getPlayer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     OpenParam openParam = (OpenParam)handyInventory.getObj();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.ADMIN_CONFIG, NumberUtil.qzlKeO(".7/="))) { handyInventory.syncOpen(MeGui.getInstance().createGui(player, openParam)); return; }  String str; if (StrUtil.isNotEmpty(str = (String)HandyInventoryUtil.getCustomButton(ConfigUtil.ADMIN_CONFIG, NetUtil.qzlKeO("v\005f\004z\035")).get(Integer.valueOf(i)))) { PlayerSchedulerUtil.syncPerformReplaceCommand(player, str); return; }  if (HandyInventoryUtil.isIndex(i, ConfigUtil.ADMIN_CONFIG, NumberUtil.qzlKeO("(3 383"))) { handyInventory.syncOpen(ConfirmGui.getInstance().createGui(player, integer, "delConfirm", openParam)); return; }  if (HandyInventoryUtil.isIndex(i, ConfigUtil.ADMIN_CONFIG, NetUtil.qzlKeO("a\000"))) { handyInventory.syncClose(); Optional<?> optional; (optional = WarpPlayerService.getInstance().findById(integer)).ifPresent(warpPlayer -> WarpUtil.runTaskTpWarpLocation(a, warpPlayer)); }
/*     */      str = null; if (HandyInventoryUtil.isIndex(i, ConfigUtil.ADMIN_CONFIG, NumberUtil.qzlKeO(" 9/78?#8")))
/*     */       str = NetUtil.qzlKeO("y\037v\021a\031z\036");  if (HandyInventoryUtil.isIndex(i, ConfigUtil.ADMIN_CONFIG, NumberUtil.qzlKeO(" 9+9")))
/*     */       str = NetUtil.qzlKeO("y\037r\037");  if (HandyInventoryUtil.isIndex(i, ConfigUtil.ADMIN_CONFIG, NumberUtil.qzlKeO("\"7!3")))
/*     */       str = NetUtil.qzlKeO("{\021x\025");  if (HandyInventoryUtil.isIndex(i, ConfigUtil.ADMIN_CONFIG, NumberUtil.qzlKeO("2)%/$%&8?#8")))
/* 233 */       str = NetUtil.qzlKeO("\024p\003v\002|\000a\031z\036"); 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.ADMIN_CONFIG, NumberUtil.qzlKeO("&>?/3")))
/*     */       str = NetUtil.qzlKeO("\000g\031v\025"); 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.ADMIN_CONFIG, NumberUtil.qzlKeO("8/<3")))
/*     */       str = NetUtil.qzlKeO("a\te\025"); 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.ADMIN_CONFIG, NumberUtil.qzlKeO("2%%<:-/")))
/*     */       str = NetUtil.qzlKeO("\024|\003e\034t\t"); 
/*     */     if (StrUtil.isEmpty(str))
/*     */       return; 
/*     */     i = ConfigUtil.ADMIN_CONFIG.getInt((new StringBuilder()).insert(0, str).append(NumberUtil.qzlKeO("b&>?/3")).toString(), 0);
/*     */     if (VaultUtil.look(player) < i) {
/*     */       MessageUtil.sendMessage(player, ConfigUtil.ADMIN_CONFIG.getString(NetUtil.qzlKeO("{\037W\005a\004z\036")));
/*     */       return;
/*     */     } 
/*     */     if (NumberUtil.qzlKeO(" 9+9").equals(str)) {
/*     */       Optional<?> optional;
/*     */       if (!(optional = WarpPlayerService.getInstance().findById(integer)).isPresent())
/*     */         return; 
/*     */       if (OoOooo(player, i))
/*     */         return; 
/*     */       handyInventory.syncClose();
/*     */     } 
/*     */     if (NetUtil.qzlKeO("y\037v\021a\031z\036").equals(str)) {
/*     */       Optional<?> optional;
/*     */       if (!(optional = WarpPlayerService.getInstance().findById(integer)).isPresent())
/*     */         return; 
/*     */       List list;
/*     */       if (CollUtil.isNotEmpty(list = BaseConstants.CONFIG.getStringList(NumberUtil.qzlKeO("\"98\001#$ 2"))) && list.contains(player.getWorld().getName())) {
/*     */         MessageUtil.sendMessage(player, ConfigUtil.CREATE_CONFIG.getString(NetUtil.qzlKeO("\036z'z\002y\024W\005a\004z\036")));
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     if (NumberUtil.qzlKeO("8/<3").equals(str)) {
/*     */       Optional<?> optional;
/*     */       if (!(optional = WarpPlayerService.getInstance().findById(integer)).isPresent())
/*     */         return; 
/*     */       if (!VaultUtil.take(player, i))
/*     */         return; 
/*     */       WarpPlayer warpPlayer;
/*     */       String str1;
/*     */       (warpPlayer = (WarpPlayer)optional.get()).setType(str1 = WarpTypeEnum.getNotAllNextEnum((warpPlayer = (WarpPlayer)optional.get()).getType()).getType());
/*     */       WarpPlayerService.getInstance().update(warpPlayer);
/*     */       MessageUtil.sendMessage(player, ConfigUtil.ADMIN_CONFIG.getString(NetUtil.qzlKeO("z\033A\te\025W\005a\004z\036"), ""));
/*     */       handyInventory.syncOpen(AdminGui.getInstance().createGui(player, integer, openParam));
/*     */     } 
/*     */     if (NumberUtil.qzlKeO("2%%<:-/").equals(str)) {
/*     */       Optional<?> optional;
/*     */       if (!(optional = WarpPlayerService.getInstance().findById(integer)).isPresent())
/*     */         return; 
/*     */       if (OoOooo(player, i))
/*     */         return; 
/*     */       WarpPlayer warpPlayer;
/*     */       (warpPlayer = (WarpPlayer)optional.get()).setDisplay(Boolean.valueOf(!(warpPlayer = (WarpPlayer)optional.get()).getDisplay().booleanValue()));
/*     */       WarpPlayerService.getInstance().update(warpPlayer);
/*     */       handyInventory.syncOpen(AdminGui.getInstance().createGui(player, integer, openParam));
/*     */     } 
/*     */     MessageUtil.sendMessage(player, ConfigUtil.ADMIN_CONFIG.getString((new StringBuilder()).insert(0, NumberUtil.qzlKeO("/>-8+\t")).append(str).toString()));
/*     */     handyInventory.syncClose();
/*     */     WarpConstants.CHAT_CACHE_MAP.put(player.getUniqueId(), Pair.of((new StringBuilder()).insert(0, NetUtil.qzlKeO("v\030t\036r/")).append(str).toString(), integer));
/*     */   }
/*     */   
/*     */   public boolean isAsync() {
/*     */     return true;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\listener\gui\AdminClickEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */