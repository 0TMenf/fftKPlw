/*     */ package cn.handyplus.warp.listener.gui;
/*     */ import cn.handyplus.warp.constants.GuiTypeEnum;
/*     */ import cn.handyplus.warp.constants.WarpConstants;
/*     */ import cn.handyplus.warp.enter.WarpPlayer;
/*     */ import cn.handyplus.warp.inventory.ViewAdminGui;
/*     */ import cn.handyplus.warp.inventory.ViewGui;
/*     */ import cn.handyplus.warp.lib.BaseConstants;
/*     */ import cn.handyplus.warp.lib.HandyHttpUtil;
/*     */ import cn.handyplus.warp.lib.HandyInventory;
/*     */ import cn.handyplus.warp.lib.HandyInventoryUtil;
/*     */ import cn.handyplus.warp.lib.MessageUtil;
/*     */ import cn.handyplus.warp.lib.Pair;
/*     */ import cn.handyplus.warp.lib.PlayerSchedulerUtil;
/*     */ import cn.handyplus.warp.service.WarpCollectionService;
/*     */ import cn.handyplus.warp.service.WarpPlayerService;
/*     */ import cn.handyplus.warp.util.ConfigUtil;
/*     */ import cn.handyplus.warp.util.WarpUtil;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ 
/*     */ public class ViewAdminClickEvent implements IHandyClickEvent {
/*     */   public boolean isAsync() {
/*  26 */     return true;
/*     */   }
/*     */   
/*     */   public void rawSlotClick(HandyInventory handyInventory, InventoryClickEvent inventoryClickEvent) {
/*  30 */     int i = inventoryClickEvent.getRawSlot();
/*  31 */     Integer integer = handyInventory.getId();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  54 */     Player player = handyInventory.getPlayer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.VIEW_ADMIN_CONFIG, WarpCollectionService.qzlKeO("%W$]"))) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 210 */       Inventory inventory = ViewGui.getInstance().createGui(player);
/*     */ 
/*     */       
/*     */       handyInventory.syncOpen(inventory);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     String str;
/*     */     
/*     */     Map<?, String> map;
/*     */     
/*     */     if (StrUtil.isNotEmpty(str = (map = HandyInventoryUtil.getCustomButton(ConfigUtil.VIEW_ADMIN_CONFIG, HandyHttpUtil.qzlKeO(" U0T,M"))).get(Integer.valueOf(i)))) {
/* 224 */       PlayerSchedulerUtil.syncPerformReplaceCommand(player, str);
/*     */       return;
/*     */     } 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.VIEW_ADMIN_CONFIG, WarpCollectionService.qzlKeO("#S+S3S"))) {
/*     */       WarpPlayerService.getInstance().deleteById(integer);
/*     */       Inventory inventory = ViewGui.getInstance().createGui(player);
/*     */     } 
/*     */     Optional<?> optional;
/*     */     if (!(optional = WarpPlayerService.getInstance().findById(integer)).isPresent())
/*     */       return; 
/*     */     WarpPlayer warpPlayer = (WarpPlayer)optional.get();
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.VIEW_ADMIN_CONFIG, HandyHttpUtil.qzlKeO("7P"))) {
/*     */       handyInventory.syncClose();
/*     */       WarpUtil.runTaskTpWarpLocation(player, warpPlayer);
/*     */     } 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.VIEW_ADMIN_CONFIG, WarpCollectionService.qzlKeO("+Y Y"))) {
/*     */       handyInventory.syncClose();
/*     */       super();
/*     */       PlayerSchedulerUtil.syncPerformCommand((Player)new StringBuilder(), player.append("plw setLogo ").append(integer).toString());
/*     */       return;
/*     */     } 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.VIEW_ADMIN_CONFIG, HandyHttpUtil.qzlKeO("D*S3L\"Y"))) {
/*     */       warpPlayer.setDisplay(Boolean.valueOf(!warpPlayer.getDisplay().booleanValue()));
/*     */       WarpPlayerService.getInstance().update(warpPlayer);
/*     */       ViewAdminGui.getInstance().setInventoryDate(handyInventory);
/*     */       return;
/*     */     } 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.VIEW_ADMIN_CONFIG, WarpCollectionService.qzlKeO("3O7S"))) {
/*     */       warpPlayer.setType(WarpTypeEnum.getNotAllNextEnum(warpPlayer.getType()).getType());
/*     */       WarpPlayerService.getInstance().update(warpPlayer);
/*     */       MessageUtil.sendMessage(player, ConfigUtil.VIEW_ADMIN_CONFIG.getString(HandyHttpUtil.qzlKeO(",K\027Y3E\001U7T,N"), ""));
/*     */       ViewAdminGui.getInstance().setInventoryDate(handyInventory);
/*     */     } 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.VIEW_ADMIN_CONFIG, WarpCollectionService.qzlKeO("+Y$W3_(X"))) {
/*     */       warpPlayer.setWorldName(player.getWorld().getName());
/*     */       warpPlayer.setServerName(BaseConstants.CONFIG.getString(HandyHttpUtil.qzlKeO("0E1V&R\rA.E")));
/*     */       warpPlayer.setWarpLocation(WarpUtil.getWarpLocationSpawn(player));
/*     */       WarpPlayerService.getInstance().update(warpPlayer);
/*     */     } 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.VIEW_ADMIN_CONFIG, HandyHttpUtil.qzlKeO("-A.E")))
/*     */       MessageUtil.sendMessage(player, ConfigUtil.VIEW_ADMIN_CONFIG.getString(HandyHttpUtil.qzlKeO(" H\"N$-A.E"))); 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.VIEW_ADMIN_CONFIG, WarpCollectionService.qzlKeO("R\"E$D.F3_(X"))) {
/*     */       MessageUtil.sendMessage(player, ConfigUtil.VIEW_ADMIN_CONFIG.getString(WarpCollectionService.qzlKeO("U/W)Q\030R\"E$D.F3_(X")));
/*     */       handyInventory.syncClose();
/*     */       WarpConstants.VIEW_ADMIN_CHAT_CACHE_MAP.put(player.getUniqueId(), Pair.of(HandyHttpUtil.qzlKeO("C+A-G\034D&S R*P7I,N"), integer));
/*     */     } 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.VIEW_ADMIN_CONFIG, HandyHttpUtil.qzlKeO("P1I E"))) {
/*     */       MessageUtil.sendMessage(player, ConfigUtil.VIEW_ADMIN_CONFIG.getString(HandyHttpUtil.qzlKeO("C+A-G\034P1I E")));
/*     */       handyInventory.syncClose();
/*     */       WarpConstants.VIEW_ADMIN_CHAT_CACHE_MAP.put(player.getUniqueId(), Pair.of(WarpCollectionService.qzlKeO("U/W)Q\030F5_$S"), integer));
/*     */     } 
/*     */   }
/*     */   
/*     */   public String guiType() {
/*     */     return GuiTypeEnum.VIEW_ADMIN.getType();
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\listener\gui\ViewAdminClickEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */