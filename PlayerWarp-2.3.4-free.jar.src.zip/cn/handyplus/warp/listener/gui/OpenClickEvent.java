/*    */ package cn.handyplus.warp.listener.gui;
/*    */ 
/*    */ import cn.handyplus.warp.constants.GuiTypeEnum;
/*    */ import cn.handyplus.warp.lib.HandyInventory;
/*    */ import cn.handyplus.warp.lib.IHandyClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpenClickEvent
/*    */   implements IHandyClickEvent
/*    */ {
/*    */   public String guiType() {
/* 52 */     return GuiTypeEnum.OPEN.getType();
/*    */   }
/*    */   public boolean isAsync() {
/* 55 */     return true;
/*    */   }
/*    */   
/*    */   public void rawSlotClick(HandyInventory handyInventory, InventoryClickEvent inventoryClickEvent) {
/*    */     // Byte code:
/*    */     //   0: aload_2
/*    */     //   1: invokevirtual getRawSlot : ()I
/*    */     //   4: istore_3
/*    */     //   5: aload_1
/*    */     //   6: dup
/*    */     //   7: dup_x1
/*    */     //   8: dup_x2
/*    */     //   9: aload_1
/*    */     //   10: invokevirtual getPageNum : ()Ljava/lang/Integer;
/*    */     //   13: astore #4
/*    */     //   15: invokevirtual getPlayer : ()Lorg/bukkit/entity/Player;
/*    */     //   18: astore #5
/*    */     //   20: invokevirtual getPageCount : ()Ljava/lang/Integer;
/*    */     //   23: astore #6
/*    */     //   25: invokevirtual getIntMap : ()Ljava/util/Map;
/*    */     //   28: astore #7
/*    */     //   30: invokevirtual getObj : ()Ljava/lang/Object;
/*    */     //   33: checkcast cn/handyplus/warp/param/OpenParam
/*    */     //   36: astore #8
/*    */     //   38: iload_3
/*    */     //   39: getstatic cn/handyplus/warp/util/ConfigUtil.OPEN_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*    */     //   42: ldc 'previousPage'
/*    */     //   44: invokestatic isIndex : (ILorg/bukkit/configuration/file/FileConfiguration;Ljava/lang/String;)Z
/*    */     //   47: ifeq -> 84
/*    */     //   50: aload #4
/*    */     //   52: invokevirtual intValue : ()I
/*    */     //   55: iconst_1
/*    */     //   56: if_icmple -> 82
/*    */     //   59: aload_1
/*    */     //   60: dup
/*    */     //   61: invokevirtual getPageNum : ()Ljava/lang/Integer;
/*    */     //   64: invokevirtual intValue : ()I
/*    */     //   67: iconst_1
/*    */     //   68: isub
/*    */     //   69: invokestatic valueOf : (I)Ljava/lang/Integer;
/*    */     //   72: invokevirtual setPageNum : (Ljava/lang/Integer;)V
/*    */     //   75: invokestatic getInstance : ()Lcn/handyplus/warp/inventory/OpenGui;
/*    */     //   78: aload_1
/*    */     //   79: invokevirtual setInventoryDate : (Lcn/handyplus/warp/lib/HandyInventory;)V
/*    */     //   82: return
/*    */     //   83: athrow
/*    */     //   84: iload_3
/*    */     //   85: getstatic cn/handyplus/warp/util/ConfigUtil.OPEN_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*    */     //   88: ldc 'nextPage'
/*    */     //   90: invokestatic isIndex : (ILorg/bukkit/configuration/file/FileConfiguration;Ljava/lang/String;)Z
/*    */     //   93: ifeq -> 136
/*    */     //   96: aload #4
/*    */     //   98: invokevirtual intValue : ()I
/*    */     //   101: iconst_1
/*    */     //   102: iadd
/*    */     //   103: aload #6
/*    */     //   105: invokevirtual intValue : ()I
/*    */     //   108: if_icmpgt -> 134
/*    */     //   111: aload_1
/*    */     //   112: dup
/*    */     //   113: invokevirtual getPageNum : ()Ljava/lang/Integer;
/*    */     //   116: invokevirtual intValue : ()I
/*    */     //   119: iconst_1
/*    */     //   120: iadd
/*    */     //   121: invokestatic valueOf : (I)Ljava/lang/Integer;
/*    */     //   124: invokevirtual setPageNum : (Ljava/lang/Integer;)V
/*    */     //   127: invokestatic getInstance : ()Lcn/handyplus/warp/inventory/OpenGui;
/*    */     //   130: aload_1
/*    */     //   131: invokevirtual setInventoryDate : (Lcn/handyplus/warp/lib/HandyInventory;)V
/*    */     //   134: return
/*    */     //   135: athrow
/*    */     //   136: iload_3
/*    */     //   137: getstatic cn/handyplus/warp/util/ConfigUtil.OPEN_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*    */     //   140: ldc '`YfJwN'
/*    */     //   142: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*    */     //   145: invokestatic isIndex : (ILorg/bukkit/configuration/file/FileConfiguration;Ljava/lang/String;)Z
/*    */     //   148: ifeq -> 170
/*    */     //   151: invokestatic getInstance : ()Lcn/handyplus/warp/inventory/CreateGui;
/*    */     //   154: aload #5
/*    */     //   156: aload #8
/*    */     //   158: invokevirtual createGui : (Lorg/bukkit/entity/Player;Lcn/handyplus/warp/param/OpenParam;)Lorg/bukkit/inventory/Inventory;
/*    */     //   161: astore #4
/*    */     //   163: aload_1
/*    */     //   164: aload #4
/*    */     //   166: invokevirtual syncOpen : (Lorg/bukkit/inventory/Inventory;)V
/*    */     //   169: return
/*    */     //   170: iload_3
/*    */     //   171: getstatic cn/handyplus/warp/util/ConfigUtil.OPEN_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*    */     //   174: ldc 'Ni'
/*    */     //   176: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*    */     //   179: invokestatic isIndex : (ILorg/bukkit/configuration/file/FileConfiguration;Ljava/lang/String;)Z
/*    */     //   182: ifeq -> 204
/*    */     //   185: invokestatic getInstance : ()Lcn/handyplus/warp/inventory/MeGui;
/*    */     //   188: aload #5
/*    */     //   190: aload #8
/*    */     //   192: invokevirtual createGui : (Lorg/bukkit/entity/Player;Lcn/handyplus/warp/param/OpenParam;)Lorg/bukkit/inventory/Inventory;
/*    */     //   195: astore #4
/*    */     //   197: aload_1
/*    */     //   198: aload #4
/*    */     //   200: invokevirtual syncOpen : (Lorg/bukkit/inventory/Inventory;)V
/*    */     //   203: return
/*    */     //   204: iload_3
/*    */     //   205: getstatic cn/handyplus/warp/util/ConfigUtil.OPEN_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*    */     //   208: ldc '`DoGfHwBlE'
/*    */     //   210: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*    */     //   213: invokestatic isIndex : (ILorg/bukkit/configuration/file/FileConfiguration;Ljava/lang/String;)Z
/*    */     //   216: ifeq -> 268
/*    */     //   219: aload #8
/*    */     //   221: invokevirtual getIsCollection : ()Ljava/lang/Boolean;
/*    */     //   224: invokevirtual booleanValue : ()Z
/*    */     //   227: ifne -> 268
/*    */     //   230: invokestatic getInstance : ()Lcn/handyplus/warp/inventory/OpenGui;
/*    */     //   233: aload #5
/*    */     //   235: invokestatic builder : ()Lcn/handyplus/warp/param/OpenParam$OpenParamBuilder;
/*    */     //   238: iconst_1
/*    */     //   239: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*    */     //   242: invokevirtual isCollection : (Ljava/lang/Boolean;)Lcn/handyplus/warp/param/OpenParam$OpenParamBuilder;
/*    */     //   245: aload #8
/*    */     //   247: invokevirtual getSearchType : ()Ljava/lang/String;
/*    */     //   250: invokevirtual searchType : (Ljava/lang/String;)Lcn/handyplus/warp/param/OpenParam$OpenParamBuilder;
/*    */     //   253: invokevirtual build : ()Lcn/handyplus/warp/param/OpenParam;
/*    */     //   256: invokevirtual createGui : (Lorg/bukkit/entity/Player;Lcn/handyplus/warp/param/OpenParam;)Lorg/bukkit/inventory/Inventory;
/*    */     //   259: astore #4
/*    */     //   261: aload_1
/*    */     //   262: aload #4
/*    */     //   264: invokevirtual syncOpen : (Lorg/bukkit/inventory/Inventory;)V
/*    */     //   267: return
/*    */     //   268: iload_3
/*    */     //   269: getstatic cn/handyplus/warp/util/ConfigUtil.OPEN_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*    */     //   272: ldc 'mO`'
/*    */     //   274: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*    */     //   277: invokestatic isIndex : (ILorg/bukkit/configuration/file/FileConfiguration;Ljava/lang/String;)Z
/*    */     //   280: ifeq -> 332
/*    */     //   283: aload #8
/*    */     //   285: invokevirtual getIsCollection : ()Ljava/lang/Boolean;
/*    */     //   288: invokevirtual booleanValue : ()Z
/*    */     //   291: ifeq -> 332
/*    */     //   294: invokestatic getInstance : ()Lcn/handyplus/warp/inventory/OpenGui;
/*    */     //   297: aload #5
/*    */     //   299: invokestatic builder : ()Lcn/handyplus/warp/param/OpenParam$OpenParamBuilder;
/*    */     //   302: iconst_0
/*    */     //   303: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*    */     //   306: invokevirtual isCollection : (Ljava/lang/Boolean;)Lcn/handyplus/warp/param/OpenParam$OpenParamBuilder;
/*    */     //   309: aload #8
/*    */     //   311: invokevirtual getSearchType : ()Ljava/lang/String;
/*    */     //   314: invokevirtual searchType : (Ljava/lang/String;)Lcn/handyplus/warp/param/OpenParam$OpenParamBuilder;
/*    */     //   317: invokevirtual build : ()Lcn/handyplus/warp/param/OpenParam;
/*    */     //   320: invokevirtual createGui : (Lorg/bukkit/entity/Player;Lcn/handyplus/warp/param/OpenParam;)Lorg/bukkit/inventory/Inventory;
/*    */     //   323: astore #4
/*    */     //   325: aload_1
/*    */     //   326: aload #4
/*    */     //   328: invokevirtual syncOpen : (Lorg/bukkit/inventory/Inventory;)V
/*    */     //   331: return
/*    */     //   332: iload_3
/*    */     //   333: getstatic cn/handyplus/warp/util/ConfigUtil.OPEN_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*    */     //   336: ldc 'pNbY`C'
/*    */     //   338: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*    */     //   341: invokestatic isIndex : (ILorg/bukkit/configuration/file/FileConfiguration;Ljava/lang/String;)Z
/*    */     //   344: ifeq -> 372
/*    */     //   347: aload_1
/*    */     //   348: dup
/*    */     //   349: invokevirtual getSearchType : ()Ljava/lang/String;
/*    */     //   352: invokestatic getNextEnum : (Ljava/lang/String;)Lcn/handyplus/warp/constants/WarpTypeEnum;
/*    */     //   355: dup
/*    */     //   356: astore #4
/*    */     //   358: invokevirtual getType : ()Ljava/lang/String;
/*    */     //   361: invokevirtual setSearchType : (Ljava/lang/String;)V
/*    */     //   364: invokestatic getInstance : ()Lcn/handyplus/warp/inventory/OpenGui;
/*    */     //   367: aload_1
/*    */     //   368: invokevirtual setInventoryDate : (Lcn/handyplus/warp/lib/HandyInventory;)V
/*    */     //   371: return
/*    */     //   372: getstatic cn/handyplus/warp/util/ConfigUtil.OPEN_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*    */     //   375: ldc '@yPxLa'
/*    */     //   377: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*    */     //   380: invokestatic getCustomButton : (Lorg/bukkit/configuration/file/FileConfiguration;Ljava/lang/String;)Ljava/util/Map;
/*    */     //   383: dup
/*    */     //   384: astore #4
/*    */     //   386: iload_3
/*    */     //   387: invokestatic valueOf : (I)Ljava/lang/Integer;
/*    */     //   390: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   395: checkcast java/lang/String
/*    */     //   398: dup
/*    */     //   399: astore #4
/*    */     //   401: invokestatic isNotEmpty : (Ljava/lang/CharSequence;)Z
/*    */     //   404: ifeq -> 415
/*    */     //   407: aload #5
/*    */     //   409: aload #4
/*    */     //   411: invokestatic syncPerformReplaceCommand : (Lorg/bukkit/entity/Player;Ljava/lang/String;)V
/*    */     //   414: return
/*    */     //   415: aload #7
/*    */     //   417: iload_3
/*    */     //   418: invokestatic valueOf : (I)Ljava/lang/Integer;
/*    */     //   421: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*    */     //   426: checkcast java/lang/Integer
/*    */     //   429: dup
/*    */     //   430: astore #4
/*    */     //   432: ifnonnull -> 436
/*    */     //   435: return
/*    */     //   436: aload #4
/*    */     //   438: invokevirtual intValue : ()I
/*    */     //   441: iconst_m1
/*    */     //   442: if_icmpne -> 468
/*    */     //   445: invokestatic getInstance : ()Lcn/handyplus/warp/inventory/SelectGui;
/*    */     //   448: aload #5
/*    */     //   450: aload #8
/*    */     //   452: iload_3
/*    */     //   453: invokestatic valueOf : (I)Ljava/lang/Integer;
/*    */     //   456: invokevirtual createGui : (Lorg/bukkit/entity/Player;Lcn/handyplus/warp/param/OpenParam;Ljava/lang/Integer;)Lorg/bukkit/inventory/Inventory;
/*    */     //   459: astore #6
/*    */     //   461: aload_1
/*    */     //   462: aload #6
/*    */     //   464: invokevirtual syncOpen : (Lorg/bukkit/inventory/Inventory;)V
/*    */     //   467: return
/*    */     //   468: invokestatic getInstance : ()Lcn/handyplus/warp/service/WarpPlayerService;
/*    */     //   471: aload #4
/*    */     //   473: invokevirtual findById : (Ljava/lang/Integer;)Ljava/util/Optional;
/*    */     //   476: dup
/*    */     //   477: astore #6
/*    */     //   479: invokevirtual isPresent : ()Z
/*    */     //   482: ifne -> 486
/*    */     //   485: return
/*    */     //   486: aload #6
/*    */     //   488: invokevirtual get : ()Ljava/lang/Object;
/*    */     //   491: checkcast cn/handyplus/warp/enter/WarpPlayer
/*    */     //   494: astore_3
/*    */     //   495: getstatic org/bukkit/event/inventory/ClickType.LEFT : Lorg/bukkit/event/inventory/ClickType;
/*    */     //   498: aload_2
/*    */     //   499: invokevirtual getClick : ()Lorg/bukkit/event/inventory/ClickType;
/*    */     //   502: invokevirtual equals : (Ljava/lang/Object;)Z
/*    */     //   505: ifeq -> 565
/*    */     //   508: aload #5
/*    */     //   510: aload_3
/*    */     //   511: invokestatic tpCheck : (Lorg/bukkit/entity/Player;Lcn/handyplus/warp/enter/WarpPlayer;)Z
/*    */     //   514: ifeq -> 565
/*    */     //   517: aload #5
/*    */     //   519: aload_3
/*    */     //   520: invokestatic tpPriceCheck : (Lorg/bukkit/entity/Player;Lcn/handyplus/warp/enter/WarpPlayer;)Z
/*    */     //   523: ifeq -> 537
/*    */     //   526: aload #5
/*    */     //   528: aload_3
/*    */     //   529: aload_1
/*    */     //   530: invokevirtual syncClose : ()V
/*    */     //   533: invokestatic runTaskTp : (Lorg/bukkit/entity/Player;Lcn/handyplus/warp/enter/WarpPlayer;)V
/*    */     //   536: return
/*    */     //   537: aload #8
/*    */     //   539: aload_3
/*    */     //   540: invokevirtual getPrice : ()Ljava/lang/Integer;
/*    */     //   543: invokevirtual setPrice : (Ljava/lang/Integer;)V
/*    */     //   546: aload_1
/*    */     //   547: invokestatic getInstance : ()Lcn/handyplus/warp/inventory/ConfirmGui;
/*    */     //   550: aload #5
/*    */     //   552: aload #4
/*    */     //   554: ldc_w 'tpConfirm'
/*    */     //   557: aload #8
/*    */     //   559: invokevirtual createGui : (Lorg/bukkit/entity/Player;Ljava/lang/Integer;Ljava/lang/String;Lcn/handyplus/warp/param/OpenParam;)Lorg/bukkit/inventory/Inventory;
/*    */     //   562: invokevirtual syncOpen : (Lorg/bukkit/inventory/Inventory;)V
/*    */     //   565: getstatic org/bukkit/event/inventory/ClickType.RIGHT : Lorg/bukkit/event/inventory/ClickType;
/*    */     //   568: aload_2
/*    */     //   569: invokevirtual getClick : ()Lorg/bukkit/event/inventory/ClickType;
/*    */     //   572: invokevirtual equals : (Ljava/lang/Object;)Z
/*    */     //   575: ifeq -> 596
/*    */     //   578: invokestatic getInstance : ()Lcn/handyplus/warp/inventory/LikeGui;
/*    */     //   581: aload #5
/*    */     //   583: aload #4
/*    */     //   585: aload #8
/*    */     //   587: invokevirtual createGui : (Lorg/bukkit/entity/Player;Ljava/lang/Integer;Lcn/handyplus/warp/param/OpenParam;)Lorg/bukkit/inventory/Inventory;
/*    */     //   590: astore_2
/*    */     //   591: aload_1
/*    */     //   592: aload_2
/*    */     //   593: invokevirtual syncOpen : (Lorg/bukkit/inventory/Inventory;)V
/*    */     //   596: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #54	-> 0
/*    */     //   #64	-> 5
/*    */     //   #7	-> 15
/*    */     //   #86	-> 20
/*    */     //   #210	-> 25
/*    */     //   #186	-> 30
/*    */     //   #136	-> 38
/*    */     //   #109	-> 50
/*    */     //   #94	-> 59
/*    */     //   #178	-> 75
/*    */     //   #154	-> 82
/*    */     //   #80	-> 84
/*    */     //   #1	-> 96
/*    */     //   #201	-> 111
/*    */     //   #223	-> 127
/*    */     //   #89	-> 134
/*    */     //   #200	-> 151
/*    */     //   #121	-> 163
/*    */     //   #225	-> 169
/*    */     //   #152	-> 170
/*    */     //   #47	-> 185
/*    */     //   #208	-> 197
/*    */     //   #34	-> 203
/*    */     //   #220	-> 204
/*    */     //   #56	-> 230
/*    */     //   #190	-> 261
/*    */     //   #8	-> 267
/*    */     //   #59	-> 268
/*    */     //   #174	-> 294
/*    */     //   #81	-> 325
/*    */     //   #161	-> 331
/*    */     //   #138	-> 332
/*    */     //   #131	-> 347
/*    */     //   #219	-> 358
/*    */     //   #198	-> 364
/*    */     //   #214	-> 371
/*    */     //   #175	-> 372
/*    */     //   #184	-> 386
/*    */     //   #75	-> 401
/*    */     //   #38	-> 407
/*    */     //   #87	-> 414
/*    */     //   #130	-> 415
/*    */     //   #211	-> 432
/*    */     //   #127	-> 435
/*    */     //   #203	-> 436
/*    */     //   #222	-> 445
/*    */     //   #103	-> 461
/*    */     //   #149	-> 467
/*    */     //   #176	-> 468
/*    */     //   #156	-> 479
/*    */     //   #5	-> 485
/*    */     //   #217	-> 486
/*    */     //   #160	-> 495
/*    */     //   #68	-> 508
/*    */     //   #74	-> 517
/*    */     //   #111	-> 529
/*    */     //   #110	-> 533
/*    */     //   #129	-> 536
/*    */     //   #140	-> 537
/*    */     //   #83	-> 546
/*    */     //   #23	-> 565
/*    */     //   #53	-> 578
/*    */     //   #29	-> 591
/*    */     //   #19	-> 596
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	597	0	a	Lcn/handyplus/warp/listener/gui/OpenClickEvent;
/*    */     //   0	597	1	a	Lcn/handyplus/warp/lib/HandyInventory;
/*    */     //   0	597	2	a	Lorg/bukkit/event/inventory/InventoryClickEvent;
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\listener\gui\OpenClickEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */