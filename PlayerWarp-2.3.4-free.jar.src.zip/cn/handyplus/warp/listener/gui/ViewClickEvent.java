/*     */ package cn.handyplus.warp.listener.gui;
/*     */ 
/*     */ import cn.handyplus.warp.constants.GuiTypeEnum;
/*     */ import cn.handyplus.warp.inventory.ViewAdminGui;
/*     */ import cn.handyplus.warp.inventory.ViewGui;
/*     */ import cn.handyplus.warp.lib.HandyInventory;
/*     */ import cn.handyplus.warp.lib.HandyInventoryUtil;
/*     */ import cn.handyplus.warp.lib.IHandyClickEvent;
/*     */ import cn.handyplus.warp.lib.PlayerSchedulerUtil;
/*     */ import cn.handyplus.warp.lib.StrUtil;
/*     */ import cn.handyplus.warp.service.WarpCollectionService;
/*     */ import cn.handyplus.warp.util.ConfigUtil;
/*     */ import cn.handyplus.warp.util.WarpPermissionUtil;
/*     */ import java.util.Map;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ViewClickEvent
/*     */   implements IHandyClickEvent
/*     */ {
/*     */   public void rawSlotClick(HandyInventory handyInventory, InventoryClickEvent inventoryClickEvent) {
/* 134 */     int i = inventoryClickEvent.getRawSlot();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Integer integer2 = handyInventory.getPageNum();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Integer integer3 = handyInventory.getPageCount();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Player player = handyInventory.getPlayer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 170 */     Map map = handyInventory.getIntMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.VIEW_CONFIG, "previousPage")) {
/*     */       if (integer2.intValue() > 1) {
/*     */         handyInventory.setPageNum(Integer.valueOf(handyInventory.getPageNum().intValue() - 1));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         ViewGui.getInstance().setInventoryDate(handyInventory);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.VIEW_CONFIG, "nextPage")) {
/*     */       if (integer2.intValue() + 1 <= integer3.intValue()) {
/* 210 */         handyInventory.setPageNum(Integer.valueOf(handyInventory.getPageNum().intValue() + 1));
/*     */         
/*     */         ViewGui.getInstance().setInventoryDate(handyInventory);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     if (HandyInventoryUtil.isIndex(i, ConfigUtil.VIEW_CONFIG, WarpPermissionUtil.qzlKeO("KBJH"))) {
/*     */       handyInventory.syncClose();
/*     */       return;
/*     */     } 
/*     */     String str;
/*     */     if (StrUtil.isNotEmpty(str = (String)HandyInventoryUtil.getCustomButton(ConfigUtil.VIEW_CONFIG, WarpCollectionService.qzlKeO("$C4B([")).get(Integer.valueOf(i)))) {
/* 223 */       PlayerSchedulerUtil.syncPerformReplaceCommand(player, str); return;
/*     */     }  Integer integer1; if ((integer1 = (Integer)map.get(Integer.valueOf(i))) == null)
/* 225 */       return;  Inventory inventory = ViewAdminGui.getInstance().createGui(player, integer1);
/*     */     handyInventory.syncOpen(inventory);
/*     */   }
/*     */   
/*     */   public boolean isAsync() {
/*     */     return true;
/*     */   }
/*     */   
/*     */   public String guiType() {
/*     */     return GuiTypeEnum.VIEW.getType();
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\listener\gui\ViewClickEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */