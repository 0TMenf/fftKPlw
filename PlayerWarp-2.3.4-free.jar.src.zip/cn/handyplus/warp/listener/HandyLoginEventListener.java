/*   */ package cn.handyplus.warp.listener;
/*   */ 
/*   */ @HandyListener
/*   */ public class HandyLoginEventListener implements Listener {
/*   */   @EventHandler
/* 6 */   public void onPlayerJoin(HandyLoginEvent handyLoginEvent) { HandySchedulerUtil.runTaskLaterAsynchronously(() -> { String str = BaseConstants.CONFIG.getString(HandyHttpUtil.qzlKeO("0E1V&R\rA.E")); Optional<?> optional; if (!(optional = WarpChannelService.getInstance().findByPlayerUuidAndServerName(a.getPlayer().getUniqueId(), str)).isPresent()) return;  WarpChannel warpChannel = (WarpChannel)optional.get(); WarpChannelService.getInstance().delById(warpChannel.getId()); WarpUtil.runTaskTpLocalWarpLocation(a.getPlayer(), warpChannel.getWarpName(), warpChannel.getWarpLocation(), warpChannel.getWarpOffset()); }20L); } @EventHandler
/* 7 */   public void onOpPlayerJoin(HandyLoginEvent handyLoginEvent) { HandyHttpUtil.checkVersion(handyLoginEvent.getPlayer()); }
/*   */ 
/*   */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\listener\HandyLoginEventListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */