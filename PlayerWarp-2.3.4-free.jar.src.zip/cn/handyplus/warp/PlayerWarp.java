/*     */ package cn.handyplus.warp;
/*     */ 
/*     */ import cn.handyplus.warp.lib.BaseUtil;
/*     */ import cn.handyplus.warp.lib.HookPluginEnum;
/*     */ import cn.handyplus.warp.lib.InitApi;
/*     */ import cn.handyplus.warp.lib.MessageUtil;
/*     */ import net.milkbowl.vault.economy.Economy;
/*     */ import org.black_ixx.playerpoints.PlayerPoints;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.RegisteredServiceProvider;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerWarp
/*     */   extends JavaPlugin
/*     */ {
/*     */   public static boolean USE_PAPI;
/*     */   public static boolean USE_PLY;
/*     */   public static boolean USE_MV_5;
/*     */   public static boolean USE_MV_4;
/*     */   public static PlayerPoints PLAYER_POINTS;
/*     */   public static Economy ECON;
/*     */   public static PlayerWarp INSTANCE;
/*     */   
/*     */   public void onEnable() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: dup
/*     */     //   2: putstatic cn/handyplus/warp/PlayerWarp.INSTANCE : Lcn/handyplus/warp/PlayerWarp;
/*     */     //   5: invokestatic getInstance : (Lorg/bukkit/plugin/java/JavaPlugin;)Lcn/handyplus/warp/lib/InitApi;
/*     */     //   8: astore_1
/*     */     //   9: invokestatic init : ()V
/*     */     //   12: getstatic cn/handyplus/warp/lib/HookPluginEnum.PLACEHOLDER_API : Lcn/handyplus/warp/lib/HookPluginEnum;
/*     */     //   15: invokestatic hook : (Lcn/handyplus/warp/lib/HookPluginEnum;)Z
/*     */     //   18: putstatic cn/handyplus/warp/PlayerWarp.USE_PAPI : Z
/*     */     //   21: getstatic cn/handyplus/warp/PlayerWarp.USE_PAPI : Z
/*     */     //   24: ifeq -> 39
/*     */     //   27: new cn/handyplus/warp/hook/PlaceholderUtil
/*     */     //   30: dup
/*     */     //   31: aload_0
/*     */     //   32: invokespecial <init> : (Lcn/handyplus/warp/PlayerWarp;)V
/*     */     //   35: invokevirtual register : ()Z
/*     */     //   38: pop
/*     */     //   39: aload_0
/*     */     //   40: invokevirtual loadEconomy : ()V
/*     */     //   43: getstatic cn/handyplus/warp/lib/HookPluginEnum.PLAYER_POINTS : Lcn/handyplus/warp/lib/HookPluginEnum;
/*     */     //   46: invokestatic hookToPlugin : (Lcn/handyplus/warp/lib/HookPluginEnum;)Ljava/util/Optional;
/*     */     //   49: <illegal opcode> accept : ()Ljava/util/function/Consumer;
/*     */     //   54: invokevirtual ifPresent : (Ljava/util/function/Consumer;)V
/*     */     //   57: getstatic cn/handyplus/warp/lib/HookPluginEnum.PLAYER_CURRENCY : Lcn/handyplus/warp/lib/HookPluginEnum;
/*     */     //   60: invokestatic hook : (Lcn/handyplus/warp/lib/HookPluginEnum;)Z
/*     */     //   63: putstatic cn/handyplus/warp/PlayerWarp.USE_PLY : Z
/*     */     //   66: getstatic cn/handyplus/warp/lib/HookPluginEnum.MULTIVERSE_CORE : Lcn/handyplus/warp/lib/HookPluginEnum;
/*     */     //   69: iconst_5
/*     */     //   70: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   73: invokestatic hook : (Lcn/handyplus/warp/lib/HookPluginEnum;Ljava/lang/Integer;)Z
/*     */     //   76: putstatic cn/handyplus/warp/PlayerWarp.USE_MV_5 : Z
/*     */     //   79: getstatic cn/handyplus/warp/PlayerWarp.USE_MV_5 : Z
/*     */     //   82: ifne -> 105
/*     */     //   85: getstatic cn/handyplus/warp/lib/HookPluginEnum.MULTIVERSE_CORE : Lcn/handyplus/warp/lib/HookPluginEnum;
/*     */     //   88: iconst_4
/*     */     //   89: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   92: invokestatic hook : (Lcn/handyplus/warp/lib/HookPluginEnum;Ljava/lang/Integer;)Z
/*     */     //   95: ifeq -> 105
/*     */     //   98: iconst_1
/*     */     //   99: putstatic cn/handyplus/warp/PlayerWarp.USE_MV_4 : Z
/*     */     //   102: invokestatic init : ()V
/*     */     //   105: bipush #7
/*     */     //   107: anewarray java/lang/String
/*     */     //   110: iconst_1
/*     */     //   111: dup
/*     */     //   112: pop2
/*     */     //   113: dup
/*     */     //   114: iconst_0
/*     */     //   115: ldc ''
/*     */     //   117: aastore
/*     */     //   118: dup
/*     */     //   119: iconst_1
/*     */     //   120: ldc '#t\t\#t###########t\####t\#######'
/*     */     //   122: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   125: aastore
/*     */     //   126: dup
/*     */     //   127: iconst_2
/*     */     //   128: ldc ''C'X[C'C'`XXX'X'`X`'`'`[[''''XXXX`'`'`X''
/*     */     //   130: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   133: aastore
/*     */     //   134: dup
/*     */     //   135: iconst_3
/*     */     //   136: ldc 't*#tc#t#w#\\f\t__,w###tc$t\W#\\f\_'
/*     */     //   138: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   141: aastore
/*     */     //   142: dup
/*     */     //   143: iconst_4
/*     */     //   144: ldc ''C'X`(C'C'XC'C'CXC'C'X`({'[Q'i''XC'C'C'{{`.{'
/*     */     //   146: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   149: aastore
/*     */     //   150: dup
/*     */     //   151: iconst_5
/*     */     //   152: ldc 't#tw\t/tw\t/w\t\W\W##_t,w\#w\t/tt#W#\t,'
/*     */     //   154: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   157: aastore
/*     */     //   158: dup
/*     */     //   159: bipush #6
/*     */     //   161: ldc '''''''''{`X`(''''''''''''''{`{'''
/*     */     //   163: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   166: aastore
/*     */     //   167: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
/*     */     //   170: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   175: dup
/*     */     //   176: astore_2
/*     */     //   177: invokeinterface hasNext : ()Z
/*     */     //   182: ifeq -> 223
/*     */     //   185: aload_2
/*     */     //   186: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   191: checkcast java/lang/String
/*     */     //   194: astore_3
/*     */     //   195: new java/lang/StringBuilder
/*     */     //   198: dup
/*     */     //   199: invokespecial <init> : ()V
/*     */     //   202: getstatic org/bukkit/ChatColor.DARK_AQUA : Lorg/bukkit/ChatColor;
/*     */     //   205: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   208: aload_3
/*     */     //   209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   212: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   215: invokestatic sendConsoleMessage : (Ljava/lang/String;)V
/*     */     //   218: aload_2
/*     */     //   219: goto -> 177
/*     */     //   222: athrow
/*     */     //   223: aload_1
/*     */     //   224: sipush #15977
/*     */     //   227: invokevirtual addMetrics : (I)Lcn/handyplus/warp/lib/InitApi;
/*     */     //   230: invokevirtual enableBc : ()Lcn/handyplus/warp/lib/InitApi;
/*     */     //   233: invokevirtual checkVersion : ()Lcn/handyplus/warp/lib/InitApi;
/*     */     //   236: ldc 'HmkJmOz[o^ptJq[-HlFnJmO'
/*     */     //   238: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   241: invokevirtual initCommand : (Ljava/lang/String;)Lcn/handyplus/warp/lib/InitApi;
/*     */     //   244: ldc '\io^i[~OkJtp^uO)SnLsZiZu'
/*     */     //   246: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   249: invokevirtual initListener : (Ljava/lang/String;)Lcn/handyplus/warp/lib/InitApi;
/*     */     //   252: ldc '`E-CbEgRsGvX-\bYsoBp_fEfY-LvB'
/*     */     //   254: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   257: invokevirtual initClickEvent : (Ljava/lang/String;)Lcn/handyplus/warp/lib/InitApi;
/*     */     //   260: ldc 'dQ)WfQcFwSrL)HfMwbQsZu'
/*     */     //   262: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   265: invokevirtual enableSql : (Ljava/lang/String;)Lcn/handyplus/warp/lib/InitApi;
/*     */     //   268: invokestatic init : ()V
/*     */     //   271: invokestatic init : ()V
/*     */     //   274: new java/lang/StringBuilder
/*     */     //   277: dup
/*     */     //   278: invokespecial <init> : ()V
/*     */     //   281: getstatic org/bukkit/ChatColor.GREEN : Lorg/bukkit/ChatColor;
/*     */     //   284: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   287: ldc '巙戓労轾兎朎劊噫Ｊ'
/*     */     //   289: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   292: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   295: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   298: invokestatic sendConsoleMessage : (Ljava/lang/String;)V
/*     */     //   301: new java/lang/StringBuilder
/*     */     //   304: dup
/*     */     //   305: invokespecial <init> : ()V
/*     */     //   308: getstatic org/bukkit/ChatColor.GREEN : Lorg/bukkit/ChatColor;
/*     */     //   311: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   314: ldc 'FJsWhM=WfQcF'佀甯斸桤'WsKwL=(Mn\b[h\)WfQcFwSrL)\ipVlV(ok^~ZuhfMwUzF{Jz('
/*     */     //   316: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   319: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   322: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   325: invokestatic sendConsoleMessage : (Ljava/lang/String;)V
/*     */     //   328: pop
/*     */     //   329: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #18	-> 0
/*     */     //   #52	-> 5
/*     */     //   #170	-> 9
/*     */     //   #43	-> 12
/*     */     //   #55	-> 21
/*     */     //   #124	-> 27
/*     */     //   #31	-> 39
/*     */     //   #64	-> 43
/*     */     //   #86	-> 57
/*     */     //   #186	-> 66
/*     */     //   #228	-> 79
/*     */     //   #136	-> 98
/*     */     //   #109	-> 102
/*     */     //   #178	-> 105
/*     */     //   #218	-> 170
/*     */     //   #89	-> 195
/*     */     //   #79	-> 219
/*     */     //   #200	-> 230
/*     */     //   #121	-> 233
/*     */     //   #225	-> 241
/*     */     //   #191	-> 249
/*     */     //   #166	-> 257
/*     */     //   #152	-> 265
/*     */     //   #34	-> 268
/*     */     //   #192	-> 271
/*     */     //   #56	-> 274
/*     */     //   #190	-> 301
/*     */     //   #8	-> 329
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	330	0	a	Lcn/handyplus/warp/PlayerWarp;
/*     */   }
/*     */   
/*     */   public void onDisable() {
/* 174 */     InitApi.disable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadEconomy() {
/* 219 */     if (getServer().getPluginManager().getPlugin(HookPluginEnum.VAULT.getName()) == null) {
/*     */       MessageUtil.sendConsoleMessage(BaseUtil.getLangMsg(HookPluginEnum.VAULT.getFailMsg()));
/*     */       return;
/*     */     } 
/*     */     RegisteredServiceProvider registeredServiceProvider;
/*     */     if ((registeredServiceProvider = getServer().getServicesManager().getRegistration(Economy.class)) == null) {
/*     */       MessageUtil.sendConsoleMessage(BaseUtil.getLangMsg(HookPluginEnum.VAULT.getFailMsg()));
/*     */       return;
/*     */     } 
/*     */     ECON = (Economy)registeredServiceProvider.getProvider();
/*     */     MessageUtil.sendConsoleMessage(BaseUtil.getLangMsg(HookPluginEnum.VAULT.getSuccessMsg()));
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\PlayerWarp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */