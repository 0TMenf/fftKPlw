/*    */ package cn.handyplus.warp.api;
/*    */ 
/*    */ import cn.handyplus.warp.constants.WarpConstants;
/*    */ import cn.handyplus.warp.enter.WarpPlayer;
/*    */ import cn.handyplus.warp.param.CreateFlagParam;
/*    */ import cn.handyplus.warp.service.WarpPlayerService;
/*    */ import java.util.Optional;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerWarpApi
/*    */ {
/*    */   public static UUID getWarpOwnerPlayer(Integer warpId) {
/* 32 */     return getWarpInfo(warpId).<UUID>map(WarpPlayer::getPlayerUuid).orElse(null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Optional<WarpPlayer> getWarpInfo(Integer warpId) {
/* 43 */     return WarpPlayerService.getInstance().findById(warpId);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void setCreateFlag(Player player, boolean createFlag, String tipMsg) {
/* 55 */     CreateFlagParam createFlagParam = CreateFlagParam.builder().createFlag(createFlag).tipMsg(tipMsg).build();
/* 56 */     WarpConstants.CREATE_FLAG.put(player.getUniqueId(), createFlagParam);
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\api\PlayerWarpApi.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */