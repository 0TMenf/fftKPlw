/*    */ package cn.handyplus.warp.param;
/*    */ 
/*    */ import lombok.Generated;
/*    */ 
/*    */ public class OpenParam
/*    */ {
/*    */   private Boolean isCollection;
/*    */   private String searchType;
/*    */   private Integer price;
/*    */   
/*    */   @Generated
/*    */   public void setIsCollection(Boolean isCollection) {
/* 13 */     this.isCollection = isCollection; } @Generated public void setSearchType(String searchType) { this.searchType = searchType; } @Generated public void setPrice(Integer price) { this.price = price; } @Generated
/* 14 */   OpenParam(Boolean isCollection, String searchType, Integer price) { this.isCollection = isCollection; this.searchType = searchType; this.price = price; } @Generated public static OpenParamBuilder builder() { return new OpenParamBuilder(); } @Generated public static class OpenParamBuilder { @Generated private Boolean isCollection; @Generated public OpenParamBuilder isCollection(Boolean isCollection) { this.isCollection = isCollection; return this; } @Generated private String searchType; @Generated private Integer price; @Generated public OpenParamBuilder searchType(String searchType) { this.searchType = searchType; return this; } @Generated public OpenParamBuilder price(Integer price) { this.price = price; return this; } @Generated public OpenParam build() { return new OpenParam(this.isCollection, this.searchType, this.price); } @Generated public String toString() { return "OpenParam.OpenParamBuilder(isCollection=" + this.isCollection + ", searchType=" + this.searchType + ", price=" + this.price + ")"; }
/*    */      }
/*    */   
/*    */   @Generated
/*    */   public Boolean getIsCollection() {
/* 19 */     return this.isCollection;
/*    */   }
/*    */   
/*    */   @Generated
/*    */   public String getSearchType() {
/* 24 */     return this.searchType;
/*    */   }
/*    */   
/*    */   @Generated
/*    */   public Integer getPrice() {
/* 29 */     return this.price;
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\param\OpenParam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */