/*    */ package cn.handyplus.warp.param;
/*    */ 
/*    */ import lombok.Generated;
/*    */ 
/*    */ public class CreateFlagParam
/*    */ {
/*    */   private boolean createFlag;
/*    */   private String tipMsg;
/*    */   
/*    */   @Generated
/*    */   public void setCreateFlag(boolean createFlag) {
/* 12 */     this.createFlag = createFlag; } @Generated public void setTipMsg(String tipMsg) { this.tipMsg = tipMsg; } @Generated
/* 13 */   CreateFlagParam(boolean createFlag, String tipMsg) { this.createFlag = createFlag; this.tipMsg = tipMsg; } @Generated public static CreateFlagParamBuilder builder() { return new CreateFlagParamBuilder(); } @Generated public static class CreateFlagParamBuilder { @Generated private boolean createFlag; @Generated public CreateFlagParamBuilder createFlag(boolean createFlag) { this.createFlag = createFlag; return this; } @Generated private String tipMsg; @Generated public CreateFlagParamBuilder tipMsg(String tipMsg) { this.tipMsg = tipMsg; return this; } @Generated public CreateFlagParam build() { return new CreateFlagParam(this.createFlag, this.tipMsg); } @Generated public String toString() { return "CreateFlagParam.CreateFlagParamBuilder(createFlag=" + this.createFlag + ", tipMsg=" + this.tipMsg + ")"; }
/*    */      }
/*    */   
/*    */   @Generated
/*    */   public boolean isCreateFlag() {
/* 18 */     return this.createFlag;
/*    */   }
/*    */   @Generated
/*    */   public String getTipMsg() {
/* 22 */     return this.tipMsg;
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\param\CreateFlagParam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */