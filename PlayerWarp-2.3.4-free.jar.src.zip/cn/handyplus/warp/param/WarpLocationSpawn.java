/*    */ package cn.handyplus.warp.param;
/*    */ 
/*    */ 
/*    */ public class WarpLocationSpawn {
/*    */   private double x;
/*    */   private double y;
/*    */   private double z;
/*    */   
/*    */   @Generated
/* 10 */   public void setX(double x) { this.x = x; } private float yaw; private float pitch; private String world; @Generated public void setY(double y) { this.y = y; } @Generated public void setZ(double z) { this.z = z; } @Generated public void setYaw(float yaw) { this.yaw = yaw; } @Generated public void setPitch(float pitch) { this.pitch = pitch; } @Generated public void setWorld(String world) { this.world = world; } @Generated public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof WarpLocationSpawn)) return false;  WarpLocationSpawn other = (WarpLocationSpawn)o; if (!other.canEqual(this)) return false;  if (Double.compare(getX(), other.getX()) != 0) return false;  if (Double.compare(getY(), other.getY()) != 0) return false;  if (Double.compare(getZ(), other.getZ()) != 0) return false;  if (Float.compare(getYaw(), other.getYaw()) != 0) return false;  if (Float.compare(getPitch(), other.getPitch()) != 0) return false;  Object this$world = getWorld(), other$world = other.getWorld(); return !((this$world == null) ? (other$world != null) : !this$world.equals(other$world)); } @Generated protected boolean canEqual(Object other) { return other instanceof WarpLocationSpawn; } @Generated public int hashCode() { int PRIME = 59; result = 1; long $x = Double.doubleToLongBits(getX()); result = result * 59 + (int)($x >>> 32L ^ $x); long $y = Double.doubleToLongBits(getY()); result = result * 59 + (int)($y >>> 32L ^ $y); long $z = Double.doubleToLongBits(getZ()); result = result * 59 + (int)($z >>> 32L ^ $z); result = result * 59 + Float.floatToIntBits(getYaw()); result = result * 59 + Float.floatToIntBits(getPitch()); Object $world = getWorld(); return result * 59 + (($world == null) ? 43 : $world.hashCode()); } @Generated public String toString() { return "WarpLocationSpawn(x=" + getX() + ", y=" + getY() + ", z=" + getZ() + ", yaw=" + getYaw() + ", pitch=" + getPitch() + ", world=" + getWorld() + ")"; }
/*    */   @Generated
/* 12 */   public double getX() { return this.x; } @Generated
/* 13 */   public double getY() { return this.y; } @Generated
/* 14 */   public double getZ() { return this.z; } @Generated
/* 15 */   public float getYaw() { return this.yaw; } @Generated
/* 16 */   public float getPitch() { return this.pitch; } @Generated
/* 17 */   public String getWorld() { return this.world; }
/*    */ 
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\param\WarpLocationSpawn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */