/*    */ package cn.handyplus.warp.hook;
/*    */ 
/*    */ import cn.handyplus.warp.PlayerWarp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WorldUtil
/*    */ {
/*    */   public static String getAlias(String worldName) {
/* 23 */     if (PlayerWarp.USE_MV_5) {
/* 24 */       return MultiverseUtil.getAlias(worldName);
/*    */     }
/* 26 */     if (PlayerWarp.USE_MV_4) {
/* 27 */       return MultiverseLegacyUtil.getAlias(worldName);
/*    */     }
/* 29 */     return worldName;
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\hook\WorldUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */