/*    */ package cn.handyplus.warp.hook;
/*    */ 
/*    */ import cn.handyplus.warp.PlayerWarp;
/*    */ import cn.handyplus.warp.lib.BaseUtil;
/*    */ import cn.handyplus.warp.lib.HookPluginEnum;
/*    */ import cn.handyplus.warp.lib.MessageUtil;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerPointsUtil
/*    */ {
/*    */   public static boolean take(Player player, int price) {
/* 28 */     if (PlayerWarp.PLAYER_POINTS == null) {
/* 29 */       MessageUtil.sendMessage(player, BaseUtil.getLangMsg(HookPluginEnum.PLAYER_POINTS.getFailMsg()));
/* 30 */       return false;
/*    */     } 
/*    */     
/* 33 */     return PlayerWarp.PLAYER_POINTS.getAPI().take(player.getUniqueId(), price);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int look(Player player) {
/* 43 */     if (PlayerWarp.PLAYER_POINTS == null || player == null) {
/* 44 */       return 0;
/*    */     }
/* 46 */     return PlayerWarp.PLAYER_POINTS.getAPI().look(player.getUniqueId());
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\hook\PlayerPointsUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */