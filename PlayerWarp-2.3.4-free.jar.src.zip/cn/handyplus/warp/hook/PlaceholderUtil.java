/*    */ package cn.handyplus.warp.hook;
/*    */ 
/*    */ import cn.handyplus.warp.PlayerWarp;
/*    */ import cn.handyplus.warp.service.WarpPlayerService;
/*    */ import me.clip.placeholderapi.expansion.PlaceholderExpansion;
/*    */ import org.bukkit.OfflinePlayer;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlaceholderUtil
/*    */   extends PlaceholderExpansion
/*    */ {
/*    */   private final PlayerWarp plugin;
/*    */   
/*    */   public PlaceholderUtil(PlayerWarp plugin) {
/* 18 */     this.plugin = plugin;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public String getIdentifier() {
/* 28 */     return "playerWarp";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String onRequest(OfflinePlayer player, @NotNull String placeholder) {
/* 41 */     if ("num".equals(placeholder)) {
/* 42 */       Integer count = WarpPlayerService.getInstance().findCount(player.getUniqueId(), null, null, null);
/* 43 */       return count.toString();
/*    */     } 
/* 45 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean persist() {
/* 56 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean canRegister() {
/* 67 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public String getAuthor() {
/* 77 */     return this.plugin.getDescription().getAuthors().toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @NotNull
/*    */   public String getVersion() {
/* 87 */     return this.plugin.getDescription().getVersion();
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\hook\PlaceholderUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */