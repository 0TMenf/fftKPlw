/*    */ package cn.handyplus.warp.hook;
/*    */ 
/*    */ import cn.handyplus.warp.PlayerWarp;
/*    */ import cn.handyplus.warp.lib.BaseUtil;
/*    */ import org.bukkit.OfflinePlayer;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VaultUtil
/*    */ {
/*    */   public static boolean take(Player player, int price) {
/* 28 */     if (PlayerWarp.ECON == null) {
/* 29 */       player.sendMessage(BaseUtil.getLangMsg("vaultFailureMsg"));
/* 30 */       return false;
/*    */     } 
/*    */     
/* 33 */     if (!PlayerWarp.ECON.has((OfflinePlayer)player, price)) {
/* 34 */       return false;
/*    */     }
/* 36 */     PlayerWarp.ECON.withdrawPlayer((OfflinePlayer)player, price);
/* 37 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void give(OfflinePlayer offlinePlayer, int price) {
/* 48 */     if (PlayerWarp.ECON == null || offlinePlayer == null) {
/*    */       return;
/*    */     }
/* 51 */     PlayerWarp.ECON.depositPlayer(offlinePlayer, price);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static double look(Player player) {
/* 61 */     if (PlayerWarp.ECON == null || player == null) {
/* 62 */       return 0.0D;
/*    */     }
/* 64 */     return PlayerWarp.ECON.getBalance((OfflinePlayer)player);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int lookToInt(Player player) {
/* 74 */     return (int)look(player);
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\hook\VaultUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */