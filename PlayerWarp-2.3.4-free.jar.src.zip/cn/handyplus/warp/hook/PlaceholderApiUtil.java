/*    */ package cn.handyplus.warp.hook;
/*    */ 
/*    */ import cn.handyplus.warp.PlayerWarp;
/*    */ import java.util.List;
/*    */ import me.clip.placeholderapi.PlaceholderAPI;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlaceholderApiUtil
/*    */ {
/*    */   public static String set(Player player, String str) {
/* 28 */     if (!PlayerWarp.USE_PAPI || player == null) {
/* 29 */       return str;
/*    */     }
/*    */     
/* 32 */     if (PlaceholderAPI.containsPlaceholders(str)) {
/* 33 */       return PlaceholderAPI.setPlaceholders(player, str);
/*    */     }
/* 35 */     return str;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static List<String> set(Player player, List<String> strList) {
/* 46 */     if (!PlayerWarp.USE_PAPI || player == null) {
/* 47 */       return strList;
/*    */     }
/* 49 */     return PlaceholderAPI.setPlaceholders(player, strList);
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\hook\PlaceholderApiUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */