/*    */ package cn.handyplus.warp.hook;
/*    */ 
/*    */ import cn.handyplus.warp.lib.HookPluginEnum;
/*    */ import cn.handyplus.warp.lib.HookPluginUtil;
/*    */ import cn.handyplus.warp.lib.StrUtil;
/*    */ import com.onarandombox.MultiverseCore.MultiverseCore;
/*    */ import com.onarandombox.MultiverseCore.api.MVWorldManager;
/*    */ import com.onarandombox.MultiverseCore.api.MultiverseWorld;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultiverseLegacyUtil
/*    */ {
/*    */   private static MultiverseCore MULTIVERSE_CORE;
/*    */   
/*    */   public static void init() {
/* 23 */     HookPluginUtil.hookToPlugin(HookPluginEnum.MULTIVERSE_CORE, Integer.valueOf(4)).ifPresent(value -> MULTIVERSE_CORE = (MultiverseCore)value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getAlias(String worldName) {
/* 33 */     MVWorldManager mvWorldManager = MULTIVERSE_CORE.getMVWorldManager();
/* 34 */     MultiverseWorld mvWorld = mvWorldManager.getMVWorld(worldName);
/* 35 */     if (mvWorld != null && StrUtil.isNotEmpty(mvWorld.getAlias())) {
/* 36 */       return mvWorld.getAlias();
/*    */     }
/* 38 */     return worldName;
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\hook\MultiverseLegacyUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */