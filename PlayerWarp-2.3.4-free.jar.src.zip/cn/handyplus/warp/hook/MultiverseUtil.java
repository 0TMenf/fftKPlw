/*    */ package cn.handyplus.warp.hook;
/*    */ 
/*    */ import cn.handyplus.warp.lib.StrUtil;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.World;
/*    */ import org.mvplugins.multiverse.core.MultiverseCoreApi;
/*    */ import org.mvplugins.multiverse.core.world.MultiverseWorld;
/*    */ import org.mvplugins.multiverse.core.world.WorldManager;
/*    */ import org.mvplugins.multiverse.external.vavr.control.Option;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultiverseUtil
/*    */ {
/*    */   protected static String getAlias(String worldName) {
/* 28 */     if (StrUtil.isEmpty(worldName)) {
/* 29 */       return worldName;
/*    */     }
/* 31 */     World world = Bukkit.getWorld(worldName);
/* 32 */     if (world == null) {
/* 33 */       return worldName;
/*    */     }
/* 35 */     WorldManager worldManager = MultiverseCoreApi.get().getWorldManager();
/* 36 */     Option<MultiverseWorld> mvWorldOpt = worldManager.getWorld(worldName);
/* 37 */     if (mvWorldOpt.isEmpty()) {
/* 38 */       return worldName;
/*    */     }
/* 40 */     MultiverseWorld multiverseWorld = (MultiverseWorld)mvWorldOpt.get();
/* 41 */     return StrUtil.isEmpty(multiverseWorld.getAlias()) ? worldName : multiverseWorld.getAlias();
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\hook\MultiverseUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */