/*    */ package cn.handyplus.warp.hook;
/*    */ 
/*    */ import cn.handyplus.currency.api.PlayerCurrencyApi;
/*    */ import cn.handyplus.warp.PlayerWarp;
/*    */ import cn.handyplus.warp.lib.StrUtil;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerCurrencyUtil
/*    */ {
/*    */   public static boolean take(Player player, String type, long price, String operatorReason) {
/* 29 */     return take(player.getUniqueId(), type, price, operatorReason);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean take(UUID playerUuid, String type, long price, String operatorReason) {
/* 41 */     if (!PlayerWarp.USE_PLY) {
/* 42 */       return false;
/*    */     }
/*    */     
/* 45 */     return PlayerCurrencyApi.take(playerUuid, type, Long.valueOf(price), PlayerWarp.INSTANCE.getName(), operatorReason);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Long look(Player player, String type) {
/* 55 */     if (!PlayerWarp.USE_PLY || player == null || StrUtil.isEmpty(type)) {
/* 56 */       return Long.valueOf(0L);
/*    */     }
/* 58 */     return PlayerCurrencyApi.look(player.getUniqueId(), type);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getDesc(String type) {
/* 68 */     if (!PlayerWarp.USE_PLY || StrUtil.isEmpty(type)) {
/* 69 */       return type;
/*    */     }
/* 71 */     return PlayerCurrencyApi.getDesc(type);
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\hook\PlayerCurrencyUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */