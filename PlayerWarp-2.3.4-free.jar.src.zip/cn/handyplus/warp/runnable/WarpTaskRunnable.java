/*     */ package cn.handyplus.warp.runnable;
/*     */ 
/*     */ import cn.handyplus.warp.constants.WarpConstants;
/*     */ import cn.handyplus.warp.enter.WarpPlayer;
/*     */ import cn.handyplus.warp.enter.WarpTpPlayer;
/*     */ import cn.handyplus.warp.lib.BaseConstants;
/*     */ import cn.handyplus.warp.lib.DateUtil;
/*     */ import cn.handyplus.warp.lib.HandyRunnable;
/*     */ import cn.handyplus.warp.lib.HandySchedulerUtil;
/*     */ import cn.handyplus.warp.lib.Page;
/*     */ import cn.handyplus.warp.service.WarpPlayerService;
/*     */ import cn.handyplus.warp.service.WarpTpPlayerService;
/*     */ import cn.handyplus.warp.util.WarpUtil;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Optional;
/*     */ import lombok.Generated;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WarpTaskRunnable
/*     */   extends HandyRunnable
/*     */ {
/*     */   private final WarpPlayer j;
/*     */   private final Player oOOOoO;
/*     */   
/*     */   public void run() {
/* 183 */     if (WarpConstants.DELAY_TIME.get(this.oOOOoO.getUniqueId()) != null && ((Boolean)WarpConstants.DELAY_TIME.get(this.oOOOoO.getUniqueId())).booleanValue()) {
/*     */       cancel();
/*     */       return;
/*     */     } 
/*     */     WarpUtil.tpWarpLocation(this.oOOOoO, this.j);
/*     */     WarpConstants.WAIT_TIME.put(this.oOOOoO.getUniqueId(), Long.valueOf(System.currentTimeMillis()));
/*     */     HandySchedulerUtil.runTaskAsynchronously(() -> PpPppP(this.oOOOoO, this.j.getId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public WarpTaskRunnable(Player player, WarpPlayer warpPlayer) {
/* 209 */     this.oOOOoO = player; this.j = warpPlayer;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\runnable\WarpTaskRunnable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */