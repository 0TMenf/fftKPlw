/*    */ package cn.handyplus.warp.util;
/*    */ 
/*    */ import cn.handyplus.warp.lib.BaseConstants;
/*    */ import cn.handyplus.warp.lib.DateUtil;
/*    */ import cn.handyplus.warp.lib.HandyConfigUtil;
/*    */ import cn.handyplus.warp.lib.HandySchedulerUtil;
/*    */ import cn.handyplus.warp.lib.JsonUtil;
/*    */ import cn.handyplus.warp.lib.SecureUtil;
/*    */ import cn.handyplus.warp.service.WarpChannelService;
/*    */ import cn.handyplus.warp.service.WarpCollectionService;
/*    */ import cn.handyplus.warp.service.WarpLikePlayerService;
/*    */ import cn.handyplus.warp.service.WarpPlayerService;
/*    */ import cn.handyplus.warp.service.WarpWhiteListService;
/*    */ import java.util.Date;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BackUpUtil
/*    */ {
/*    */   public static void init() {
/* 61 */     HandySchedulerUtil.runTaskTimerAsynchronously(() -> { if (!BaseConstants.CONFIG.getBoolean(WarpLikePlayerService.qzlKeO("\000\016\001\0047\037"))) return;  String str = DateUtil.format(new Date(), "HH:mm"); if (!BaseConstants.CONFIG.getString(SecureUtil.qzlKeO("[GZMlVmOTC"), "00:00").equals(str)) return;  iiIIiI(); }1200L, 1200L);
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\war\\util\BackUpUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */