/*     */ package cn.handyplus.warp.util;
/*     */ 
/*     */ import cn.handyplus.warp.lib.HandyConfigUtil;
/*     */ import cn.handyplus.warp.lib.HandyHttpUtil;
/*     */ import cn.handyplus.warp.service.WarpChannelService;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigUtil
/*     */ {
/*     */   public static FileConfiguration CONFIRM_CONFIG;
/*     */   public static FileConfiguration VIEW_CONFIG;
/*     */   public static FileConfiguration CREATE_CONFIG;
/*     */   public static FileConfiguration VIEW_ADMIN_CONFIG;
/*     */   public static FileConfiguration ADMIN_CONFIG;
/*     */   public static FileConfiguration ME_CONFIG;
/*     */   public static FileConfiguration LIKE_CONFIG;
/*     */   public static FileConfiguration SELECT_CONFIG;
/*     */   public static FileConfiguration OPEN_CONFIG;
/*     */   
/*     */   public static void init() {
/* 202 */     OPEN_CONFIG = HandyConfigUtil.load(WarpChannelService.qzlKeO("i\\g\006aYkG PcE"));
/*     */     ME_CONFIG = HandyConfigUtil.load(HandyHttpUtil.qzlKeO("$U*\017.EmY.L"));
/*     */     CREATE_CONFIG = HandyConfigUtil.load(WarpChannelService.qzlKeO("i\\g\006m[kHzL PcE"));
/*     */     LIKE_CONFIG = HandyConfigUtil.load(HandyHttpUtil.qzlKeO("$U*\017/I(EmY.L"));
/*     */     ADMIN_CONFIG = HandyConfigUtil.load(WarpChannelService.qzlKeO("N{@!HjDgG PcE"));
/*     */     VIEW_CONFIG = HandyConfigUtil.load(HandyHttpUtil.qzlKeO("$U*\0175I&WmY.L"));
/*     */     VIEW_ADMIN_CONFIG = HandyConfigUtil.load(WarpChannelService.qzlKeO("i\\g\006x@k^QHjDgG PcE"));
/*     */     SELECT_CONFIG = HandyConfigUtil.load(HandyHttpUtil.qzlKeO("$U*\0170E/E TmY.L"));
/*     */     CONFIRM_CONFIG = HandyConfigUtil.load(WarpChannelService.qzlKeO("N{@!JaGh@|D PcE"));
/*     */     pPPPpP();
/*     */     HandyConfigUtil.loadLangConfig(true);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\war\\util\ConfigUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */