/*    */ package cn.handyplus.warp.util;
/*    */ 
/*    */ import cn.handyplus.warp.lib.BaseConstants;
/*    */ import cn.handyplus.warp.lib.DateUtil;
/*    */ import cn.handyplus.warp.lib.HandySchedulerUtil;
/*    */ import cn.handyplus.warp.lib.InventoryViewUtil;
/*    */ import cn.handyplus.warp.lib.MessageUtil;
/*    */ import cn.handyplus.warp.lib.NumberUtil;
/*    */ import cn.handyplus.warp.service.WarpPlayerService;
/*    */ import java.time.LocalDateTime;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WarpTaskUtil
/*    */ {
/*    */   public static void init() {
/* 51 */     HandySchedulerUtil.runTaskTimerAsynchronously(() -> { if (!NumberUtil.qzlKeO("|f").equals(LocalDateTime.now().format(DateTimeFormatter.ofPattern(InventoryViewUtil.qzlKeO("T "))))) return;  I(); l(); h(); }1200L, 72000L);
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\war\\util\WarpTaskUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */