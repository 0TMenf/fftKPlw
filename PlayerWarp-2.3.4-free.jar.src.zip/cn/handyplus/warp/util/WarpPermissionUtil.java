/*     */ package cn.handyplus.warp.util;
/*     */ 
/*     */ import cn.handyplus.warp.lib.BaseConstants;
/*     */ import cn.handyplus.warp.lib.RgbTextUtil;
/*     */ import cn.handyplus.warp.service.WarpCollectionService;
/*     */ import java.util.Iterator;
/*     */ import org.bukkit.configuration.ConfigurationSection;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WarpPermissionUtil
/*     */ {
/*     */   public static long getDelayTime(Player a) {
/*  31 */     long l = BaseConstants.CONFIG.getLong(RgbTextUtil.qzlKeO("X$P E\025U,YoX$Z I-H"), 3L);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ConfigurationSection configurationSection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  54 */     if ((configurationSection = BaseConstants.CONFIG.getConfigurationSection(WarpCollectionService.qzlKeO("R\"Z&O\023_*S"))) == null) {
/*     */       return l;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 186 */     Iterator<String> iterator = 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 210 */       configurationSection.getValues(false).keySet().iterator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/*     */       if (iterator.hasNext()) {
/*     */         String str = iterator.next();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 228 */         super(); if (!(new StringBuilder()).hasPermission(a.append(RgbTextUtil.qzlKeO("L-]8Y3k N1\022%Y-]8h(Q$\022")).append(str).toString()));
/*     */         long l1;
/*     */         if ((l1 = BaseConstants.CONFIG.getLong((new StringBuilder()).insert(0, WarpCollectionService.qzlKeO("#S+W>b.[\"\030")).append(str).toString())) < l)
/*     */           l = l1; 
/*     */       } 
/*     */       return l;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_2
/*     */     //   1: iconst_5
/*     */     //   2: ixor
/*     */     //   3: iconst_4
/*     */     //   4: ishl
/*     */     //   5: iconst_2
/*     */     //   6: dup
/*     */     //   7: ishl
/*     */     //   8: iconst_1
/*     */     //   9: ixor
/*     */     //   10: ixor
/*     */     //   11: iconst_4
/*     */     //   12: iconst_3
/*     */     //   13: ishl
/*     */     //   14: iconst_3
/*     */     //   15: ixor
/*     */     //   16: iconst_5
/*     */     //   17: iconst_3
/*     */     //   18: ishl
/*     */     //   19: iconst_1
/*     */     //   20: ixor
/*     */     //   21: aload_0
/*     */     //   22: checkcast java/lang/String
/*     */     //   25: dup
/*     */     //   26: astore_0
/*     */     //   27: invokevirtual length : ()I
/*     */     //   30: dup
/*     */     //   31: newarray char
/*     */     //   33: iconst_1
/*     */     //   34: dup
/*     */     //   35: pop2
/*     */     //   36: swap
/*     */     //   37: iconst_1
/*     */     //   38: isub
/*     */     //   39: dup_x2
/*     */     //   40: istore_3
/*     */     //   41: astore_1
/*     */     //   42: istore #4
/*     */     //   44: dup_x2
/*     */     //   45: pop
/*     */     //   46: istore_2
/*     */     //   47: pop
/*     */     //   48: iflt -> 88
/*     */     //   51: aload_1
/*     */     //   52: aload_0
/*     */     //   53: iload_3
/*     */     //   54: dup_x1
/*     */     //   55: invokevirtual charAt : (I)C
/*     */     //   58: iinc #3, -1
/*     */     //   61: iload_2
/*     */     //   62: ixor
/*     */     //   63: i2c
/*     */     //   64: castore
/*     */     //   65: iload_3
/*     */     //   66: iflt -> 88
/*     */     //   69: aload_1
/*     */     //   70: aload_0
/*     */     //   71: iload_3
/*     */     //   72: iinc #3, -1
/*     */     //   75: dup_x1
/*     */     //   76: invokevirtual charAt : (I)C
/*     */     //   79: iload #4
/*     */     //   81: ixor
/*     */     //   82: i2c
/*     */     //   83: castore
/*     */     //   84: iload_3
/*     */     //   85: goto -> 48
/*     */     //   88: new java/lang/String
/*     */     //   91: dup
/*     */     //   92: aload_1
/*     */     //   93: invokespecial <init> : ([C)V
/*     */     //   96: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	97	0	a	Ljava/lang/String;
/*     */   }
/*     */   
/*     */   public static long getWaitTime(Player a) {
/*     */     long l = BaseConstants.CONFIG.getLong(RgbTextUtil.qzlKeO("6](H\025U,YoX$Z I-H"), 60L);
/*     */     ConfigurationSection configurationSection;
/*     */     if ((configurationSection = BaseConstants.CONFIG.getConfigurationSection(WarpCollectionService.qzlKeO("0W.B\023_*S"))) == null)
/*     */       return l; 
/*     */     Iterator<String> iterator = configurationSection.getValues(false).keySet().iterator();
/*     */     while (true) {
/*     */       if (iterator.hasNext()) {
/*     */         String str = iterator.next();
/*     */         super();
/*     */         if (!(new StringBuilder()).hasPermission(a.append(RgbTextUtil.qzlKeO("1P E$N\026]3LoK U5h(Q$\022")).append(str).toString()));
/*     */         long l1;
/*     */         if ((l1 = BaseConstants.CONFIG.getLong((new StringBuilder()).insert(0, WarpCollectionService.qzlKeO("A&_3b.[\"\030")).append(str).toString())) < l)
/*     */           l = l1; 
/*     */         continue;
/*     */       } 
/*     */       break;
/*     */     } 
/*     */     return l;
/*     */   }
/*     */   
/*     */   public static Integer getWarpNumber(Player a) {
/*     */     int i = BaseConstants.CONFIG.getInt(RgbTextUtil.qzlKeO("6]3L\017I,^$NoX$Z I-H"), 10);
/*     */     ConfigurationSection configurationSection;
/*     */     if ((configurationSection = BaseConstants.CONFIG.getConfigurationSection(WarpCollectionService.qzlKeO("0W5F\tC*T\"D"))) == null)
/*     */       return Integer.valueOf(i); 
/*     */     Iterator<String> iterator = configurationSection.getValues(false).keySet().iterator();
/*     */     while (true) {
/*     */       if (iterator.hasNext()) {
/*     */         String str = iterator.next();
/*     */         super();
/*     */         if (!(new StringBuilder()).hasPermission(a.append(RgbTextUtil.qzlKeO("1P E$N\026]3LoR4Q#Y3\022")).append(str).toString()));
/*     */         int j;
/*     */         if ((j = BaseConstants.CONFIG.getInt((new StringBuilder()).insert(0, WarpCollectionService.qzlKeO("A&D7x2[%S5\030")).append(str).toString())) > i)
/*     */           i = j; 
/*     */         continue;
/*     */       } 
/*     */       return Integer.valueOf(i);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\war\\util\WarpPermissionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */