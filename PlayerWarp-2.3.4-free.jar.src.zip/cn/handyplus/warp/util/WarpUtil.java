/*     */ package cn.handyplus.warp.util;
/*     */ 
/*     */ import cn.handyplus.warp.constants.WarpConstants;
/*     */ import cn.handyplus.warp.constants.WarpTypeEnum;
/*     */ import cn.handyplus.warp.enter.WarpChannel;
/*     */ import cn.handyplus.warp.enter.WarpPlayer;
/*     */ import cn.handyplus.warp.event.WarpCreateSuccessEvent;
/*     */ import cn.handyplus.warp.event.WarpTpEvent;
/*     */ import cn.handyplus.warp.hook.VaultUtil;
/*     */ import cn.handyplus.warp.hook.WorldUtil;
/*     */ import cn.handyplus.warp.lib.BaseConstants;
/*     */ import cn.handyplus.warp.lib.BaseUtil;
/*     */ import cn.handyplus.warp.lib.BcUtil;
/*     */ import cn.handyplus.warp.lib.ClassUtil;
/*     */ import cn.handyplus.warp.lib.CollUtil;
/*     */ import cn.handyplus.warp.lib.DateUtil;
/*     */ import cn.handyplus.warp.lib.HandySchedulerUtil;
/*     */ import cn.handyplus.warp.lib.ItemStackUtil;
/*     */ import cn.handyplus.warp.lib.JsonUtil;
/*     */ import cn.handyplus.warp.lib.MapUtil;
/*     */ import cn.handyplus.warp.lib.MessageUtil;
/*     */ import cn.handyplus.warp.lib.NumberUtil;
/*     */ import cn.handyplus.warp.lib.StrUtil;
/*     */ import cn.handyplus.warp.param.CreateFlagParam;
/*     */ import cn.handyplus.warp.param.WarpLocationSpawn;
/*     */ import cn.handyplus.warp.service.WarpChannelService;
/*     */ import cn.handyplus.warp.service.WarpPlayerService;
/*     */ import cn.handyplus.warp.service.WarpWhiteListService;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Random;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.WorldCreator;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WarpUtil
/*     */ {
/*     */   public static boolean editPrice(Player a, String str, Integer integer1, Integer integer2) {
/*     */     Optional<?> optional;
/*  93 */     if (!(optional = WarpPlayerService.getInstance().findById(integer1)).isPresent())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 180 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     WarpPlayer warpPlayer = (WarpPlayer)optional.get();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Integer integer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 232 */     if ((integer = NumberUtil.isNumericToInt(str)) == null || integer.intValue() < 0) {
/*     */       MessageUtil.sendMessage(a, BaseUtil.getLangMsg(NumberUtil.qzlKeO("-;##\"\"\n7%:9$)\033?1")));
/*     */       return false;
/*     */     } 
/*     */     int i;
/*     */     if ((i = BaseConstants.CONFIG.getInt(ClassUtil.qzlKeO("\007A\022p\030I\tE"), 0)) > 0 && integer.intValue() > i) {
/*     */       MessageUtil.sendMessage(a, ConfigUtil.ADMIN_CONFIG.getString(NumberUtil.qzlKeO("!74\006>?/3\n7%:9$)\033?1"), "").replace(ClassUtil.qzlKeO("N[\032R\003C\017]"), i + ""));
/*     */       return false;
/*     */     } 
/*     */     if (!VaultUtil.take(a, integer2.intValue())) {
/*     */       MessageUtil.sendMessage(a, ConfigUtil.ADMIN_CONFIG.getString(NumberUtil.qzlKeO("\"9\016#8\"#8")));
/*     */       return true;
/*     */     } 
/*     */     warpPlayer.setPrice(integer);
/*     */     WarpPlayerService.getInstance().update(warpPlayer);
/*     */     MessageUtil.sendMessage(a, ConfigUtil.ADMIN_CONFIG.getString(ClassUtil.qzlKeO("O\001p\030I\tE(U\036T\005N"), "").replace(NumberUtil.qzlKeO("h-<$%5)+"), integer.toString()));
/*     */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean editDescription(Player a, String str, Integer integer1, Integer integer2) {
/*     */     if (!checkDescription(a, str)) {
/*     */       return false;
/*     */     }
/*     */     Optional<?> optional;
/*     */     if (!(optional = WarpPlayerService.getInstance().findById(integer1)).isPresent()) {
/*     */       return true;
/*     */     }
/*     */     if (!VaultUtil.take(a, integer2.intValue())) {
/*     */       MessageUtil.sendMessage(a, ConfigUtil.ADMIN_CONFIG.getString(NumberUtil.qzlKeO("\"9\016#8\"#8")));
/*     */       return true;
/*     */     } 
/*     */     WarpPlayer warpPlayer = (WarpPlayer)optional.get();
/*     */     warpPlayer.setDescription(str);
/*     */     WarpPlayerService.getInstance().update(warpPlayer);
/*     */     MessageUtil.sendMessage(a, ConfigUtil.ADMIN_CONFIG.getString(ClassUtil.qzlKeO("O\001d\017S\tR\003P\036I\005N(U\036T\005N"), ""));
/*     */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void adminEditName(Player a, String str, Integer integer) {
/*     */     Optional<?> optional;
/*     */     if (!(optional = WarpPlayerService.getInstance().findById(integer)).isPresent()) {
/*     */       return;
/*     */     }
/*     */     WarpPlayer warpPlayer = (WarpPlayer)optional.get();
/*     */     warpPlayer.setName(str);
/*     */     WarpPlayerService.getInstance().update(warpPlayer);
/*     */     MessageUtil.sendMessage(a, ConfigUtil.VIEW_ADMIN_CONFIG.getString(ClassUtil.qzlKeO("\005K$A\007E(U\036T\005N"), "").replace(NumberUtil.qzlKeO("r78-;)+"), str));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void adminEditDescription(Player a, String str, Integer integer) {
/*     */     Optional<?> optional;
/*     */     if (!(optional = WarpPlayerService.getInstance().findById(integer)).isPresent()) {
/*     */       return;
/*     */     }
/*     */     WarpPlayer warpPlayer = (WarpPlayer)optional.get();
/* 489 */     warpPlayer.setDescription(str);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 628 */     WarpPlayerService.getInstance().update(warpPlayer);
/*     */     MessageUtil.sendMessage(a, ConfigUtil.VIEW_ADMIN_CONFIG.getString(ClassUtil.qzlKeO("O\001d\017S\tR\003P\036I\005N(U\036T\005N"), ""));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean editName(Player a, String str, Integer integer1, Integer integer2) {
/*     */     if (!check(a, str)) {
/*     */       return false;
/*     */     }
/*     */     Optional<?> optional;
/*     */     if (!(optional = WarpPlayerService.getInstance().findById(integer1)).isPresent()) {
/*     */       return true;
/*     */     }
/*     */     if (!VaultUtil.take(a, integer2.intValue())) {
/*     */       MessageUtil.sendMessage(a, ConfigUtil.ADMIN_CONFIG.getString(ClassUtil.qzlKeO("\004O(U\036T\005N")));
/*     */     }
/*     */     WarpPlayer warpPlayer = (WarpPlayer)optional.get();
/*     */     warpPlayer.setName(str);
/*     */     WarpPlayerService.getInstance().update(warpPlayer);
/*     */     MessageUtil.sendMessage(a, ConfigUtil.ADMIN_CONFIG.getString(NumberUtil.qzlKeO("#=\0027!3\016#8\"#8"), "").replace(ClassUtil.qzlKeO("\004\021N\013M\017]"), str));
/*     */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean checkWarpNumber(Player a) {
/*     */     List list;
/* 677 */     if (CollUtil.isNotEmpty(list = BaseConstants.CONFIG.getStringList(ClassUtil.qzlKeO("\004O\036w\005R\006D"))) && list.contains(a.getWorld().getName())) {
/*     */       MessageUtil.sendMessage(a, BaseUtil.getLangMsg(NumberUtil.qzlKeO("8#\001#$ 2\017$)783"))); return true;
/*     */     }  int i = WarpPermissionUtil.getWarpNumber(a).intValue(); if (WarpPlayerService.getInstance().findCountByPlayerUuid(a.getUniqueId()).intValue() >= i) {
/*     */       String str = ConfigUtil.CREATE_CONFIG.getString(ClassUtil.qzlKeO("W\013R\032n\037M\bE\030m\031G"), "").replace(NumberUtil.qzlKeO("r789;.3>+"), i + ""); MessageUtil.sendMessage(a, str); return true;
/*     */     }  CreateFlagParam createFlagParam; if ((createFlagParam = (CreateFlagParam)WarpConstants.CREATE_FLAG.get(a.getUniqueId())) != null && !createFlagParam.isCreateFlag()) {
/*     */       MessageUtil.sendMessage(a, createFlagParam.getTipMsg()); return true;
/*     */     }  return false;
/*     */   }
/*     */   public static boolean addWarp(Player a, String str, Integer integer) { if (!check(a, str))
/*     */       return false;  String str1 = ItemStackUtil.itemStackSerialize(ItemStackUtil.getItemStack(BaseConstants.CONFIG.getString(ClassUtil.qzlKeO("D\017F\013U\006T&O\rO"), NumberUtil.qzlKeO("\027\034\006\000\023")))); WarpPlayer warpPlayer = new WarpPlayer(); warpPlayer.setPlayerName(a.getName()); warpPlayer.setPlayerUuid(a.getUniqueId()); warpPlayer.setName(str); warpPlayer.setType(WarpTypeEnum.ARCHITECT.getType()); warpPlayer.setLogoId(Integer.valueOf(-1)); warpPlayer.setLogoName(str1); warpPlayer.setPrice(Integer.valueOf(0)); warpPlayer.setServerName(BaseConstants.CONFIG.getString(ClassUtil.qzlKeO("\031E\030V\017R$A\007E"))); warpPlayer.setWorldName(a.getWorld().getName()); warpPlayer.setTpNumber(Integer.valueOf(0));
/*     */     warpPlayer.setThermalValue(Integer.valueOf(0));
/*     */     warpPlayer.setDisplay(Boolean.valueOf(BaseConstants.CONFIG.getBoolean(NumberUtil.qzlKeO("2%%<:-/"), true)));
/*     */     warpPlayer.setWarpLocation(getWarpLocationSpawn(a));
/*     */     super();
/*     */     (new Date()).setCreateTime((Date)warpPlayer);
/*     */     if (warpPlayer != null && integer.intValue() > 0) {
/*     */       warpPlayer.setExpirationTime(DateUtil.offset(warpPlayer.getCreateTime(), 12, integer.intValue()));
/*     */     } else {
/*     */       warpPlayer.setExpirationTime(DateUtil.getDate(Integer.valueOf(36500)));
/*     */     } 
/*     */     int i = WarpPlayerService.getInstance().add(warpPlayer);
/*     */     MessageUtil.sendMessage(a, ConfigUtil.CREATE_CONFIG.getString(ClassUtil.qzlKeO("\tR\017A\036E9U\tC\017E\016m\031G")));
/*     */     if (StrUtil.isNotEmpty(str1 = ConfigUtil.CREATE_CONFIG.getString(NumberUtil.qzlKeO("5>3-\")\00595/3)2\r: \033?1"))))
/*     */       MessageUtil.sendAllMessage(str1 = str1.replace(ClassUtil.qzlKeO("\004\021P\006A\023E\030]"), a.getName()).replace(NumberUtil.qzlKeO("r78-;)+"), str)); 
/*     */     WarpCreateSuccessEvent.callBuffEvent(a, Integer.valueOf(i));
/*     */     PppppP(a, Integer.valueOf(i));
/*     */     return true; }
/*     */   public static String getLocationDesc(String a) { WarpLocationSpawn warpLocationSpawn = (WarpLocationSpawn)JsonUtil.toBean(a, WarpLocationSpawn.class);
/*     */     return (new StringBuilder()).insert(0, WorldUtil.getAlias(warpLocationSpawn.getWorld())).append(ClassUtil.qzlKeO("\f")).append((int)warpLocationSpawn.getX()).append(NumberUtil.qzlKeO("z")).append((int)warpLocationSpawn.getY()).append(ClassUtil.qzlKeO("\f")).append((int)warpLocationSpawn.getZ()).toString(); }
/*     */   public static void executionCommand(Player a, String str1, String str2, String str3, String str4) { List list;
/*     */     if (CollUtil.isEmpty(list = BaseConstants.CONFIG.getStringList(str1)))
/*     */       return; 
/*     */     Iterator<?> iterator;
/*     */     while ((iterator = list.iterator()).hasNext()) {
/*     */       String str;
/*     */       if (StrUtil.isEmpty(str = (String)iterator.next()));
/*     */       str = (str = (str = (str = str.replace(NumberUtil.qzlKeO("r7& 753>+"), a.getName())).replace(ClassUtil.qzlKeO("\004\021N\013M\017]"), str2)).replace(NumberUtil.qzlKeO("h-;9>:(+"), str3)).replace(ClassUtil.qzlKeO("\004\021W\013R\032p\006A\023E\030]"), str4);
/*     */     }  } public static void runTaskTpLocalWarpLocation(Player a, String str1, String str2, String str3) { HandySchedulerUtil.runTask(() -> OoOOOO(a, str1, str2, str3)); } public static void adminEditPrice(Player a, String str, Integer integer) { Optional<?> optional;
/*     */     if (!(optional = WarpPlayerService.getInstance().findById(integer)).isPresent())
/*     */       return; 
/*     */     WarpPlayer warpPlayer = (WarpPlayer)optional.get();
/*     */     Integer integer1;
/*     */     if ((integer1 = NumberUtil.isNumericToInt(str)) == null || integer1.intValue() < 0) {
/*     */       MessageUtil.sendMessage(a, BaseUtil.getLangMsg(NumberUtil.qzlKeO("-;##\"\"\n7%:9$)\033?1")));
/*     */       return;
/*     */     } 
/*     */     warpPlayer.setPrice(integer1);
/* 724 */     WarpPlayerService.getInstance().update(warpPlayer);
/*     */     MessageUtil.sendMessage(a, ConfigUtil.VIEW_ADMIN_CONFIG.getString(ClassUtil.qzlKeO("O\001p\030I\tE(U\036T\005N"), "").replace(NumberUtil.qzlKeO("h-<$%5)+"), integer1.toString())); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean check(Player a, String str) {
/*     */     int i = ConfigUtil.CREATE_CONFIG.getInt(ClassUtil.qzlKeO("\004A\007E&E\004G\036H"));
/*     */     if (ChatColor.stripColor(str).length() > i) {
/*     */       String str1 = ConfigUtil.CREATE_CONFIG.getString(NumberUtil.qzlKeO(" 3\"18>\n7%:9$)\033?1"), "").replace(ClassUtil.qzlKeO("\004\021L\017N\rT\002]"), i + "");
/*     */       MessageUtil.sendMessage(a, str1);
/*     */       return false;
/*     */     } 
/*     */     if ((str.contains(NumberUtil.qzlKeO("p")) || str.contains(ClassUtil.qzlKeO(""))) && !a.hasPermission(NumberUtil.qzlKeO("& 753>\001-$<x/$)783b5#:#$"))) {
/*     */       String str1 = ConfigUtil.CREATE_CONFIG.getString(ClassUtil.qzlKeO("C\005L\005R,A\003L\037R\017m\031G"), NumberUtil.qzlKeO("px伶泭束lp-v<:-/)$\0337>&b5>3-\")x/9 9>vjb朏阆朩前庶弿舾呛禼盒坼桑"));
/*     */       MessageUtil.sendMessage(a, str1);
/*     */       return false;
/*     */     } 
/*     */     List<?> list;
/*     */     for (String str1 : list = ConfigUtil.CREATE_CONFIG.getStringList(ClassUtil.qzlKeO("N\013M\017b\006A\tK&I\031T"))) {
/* 770 */       if (str.contains(str1)) {
/*     */         String str2 = ConfigUtil.CREATE_CONFIG.getString(NumberUtil.qzlKeO("8-;)\024 7/=\000??\"\n7%:9$)\033?1"), "").replace(ClassUtil.qzlKeO("\004\021N\013M\017]"), str1);
/*     */         MessageUtil.sendMessage(a, str2);
/*     */         return false;
/*     */       } 
/*     */     } 
/*     */     List list1;
/*     */     if (CollUtil.isNotEmpty(list1 = BaseConstants.CONFIG.getStringList(NumberUtil.qzlKeO("\"98\001#$ 2"))) && CollUtil.contains(list1, a.getWorld().getName())) {
/*     */       MessageUtil.sendMessage(a, ConfigUtil.CREATE_CONFIG.getString(ClassUtil.qzlKeO("N\005w\005R\006D(U\036T\005N")));
/*     */       return false;
/*     */     } 
/*     */     boolean bool;
/*     */     List list2;
/*     */     if ((bool = BaseConstants.CONFIG.getBoolean(NumberUtil.qzlKeO("\"7!3\0038 /"), true)) && CollUtil.isNotEmpty(list2 = WarpPlayerService.getInstance().findByName(str))) {
/*     */       str = ConfigUtil.CREATE_CONFIG.getString(ClassUtil.qzlKeO("\004A\007E%N\006Y,A\003L\037R\017m\031G"), "").replace(NumberUtil.qzlKeO("r78-;)+"), str);
/*     */       MessageUtil.sendMessage(a, str);
/*     */       return false;
/*     */     } 
/*     */     return true;
/*     */   }
/*     */   
/*     */   public static boolean checkDescription(Player a, String str) {
/*     */     int i = ConfigUtil.ADMIN_CONFIG.getInt(ClassUtil.qzlKeO("D\017S\tR\003P\036I\005N&E\004G\036H"), 16);
/*     */     if (ChatColor.stripColor(str).length() > i) {
/*     */       String str1 = ConfigUtil.ADMIN_CONFIG.getString(NumberUtil.qzlKeO("2)%/$%&8?#8\0003\"18>\n7%:9$)\033?1"), "").replace(ClassUtil.qzlKeO("\004\021L\017N\rT\002]"), i + "");
/*     */       MessageUtil.sendMessage(a, str1);
/*     */       return false;
/*     */     } 
/*     */     List<?> list;
/*     */     for (String str1 : list = ConfigUtil.CREATE_CONFIG.getStringList(NumberUtil.qzlKeO("8-;)\024 7/=\000??\""))) {
/*     */       if (str.contains(str1)) {
/*     */         str1 = ConfigUtil.ADMIN_CONFIG.getString(ClassUtil.qzlKeO("D\017S\tR\003P\036I\005N,A\003L\037R\017m\031G"), "").replace(NumberUtil.qzlKeO("r78-;)+"), str1);
/*     */         MessageUtil.sendMessage(a, str1);
/*     */         return false;
/*     */       } 
/*     */     } 
/*     */     return true;
/*     */   }
/*     */   
/*     */   public static boolean tpPriceCheck(Player a, WarpPlayer warpPlayer) {
/*     */     if (warpPlayer.getPrice().intValue() < 1)
/*     */       return true; 
/*     */     if (a.getUniqueId().equals(warpPlayer.getPlayerUuid()))
/*     */       return true; 
/*     */     return WarpWhiteListService.getInstance().findByWarpIdAndPlayerUuid(warpPlayer.getId(), a.getUniqueId()).isPresent();
/*     */   }
/*     */   
/*     */   public static void runTaskTpWarpLocation(Player a, WarpPlayer warpPlayer) {
/*     */     HandySchedulerUtil.runTask(() -> tpWarpLocation(a, warpPlayer));
/*     */   }
/*     */   
/*     */   public static String getWarpLocationSpawn(Player a) {
/*     */     Location location = a.getLocation();
/*     */     WarpLocationSpawn warpLocationSpawn = new WarpLocationSpawn();
/*     */     warpLocationSpawn.setX(location.getX());
/*     */     warpLocationSpawn.setY(location.getY());
/*     */     warpLocationSpawn.setZ(location.getZ());
/*     */     warpLocationSpawn.setYaw(location.getYaw());
/*     */     warpLocationSpawn.setPitch(location.getPitch());
/*     */     warpLocationSpawn.setWorld(((World)Objects.<World>requireNonNull(location.getWorld())).getName());
/*     */     return JsonUtil.toJson(warpLocationSpawn);
/*     */   }
/*     */   
/*     */   public static void runTaskTp(Player a, WarpPlayer warpPlayer) {
/*     */     HandySchedulerUtil.runTask(() -> I(a, warpPlayer));
/*     */   }
/*     */   
/*     */   public static boolean tpCheck(Player a, WarpPlayer warpPlayer) {
/*     */     if (warpPlayer.getExpirationTime() != null && warpPlayer.getExpirationTime().getTime() < System.currentTimeMillis()) {
/*     */       MessageUtil.sendMessage(a, BaseUtil.getLangMsg(NumberUtil.qzlKeO("8#\001-$<\033?1")));
/*     */       return false;
/*     */     } 
/*     */     long l = WarpPermissionUtil.getWaitTime(a);
/*     */     if (WarpConstants.WAIT_TIME.containsKey(a.getUniqueId())) {
/*     */       long l1;
/*     */       if ((l1 = (System.currentTimeMillis() - ((Long)WarpConstants.WAIT_TIME.get(a.getUniqueId())).longValue()) / 1000L) < l) {
/*     */         String str = BaseUtil.getLangMsg(ClassUtil.qzlKeO("\035A\003T>I\007E")).replace(NumberUtil.qzlKeO("r7!-?8\002%;)+"), String.valueOf(l - l1));
/*     */         MessageUtil.sendMessage(a, str);
/*     */         return false;
/*     */       } 
/*     */     } 
/*     */     boolean bool;
/*     */     if (bool = BaseConstants.CONFIG.getBoolean((new StringBuilder()).insert(0, ClassUtil.qzlKeO("P\017R\007I\031S\003O\004\016")).append(warpPlayer.getId()).toString())) {
/*     */       String str = (new StringBuilder()).insert(0, NumberUtil.qzlKeO("<:-/)$\0337>&b\"<x")).append(warpPlayer.getId()).toString();
/*     */       if (!a.hasPermission(str)) {
/*     */         String str1 = BaseUtil.getLangMsg(ClassUtil.qzlKeO("\004O>P:E\030M\003S\031I\005N")).replace(NumberUtil.qzlKeO("r7&)$!??%%9\"+"), str);
/*     */         MessageUtil.sendMessage(a, str1);
/*     */         return false;
/*     */       } 
/*     */     } 
/*     */     return true;
/*     */   }
/*     */   
/*     */   public static List<String> getDescription(String a) {
/*     */     ArrayList<String> arrayList = new ArrayList();
/*     */     if (StrUtil.isEmpty(a)) {
/*     */       arrayList.add(BaseUtil.getLangMsg(ClassUtil.qzlKeO("N\005T")));
/*     */       return arrayList;
/*     */     } 
/*     */     arrayList.addAll(StrUtil.strToStrList(a));
/*     */     return arrayList;
/*     */   }
/*     */   
/*     */   public static void tpWarpLocation(Player a, WarpPlayer warpPlayer) {
/*     */     String str = BaseConstants.CONFIG.getString(NumberUtil.qzlKeO("?3> )$\0027!3"));
/*     */     if (warpPlayer.getServerName().equalsIgnoreCase(str)) {
/*     */       OoOOOO(a, warpPlayer.getName(), warpPlayer.getWarpLocation(), warpPlayer.getWarpOffset());
/*     */       return;
/*     */     } 
/*     */     WarpChannel warpChannel = new WarpChannel();
/*     */     warpChannel.setPlayerName(a.getName());
/*     */     warpChannel.setPlayerUuid(a.getUniqueId());
/*     */     warpChannel.setWarpName(warpPlayer.getName());
/*     */     warpChannel.setServerName(warpPlayer.getServerName());
/*     */     warpChannel.setWarpLocation(warpPlayer.getWarpLocation());
/*     */     warpChannel.setWarpOffset(warpPlayer.getWarpOffset());
/*     */     WarpChannelService.getInstance().add(warpChannel);
/*     */     BcUtil.tpConnect(a, warpPlayer.getServerName());
/*     */   }
/*     */   
/*     */   public static Map<String, List<String>> getDescriptionMap(String a) {
/*     */     return MapUtil.of(NumberUtil.qzlKeO("2)%/$%&8?#8"), getDescription(a));
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\war\\util\WarpUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */