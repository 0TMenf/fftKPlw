/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HookPluginUtil
/*     */ {
/*     */   public static boolean hook(@NotNull HookPluginEnum hookPluginEnum) {
/*  35 */     return hook(hookPluginEnum, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hook(@NotNull HookPluginEnum hookPluginEnum, @Nullable Integer version, int isMsg) {
/*  54 */     return hookToPlugin(hookPluginEnum, version, isMsg).isPresent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Optional<Plugin> hookToPlugin(@NotNull HookPluginEnum hookPluginEnum, @Nullable Integer version) {
/*  79 */     return hookToPlugin(hookPluginEnum, version, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hook(@NotNull HookPluginEnum hookPluginEnum, @Nullable Integer version) {
/* 134 */     return hook(hookPluginEnum, version, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Optional<Plugin> hookToPlugin(@NotNull HookPluginEnum hookPluginEnum) {
/* 178 */     return hookToPlugin(hookPluginEnum, null, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Optional<Plugin> hookToPlugin(@NotNull HookPluginEnum hookPluginEnum, @Nullable Integer version, int isMsg) {
/*     */     Plugin plugin;
/* 220 */     Optional<T> optional = ((plugin = Bukkit.getPluginManager().getPlugin(hookPluginEnum.getName())) != null && plugin.isEnabled()) ? Optional.<T>of((T)plugin) : Optional.<T>empty();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (optional.isPresent() && version != null && BaseUtil.getFirstPluginVersion((Plugin)optional.get()) < version.intValue()) {
/*     */       optional = Optional.empty();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (isMsg != 0)
/* 233 */       MessageUtil.sendConsoleMessage(BaseUtil.getLangMsg(optional.isPresent() ? hookPluginEnum.getSuccessMsg() : hookPluginEnum.getFailMsg())); 
/*     */     return (Optional)optional;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\HookPluginUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */