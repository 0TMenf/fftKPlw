/*     */ package cn.handyplus.warp.lib;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ public final class LockUtil {
/*     */   public static void unTimeLock(UUID a) {
/*   8 */     j.remove(a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean tryPass(String a) {
/*  54 */     return (K.putIfAbsent(a, Boolean.TRUE) == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void unReentrantLock(String a) {
/*     */     ReentrantLock reentrantLock;
/*  72 */     if ((reentrantLock = oOoOoO.get(a)) == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  78 */     if (reentrantLock.isHeldByCurrentThread())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 203 */       reentrantLock.unlock();
/*     */     }
/*     */     oOoOoO.computeIfPresent(a, (a, reentrantLock) -> (!reentrantLock.isLocked() && !reentrantLock.hasQueuedThreads()) ? null : reentrantLock);
/*     */   }
/*     */ 
/*     */   
/* 209 */   private static final ConcurrentHashMap<String, Boolean> K = new ConcurrentHashMap<>();
/*     */   
/*     */   public static boolean timeLock(UUID a) {
/*     */     long l = System.currentTimeMillis();
/*     */     AtomicBoolean atomicBoolean = new AtomicBoolean(false);
/*     */     j.compute(a, (uUID, long_) -> {
/*     */           if (long_ == null || a - long_.longValue() >= 300L) {
/*     */             atomicBoolean.set(true);
/*     */             return Long.valueOf(a);
/*     */           } 
/*     */           return long_;
/*     */         });
/*     */     return atomicBoolean.get();
/*     */   }
/*     */   
/*     */   public static void reentrantLock(String a) {
/*     */     ((ReentrantLock)oOoOoO.computeIfAbsent(a, a -> new ReentrantLock(true))).lock();
/*     */   }
/*     */   
/*     */   private static final ConcurrentHashMap<UUID, Long> j = new ConcurrentHashMap<>();
/*     */   
/*     */   public static void done(String a) {
/*     */     K.remove(a);
/*     */   }
/*     */   
/*     */   private static final Map<String, ReentrantLock> oOoOoO = new ConcurrentHashMap<>();
/*     */   private static final long L = 300L;
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\LockUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */