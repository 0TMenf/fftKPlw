/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ public final class DateUtil {
/*     */   public static boolean isPerpetual(@NotNull Date date) {
/*   5 */     return (date.getTime() > 4733481600000L);
/*     */   }
/*     */   
/*     */   public static final String YYYY = "yyyy-MM-dd";
/*     */   public static final String HH_MM = "HH:mm";
/*     */   public static final String YYYY_HH = "yyyy-MM-dd HH:mm:ss";
/*     */   
/*     */   public static Date toDate(@NotNull LocalDateTime localDateTime) {
/*  13 */     return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
/*     */   }
/*     */   
/*  16 */   private static final ConcurrentHashMap<String, ThreadLocal<SimpleDateFormat>> j = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String ZERO = "00:00";
/*     */ 
/*     */   
/*     */   private static final int oOoooo = 64;
/*     */ 
/*     */ 
/*     */   
/*     */   public static Date getSunday() {
/*  28 */     Calendar calendar = Calendar.getInstance(Locale.CHINA);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 226 */     calendar.setFirstDayOfWeek(2); calendar.setTimeInMillis(getToday().getTime()); calendar.set(7, 1);
/*     */     return parse((new StringBuilder()).insert(0, format(calendar.getTime(), "yyyy-MM-dd")).append(WarpCollectionService.qzlKeO("\026u\005}\003~\fr\017")).toString(), "yyyy-MM-dd HH:mm:ss");
/*     */   } public static Date endOfDay(@NotNull Date date) {
/*     */     Calendar calendar = Calendar.getInstance();
/*     */     calendar.setTime(date);
/*     */     calendar.set(11, 23);
/*     */     calendar.set(12, 59);
/*     */     calendar.set(13, 59);
/*     */     calendar.set(14, 999);
/*     */     return calendar.getTime();
/*     */   } public static Date getDate(@NotNull Integer day) {
/*     */     Date date = new Date();
/*     */     GregorianCalendar gregorianCalendar = new GregorianCalendar();
/*     */     gregorianCalendar.setTime(date);
/*     */     gregorianCalendar.add(5, day.intValue());
/*     */     return gregorianCalendar.getTime();
/*     */   }
/*     */   public static Date parse(@NotNull String str, @NotNull String format) {
/*     */     SimpleDateFormat simpleDateFormat = iIIIiI(format);
/*     */     try {
/*     */       return simpleDateFormat.parse(str);
/*     */     } catch (ParseException parseException) {
/*     */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, WarpTpPlayerService.qzlKeO("sJqXf\013叒甴弁帓"), parseException);
/*     */       return null;
/*     */     } 
/*     */   }
/*     */   public static Date getTodayEnd() {
/*     */     return endOfDay(getToday());
/*     */   }
/*     */   public static int getDifferDay(@NotNull Long dateTime) {
/*     */     return (int)((System.currentTimeMillis() - dateTime.longValue()) / 86400000L);
/*     */   }
/* 258 */   public static Date addDate(@NotNull Date date, @NotNull Integer day) { return offset(date, 5, day.intValue()); } public static Integer dayOfWeekEnum(@NotNull Date date) { true;
/*     */     true[0] = Integer.valueOf(7);
/*     */     true[1] = Integer.valueOf(1);
/*     */     true[2] = Integer.valueOf(2);
/*     */     true[3] = Integer.valueOf(3);
/*     */     true[4] = Integer.valueOf(4);
/*     */     true[5] = Integer.valueOf(5);
/*     */     true[6] = Integer.valueOf(6);
/*     */     boolean bool = true;
/*     */     Calendar calendar = Calendar.getInstance();
/*     */     calendar.setTime(date);
/*     */     return bool[calendar.get(7) - 1]; }
/*     */   public static Date getToday() { return beginOfDay(new Date()); }
/*     */   public static Date getFirstDayOfMonth(@NotNull Date date) {
/* 272 */     return toDate(toLocalDateTime(date).withDayOfMonth(1).truncatedTo(ChronoUnit.DAYS));
/*     */   } public static Date beginOfDay(@NotNull Date date) {
/*     */     Calendar calendar = Calendar.getInstance();
/*     */     calendar.setTime(date);
/*     */     calendar.set(11, 0);
/*     */     calendar.set(12, 0);
/*     */     calendar.set(13, 0);
/*     */     calendar.set(14, 0);
/*     */     return calendar.getTime();
/*     */   } public static String format(@NotNull Date date, @NotNull String format) {
/*     */     return iIIIiI(format).format(date);
/*     */   } public static Date getMonday() {
/*     */     Calendar calendar = Calendar.getInstance(Locale.CHINA);
/*     */     calendar.setFirstDayOfWeek(2);
/*     */     calendar.setTimeInMillis(getToday().getTime());
/*     */     calendar.set(7, 2);
/*     */     return calendar.getTime();
/*     */   }
/*     */   public static Date getLastDayOfMonth() {
/* 291 */     return toDate(LocalDateTime.now().plusMonths(1L).withDayOfMonth(1).truncatedTo(ChronoUnit.DAYS).plus(-1L, ChronoUnit.MILLIS));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Date getFirstDayOfMonth() {
/* 413 */     return toDate(LocalDateTime.now().withDayOfMonth(1).truncatedTo(ChronoUnit.DAYS));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static Integer parseTime(@Nullable String timeStr) {
/* 422 */     if (StrUtil.isEmpty(timeStr))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 437 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 448 */     if (PatternUtil.DIGITS_ONLY.matcher(timeStr).matches())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 496 */       return Integer.valueOf(Integer.parseInt(timeStr));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Matcher matcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 703 */     if ((matcher = PatternUtil.TIME_WITH_UNIT.matcher(timeStr))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 758 */       .matches()) {
/*     */       int i;
/*     */       if ((i = Integer.parseInt(matcher.group(1))) <= 0)
/*     */         return Integer.valueOf(0); 
/*     */     } 
/*     */     return null;
/*     */   }
/*     */   
/*     */   public static long between(@NotNull Date dateOne, @NotNull Date dateTwo, @NotNull ChronoUnit unit) {
/*     */     return unit.between(toLocalDateTime(dateOne), toLocalDateTime(dateTwo));
/*     */   }
/*     */   
/*     */   public static Date getMonth(@NotNull Date date, int month) {
/*     */     Calendar calendar = Calendar.getInstance(Locale.CHINA);
/*     */     calendar.setFirstDayOfWeek(2);
/*     */     calendar.setTimeInMillis(date.getTime());
/*     */     calendar.set(5, month);
/*     */     return calendar.getTime();
/*     */   }
/*     */   
/*     */   public static Date offset(@NotNull Date date, int field, int offset) {
/*     */     Calendar calendar = Calendar.getInstance();
/*     */     calendar.setTime(date);
/*     */     calendar.add(field, offset);
/*     */     return calendar.getTime();
/*     */   }
/*     */   
/*     */   public static Date getLastDayOfMonth(@NotNull Date date) {
/*     */     return toDate(toLocalDateTime(date).plusMonths(1L).withDayOfMonth(1).truncatedTo(ChronoUnit.DAYS).plus(-1L, ChronoUnit.MILLIS));
/*     */   }
/*     */   
/*     */   public static long between(@NotNull Date dateOne, @NotNull Date dateTwo) {
/*     */     return between(dateOne, dateTwo, ChronoUnit.HOURS);
/*     */   }
/*     */   
/*     */   public static long toEpochSecond(@NotNull LocalDateTime localDateTime) {
/*     */     return localDateTime.toInstant(ZoneOffset.of(WarpTpPlayerService.qzlKeO("(\023"))).toEpochMilli();
/*     */   }
/*     */   
/*     */   public static Date getWeek(@NotNull Date date, int week) {
/*     */     if (++week > 7)
/*     */       week = 1; 
/*     */     Calendar calendar = Calendar.getInstance(Locale.CHINA);
/*     */     calendar.setFirstDayOfWeek(2);
/*     */     calendar.setTimeInMillis(date.getTime());
/*     */     calendar.set(7, week);
/*     */     return calendar.getTime();
/*     */   }
/*     */   
/*     */   public static LocalDateTime toLocalDateTime(@NotNull Date date) {
/*     */     return LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\DateUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */