/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ public final class HttpUtil {
/*     */   public static String get(String a, Map<String, String> map1, Map<String, String> map2) throws IOException {
/*   5 */     return PPpPpp(MessageUtil.qzlKeO("@zS"), (new StringBuilder()).insert(0, a).append(iiIiIi(map1)).toString(), "", "application/x-www-form-urlencoded;charset=utf-8", map2);
/*     */   }
/*     */ 
/*     */   
/*   9 */   private static Integer a = Integer.valueOf(10000);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String L = "application/x-www-form-urlencoded;charset=utf-8";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String K = "utf-8";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String j = "application/json; charset=utf-8";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String post(String a, String str1) throws IOException {
/*  31 */     return post(a, str1, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String post(String a, Map<String, String> map) throws IOException {
/*  56 */     return PPpPpp(MessageUtil.qzlKeO("oHlS"), a, iiIiIi(map), "application/x-www-form-urlencoded;charset=utf-8", null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String get(String a, Map<String, String> map) throws IOException {
/*  72 */     return get(a, map, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void downloadFile(String a, File file, String str1) throws IOException {
/* 129 */     HttpURLConnection httpURLConnection = (HttpURLConnection)(new URL(a)).openConnection();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 140 */     httpURLConnection.setConnectTimeout(HttpUtil.a.intValue()); httpURLConnection.setRequestProperty(Page.qzlKeO("vF~\016MDiMx"), MessageUtil.qzlKeO("rhEnSk^(\013)\017'\027dPjOfKn]kZ<\037JlNz'\n)\017<\037PVi[hHt\037Ik<\037CV`zK.")); InputStream inputStream; byte[] arrayOfByte = IFJufP(inputStream = httpURLConnection.getInputStream());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 155 */     if (!file.exists()) {
/*     */       boolean bool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 204 */       MessageUtil.sendConsoleDebugMessage(String.valueOf(bool = file.mkdir()));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     File file1 = new File(file + File.separator + str1);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     FileOutputStream fileOutputStream = new FileOutputStream(file1); fileOutputStream.write(arrayOfByte); fileOutputStream.close(); inputStream.close();
/* 216 */   } private static Integer OkDyhE = Integer.valueOf(10000); public static String get(String a) throws IOException { return PPpPpp(Page.qzlKeO("KfX"), a, "", "application/x-www-form-urlencoded;charset=utf-8", null); } public static String post(String a) throws IOException { return PPpPpp(Page.qzlKeO("sCpX"), a, "", "application/x-www-form-urlencoded;charset=utf-8", null); } public static void setTimeOut(Integer a, Integer integer1) { HttpUtil.a = a; OkDyhE = integer1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String post(String a, String str1, Map<String, String> map) throws IOException {
/* 224 */     return PPpPpp(MessageUtil.qzlKeO("oHlS"), a, str1, "application/json; charset=utf-8", map);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\HttpUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */