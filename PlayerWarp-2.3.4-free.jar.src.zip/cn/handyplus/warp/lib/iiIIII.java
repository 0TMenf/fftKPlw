/*   1 */ package cn.handyplus.warp.lib;public class iiIIII { public void IIiiii(ClickEvent.Action action, String str) { if (StrUtil.isEmpty(str)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 218 */     this.OooOoo = this.OooOoo.clickEvent(ClickEvent.clickEvent(action, str)); }
/* 219 */   private Component OooOoo; public static iiIIII PPPPpp() { return new iiIIII(); } public void xXxxXx() { Bukkit.getConsoleSender().sendMessage(iIIiII()); } public void l(String str) { IIiiii(ClickEvent.Action.COPY_TO_CLIPBOARD, str); } public void IiIIii(String str) { IIiiii(ClickEvent.Action.SUGGEST_COMMAND, str); }
/*     */ 
/*     */   
/*     */   public void iIiIii(Player player) {
/*     */     player.sendActionBar(iIIiII());
/*     */   }
/*     */   
/*     */   public Component iIIiII() {
/*     */     return this.OooOoo;
/*     */   }
/*     */   
/*     */   public void iIiIiI(CommandSender commandSender) {
/*     */     if (commandSender == null)
/*     */       return; 
/*     */     commandSender.sendMessage(this.OooOoo);
/*     */   }
/*     */   
/*     */   public void h(String str) {
/*     */     IIiiii(ClickEvent.Action.RUN_COMMAND, str);
/*     */   }
/*     */   
/*     */   public void KaUOHD(ItemStack itemStack) {
/*     */     if (itemStack == null)
/*     */       return; 
/*     */     this.OooOoo = this.OooOoo.hoverEvent((HoverEventSource)itemStack.asHoverEvent());
/*     */   }
/*     */   
/*     */   public void l() {
/*     */     Bukkit.getOnlinePlayers().forEach(this::iIiIii);
/*     */   }
/*     */   
/*     */   public void A(String str) {
/*     */     if (StrUtil.isEmpty(str))
/*     */       return; 
/*     */     Component component = ComponentUtil.parseColor(str);
/*     */     this.OooOoo = this.OooOoo.hoverEvent((HoverEventSource)HoverEvent.showText(component));
/*     */   }
/*     */   
/*     */   public void I(String str) {
/*     */     IIiiii(ClickEvent.Action.OPEN_URL, str);
/*     */   }
/*     */   
/*     */   public void oOOOoo(Component component) {
/*     */     if (component == null)
/*     */       return; 
/*     */     this.OooOoo = this.OooOoo.append(component);
/*     */   }
/*     */   
/*     */   public void I() {
/*     */     Bukkit.getOnlinePlayers().forEach(this::iIiIiI);
/*     */   }
/*     */   
/*     */   public iiIIII PPpppP(String str) {
/*     */     return XxxXXX(str, true);
/*     */   }
/*     */   
/*     */   public iiIIII XxxXXX(String str, int i) {
/*     */     this.OooOoo = (i != 0) ? ComponentUtil.parseColor(str) : (Component)Component.text(str);
/*     */     return this;
/*     */   } }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\iiIIII.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */