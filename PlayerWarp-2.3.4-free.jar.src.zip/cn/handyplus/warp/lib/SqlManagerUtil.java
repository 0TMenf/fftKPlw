/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import cn.handyplus.warp.lib.expand.zaxxer.hikari.HikariConfig;
/*     */ import cn.handyplus.warp.lib.expand.zaxxer.hikari.HikariDataSource;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.logging.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlManagerUtil
/*     */ {
/*     */   public static SqlManagerUtil getInstance() {
/*  26 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enableSql() {
/*  54 */     enableSql(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void xXXxxx(Connection connection, Boolean bool) {
/*  63 */     if (null != connection && null != bool)
/*     */ 
/*     */       
/*     */       try { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 113 */         connection.setAutoCommit(bool.booleanValue()); return; }
/*     */       catch (Exception exception) { InitApi.PLUGIN.getLogger().log(Level.SEVERE, HandySchedulerUtil.qzlKeO("kgswnAf[gn}Y}wsf:參甅弐帢"), exception); }
/*     */         } public void xxxxXx(Connection connection, PreparedStatement preparedStatement, ResultSet resultSet) { 
/* 116 */     try { if (resultSet != null) {
/*     */         resultSet.close();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 230 */       if (preparedStatement != null)
/* 231 */         preparedStatement.close();  if (connection != null && connection.getAutoCommit()) { connection.close(); return; }  } catch (SQLException sQLException) { InitApi.PLUGIN.getLogger().log(Level.SEVERE, BcUtil.qzlKeO("(\024$\013.+:\024k厩畔彺平"), sQLException); }
/*     */      }
/*     */ 
/*     */   
/*     */   public String oOOOOo() {
/*     */     if (BaseConstants.STORAGE_CONFIG == null)
/*     */       return DbTypeEnum.SQLite.getType(); 
/*     */     String str = BaseConstants.STORAGE_CONFIG.getString("storage-method");
/*     */     if (DbTypeEnum.MySQL.getType().equalsIgnoreCase(str))
/*     */       return DbTypeEnum.MySQL.getType(); 
/*     */     return DbTypeEnum.SQLite.getType();
/*     */   }
/*     */   
/*     */   public void enableSql(String str) {
/*     */     BaseConstants.STORAGE_CONFIG = HandyConfigUtil.load(HandySchedulerUtil.qzlKeO("ifu`{u<cv"));
/*     */     close();
/*     */     xbLhRI(str);
/*     */   }
/*     */   
/*     */   public void close() {
/*     */     if (this.PpPpPP != null)
/*     */       this.PpPpPP.close(); 
/*     */   }
/*     */   
/*     */   public Connection xXXxxx(String str) {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
/*     */     //   4: ifeq -> 12
/*     */     //   7: aload_0
/*     */     //   8: invokevirtual oOOOOo : ()Ljava/lang/String;
/*     */     //   11: astore_1
/*     */     //   12: aload_0
/*     */     //   13: getfield PpPpPP : Lcn/handyplus/warp/lib/expand/zaxxer/hikari/HikariDataSource;
/*     */     //   16: ifnull -> 29
/*     */     //   19: aload_0
/*     */     //   20: getfield PpPpPP : Lcn/handyplus/warp/lib/expand/zaxxer/hikari/HikariDataSource;
/*     */     //   23: invokevirtual isClosed : ()Z
/*     */     //   26: ifeq -> 42
/*     */     //   29: ldc ':Zsy{`sV{f{Aughq2铤掷弘帪兩闿６釟斪扁弚'
/*     */     //   31: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   34: invokestatic sendConsoleDebugMessage : (Ljava/lang/String;)V
/*     */     //   37: aload_0
/*     */     //   38: aload_1
/*     */     //   39: invokespecial xbLhRI : (Ljava/lang/String;)V
/*     */     //   42: aload_0
/*     */     //   43: getfield PpPpPP : Lcn/handyplus/warp/lib/expand/zaxxer/hikari/HikariDataSource;
/*     */     //   46: invokevirtual getConnection : ()Ljava/sql/Connection;
/*     */     //   49: areturn
/*     */     //   50: athrow
/*     */     //   51: astore_1
/*     */     //   52: getstatic cn/handyplus/warp/lib/InitApi.PLUGIN : Lorg/bukkit/plugin/java/JavaPlugin;
/*     */     //   55: invokevirtual getLogger : ()Ljava/util/logging/Logger;
/*     */     //   58: getstatic java/util/logging/Level.SEVERE : Ljava/util/logging/Level;
/*     */     //   61: ldc '.\\f\\b%.?$k厩畔彺平'
/*     */     //   63: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   66: aload_1
/*     */     //   67: invokevirtual log : (Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   70: new java/lang/RuntimeException
/*     */     //   73: dup
/*     */     //   74: aload_1
/*     */     //   75: invokespecial <init> : (Ljava/lang/Throwable;)V
/*     */     //   78: athrow
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #203	-> 0
/*     */     //   #222	-> 7
/*     */     //   #194	-> 12
/*     */     //   #176	-> 29
/*     */     //   #156	-> 37
/*     */     //   #217	-> 42
/*     */     //   #139	-> 51
/*     */     //   #160	-> 52
/*     */     //   #70	-> 70
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	79	0	a	Lcn/handyplus/warp/lib/SqlManagerUtil;
/*     */     //   0	79	1	a	Ljava/lang/String;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   42	49	51	java/sql/SQLException
/*     */   }
/*     */   
/*     */   private static final SqlManagerUtil j = new SqlManagerUtil();
/*     */   private HikariDataSource PpPpPP;
/*     */   public static final String STORAGE_METHOD = "storage-method";
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\SqlManagerUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */