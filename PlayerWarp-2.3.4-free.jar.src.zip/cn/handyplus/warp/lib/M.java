/*    */ package cn.handyplus.warp.lib;
/*    */ 
/*    */ import cn.handyplus.warp.service.WarpCollectionService;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class M
/*    */ {
/* 41 */   private static final WarpCollectionService BJuIXx = new WarpCollectionService(null);
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\M.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */