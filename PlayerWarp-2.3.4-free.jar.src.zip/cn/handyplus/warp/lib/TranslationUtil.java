/*     */ package cn.handyplus.warp.lib;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public final class TranslationUtil {
/*     */   @NotNull
/*     */   public static String getEffectTranslation(@NotNull String effect) {
/*   7 */     if (BaseConstants.JSON_CACHE_MAP.isEmpty())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  86 */       return effect;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 186 */     return BaseConstants.JSON_CACHE_MAP.getOrDefault((new StringBuilder()).insert(0, BcUtil.qzlKeO(".\036-\035(\fe\025\"\026.\0339\031-\fe")).append(effect.toLowerCase()).toString(), effect);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public static String getEnchantmentLevelTranslation(@NotNull String enchantmentLevel) {
/*     */     if (BaseConstants.JSON_CACHE_MAP.isEmpty()) {
/*     */       return enchantmentLevel;
/*     */     }
/*     */     return BaseConstants.JSON_CACHE_MAP.getOrDefault((new StringBuilder()).insert(0, WarpTpPlayerService.qzlKeO("fE`CbEwFfEw\005oNuNo\005")).append(enchantmentLevel).toString(), enchantmentLevel);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public static String getEnchantmentTranslation(@NotNull String enchantment) {
/*     */     if (BaseConstants.JSON_CACHE_MAP.isEmpty()) {
/*     */       return enchantment;
/*     */     }
/* 202 */     String str = LegacyUtil.getEnchantmentKey(LegacyUtil.getEnchantmentByName(enchantment));
/*     */     return BaseConstants.JSON_CACHE_MAP.getOrDefault((new StringBuilder()).insert(0, BcUtil.qzlKeO("\035%\033#\031%\f&\035%\fe\025\"\026.\0339\031-\fe")).append(str).toString(), enchantment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static String getMaterialTranslation(@NotNull String materialName) {
/*     */     String str;
/*     */     if (StrUtil.isNotEmpty(str = getItemTranslation(materialName))) {
/*     */       return str;
/*     */     }
/* 233 */     return getBlockTranslation(materialName);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public static String getEntityTranslation(@NotNull String entity) {
/*     */     if (BaseConstants.JSON_CACHE_MAP.isEmpty())
/*     */       return entity; 
/*     */     return BaseConstants.JSON_CACHE_MAP.getOrDefault((new StringBuilder()).insert(0, WarpTpPlayerService.qzlKeO("Nm_j_z\005nBmN`YbMw\005")).append(entity.toLowerCase()).toString(), entity);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static String getBlockTranslation(@NotNull String block) {
/*     */     if (MapUtil.isEmpty(BaseConstants.JSON_CACHE_MAP))
/*     */       return null; 
/*     */     return BaseConstants.JSON_CACHE_MAP.get((new StringBuilder()).insert(0, BcUtil.qzlKeO("\032'\027(\023e\025\"\026.\0339\031-\fe")).append(block.toLowerCase()).toString());
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public static String getColorTranslation(@NotNull String color) {
/*     */     if (BaseConstants.JSON_CACHE_MAP.isEmpty())
/*     */       return color; 
/*     */     return BaseConstants.JSON_CACHE_MAP.getOrDefault((new StringBuilder()).insert(0, BcUtil.qzlKeO("\033$\024$\ne\025\"\026.\0339\031-\fe")).append(color.toLowerCase()).toString(), color);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static String getItemTranslation(@NotNull String item) {
/*     */     if (MapUtil.isEmpty(BaseConstants.JSON_CACHE_MAP))
/*     */       return null; 
/*     */     return BaseConstants.JSON_CACHE_MAP.get((new StringBuilder()).insert(0, WarpTpPlayerService.qzlKeO("BwNn\005nBmN`YbMw\005")).append(item.toLowerCase()).toString());
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\TranslationUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */