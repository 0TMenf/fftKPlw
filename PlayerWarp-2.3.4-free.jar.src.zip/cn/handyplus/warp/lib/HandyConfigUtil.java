/*     */ package cn.handyplus.warp.lib;
/*     */ public final class HandyConfigUtil {
/*     */   private static final String j = "isCheckUpdateToOpMsg";
/*     */   private static final String XxxxXx = "isCheckUpdate";
/*     */   
/*     */   public static FileConfiguration loadConfig() {
/*   7 */     BaseConstants.CONFIG = load(HandyHttpUtil.qzlKeO(" O-F*GmY.L"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     return PPpPpp(BaseConstants.CONFIG);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setPath(FileConfiguration a, String str1, Object object, String str2) {
/*     */     setPath(a, str1, object, null, str2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FileConfiguration loadLangConfig(int a) {
/*     */     if (BaseConstants.CONFIG == null) {
/*     */       loadConfig();
/*     */     }
/* 201 */     return loadLangConfig(BaseConstants.CONFIG.getString(NetUtil.qzlKeO("y\021{\027`\021r\025"), HandyHttpUtil.qzlKeO("Z+\000n")), a);
/*     */   } public static File getOrCreateFile(String a) { try { File file1; File file2; if ((file2 = (file1 = new File(InitApi.PLUGIN.getDataFolder(), a)).getParentFile()) != null && !file2.exists()) { boolean bool = file2.mkdirs(); MessageUtil.sendConsoleDebugMessage((new StringBuilder()).insert(0, HandyHttpUtil.qzlKeO("剘廚旄他皭彵纐枼y\000")).append(bool).toString()); }  if (!file1.exists()) { boolean bool = file1.createNewFile(); MessageUtil.sendConsoleDebugMessage((new StringBuilder()).insert(0, NetUtil.qzlKeO("刎床斒了细柬/P")).append(bool).toString()); }  return file1; } catch (Throwable throwable) { throw throwable; }
/* 203 */      } public static FileConfiguration load(String a) { File file; if (!(file = new File(InitApi.PLUGIN.getDataFolder(), a)).exists()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 222 */       if (InitApi.PLUGIN.getResource(a) == null) { MessageUtil.sendConsoleMessage((new StringBuilder()).insert(0, HandyHttpUtil.qzlKeO("劀輾斧亵弢幻县嚣\032波朩厒玐宺庴盇斧亵\032")).append(a).toString()); return null; }
/*     */        InitApi.PLUGIN.saveResource(a, false);
/*     */     }  return (FileConfiguration)YamlConfiguration.loadConfiguration(file); } public static void setPath(FileConfiguration a, String str1, Object object, List<?> list, String str2) { try { a.set(str1, object); if (CollUtil.isNotEmpty(list) && BaseConstants.VERSION_ID.intValue() >= VersionCheckEnum.V_1_18.getVersionId().intValue())
/*     */         a.setComments(str1, list);  a.save(new File(InitApi.PLUGIN.getDataFolder(), str2)); return; }
/*     */     catch (IOException iOException)
/* 227 */     { InitApi.PLUGIN.getLogger().log(Level.SEVERE, HandyHttpUtil.qzlKeO("0E7p\"T+\000厒甿彁帘"), iOException); return; } catch (NoSuchMethodError noSuchMethodError) { return; }  } public static Map<String, FileConfiguration> loadDirectory(String a) { HashMap<Object, Object> hashMap = new HashMap<>(); File file; if (!(file = new File(InitApi.PLUGIN.getDataFolder(), a)).exists())
/*     */       InitApi.PLUGIN.saveResource(a, false);  File[] arrayOfFile; if ((arrayOfFile = file.listFiles()) == null)
/*     */       return (Map)hashMap;  int i = (arrayOfFile = arrayOfFile).length; byte b; if ((b = 0) < i) { File file1 = arrayOfFile[b]; b++; hashMap.put(file1.getName(), load((new StringBuilder()).insert(0, a).append(file1.getName()).toString())); }  return (Map)hashMap; }
/* 230 */   public static boolean createNewFile(String a) { try { File file1; File file2; if ((file2 = (file1 = new File(InitApi.PLUGIN.getDataFolder(), a)).getParentFile()) != null && !file2.exists()) { boolean bool = file2.mkdirs(); MessageUtil.sendConsoleDebugMessage((new StringBuilder()).insert(0, NetUtil.qzlKeO("刎床斒了盻弥细柬/P")).append(bool).toString()); }
/* 231 */        if (!file1.exists()) {
/*     */         return file1.createNewFile();
/*     */       }
/*     */       return true; }
/*     */     catch (Throwable throwable)
/*     */     { throw throwable; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FileConfiguration loadLangConfig(String a, int i) {
/*     */     FileConfiguration fileConfiguration;
/*     */     if ((fileConfiguration = load((new StringBuilder()).insert(0, NetUtil.qzlKeO("y\021{\027`\021r\025f_")).append(a).append(HandyHttpUtil.qzlKeO("mY.L")).toString())) == null) {
/*     */       fileConfiguration = load(NetUtil.qzlKeO("\034t\036r\005t\027p\003:\n}/V>;\tx\034"));
/*     */     }
/*     */     BaseConstants.LANG_CONFIG = fileConfiguration;
/*     */     if (i != 0) {
/*     */       LanguageTypeEnum languageTypeEnum;
/*     */       if ((languageTypeEnum = LanguageTypeEnum.getByValue(a)) == null) {
/*     */         PPpPpp();
/*     */         return fileConfiguration;
/*     */       } 
/*     */       XXXxxX(languageTypeEnum);
/*     */     } 
/*     */     return fileConfiguration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FileConfiguration loadLangConfig(String a) {
/*     */     return loadLangConfig(a, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<String> getKey(FileConfiguration a, String str) {
/* 279 */     if (StrUtil.isEmpty(str))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 291 */       return a.getKeys(false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 642 */     HashSet<String> hashSet = new HashSet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ConfigurationSection configurationSection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if ((configurationSection = a.getConfigurationSection(str)) == null) {
/*     */       return hashSet;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 677 */     return configurationSection.getKeys(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean contains(FileConfiguration a, String str) {
/*     */     if (a == null || StrUtil.isEmpty(str)) {
/*     */       return false;
/*     */     }
/*     */     return a.contains(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, List<String>> getStringListMapChild(FileConfiguration<String, List> a, String a) {
/*     */     // Byte code:
/*     */     //   0: new java/util/LinkedHashMap
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: astore_2
/*     */     //   8: aload_0
/*     */     //   9: aload_1
/*     */     //   10: invokestatic getChildMap : (Lorg/bukkit/configuration/file/FileConfiguration;Ljava/lang/String;)Ljava/util/Map;
/*     */     //   13: invokeinterface keySet : ()Ljava/util/Set;
/*     */     //   18: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   23: dup
/*     */     //   24: astore_3
/*     */     //   25: invokeinterface hasNext : ()Z
/*     */     //   30: ifeq -> 88
/*     */     //   33: aload_3
/*     */     //   34: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   39: checkcast java/lang/String
/*     */     //   42: astore #4
/*     */     //   44: aload_3
/*     */     //   45: aload_2
/*     */     //   46: new java/lang/StringBuilder
/*     */     //   49: aload_0
/*     */     //   50: dup_x1
/*     */     //   51: dup
/*     */     //   52: pop2
/*     */     //   53: dup
/*     */     //   54: invokespecial <init> : ()V
/*     */     //   57: aload_1
/*     */     //   58: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   61: ldc '.'
/*     */     //   63: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   66: aload #4
/*     */     //   68: dup_x2
/*     */     //   69: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   72: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   75: invokevirtual getStringList : (Ljava/lang/String;)Ljava/util/List;
/*     */     //   78: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   83: pop
/*     */     //   84: goto -> 25
/*     */     //   87: athrow
/*     */     //   88: aload_2
/*     */     //   89: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #327	-> 0
/*     */     //   #454	-> 8
/*     */     //   #414	-> 13
/*     */     //   #563	-> 45
/*     */     //   #531	-> 84
/*     */     //   #504	-> 88
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	90	0	a	Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   0	90	1	a	Ljava/lang/String;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, Object> getChildMap(FileConfiguration a, String str) {
/*     */     if (StrUtil.isEmpty(str)) {
/*     */       return a.getValues(false);
/*     */     }
/*     */     LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<>();
/*     */     ConfigurationSection configurationSection;
/* 744 */     if ((configurationSection = a.getConfigurationSection(str)) == null) {
/*     */       return (Map)linkedHashMap;
/*     */     }
/*     */     return configurationSection.getValues(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setPathIsNotContains(FileConfiguration a, String str1, Object object, List<String> list, String str2) {
/*     */     if (a.contains(str1)) {
/*     */       return;
/*     */     }
/*     */     setPath(a, str1, object, list, str2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, String> getStringMapChild(FileConfiguration<String, String> a, String str) {
/*     */     LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<>();
/*     */     Iterator<?> iterator;
/* 770 */     for (; (iterator = getChildMap(a, str).keySet().iterator()).hasNext(); super(), a.put(str1, (new StringBuilder()).getString(a.append(str).append(".").append(str1).toString()))) String str1 = (String)iterator.next(); 
/*     */     return (Map)linkedHashMap;
/*     */   }
/*     */   
/*     */   public static boolean exists(String a) {
/*     */     return (new File(InitApi.PLUGIN.getDataFolder(), a)).exists();
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\HandyConfigUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */