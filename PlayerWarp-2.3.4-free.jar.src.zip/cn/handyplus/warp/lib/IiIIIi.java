/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import org.bukkit.Bukkit;
/*     */ 
/*     */ public class IiIIIi
/*     */ {
/*     */   public static void l(Runnable a, long l) {
/*   8 */     Bukkit.getScheduler().runTaskLaterAsynchronously(HandySchedulerUtil.PPpppp, a, l); } public static void XxXXxx(Runnable a, long l) {
/*   9 */     Bukkit.getScheduler().runTaskLater(HandySchedulerUtil.PPpppp, a, l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void l(Runnable a) {
/*  35 */     Bukkit.getScheduler().runTask(HandySchedulerUtil.PPpppp, a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void iIiiIi(HandyRunnable a, long l) {
/*  44 */     a.setupTask(Bukkit.getScheduler().runTaskLater(HandySchedulerUtil.PPpppp, a, l));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sZxJew() {
/*  70 */     Bukkit.getScheduler().cancelTasks(HandySchedulerUtil.PPpppp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void l(Runnable a, long l1, long l2) {
/* 107 */     Bukkit.getScheduler().runTaskTimerAsynchronously(HandySchedulerUtil.PPpppp, a, l1, l2);
/*     */   } public static void IiiiIi(Runnable a, long l1, long l2) {
/* 109 */     Bukkit.getScheduler().runTaskTimer(HandySchedulerUtil.PPpppp, a, l1, l2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void IiiiiI(Runnable a) {
/* 166 */     Bukkit.getScheduler().runTaskAsynchronously(HandySchedulerUtil.PPpppp, a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void l(HandyRunnable a, long l1, long l2) {
/* 176 */     a.setupTask(Bukkit.getScheduler().runTaskTimerAsynchronously(HandySchedulerUtil.PPpppp, a, l1, l2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void oOOOOO(HandyRunnable a, long l1, long l2) {
/* 218 */     a.setupTask(Bukkit.getScheduler().runTaskTimer(HandySchedulerUtil.PPpppp, a, l1, l2)); } public static void l(HandyRunnable a, long l) {
/* 219 */     a.setupTask(Bukkit.getScheduler().runTaskLaterAsynchronously(HandySchedulerUtil.PPpppp, a, l));
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\IiIIIi.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */