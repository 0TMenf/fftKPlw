/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.stream.Stream;
/*     */ import net.md_5.bungee.api.ChatMessageType;
/*     */ import net.md_5.bungee.api.chat.BaseComponent;
/*     */ import net.md_5.bungee.api.chat.ClickEvent;
/*     */ import net.md_5.bungee.api.chat.TextComponent;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class iiIiiI
/*     */ {
/*     */   private BaseComponent[] pPPppP;
/*     */   
/*     */   public void l() {
/*  39 */     Bukkit.getOnlinePlayers().forEach(this::iIiIiI);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public iiIiiI iiIIiI(String str, int i) {
/*  48 */     this.pPPppP = TextComponent.fromLegacyText((i != 0) ? LegacyUtil.parseColor(str) : str);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 154 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static iiIiiI iiiIII() {
/*     */     return new iiIiiI();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public iiIiiI PPPpPP(String str) {
/*     */     return iiIIiI(str, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void h(String str) {
/*     */     oOOooO(ClickEvent.Action.OPEN_URL, str);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void I() {
/*     */     Bukkit.getOnlinePlayers().forEach(this::iIiIii);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void xXxxXx() {
/*     */     Bukkit.getConsoleSender().sendMessage(BaseComponent.toLegacyText(pPPpPP()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void iIIIIi(BaseComponent[] arrayOfBaseComponent) {
/*     */     this.pPPppP = (BaseComponent[])Stream.concat(Arrays.stream((Object[])this.pPPppP), Arrays.stream((Object[])arrayOfBaseComponent)).toArray(a -> {
/*     */           true;
/*     */           return true;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ihLGWY(String str) {
/*     */     if (BaseConstants.VERSION_ID.intValue() < VersionCheckEnum.V_1_15.getVersionId().intValue()) {
/*     */       return;
/*     */     }
/* 203 */     oOOooO(ClickEvent.Action.COPY_TO_CLIPBOARD, str);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void oOOooO(ClickEvent.Action a, String a) {
/*     */     // Byte code:
/*     */     //   0: aload_2
/*     */     //   1: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
/*     */     //   4: ifeq -> 9
/*     */     //   7: return
/*     */     //   8: athrow
/*     */     //   9: aload_0
/*     */     //   10: getfield pPPppP : [Lnet/md_5/bungee/api/chat/BaseComponent;
/*     */     //   13: dup
/*     */     //   14: astore_3
/*     */     //   15: arraylength
/*     */     //   16: istore #4
/*     */     //   18: iconst_0
/*     */     //   19: dup
/*     */     //   20: istore #5
/*     */     //   22: iload #4
/*     */     //   24: if_icmpge -> 59
/*     */     //   27: aload_3
/*     */     //   28: iload #5
/*     */     //   30: aaload
/*     */     //   31: astore #6
/*     */     //   33: new net/md_5/bungee/api/chat/ClickEvent
/*     */     //   36: aload #6
/*     */     //   38: dup_x1
/*     */     //   39: dup
/*     */     //   40: pop2
/*     */     //   41: dup
/*     */     //   42: aload_1
/*     */     //   43: iinc #5, 1
/*     */     //   46: aload_2
/*     */     //   47: invokespecial <init> : (Lnet/md_5/bungee/api/chat/ClickEvent$Action;Ljava/lang/String;)V
/*     */     //   50: invokevirtual setClickEvent : (Lnet/md_5/bungee/api/chat/ClickEvent;)V
/*     */     //   53: iload #5
/*     */     //   55: goto -> 22
/*     */     //   58: athrow
/*     */     //   59: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #137	-> 0
/*     */     //   #121	-> 9
/*     */     //   #225	-> 33
/*     */     //   #121	-> 53
/*     */     //   #166	-> 59
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	60	0	a	Lcn/handyplus/warp/lib/iiIiiI;
/*     */     //   0	60	1	a	Lnet/md_5/bungee/api/chat/ClickEvent$Action;
/*     */     //   0	60	2	a	Ljava/lang/String;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseComponent[] pPPpPP() {
/* 215 */     return this.pPPppP;
/*     */   } public void iIiIiI(CommandSender commandSender) {
/*     */     if (commandSender == null)
/*     */       return; 
/*     */     if (BaseUtil.isPlayer(commandSender).booleanValue()) {
/*     */       ((Player)commandSender).spigot().sendMessage(ChatMessageType.CHAT, pPPpPP());
/*     */       return;
/*     */     } 
/*     */     commandSender.sendMessage(BaseComponent.toLegacyText(pPPpPP()));
/*     */   } public void I(String str) {
/*     */     oOOooO(ClickEvent.Action.SUGGEST_COMMAND, str);
/*     */   } public void iIiIii(Player player) {
/*     */     player.spigot().sendMessage(ChatMessageType.ACTION_BAR, pPPpPP());
/*     */   }
/*     */   public void l(String a) {
/*     */     // Byte code:
/*     */     //   0: getstatic cn/handyplus/warp/lib/BaseConstants.VERSION_ID : Ljava/lang/Integer;
/*     */     //   3: invokevirtual intValue : ()I
/*     */     //   6: getstatic cn/handyplus/warp/lib/VersionCheckEnum.V_1_16 : Lcn/handyplus/warp/lib/VersionCheckEnum;
/*     */     //   9: invokevirtual getVersionId : ()Ljava/lang/Integer;
/*     */     //   12: invokevirtual intValue : ()I
/*     */     //   15: if_icmpge -> 20
/*     */     //   18: return
/*     */     //   19: athrow
/*     */     //   20: aload_1
/*     */     //   21: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
/*     */     //   24: ifeq -> 29
/*     */     //   27: return
/*     */     //   28: athrow
/*     */     //   29: aload_0
/*     */     //   30: getfield pPPppP : [Lnet/md_5/bungee/api/chat/BaseComponent;
/*     */     //   33: dup
/*     */     //   34: astore_2
/*     */     //   35: arraylength
/*     */     //   36: istore_3
/*     */     //   37: iconst_0
/*     */     //   38: dup
/*     */     //   39: istore #4
/*     */     //   41: iload_3
/*     */     //   42: if_icmpge -> 98
/*     */     //   45: aload_2
/*     */     //   46: iload #4
/*     */     //   48: aaload
/*     */     //   49: astore #5
/*     */     //   51: new net/md_5/bungee/api/chat/HoverEvent
/*     */     //   54: aload #5
/*     */     //   56: dup_x1
/*     */     //   57: dup
/*     */     //   58: pop2
/*     */     //   59: dup
/*     */     //   60: getstatic net/md_5/bungee/api/chat/HoverEvent$Action.SHOW_TEXT : Lnet/md_5/bungee/api/chat/HoverEvent$Action;
/*     */     //   63: iconst_1
/*     */     //   64: anewarray net/md_5/bungee/api/chat/hover/content/Content
/*     */     //   67: iconst_1
/*     */     //   68: dup
/*     */     //   69: pop2
/*     */     //   70: dup
/*     */     //   71: iconst_0
/*     */     //   72: new net/md_5/bungee/api/chat/hover/content/Text
/*     */     //   75: dup
/*     */     //   76: aload_1
/*     */     //   77: invokestatic fromLegacyText : (Ljava/lang/String;)[Lnet/md_5/bungee/api/chat/BaseComponent;
/*     */     //   80: invokespecial <init> : ([Lnet/md_5/bungee/api/chat/BaseComponent;)V
/*     */     //   83: iinc #4, 1
/*     */     //   86: aastore
/*     */     //   87: invokespecial <init> : (Lnet/md_5/bungee/api/chat/HoverEvent$Action;[Lnet/md_5/bungee/api/chat/hover/content/Content;)V
/*     */     //   90: invokevirtual setHoverEvent : (Lnet/md_5/bungee/api/chat/HoverEvent;)V
/*     */     //   93: iload #4
/*     */     //   95: goto -> 41
/*     */     //   98: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #217	-> 0
/*     */     //   #139	-> 18
/*     */     //   #70	-> 20
/*     */     //   #68	-> 27
/*     */     //   #74	-> 29
/*     */     //   #167	-> 51
/*     */     //   #74	-> 93
/*     */     //   #110	-> 98
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	99	0	a	Lcn/handyplus/warp/lib/iiIiiI;
/*     */     //   0	99	1	a	Ljava/lang/String;
/*     */   }
/*     */   public void A(String str) {
/* 233 */     oOOooO(ClickEvent.Action.RUN_COMMAND, str);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\iiIiiI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */