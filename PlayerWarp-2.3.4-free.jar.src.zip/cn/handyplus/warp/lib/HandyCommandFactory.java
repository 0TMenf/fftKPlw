/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import cn.handyplus.warp.util.WarpPermissionUtil;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HandyCommandFactory
/*     */ {
/*  41 */   private static final HandyCommandFactory K = new HandyCommandFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private static final Map<String, IHandyCommandEvent> j = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HandyCommandFactory XXXxXx() {
/*  55 */     return K;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean XxXXXx(CommandSender commandSender, Command command, String str1, String[] arrayOfString, String str2) {
/* 103 */     if (arrayOfString.length == 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 149 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     IHandyCommandEvent iHandyCommandEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     if ((iHandyCommandEvent = j.get(arrayOfString[0].toLowerCase())) == null) {
/*     */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 217 */     if (StrUtil.isNotEmpty(iHandyCommandEvent.permission()) && !commandSender.hasPermission(iHandyCommandEvent.permission())) {
/*     */       MessageUtil.sendMessage(commandSender, StrUtil.replace(str2, WarpPermissionUtil.qzlKeO("YF[N@PZJFM"), iHandyCommandEvent.permission())); return true;
/*     */     }  if (iHandyCommandEvent.isAsync()) {
/*     */       IIIiiI(iHandyCommandEvent, commandSender, command, str1, arrayOfString);
/*     */       return true;
/*     */     } 
/*     */     l(iHandyCommandEvent, commandSender, command, str1, arrayOfString);
/*     */     return true; } public boolean PpPPPp(String str1, CommandSender commandSender, Command command, String str2, String[] arrayOfString, String str3) { if (arrayOfString.length == 0)
/*     */       return false; 
/*     */     Map map;
/*     */     if ((map = iIIIii.get(str1.toLowerCase())) == null)
/*     */       return false; 
/*     */     HandySubCommandParam handySubCommandParam;
/*     */     if ((handySubCommandParam = (HandySubCommandParam)map.get(arrayOfString[0].toLowerCase())) == null)
/*     */       return false; 
/*     */     if (StrUtil.isNotEmpty(handySubCommandParam.getPermission()) && !commandSender.hasPermission(handySubCommandParam.getPermission())) {
/* 233 */       MessageUtil.sendMessage(commandSender, StrUtil.replace(str3, GameRuleUtil.qzlKeO(" 0\"89&#<?;"), handySubCommandParam.getPermission()));
/*     */       return true;
/*     */     } 
/*     */     if (handySubCommandParam.isAsync()) {
/*     */       l(handySubCommandParam, commandSender, command, str2, arrayOfString);
/*     */       return true;
/*     */     } 
/*     */     XXXXXX(handySubCommandParam, commandSender, command, str2, arrayOfString);
/*     */     return true; }
/*     */ 
/*     */   
/*     */   private static Map<String, Map<String, HandySubCommandParam>> iIIIii = new HashMap<>();
/*     */   
/*     */   public void IIIIII(List<?> list) {
/*     */     if (CollUtil.isEmpty(list))
/*     */       return; 
/*     */     Iterator<?> iterator;
/*     */     if ((iterator = list.iterator()).hasNext()) {
/*     */       IHandyCommandEvent iHandyCommandEvent = (IHandyCommandEvent)iterator.next();
/*     */       j.put(iHandyCommandEvent.command().toLowerCase(), iHandyCommandEvent);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void xxxXxx(Map<String, Map<String, HandySubCommandParam>> map) {
/*     */     iIIIii = map;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\HandyCommandFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */