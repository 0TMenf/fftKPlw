/*     */ package cn.handyplus.warp.lib;
/*     */ import java.math.BigDecimal;
/*     */ 
/*     */ public final class NumberUtil {
/*     */   public static Integer isNumericToInt(@NotNull String str) {
/*   6 */     return isNumericToInt(str, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean lt(@NotNull BigDecimal num1, @NotNull BigDecimal num2) {
/*  32 */     return (num1.compareTo(num2) < 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean le(@NotNull BigDecimal num1, @NotNull BigDecimal num2) {
/*  39 */     return (num1.compareTo(num2) <= 0);
/*     */   }
/*     */   
/*     */   public static Integer isNumericToInt(@NotNull String str, Integer def) {
/*  43 */     return isNumericToBigDecimal(str).<Integer>map(BigDecimal::intValue).orElse(def);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal mul(@NotNull BigDecimal num1, @NotNull BigDecimal num2) {
/*  83 */     return ((num2 = num1.multiply(num2))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 140 */       .scale() > 2) ? num2.setScale(2, RoundingMode.HALF_UP) : num2;
/*     */   } public static boolean ge(@NotNull BigDecimal num1, @NotNull BigDecimal num2) { return (num1.compareTo(num2) >= 0); } public static Long isNumericToLong(@NotNull String str, Long def) {
/*     */     return isNumericToBigDecimal(str).<Long>map(BigDecimal::longValue).orElse(def);
/*     */   } public static boolean gt(@NotNull BigDecimal num1, @NotNull BigDecimal num2) {
/*     */     return (num1.compareTo(num2) > 0);
/*     */   }
/* 146 */   public static BigDecimal toBigDecimal(Number a) { if (null == a) {
/*     */       return BigDecimal.ZERO;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 168 */     AssertUtil.isTrue(isValidNumber(a), ClassUtil.qzlKeO("$U\007B\017RJI\031\000\003N\034A\006I\016\001")); if (a instanceof BigDecimal) {
/*     */       return (BigDecimal)a;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (a instanceof Long) {
/*     */       return new BigDecimal(((Long)a).longValue());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 207 */     if (a instanceof Integer)
/*     */       return new BigDecimal(((Integer)a).intValue());  if (a instanceof BigInteger)
/*     */       return new BigDecimal((BigInteger)a); 
/*     */     return new BigDecimal(a.toString()); }
/* 211 */   public static Double isNumericToDouble(@NotNull String str) { return isNumericToDouble(str, null); } public static BigDecimal isNumericToBigDecimal(@NotNull String str, BigDecimal def) { if (StrUtil.isEmpty(str)) {
/*     */       return def;
/*     */     }
/*     */ 
/*     */     
/*     */     str = str.trim();
/*     */ 
/*     */     
/*     */     try {
/*     */       Matcher matcher;
/*     */       
/* 222 */       if ((matcher = PatternUtil.BIG_DECIMAL_NUMERIC.matcher(str)).matches()) {
/*     */         return new BigDecimal(str);
/*     */       }
/*     */     } catch (NumberFormatException numberFormatException) {
/*     */       return def;
/*     */     } 
/*     */     return def; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Long isNumericToLong(@NotNull String str) {
/*     */     return isNumericToLong(str, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Optional<BigDecimal> isNumericToBigDecimal(@NotNull String str) {
/*     */     return Optional.ofNullable(isNumericToBigDecimal(str, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Double isNumericToDouble(@NotNull String str, Double def) {
/*     */     return isNumericToBigDecimal(str).<Double>map(BigDecimal::doubleValue).orElse(def);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal div(@NotNull BigDecimal num1, @NotNull BigDecimal num2) {
/*     */     return num1.divide(num2, 2, RoundingMode.HALF_UP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValidNumber(Number a) {
/* 543 */     if (null == a)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 761 */       return false; }  if (a instanceof Double)
/*     */       return (!((Double)a).isInfinite() && !((Double)a).isNaN());  if (a instanceof Float)
/*     */       return (!((Float)a).isInfinite() && !((Float)a).isNaN());  return true; } @NotNull public static String format(Number a) { if (a == null)
/*     */       return SecureUtil.qzlKeO("\026");  BigDecimal bigDecimal; boolean bool = ((bigDecimal = (bigDecimal = toBigDecimal(a)).setScale(2, RoundingMode.DOWN).stripTrailingZeros()).scale() > 0) ? true : false; BigInteger bigInteger; String str2 = l((bigInteger = bigDecimal.toBigInteger()).toString());
/*     */     if (!bool)
/*     */       return str2; 
/*     */     String str1;
/*     */     if ((str1 = bigDecimal.subtract(new BigDecimal(bigInteger)).abs().toPlainString()).startsWith(ClassUtil.qzlKeO("Z\016")))
/*     */       str1 = str1.substring(1); 
/* 770 */     return (new StringBuilder()).insert(0, str2).append(str1).toString(); }
/*     */ 
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_5
/*     */     //   1: iconst_4
/*     */     //   2: ishl
/*     */     //   3: iconst_3
/*     */     //   4: iconst_1
/*     */     //   5: ishl
/*     */     //   6: ixor
/*     */     //   7: iconst_3
/*     */     //   8: iconst_5
/*     */     //   9: ixor
/*     */     //   10: iconst_3
/*     */     //   11: ishl
/*     */     //   12: iconst_3
/*     */     //   13: iconst_5
/*     */     //   14: ixor
/*     */     //   15: ixor
/*     */     //   16: iconst_4
/*     */     //   17: dup
/*     */     //   18: ishl
/*     */     //   19: iconst_3
/*     */     //   20: iconst_5
/*     */     //   21: ixor
/*     */     //   22: iconst_1
/*     */     //   23: ishl
/*     */     //   24: ixor
/*     */     //   25: aload_0
/*     */     //   26: checkcast java/lang/String
/*     */     //   29: dup
/*     */     //   30: astore_0
/*     */     //   31: invokevirtual length : ()I
/*     */     //   34: dup
/*     */     //   35: newarray char
/*     */     //   37: iconst_1
/*     */     //   38: dup
/*     */     //   39: pop2
/*     */     //   40: swap
/*     */     //   41: iconst_1
/*     */     //   42: isub
/*     */     //   43: dup_x2
/*     */     //   44: istore_3
/*     */     //   45: astore_1
/*     */     //   46: istore #4
/*     */     //   48: dup_x2
/*     */     //   49: pop2
/*     */     //   50: istore_2
/*     */     //   51: iflt -> 91
/*     */     //   54: aload_1
/*     */     //   55: aload_0
/*     */     //   56: iload_3
/*     */     //   57: dup_x1
/*     */     //   58: invokevirtual charAt : (I)C
/*     */     //   61: iinc #3, -1
/*     */     //   64: iload_2
/*     */     //   65: ixor
/*     */     //   66: i2c
/*     */     //   67: castore
/*     */     //   68: iload_3
/*     */     //   69: iflt -> 91
/*     */     //   72: aload_1
/*     */     //   73: aload_0
/*     */     //   74: iload_3
/*     */     //   75: iinc #3, -1
/*     */     //   78: dup_x1
/*     */     //   79: invokevirtual charAt : (I)C
/*     */     //   82: iload #4
/*     */     //   84: ixor
/*     */     //   85: i2c
/*     */     //   86: castore
/*     */     //   87: iload_3
/*     */     //   88: goto -> 51
/*     */     //   91: new java/lang/String
/*     */     //   94: dup
/*     */     //   95: aload_1
/*     */     //   96: invokespecial <init> : ([C)V
/*     */     //   99: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	100	0	a	Ljava/lang/String;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\NumberUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */