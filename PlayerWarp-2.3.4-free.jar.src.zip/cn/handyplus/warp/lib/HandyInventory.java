/*     */ package cn.handyplus.warp.lib;
/*     */ import lombok.Generated;
/*     */ 
/*     */ public class HandyInventory implements InventoryHolder {
/*     */   @Generated
/*     */   public Map<Integer, Object> getObjMap() {
/*   7 */     return this.aTTYbl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public Integer getId() {
/*  34 */     return this.e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public Map<Integer, Long> getMap() {
/*  52 */     return this.h;
/*     */   }
/*     */   
/*     */   @Generated
/*  56 */   public String getGuiType() { return this.L; } @Generated
/*     */   public Map<Integer, String> getStrMap() {
/*  58 */     return this.k;
/*     */   } public HandyInventory(String str1, String str2) {
/*  60 */     this(str1, str2, 54);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public String getSound() {
/*  70 */     return this.D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public Player getPlayer()
/*     */   {
/*  87 */     return this.j; } @Generated
/*     */   public Map<Integer, String> getSoundMap() {
/*  89 */     return this.I;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HandyInventory(String str1, String str2, int i, String str3) {
/*  97 */     this(str1, str2, i, true, str3);
/*     */   }
/*     */   @Generated
/*     */   public Inventory getInventory() {
/* 101 */     return this.K;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public Map<Integer, List<String>> getListMap() {
/* 109 */     return this.a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public boolean isToCancel() {
/* 117 */     return this.C;
/*     */   } public void setPageCount(Integer integer) {
/* 119 */     this.m = Integer.valueOf((int)Math.ceil(integer.intValue() / this.F.intValue()));
/*     */   }
/*     */   
/*     */   public HandyInventory(String str1, String str2, int i) {
/* 123 */     this(str1, str2, 54, i, null); } @Generated
/* 124 */   public Map<Integer, Integer> getIntMap() { return this.B; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HandyInventory(String str1, String str2, int i, int j, String str3)
/*     */   {
/* 132 */     this; super(); ((HandyInventory)new HashMap()).h = (Map<Integer, Long>)this;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 205 */     this.B = new HashMap<>(); this.aTTYbl = new HashMap<>(); this.a = new HashMap<>(); this.k = new HashMap<>(); this.I = new HashMap<>(); ((HandyInventory)str1).L = (String)this; str2.PPpPpP(i, this); j.C = this; } private Integer H = Integer.valueOf(1); @Generated public Integer getPageNum() { return this.H; } public HandyInventory(String str1, String str2, int i) { this(str1, str2, i, true, null); } private Integer F = Integer.valueOf(10); @Generated public Integer getPageSize() { return this.F; } public void syncOpen(Inventory inventory) { PlayerSchedulerUtil.syncOpenInventory(this.j, inventory); } @Generated public String getSearchType() { return this.f; } @Generated public String getLockKey() { return this.E; } @Generated public void setPageNum(Integer integer) { this.H = integer; } @Generated public void setListMap(Map<Integer, List<String>> map) { this.a = map; } @Generated public void setIntMap(Map<Integer, Integer> map) { this.B = map; } @Generated public void setMap(Map<Integer, Long> map) { this.h = map; } @Generated public void setObj(Object object) { this.c = object; } @Generated public void setObjMap(Map<Integer, Object> map) { this.aTTYbl = map; } private Integer m = Integer.valueOf(0);
/*     */   @Generated public void setId(Integer integer) { this.e = integer; }
/*     */   @Generated public void setLockKey(String str) { this.E = str; }
/*     */   @Generated public void setToCancel(int i) { this.C = i; }
/*     */   @Generated public void setSound(String str) { this.D = str; }
/*     */   @Generated public void setPlayer(Player player) { this.j = player; }
/*     */   @Generated
/*     */   public void setGuiType(String str) { this.L = str; }
/*     */   @Generated
/*     */   public void setInventory(Inventory inventory) { this.K = inventory; }
/*     */   @Generated
/*     */   public void setSearchType(String str) { this.f = str; }
/*     */   @Generated
/*     */   public void setSoundMap(Map<Integer, String> map) { this.I = map; }
/*     */   @Generated
/*     */   public void setStrMap(Map<Integer, String> map) { this.k = map; }
/*     */   @Generated
/*     */   public void setPageSize(Integer integer) { this.F = integer; }
/*     */   private Map<Integer, Integer> B; private String f; private Map<Integer, String> I; private Map<Integer, String> k; private String E; private Object c; private boolean C; private Map<Integer, Long> h; private String D; private Integer e; private Map<Integer, List<String>> a; private String L; private Inventory K; private Player j; private Map<Integer, Object> aTTYbl; @Generated
/*     */   public Integer getPageCount() { return this.m; } @Generated
/* 225 */   public Object getObj() { return this.c; }
/*     */ 
/*     */   
/*     */   public void syncClose() {
/* 229 */     PlayerSchedulerUtil.syncCloseInventory(this.j);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void playSound(int i) {
/*     */     String str1;
/* 628 */     if (StrUtil.isEmpty(str1 = this.I.getOrDefault(Integer.valueOf(i), this.D))) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 646 */     if (Boolean.FALSE.toString().equalsIgnoreCase(str1)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     List<String> list;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String str2 = (list = StrUtil.strToStrList(str1, ":")).get(0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean bool1 = (list.size() > 1) ? NumberUtil.isNumericToInt(list.get(1), Integer.valueOf(1)).intValue() : true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean bool2 = (list.size() > 2) ? NumberUtil.isNumericToInt(list.get(2), Integer.valueOf(1)).intValue() : true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Optional<Sound> optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 769 */     if (!(optional = BaseUtil.getSound(str2)).isPresent()) {
/*     */       MessageUtil.sendConsoleMessage((new StringBuilder()).insert(0, NetUtil.qzlKeO("酘缞锌讟9泑朜安庁鞃敝J")).append(str2).toString());
/*     */       return;
/*     */     } 
/*     */     PlayerSchedulerUtil.playSound(this.j, optional.get(), bool1, bool2);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\HandyInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */