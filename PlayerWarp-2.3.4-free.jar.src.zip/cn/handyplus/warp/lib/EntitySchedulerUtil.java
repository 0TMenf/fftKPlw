/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import javax.annotation.Nullable;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntitySchedulerUtil
/*     */ {
/*     */   public static <T> void runSafeOnPlayerScheduler(@NotNull LivingEntity entity, @NotNull Supplier<?> task, int isSync) {
/*  48 */     runSafeOnPlayerScheduler(entity, task, null, isSync);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void runSafeOnPlayerScheduler(@NotNull LivingEntity entity, @NotNull Runnable task, int isSync) {
/*  55 */     runSafeOnPlayerScheduler(entity, () -> { a.run(); return null; }isSync);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> void runSafeOnPlayerScheduler(@NotNull LivingEntity entity, @NotNull Supplier task, @Nullable Consumer success, int isSync) {
/* 121 */     Runnable runnable = () -> {
/*     */         Object object = a.get();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         if (consumer != null) {
/*     */           consumer.accept(object);
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 208 */     if (HandySchedulerUtil.isFolia()) {
/*     */       entity.getScheduler().run(HandySchedulerUtil.PPpppp, scheduledTask -> a.run(), () -> {
/*     */           
/*     */           });
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/*     */     if (isSync != 0) {
/* 220 */       IiIIIi.l(runnable);
/*     */       return;
/*     */     } 
/*     */     runnable.run();
/*     */   }
/*     */   
/*     */   public static void runSafeOnPlayerScheduler(@NotNull LivingEntity entity, @NotNull Runnable task) {
/*     */     runSafeOnPlayerScheduler(entity, task, true);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\EntitySchedulerUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */