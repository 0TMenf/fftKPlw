package cn.handyplus.warp.lib;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Documented
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface HandySubCommand {
  String subCommand();
  
  String mainCommand();
  
  String permission() default "";
}


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\HandySubCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */