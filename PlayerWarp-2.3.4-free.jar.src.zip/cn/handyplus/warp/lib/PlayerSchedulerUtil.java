/*   1 */ package cn.handyplus.warp.lib;public class PlayerSchedulerUtil { public static void syncTeleport(@NotNull Entity entity, @NotNull Location target) { syncTeleport(entity, target, PlayerTeleportEvent.TeleportCause.PLUGIN); }
/*     */    public static void openInventory(@NotNull Player player, @NotNull Inventory inventory) {
/*   3 */     iIiiii(player, inventory, false);
/*     */   }
/*     */   
/*     */   public static boolean teleport(@NotNull Entity entity, @NotNull Location target, @NotNull PlayerTeleportEvent.TeleportCause cause) {
/*   7 */     if (HandySchedulerUtil.isFolia()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  86 */       entity.teleportAsync(target, cause);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     return entity.teleport(target, cause);
/*     */   } public static void syncPlayerPerformCommand(@NotNull Player player, @NotNull String command) { l(player, command, false, true); } public static boolean teleport(@NotNull Entity entity, @NotNull Location target) { return teleport(entity, target, PlayerTeleportEvent.TeleportCause.PLUGIN); }
/*     */   public static void addPotionEffects(@NotNull LivingEntity entity, @NotNull List potionEffectList) { if (potionEffectList.isEmpty())
/*     */       return; 
/*     */     if (HandySchedulerUtil.isFolia()) {
/* 233 */       entity.getScheduler().run(HandySchedulerUtil.PPpppp, scheduledTask -> a.addPotionEffects(list), () -> {
/*     */           
/*     */           });
/*     */       return;
/*     */     } 
/*     */     IiIIIi.l(() -> a.addPotionEffects(list)); }
/*     */    public static void addPotionEffects(@NotNull LivingEntity entity, @NotNull PotionEffect potionEffect) {
/*     */     addPotionEffects(entity, Collections.singletonList(potionEffect));
/*     */   } public static void performCommand(@NotNull Player player, @NotNull String command) {
/*     */     l(player, command, true, false);
/*     */   } public static void dropItem(@NotNull Player player, @NotNull List dropItemList) {
/* 244 */     if (HandySchedulerUtil.isFolia()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 273 */       player.getScheduler().run(HandySchedulerUtil.PPpppp, scheduledTask -> a.forEach(()), () -> {
/*     */           
/*     */           });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 656 */     HandySchedulerUtil.runTask(() -> a.forEach(()));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void playSound(@NotNull Player player, @NotNull String sound, float volume, float pitch) {
/*     */     if (HandySchedulerUtil.isFolia()) {
/*     */       player.getScheduler().run(HandySchedulerUtil.PPpppp, scheduledTask -> a.playSound(a.getLocation(), str, f1, f2), () -> {
/*     */           
/*     */           });
/*     */       return;
/*     */     } 
/*     */     IiIIIi.l(() -> a.playSound(a.getLocation(), str, f1, f2));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void playSound(@NotNull Player player, @NotNull Sound sound, float volume, float pitch) {
/*     */     if (HandySchedulerUtil.isFolia()) {
/*     */       player.getScheduler().run(HandySchedulerUtil.PPpppp, scheduledTask -> a.playSound(a.getLocation(), sound, f1, f2), () -> {
/*     */           
/*     */           });
/*     */       return;
/*     */     } 
/*     */     IiIIIi.l(() -> a.playSound(a.getLocation(), sound, f1, f2));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void syncPerformCommand(@NotNull Player player, @NotNull String command) {
/*     */     l(player, command, true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void playerPerformCommand(@NotNull Player player, @NotNull String command) {
/*     */     l(player, command, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void syncTeleport(@NotNull Entity entity, @NotNull Location target, @NotNull PlayerTeleportEvent.TeleportCause cause) {
/*     */     if (HandySchedulerUtil.isFolia()) {
/*     */       entity.teleportAsync(target, cause);
/*     */       return;
/*     */     } 
/*     */     IiIIIi.l(() -> a.teleport(location, teleportCause));
/*     */   }
/*     */ 
/*     */   
/*     */   public static void removePotionEffect(@NotNull LivingEntity entity, @NotNull PotionEffectType potionEffect) {
/*     */     if (HandySchedulerUtil.isFolia()) {
/*     */       entity.getScheduler().run(HandySchedulerUtil.PPpppp, scheduledTask -> a.removePotionEffect(potionEffectType), () -> {
/*     */           
/*     */           });
/*     */       return;
/*     */     } 
/*     */     IiIIIi.l(() -> a.removePotionEffect(potionEffectType));
/*     */   }
/*     */   
/*     */   public static void syncOpenInventory(@NotNull Player player, @NotNull Inventory inventory) {
/*     */     iIiiii(player, inventory, true);
/*     */   }
/*     */   
/*     */   public static void playerPerformOpCommand(@NotNull Player player, @NotNull String command) {
/*     */     xXxXxx(player, command, false, false);
/*     */   }
/*     */   
/*     */   public static void closeInventory(@NotNull Player player) {
/*     */     PPPppP(player, false);
/*     */   }
/*     */   
/*     */   public static void syncDispatchCommand(@NotNull String command) {
/*     */     AGpILd(command, true);
/*     */   }
/*     */   
/*     */   public static void dispatchCommand(@NotNull String command) {
/*     */     AGpILd(command, false);
/*     */   }
/*     */   
/*     */   public static void performOpCommand(@NotNull Player player, @NotNull String command) {
/*     */     xXxXxx(player, command, true, false);
/*     */   }
/*     */   
/*     */   public static void syncCloseInventory(@NotNull Player player) {
/*     */     PPPppP(player, true);
/*     */   }
/*     */   
/*     */   public static void syncPerformReplaceCommand(@NotNull Player player, @NotNull String command) {
/*     */     if (command.contains(Pair.qzlKeO("\027\033 \027?\035\021"))) {
/*     */       syncCloseInventory(player);
/*     */       return;
/*     */     } 
/* 744 */     if ((command = command.replace(SecureUtil.qzlKeO("\002BVUG@CK["), player.getName())).contains(Pair.qzlKeO("##\b\021"))) {
/*     */       String str = command.replace(SecureUtil.qzlKeO("bII{"), "");
/*     */       syncPerformOpCommand(player, str);
/*     */     } 
/*     */     if (command.contains(Pair.qzlKeO("\027\033#\026?\027 \035\021"))) {
/*     */       syncDispatchCommand(command.replace(SecureUtil.qzlKeO("}ZIWUVJ\\{"), ""));
/*     */       return;
/*     */     } 
/*     */     syncPerformCommand(player, command);
/*     */   }
/*     */   
/*     */   public static void dropItem(@NotNull Player player, @NotNull List dropItemList, long delay) {
/*     */     if (HandySchedulerUtil.isFolia()) {
/*     */       player.getScheduler().runDelayed(HandySchedulerUtil.PPpppp, scheduledTask -> a.forEach(itemStack -> a.getWorld().dropItem(a.getLocation(), itemStack)), () -> {
/*     */           
/*     */           }delay);
/*     */       return;
/*     */     } 
/*     */     HandySchedulerUtil.runTaskLater(() -> a.forEach(()), delay);
/*     */   }
/*     */   
/*     */   public static void syncPerformOpCommand(@NotNull Player player, @NotNull String command) {
/*     */     xXxXxx(player, command, true, true);
/*     */   }
/*     */   
/*     */   public static void syncPlayerPerformOpCommand(@NotNull Player player, @NotNull String command) {
/* 770 */     xXxXxx(player, command, false, true);
/*     */   } }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\PlayerSchedulerUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */