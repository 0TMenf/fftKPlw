package cn.handyplus.warp.lib;

@FunctionalInterface
public interface cn/handyplus/warp/lib/G<T> {
  boolean IIiiiI(T paramT);
}


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\G.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */