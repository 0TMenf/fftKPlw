/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import cc.baka9.catseedlogin.bukkit.event.CatSeedPlayerLoginEvent;
/*     */ import cc.baka9.catseedlogin.bukkit.event.CatSeedPlayerRegisterEvent;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CatSeedEvnetListener
/*     */   implements Listener
/*     */ {
/*     */   @EventHandler
/*     */   public void onRegEvent(CatSeedPlayerRegisterEvent catSeedPlayerRegisterEvent) {
/*  41 */     Bukkit.getServer().getPluginManager().callEvent(new HandyRegisterEvent(catSeedPlayerRegisterEvent.getPlayer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onLoginEvent(CatSeedPlayerLoginEvent catSeedPlayerLoginEvent) {
/*  76 */     if (CatSeedPlayerLoginEvent.Result.SUCCESS.equals(catSeedPlayerLoginEvent.getResult()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 100 */       Bukkit.getServer().getPluginManager().callEvent(new HandyLoginEvent(catSeedPlayerLoginEvent.getPlayer()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\CatSeedEvnetListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */