package cn.handyplus.warp.lib;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface pPPPPP<T> {
  int updateById(Integer paramInteger);
  
  int update();
  
  int deleteBatchIds(List<Integer> paramList);
  
  Page<T> page();
  
  List<T> selectBatchIds(List<Integer> paramList);
  
  int deleteById(Integer paramInteger);
  
  List<Map<String, Object>> selectListMap();
  
  List<T> list();
  
  boolean insertBatch(List<T> paramList);
  
  Optional<T> selectById(Integer paramInteger);
  
  int insert(T paramT);
  
  int count(String paramString);
  
  int count();
  
  int delete();
  
  Optional<T> selectOne();
}


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\pPPPPP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */