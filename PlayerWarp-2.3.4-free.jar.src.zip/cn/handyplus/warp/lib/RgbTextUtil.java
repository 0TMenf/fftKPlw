/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RgbTextUtil
/*     */ {
/*     */   private iiIIII j;
/*     */   private iiIiiI PpPPPp;
/*     */   
/*     */   public static RgbTextUtil init(String a, int i) {
/*  30 */     RgbTextUtil rgbTextUtil = new RgbTextUtil();
/*  31 */     if (BaseUtil.supportsComponentApi()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  54 */       rgbTextUtil.j = iiIIII.PPPPpp().XxxXXX(a, i); return rgbTextUtil;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     rgbTextUtil.PpPPPp = iiIiiI.iiiIII().iiIIiI(a, i); return rgbTextUtil;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RgbTextUtil addExtra(RgbTextUtil rgbTextUtil1) {
/*     */     if (BaseUtil.supportsComponentApi()) {
/* 182 */       this.j.oOOOoo(rgbTextUtil1.j.iIIiII()); return this;
/*     */     }  this.PpPPPp.iIIIIi(rgbTextUtil1.PpPPPp.pPPpPP()); return this;
/*     */   }
/*     */   public void send(List<?> list) { if (CollUtil.isEmpty(list))
/*     */       return;  if (BaseUtil.supportsComponentApi()) {
/*     */       list.forEach(uUID -> this.j.iIiIiI((CommandSender)BaseUtil.getOnlinePlayer(uUID).orElse(null))); return;
/*     */     }  list.forEach(uUID -> this.PpPPPp.iIiIiI((CommandSender)BaseUtil.getOnlinePlayer(uUID).orElse(null))); } public RgbTextUtil addHoverText(String str) { if (BaseConstants.VERSION_ID.intValue() < VersionCheckEnum.V_1_16.getVersionId().intValue())
/*     */       return this; 
/*     */     if (StrUtil.isEmpty(str))
/*     */       return this; 
/*     */     if (BaseUtil.supportsComponentApi()) {
/*     */       this.j.A(str);
/*     */       return this;
/*     */     } 
/*     */     this.PpPPPp.l(str);
/*     */     return this; } public RgbTextUtil addClickUrl(String str) { if (BaseUtil.supportsComponentApi()) {
/*     */       this.j.I(str);
/*     */       return this;
/*     */     } 
/* 201 */     this.PpPPPp.h(str); return this; }
/*     */ 
/*     */ 
/*     */   
/*     */   public static RgbTextUtil init(String a) {
/*     */     return init(a, true);
/*     */   }
/*     */   
/*     */   public RgbTextUtil addClickCopyToClipboard(String str) {
/*     */     if (BaseConstants.VERSION_ID.intValue() < VersionCheckEnum.V_1_15.getVersionId().intValue()) {
/* 211 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     if (BaseUtil.supportsComponentApi()) {
/*     */       this.j.l(str);
/*     */ 
/*     */       
/*     */       return this;
/*     */     } 
/*     */     
/* 222 */     this.PpPPPp.ihLGWY(str); return this; } public RgbTextUtil addHoverText(ItemStack itemStack) { if (BaseConstants.VERSION_ID.intValue() < VersionCheckEnum.V_1_16.getVersionId().intValue())
/*     */       return this; 
/*     */     if (itemStack == null)
/*     */       return this; 
/*     */     if (BaseUtil.supportsComponentApi()) {
/*     */       this.j.KaUOHD(itemStack);
/*     */       return this;
/*     */     } 
/* 230 */     List<?> list = ItemStackUtil.getItemMeta(itemStack).getLore();
/*     */     this.PpPPPp.l(CollUtil.listToStr(list, Pair.qzlKeO("F")));
/*     */     return this; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RgbTextUtil addClickCommand(String str) {
/*     */     if (BaseUtil.supportsComponentApi()) {
/*     */       this.j.h(str);
/*     */       return this;
/*     */     } 
/*     */     this.PpPPPp.A(str);
/*     */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendAll() {
/*     */     if (BaseUtil.supportsComponentApi()) {
/* 489 */       this.j.I();
/*     */       return;
/*     */     } 
/*     */     this.PpPPPp.l();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RgbTextUtil addExtra(String str) {
/*     */     if (StrUtil.isEmpty(str)) {
/*     */       return this;
/*     */     }
/*     */     return addExtra(init(str));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(CommandSender commandSender) {
/*     */     if (BaseUtil.supportsComponentApi()) {
/*     */       this.j.iIiIiI(commandSender);
/*     */       return;
/*     */     } 
/*     */     this.PpPPPp.iIiIiI(commandSender);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RgbTextUtil addClickSuggestCommand(String str) {
/*     */     if (BaseUtil.supportsComponentApi()) {
/*     */       this.j.IiIIii(str);
/*     */       return this;
/*     */     } 
/*     */     this.PpPPPp.I(str);
/*     */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendAllActionBar() {
/*     */     if (BaseUtil.supportsComponentApi()) {
/*     */       this.j.l();
/*     */       return;
/*     */     } 
/*     */     this.PpPPPp.I();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendConsole() {
/*     */     if (BaseUtil.supportsComponentApi()) {
/* 571 */       this.j.xXxxXx();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 769 */     this.PpPPPp.xXxxXx();
/*     */   } public void sendActionBar(Player player) {
/*     */     if (BaseUtil.supportsComponentApi()) {
/* 772 */       this.j.iIiIii(player);
/*     */       return;
/*     */     } 
/*     */     this.PpPPPp.iIiIii(player);
/*     */   }
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_2
/*     */     //   1: iconst_5
/*     */     //   2: ixor
/*     */     //   3: iconst_4
/*     */     //   4: ishl
/*     */     //   5: iconst_3
/*     */     //   6: iconst_2
/*     */     //   7: ishl
/*     */     //   8: iconst_1
/*     */     //   9: ixor
/*     */     //   10: ixor
/*     */     //   11: iconst_2
/*     */     //   12: iconst_5
/*     */     //   13: ixor
/*     */     //   14: iconst_3
/*     */     //   15: ishl
/*     */     //   16: iconst_4
/*     */     //   17: ixor
/*     */     //   18: iconst_4
/*     */     //   19: dup
/*     */     //   20: ishl
/*     */     //   21: iconst_1
/*     */     //   22: ixor
/*     */     //   23: aload_0
/*     */     //   24: checkcast java/lang/String
/*     */     //   27: dup
/*     */     //   28: astore_0
/*     */     //   29: invokevirtual length : ()I
/*     */     //   32: dup
/*     */     //   33: newarray char
/*     */     //   35: iconst_1
/*     */     //   36: dup
/*     */     //   37: pop2
/*     */     //   38: swap
/*     */     //   39: iconst_1
/*     */     //   40: isub
/*     */     //   41: dup_x2
/*     */     //   42: istore_3
/*     */     //   43: astore_1
/*     */     //   44: istore #4
/*     */     //   46: dup_x2
/*     */     //   47: pop
/*     */     //   48: istore_2
/*     */     //   49: pop
/*     */     //   50: iflt -> 90
/*     */     //   53: aload_1
/*     */     //   54: aload_0
/*     */     //   55: iload_3
/*     */     //   56: dup_x1
/*     */     //   57: invokevirtual charAt : (I)C
/*     */     //   60: iinc #3, -1
/*     */     //   63: iload_2
/*     */     //   64: ixor
/*     */     //   65: i2c
/*     */     //   66: castore
/*     */     //   67: iload_3
/*     */     //   68: iflt -> 90
/*     */     //   71: aload_1
/*     */     //   72: aload_0
/*     */     //   73: iload_3
/*     */     //   74: iinc #3, -1
/*     */     //   77: dup_x1
/*     */     //   78: invokevirtual charAt : (I)C
/*     */     //   81: iload #4
/*     */     //   83: ixor
/*     */     //   84: i2c
/*     */     //   85: castore
/*     */     //   86: iload_3
/*     */     //   87: goto -> 50
/*     */     //   90: new java/lang/String
/*     */     //   93: dup
/*     */     //   94: aload_1
/*     */     //   95: invokespecial <init> : ([C)V
/*     */     //   98: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	99	0	a	Ljava/lang/String;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\RgbTextUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */