/*     */ package cn.handyplus.warp.lib;public class KcifTq { private String h; private Integer m; private String D; private IndexEnum e; private String H; private Integer a; private Field L; private Boolean K; private String j; private String oOooOO;
/*     */   
/*     */   @Generated
/*   4 */   public KcifTq(String str1, String str2, String str3, String str4, Boolean bool, String str5, Integer integer1, Integer integer2, IndexEnum indexEnum, Field field) { this.h = str1; this.j = str2; this.oOooOO = str3; this.H = str4; this.K = bool; this.D = str5; this.a = integer1; this.m = integer2; this.e = indexEnum; this.L = field; } @Generated public static foParam$FieldInfoParamBuilder OOOooO() { return new foParam$FieldInfoParamBuilder(); } @Generated public static class foParam$FieldInfoParamBuilder { @Generated private String h; @Generated private Boolean m; @Generated private String D; @Generated private String e; @Generated private Integer H; @Generated public foParam$FieldInfoParamBuilder fieldDefault(String str) { this.h = str; return this; } @Generated private String a; @Generated private String L; @Generated private IndexEnum K; @Generated private Integer j; @Generated private Field xxXXXx; @Generated public KcifTq build() { return new KcifTq(this.D, this.L, this.e, this.a, this.m, this.h, this.H, this.j, this.K, this.xxXXXx); } @Generated public String toString() { return (new StringBuilder()).insert(0, WarpChannelService.qzlKeO("ogLbMGGhF^H|Hc\007H@kEj``Oayo[oDL\\gEjL|\001h@kEjgoDk\024")).append(this.D).append(HandySchedulerUtil.qzlKeO(">:tswvvHw{~Tsww'")).append(this.L).append(WarpChannelService.qzlKeO("\"\th@kEj}wYk\024")).append(this.e).append(HandySchedulerUtil.qzlKeO("62|{~~Quwwtf'")).append(this.a).append(WarpChannelService.qzlKeO("\005.OgLbM@Fzg{Eb\024")).append(this.m).append(HandySchedulerUtil.qzlKeO("62|{~~Vt{gvf'")).append(this.h).append(WarpChannelService.qzlKeO("\005.OgLbMGGjLv\024")).append(this.H).append(HandySchedulerUtil.qzlKeO(">:tswvvVwtunz'")).append(this.j).append(WarpChannelService.qzlKeO("\"\tgGjLvl`\\c\024")).append(this.K).append(HandySchedulerUtil.qzlKeO("62|{~~Q{qrw'")).append(this.xxXXXx).append(")").toString(); } @Generated public foParam$FieldInfoParamBuilder fieldName(String str) { this.D = str; return this; } @Generated public foParam$FieldInfoParamBuilder indexEnum(IndexEnum indexEnum) { this.K = indexEnum; return this; } @Generated public foParam$FieldInfoParamBuilder fieldComment(String str) { this.a = str; return this; } @Generated public foParam$FieldInfoParamBuilder fieldCache(Field field) { this.xxXXXx = field; return this; } @Generated public foParam$FieldInfoParamBuilder fieldLength(Integer integer) { this.j = integer; return this; } @Generated public foParam$FieldInfoParamBuilder fieldRealName(String str) { this.L = str; return this; } @Generated public foParam$FieldInfoParamBuilder fieldType(String str) { this.e = str; return this; } @Generated public foParam$FieldInfoParamBuilder fieldNotNull(Boolean bool) { this.m = bool; return this; } @Generated public foParam$FieldInfoParamBuilder fieldIndex(Integer integer) { this.H = integer; return this; } } @Generated
/*     */   public String l() {
/*   6 */     return this.oOooOO;
/*     */   } @Generated
/*     */   public String gHjied() {
/*   9 */     return this.H;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public Boolean xxxXxX() {
/*  26 */     return this.K;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public String h() {
/*  35 */     return this.j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public String I() {
/*  54 */     return this.D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public void A(String str)
/*     */   {
/*  95 */     this.H = str; } @Generated public void h(String str) { this.D = str; } @Generated public void I(String str) { this.oOooOO = str; } @Generated public void YtVXIa(Field field) { this.L = field; } @Generated public boolean equals(Object object) { if (object == this) return true;  if (!(object instanceof KcifTq)) return false;  if (!(object = object).OoOOoo(this)) return false;  Boolean bool1 = xxxXxX(), bool2 = object.xxxXxX(); if ((bool1 == null) ? (bool2 != null) : !bool1.equals(bool2)) return false;  Integer integer1 = l(), integer2 = object.l(); if ((integer1 == null) ? (integer2 != null) : !integer1.equals(integer2)) return false;  integer1 = iIIIIi(); integer2 = object.iIIIIi(); if ((integer1 == null) ? (integer2 != null) : !integer1.equals(integer2)) return false;  String str1 = A(), str2 = object.A(); if ((str1 == null) ? (str2 != null) : !str1.equals(str2)) return false;  str1 = h(); str2 = object.h(); if ((str1 == null) ? (str2 != null) : !str1.equals(str2)) return false;  str1 = l(); str2 = object.l(); if ((str1 == null) ? (str2 != null) : !str1.equals(str2)) return false;  str1 = gHjied(); str2 = object.gHjied(); if ((str1 == null) ? (str2 != null) : !str1.equals(str2)) return false;  str1 = I(); str2 = object.I(); if ((str1 == null) ? (str2 != null) : !str1.equals(str2)) return false;  IndexEnum indexEnum1 = PppPpp(), indexEnum2 = object.PppPpp(); if ((indexEnum1 == null) ? (indexEnum2 != null) : !indexEnum1.equals(indexEnum2)) return false;  Field field = xxXXXx(); object = object.xxXXXx(); return !((field == null) ? (object != null) : !field.equals(object)); } @Generated public int hashCode() { int i = 59; i = 1; Boolean bool = xxxXxX(); i = i * 59 + ((bool == null) ? 43 : bool.hashCode()); Integer integer = l(); i = i * 59 + ((integer == null) ? 43 : integer.hashCode()); integer = iIIIIi(); i = i * 59 + ((integer == null) ? 43 : integer.hashCode()); String str = A(); i = i * 59 + ((str == null) ? 43 : str.hashCode()); str = h(); i = i * 59 + ((str == null) ? 43 : str.hashCode()); str = l(); i = i * 59 + ((str == null) ? 43 : str.hashCode()); str = gHjied(); i = i * 59 + ((str == null) ? 43 : str.hashCode()); str = I(); i = i * 59 + ((str == null) ? 43 : str.hashCode()); IndexEnum indexEnum = PppPpp(); i = i * 59 + ((indexEnum == null) ? 43 : indexEnum.hashCode()); Field field = xxXXXx(); return i = i * 59 + ((field == null) ? 43 : field.hashCode()); } @Generated public void AzqgWb(Boolean bool) { this.K = bool; } @Generated public void ppPppp(IndexEnum indexEnum) { this.e = indexEnum; } @Generated public void l(String str) { this.h = str; } @Generated public void l(Integer integer) { this.a = integer; } @Generated public String toString() { return (new StringBuilder()).insert(0, Page.qzlKeO("JJiOhjbEcsmQmN$EeF`GBBaF1")).append(A()).append(BcUtil.qzlKeO("Tk\036\"\035'\034\031\035*\024\005\031&\035v")).append(h()).append(Page.qzlKeO("\017,EeF`GXZ|F1")).append(l()).append(BcUtil.qzlKeO("gX-\021.\024/;$\025&\035%\fv")).append(gHjied()).append(Page.qzlKeO(" \003jJiOhmcWBV`O1")).append(xxxXxX()).append(BcUtil.qzlKeO("gX-\021.\024/<.\036*\r'\fv")).append(I()).append(Page.qzlKeO(" \003jJiOhjbGi[1")).append(l()).append(BcUtil.qzlKeO("Tk\036\"\035'\034\007\035%\037?\020v")).append(iIIIIi()).append(Page.qzlKeO("\017,JbGi[IMyN1")).append(PppPpp()).append(BcUtil.qzlKeO("gX-\021.\024/;*\033#\035v")).append(xxXXXx()).append(")").toString(); } @Generated public void iiiiii(String str) { this.j = str; } @Generated public void XXxXXX(Integer integer) { this.m = integer; } @Generated public boolean OoOOoo(Object object) { return object instanceof KcifTq; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public Field xxXXXx() {
/* 137 */     return this.L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public String A() {
/* 165 */     return this.h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public Integer iIIIIi() {
/* 178 */     return this.m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public Integer l() {
/* 186 */     return this.a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public IndexEnum PppPpp() {
/* 201 */     return this.e;
/*     */   } }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\KcifTq.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */