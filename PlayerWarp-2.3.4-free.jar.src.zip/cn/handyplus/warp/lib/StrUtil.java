/*     */ package cn.handyplus.warp.lib;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public final class StrUtil {
/*     */   @Nullable
/*     */   public static String toLowerCase(@Nullable String str) {
/*   7 */     return (str != null) ? str.toLowerCase() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNotEmpty(@Nullable CharSequence str) {
/*  16 */     return !isEmpty(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static String humpToLine(@NotNull String str) {
/*     */     // Byte code:
/*     */     //   0: getstatic cn/handyplus/warp/lib/PatternUtil.HUMP_PATTERN : Ljava/util/regex/Pattern;
/*     */     //   3: aload_0
/*     */     //   4: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
/*     */     //   7: astore_1
/*     */     //   8: new java/lang/StringBuffer
/*     */     //   11: dup
/*     */     //   12: invokespecial <init> : ()V
/*     */     //   15: astore_2
/*     */     //   16: aload_1
/*     */     //   17: invokevirtual find : ()Z
/*     */     //   20: ifeq -> 66
/*     */     //   23: aload_2
/*     */     //   24: new java/lang/StringBuilder
/*     */     //   27: aload_2
/*     */     //   28: dup
/*     */     //   29: pop2
/*     */     //   30: dup
/*     */     //   31: invokespecial <init> : ()V
/*     */     //   34: ldc ''
/*     */     //   36: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   39: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   42: aload_1
/*     */     //   43: dup_x2
/*     */     //   44: dup_x2
/*     */     //   45: iconst_0
/*     */     //   46: invokevirtual group : (I)Ljava/lang/String;
/*     */     //   49: invokevirtual toLowerCase : ()Ljava/lang/String;
/*     */     //   52: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   55: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   58: invokevirtual appendReplacement : (Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;
/*     */     //   61: pop
/*     */     //   62: goto -> 17
/*     */     //   65: athrow
/*     */     //   66: aload_1
/*     */     //   67: aload_2
/*     */     //   68: invokevirtual appendTail : (Ljava/lang/StringBuffer;)Ljava/lang/StringBuffer;
/*     */     //   71: pop
/*     */     //   72: aload_2
/*     */     //   73: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   76: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #69	-> 0
/*     */     //   #114	-> 8
/*     */     //   #135	-> 16
/*     */     //   #97	-> 23
/*     */     //   #39	-> 66
/*     */     //   #182	-> 72
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	77	0	str	Ljava/lang/String;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equals(@Nullable CharSequence str1, @Nullable CharSequence str2) {
/* 112 */     if (null == str1)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 489 */       return (str2 == null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (null == str2) {
/* 591 */       return false;
/*     */     }
/*     */     return str1.toString().contentEquals(str2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static String deleteWhitespace(@Nullable String str) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
/*     */     //   4: ifeq -> 10
/*     */     //   7: aload_0
/*     */     //   8: areturn
/*     */     //   9: athrow
/*     */     //   10: aload_0
/*     */     //   11: invokevirtual length : ()I
/*     */     //   14: dup
/*     */     //   15: istore_1
/*     */     //   16: newarray char
/*     */     //   18: iconst_1
/*     */     //   19: dup
/*     */     //   20: pop2
/*     */     //   21: astore_2
/*     */     //   22: iconst_0
/*     */     //   23: istore_3
/*     */     //   24: iconst_0
/*     */     //   25: dup
/*     */     //   26: istore #4
/*     */     //   28: iload_1
/*     */     //   29: if_icmpge -> 65
/*     */     //   32: aload_0
/*     */     //   33: iload #4
/*     */     //   35: invokevirtual charAt : (I)C
/*     */     //   38: invokestatic isWhitespace : (C)Z
/*     */     //   41: ifne -> 56
/*     */     //   44: aload_2
/*     */     //   45: iload_3
/*     */     //   46: aload_0
/*     */     //   47: iload #4
/*     */     //   49: invokevirtual charAt : (I)C
/*     */     //   52: iinc #3, 1
/*     */     //   55: castore
/*     */     //   56: iinc #4, 1
/*     */     //   59: iload #4
/*     */     //   61: goto -> 28
/*     */     //   64: athrow
/*     */     //   65: iload_3
/*     */     //   66: iload_1
/*     */     //   67: if_icmpne -> 72
/*     */     //   70: aload_0
/*     */     //   71: areturn
/*     */     //   72: new java/lang/String
/*     */     //   75: dup
/*     */     //   76: aload_2
/*     */     //   77: iconst_0
/*     */     //   78: iload_3
/*     */     //   79: invokespecial <init> : ([CII)V
/*     */     //   82: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #120	-> 0
/*     */     //   #24	-> 7
/*     */     //   #197	-> 10
/*     */     //   #185	-> 16
/*     */     //   #122	-> 22
/*     */     //   #128	-> 24
/*     */     //   #15	-> 32
/*     */     //   #105	-> 44
/*     */     //   #128	-> 56
/*     */     //   #73	-> 65
/*     */     //   #28	-> 70
/*     */     //   #91	-> 72
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	83	0	str	Ljava/lang/String;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static List<Double> strToDoubleList(@Nullable String str) {
/*     */     ArrayList<Double> arrayList = new ArrayList();
/*     */     if (isEmpty(str)) {
/*     */       return arrayList;
/*     */     }
/*     */     return (List<Double>)Arrays.<String>stream(str.split(HandySchedulerUtil.qzlKeO("6"))).map(a -> Double.valueOf(a.trim())).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static List<String> strToStrList(@Nullable String str, @NotNull String split) {
/*     */     ArrayList<String> arrayList = new ArrayList();
/*     */     if (isEmpty(str)) {
/*     */       return arrayList;
/*     */     }
/*     */     return (List<String>)Arrays.<String>stream(str.split(split)).map(String::trim).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEmpty(@Nullable CharSequence str) {
/*     */     return (str == null || str.length() == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static List<Long> strToLongList(@Nullable String str) {
/*     */     ArrayList<Long> arrayList = new ArrayList();
/*     */     if (isEmpty(str)) {
/*     */       return arrayList;
/*     */     }
/*     */     return (List<Long>)Arrays.<String>stream(str.split(HandySchedulerUtil.qzlKeO("6"))).map(a -> Long.valueOf(Long.parseLong(a.trim()))).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static String replace(@Nullable String str, @Nullable String format, String value) {
/*     */     if (isEmpty(str) || isEmpty(format)) {
/*     */       return str;
/*     */     }
/*     */     String str1 = (format.startsWith(HandySchedulerUtil.qzlKeO("6a")) && format.endsWith(HandyHttpUtil.qzlKeO("]"))) ? format : (new StringBuilder()).insert(0, HandySchedulerUtil.qzlKeO("6a")).append(format).append(HandyHttpUtil.qzlKeO("]")).toString();
/*     */     return str.replace(str1, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static List<String> strToStrList(@Nullable String str) {
/*     */     return strToStrList(str, HandyHttpUtil.qzlKeO("\f"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static List<Integer> strToIntList(@Nullable String str) {
/*     */     ArrayList<Integer> arrayList = new ArrayList();
/*     */     if (isEmpty(str)) {
/*     */       return arrayList;
/*     */     }
/*     */     return (List<Integer>)Arrays.<String>stream(str.split(HandyHttpUtil.qzlKeO("\f"))).map(a -> Integer.valueOf(a.trim())).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static String lineToHump(@NotNull String str) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokevirtual toLowerCase : ()Ljava/lang/String;
/*     */     //   4: astore_0
/*     */     //   5: getstatic cn/handyplus/warp/lib/PatternUtil.LINE_PATTERN : Ljava/util/regex/Pattern;
/*     */     //   8: aload_0
/*     */     //   9: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
/*     */     //   12: astore_1
/*     */     //   13: new java/lang/StringBuffer
/*     */     //   16: dup
/*     */     //   17: invokespecial <init> : ()V
/*     */     //   20: astore_2
/*     */     //   21: aload_1
/*     */     //   22: invokevirtual find : ()Z
/*     */     //   25: ifeq -> 47
/*     */     //   28: aload_2
/*     */     //   29: aload_1
/*     */     //   30: dup_x1
/*     */     //   31: dup_x2
/*     */     //   32: iconst_1
/*     */     //   33: invokevirtual group : (I)Ljava/lang/String;
/*     */     //   36: invokevirtual toUpperCase : ()Ljava/lang/String;
/*     */     //   39: invokevirtual appendReplacement : (Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;
/*     */     //   42: pop
/*     */     //   43: goto -> 22
/*     */     //   46: athrow
/*     */     //   47: aload_1
/*     */     //   48: aload_2
/*     */     //   49: invokevirtual appendTail : (Ljava/lang/StringBuffer;)Ljava/lang/StringBuffer;
/*     */     //   52: pop
/*     */     //   53: aload_2
/*     */     //   54: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   57: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #215	-> 0
/*     */     //   #141	-> 5
/*     */     //   #177	-> 13
/*     */     //   #71	-> 21
/*     */     //   #99	-> 28
/*     */     //   #27	-> 47
/*     */     //   #116	-> 53
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	58	0	str	Ljava/lang/String;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static String replaceSpace(@Nullable String str) {
/*     */     if (isEmpty(str)) {
/*     */       return str;
/*     */     }
/*     */     return str.replace(HandyHttpUtil.qzlKeO("\003"), HandySchedulerUtil.qzlKeO(":"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWrap(@Nullable CharSequence str, int prefixChar, int suffixChar) {
/*     */     if (null == str || str.length() < 2) {
/*     */       return false;
/*     */     }
/* 764 */     return (str.charAt(0) == prefixChar && str.charAt(str.length() - 1) == suffixChar);
/*     */   }
/*     */   
/*     */   public static String replaceLast(@NotNull String text, @NotNull String regex, @NotNull String replacement) {
/*     */     int i;
/*     */     if ((i = text.lastIndexOf(regex)) != -1)
/*     */       return (new StringBuilder()).insert(0, text.substring(0, i)).append(replacement).append(text.substring(i + regex.length())).toString(); 
/*     */     return text;
/*     */   }
/*     */   
/*     */   public static boolean contains(@Nullable CharSequence str, @Nullable CharSequence search) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: ifnull -> 8
/*     */     //   4: aload_1
/*     */     //   5: ifnonnull -> 11
/*     */     //   8: iconst_0
/*     */     //   9: ireturn
/*     */     //   10: athrow
/*     */     //   11: aload_1
/*     */     //   12: invokeinterface length : ()I
/*     */     //   17: dup
/*     */     //   18: istore_2
/*     */     //   19: ifne -> 25
/*     */     //   22: iconst_1
/*     */     //   23: ireturn
/*     */     //   24: athrow
/*     */     //   25: aload_0
/*     */     //   26: invokeinterface toString : ()Ljava/lang/String;
/*     */     //   31: astore_3
/*     */     //   32: aload_1
/*     */     //   33: invokeinterface toString : ()Ljava/lang/String;
/*     */     //   38: astore_1
/*     */     //   39: aload_3
/*     */     //   40: invokevirtual length : ()I
/*     */     //   43: iload_2
/*     */     //   44: isub
/*     */     //   45: istore #4
/*     */     //   47: iconst_0
/*     */     //   48: dup
/*     */     //   49: istore #5
/*     */     //   51: iload #4
/*     */     //   53: if_icmpgt -> 79
/*     */     //   56: aload_3
/*     */     //   57: iconst_1
/*     */     //   58: iload #5
/*     */     //   60: aload_1
/*     */     //   61: iconst_0
/*     */     //   62: iload_2
/*     */     //   63: invokevirtual regionMatches : (ZILjava/lang/String;II)Z
/*     */     //   66: ifeq -> 71
/*     */     //   69: iconst_1
/*     */     //   70: ireturn
/*     */     //   71: iinc #5, 1
/*     */     //   74: iload #5
/*     */     //   76: goto -> 51
/*     */     //   79: iconst_0
/*     */     //   80: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #423	-> 0
/*     */     //   #381	-> 8
/*     */     //   #672	-> 11
/*     */     //   #629	-> 19
/*     */     //   #343	-> 22
/*     */     //   #340	-> 25
/*     */     //   #449	-> 32
/*     */     //   #772	-> 39
/*     */     //   #499	-> 47
/*     */     //   #458	-> 56
/*     */     //   #705	-> 69
/*     */     //   #499	-> 71
/*     */     //   #303	-> 79
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	81	0	str	Ljava/lang/CharSequence;
/*     */     //   0	81	1	search	Ljava/lang/CharSequence;
/*     */   }
/*     */   
/*     */   public static boolean contains(@Nullable String str, @Nullable List<?> list) {
/*     */     if (isEmpty(str) || CollUtil.isEmpty(list))
/*     */       return false; 
/*     */     Objects.requireNonNull(str);
/*     */     return list.stream().anyMatch(str::contains);
/*     */   }
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_5
/*     */     //   1: iconst_4
/*     */     //   2: ishl
/*     */     //   3: iconst_2
/*     */     //   4: dup
/*     */     //   5: ishl
/*     */     //   6: iconst_3
/*     */     //   7: ixor
/*     */     //   8: ixor
/*     */     //   9: iconst_2
/*     */     //   10: iconst_5
/*     */     //   11: ixor
/*     */     //   12: iconst_4
/*     */     //   13: ishl
/*     */     //   14: iconst_5
/*     */     //   15: iconst_1
/*     */     //   16: ishl
/*     */     //   17: ixor
/*     */     //   18: iconst_3
/*     */     //   19: iconst_5
/*     */     //   20: ixor
/*     */     //   21: iconst_3
/*     */     //   22: ishl
/*     */     //   23: iconst_5
/*     */     //   24: ixor
/*     */     //   25: aload_0
/*     */     //   26: checkcast java/lang/String
/*     */     //   29: dup
/*     */     //   30: astore_0
/*     */     //   31: invokevirtual length : ()I
/*     */     //   34: dup
/*     */     //   35: newarray char
/*     */     //   37: iconst_1
/*     */     //   38: dup
/*     */     //   39: pop2
/*     */     //   40: swap
/*     */     //   41: iconst_1
/*     */     //   42: isub
/*     */     //   43: dup_x2
/*     */     //   44: istore_3
/*     */     //   45: astore_1
/*     */     //   46: istore #4
/*     */     //   48: dup_x2
/*     */     //   49: pop2
/*     */     //   50: istore_2
/*     */     //   51: iflt -> 91
/*     */     //   54: aload_1
/*     */     //   55: aload_0
/*     */     //   56: iload_3
/*     */     //   57: dup_x1
/*     */     //   58: invokevirtual charAt : (I)C
/*     */     //   61: iinc #3, -1
/*     */     //   64: iload_2
/*     */     //   65: ixor
/*     */     //   66: i2c
/*     */     //   67: castore
/*     */     //   68: iload_3
/*     */     //   69: iflt -> 91
/*     */     //   72: aload_1
/*     */     //   73: aload_0
/*     */     //   74: iload_3
/*     */     //   75: iinc #3, -1
/*     */     //   78: dup_x1
/*     */     //   79: invokevirtual charAt : (I)C
/*     */     //   82: iload #4
/*     */     //   84: ixor
/*     */     //   85: i2c
/*     */     //   86: castore
/*     */     //   87: iload_3
/*     */     //   88: goto -> 51
/*     */     //   91: new java/lang/String
/*     */     //   94: dup
/*     */     //   95: aload_1
/*     */     //   96: invokespecial <init> : ([C)V
/*     */     //   99: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	100	0	a	Ljava/lang/String;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\StrUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */