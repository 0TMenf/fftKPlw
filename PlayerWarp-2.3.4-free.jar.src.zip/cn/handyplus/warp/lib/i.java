/*    */ package cn.handyplus.warp.lib;
/*    */ 
/*    */ import cn.handyplus.warp.service.WarpLikePlayerService;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class i
/*    */ {
/* 41 */   private static final WarpLikePlayerService IiiIiI = new WarpLikePlayerService(null);
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\i.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */