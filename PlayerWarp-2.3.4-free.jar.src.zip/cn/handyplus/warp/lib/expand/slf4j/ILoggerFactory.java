package cn.handyplus.warp.lib.expand.slf4j;

public interface ILoggerFactory {
  Logger getLogger(String paramString);
}


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\expand\slf4j\ILoggerFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */