package cn.handyplus.warp.lib.expand.slf4j.event;

public class EventConstants {
  public static final int ERROR_INT = 40;
  
  public static final int WARN_INT = 30;
  
  public static final int INFO_INT = 20;
  
  public static final int DEBUG_INT = 10;
  
  public static final int TRACE_INT = 0;
  
  public static final String NA_SUBST = "NA/SubstituteLogger";
}


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\expand\slf4j\event\EventConstants.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */