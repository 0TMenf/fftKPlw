/*    */ package cn.handyplus.warp.lib.expand.slf4j.impl;
/*    */ 
/*    */ import cn.handyplus.warp.lib.expand.slf4j.ILoggerFactory;
/*    */ import cn.handyplus.warp.lib.expand.slf4j.helpers.NOPLoggerFactory;
/*    */ import cn.handyplus.warp.lib.expand.slf4j.spi.LoggerFactoryBinder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StaticLoggerBinder
/*    */   implements LoggerFactoryBinder
/*    */ {
/* 44 */   private static final StaticLoggerBinder SINGLETON = new StaticLoggerBinder();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final StaticLoggerBinder getSingleton() {
/* 52 */     return SINGLETON;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 60 */   public static String REQUESTED_API_VERSION = "1.6.99";
/*    */   
/* 62 */   private static final String loggerFactoryClassStr = NOPLoggerFactory.class.getName();
/*    */ 
/*    */   
/*    */   private final ILoggerFactory loggerFactory;
/*    */ 
/*    */ 
/*    */   
/*    */   private StaticLoggerBinder() {
/* 70 */     this.loggerFactory = (ILoggerFactory)new NOPLoggerFactory();
/*    */   }
/*    */   
/*    */   public ILoggerFactory getLoggerFactory() {
/* 74 */     return this.loggerFactory;
/*    */   }
/*    */   
/*    */   public String getLoggerFactoryClassStr() {
/* 78 */     return loggerFactoryClassStr;
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\expand\slf4j\impl\StaticLoggerBinder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */