/*    */ package cn.handyplus.warp.lib.expand;
/*    */ import lombok.Generated;
/*    */ 
/*    */ public final class TexturesParam {
/*    */   private Textures textures;
/*    */   
/*    */   @Generated
/*    */   public void setTextures(Textures textures) {
/*  9 */     this.textures = textures;
/*    */   }
/*    */   
/*    */   @Generated
/* 13 */   public Textures getTextures() { return this.textures; } public static class Textures { @Generated
/*    */     public void setSKIN(TexturesParam.Skin SKIN) {
/* 15 */       this.SKIN = SKIN;
/*    */     } private TexturesParam.Skin SKIN; }
/*    */   public static class Skin { private String url;
/*    */     @Generated
/*    */     public void setUrl(String url) {
/* 20 */       this.url = url;
/*    */     } }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getUrl() {
/* 31 */     return this.textures.SKIN.url;
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\expand\TexturesParam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */