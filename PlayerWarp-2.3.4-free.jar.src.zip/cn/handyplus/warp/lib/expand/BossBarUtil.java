/*     */ package cn.handyplus.warp.lib.expand;
/*     */ 
/*     */ import cn.handyplus.warp.lib.BaseUtil;
/*     */ import cn.handyplus.warp.lib.HandyRunnable;
/*     */ import cn.handyplus.warp.lib.HandySchedulerUtil;
/*     */ import cn.handyplus.warp.lib.InitApi;
/*     */ import cn.handyplus.warp.lib.LegacyUtil;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.NamespacedKey;
/*     */ import org.bukkit.boss.BarColor;
/*     */ import org.bukkit.boss.BarFlag;
/*     */ import org.bukkit.boss.BarStyle;
/*     */ import org.bukkit.boss.BossBar;
/*     */ import org.bukkit.boss.KeyedBossBar;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BossBarUtil
/*     */ {
/*     */   public static KeyedBossBar createBossBar(String title) {
/*  45 */     KeyedBossBar bossBar = Bukkit.createBossBar(new NamespacedKey((Plugin)InitApi.PLUGIN, 
/*  46 */           UUID.randomUUID().toString()), 
/*  47 */         LegacyUtil.parseColor(title), BarColor.PINK, BarStyle.SOLID, new BarFlag[0]);
/*     */ 
/*     */ 
/*     */     
/*  51 */     bossBar.setProgress(1.0D);
/*  52 */     return bossBar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setStyle(KeyedBossBar bossBar, BarStyle barStyle) {
/*  62 */     bossBar.setStyle(barStyle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setColor(KeyedBossBar bossBar, BarColor barColor) {
/*  72 */     bossBar.setColor(barColor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setProgress(KeyedBossBar bossBar, double progress) {
/*  82 */     bossBar.setProgress(progress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setProgress(final NamespacedKey namespacedKey, Integer delay) {
/*  93 */     final BigDecimal bigDecimal = BigDecimal.valueOf(0.1D / delay.intValue()).setScale(5, RoundingMode.HALF_UP);
/*  94 */     final BigDecimal[] one = { BigDecimal.ONE };
/*  95 */     HandyRunnable handyRunnable = new HandyRunnable()
/*     */       {
/*     */         public void run() {
/*  98 */           BossBar bossBar = BossBarUtil.getBossBar(namespacedKey);
/*  99 */           if (bossBar == null || !bossBar.isVisible() || one[0].compareTo(BigDecimal.ZERO) <= 0) {
/* 100 */             cancel();
/*     */             return;
/*     */           } 
/* 103 */           one[0] = one[0].subtract(bigDecimal);
/* 104 */           if (one[0].compareTo(BigDecimal.ZERO) <= 0) {
/* 105 */             one[0] = BigDecimal.ZERO;
/*     */           }
/* 107 */           bossBar.setProgress(one[0].doubleValue());
/*     */         }
/*     */       };
/* 110 */     HandySchedulerUtil.runTaskTimer(handyRunnable, 2L, 2L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyedBossBar createBossBar(FileConfiguration config, String type, String title) {
/* 123 */     String color = config.getString(type + ".color", "PINK");
/* 124 */     String style = config.getString(type + ".style", "SOLID");
/* 125 */     BarColor barColor = BarColor.valueOf(color.toUpperCase());
/* 126 */     BarStyle barStyle = BarStyle.valueOf(style.toUpperCase());
/* 127 */     return createBossBar(title, barColor, barStyle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyedBossBar createBossBar(String title, BarColor barColor, BarStyle barStyle) {
/* 140 */     KeyedBossBar bossBar = Bukkit.createBossBar(new NamespacedKey((Plugin)InitApi.PLUGIN, 
/* 141 */           UUID.randomUUID().toString()), 
/* 142 */         LegacyUtil.parseColor(title), barColor, barStyle, new BarFlag[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     bossBar.setProgress(1.0D);
/* 148 */     return bossBar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyedBossBar createBossBar(String title, BarColor barColor, BarStyle barStyle, BarFlag barFlag) {
/* 162 */     KeyedBossBar bossBar = Bukkit.createBossBar(new NamespacedKey((Plugin)InitApi.PLUGIN, 
/* 163 */           UUID.randomUUID().toString()), 
/* 164 */         LegacyUtil.parseColor(title), barColor, barStyle, new BarFlag[] { barFlag });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     bossBar.setProgress(1.0D);
/* 170 */     return bossBar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addPlayer(NamespacedKey namespacedKey, Player player) {
/* 181 */     addPlayer(namespacedKey, Collections.singletonList(player));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addPlayer(NamespacedKey namespacedKey, String playerName) {
/* 192 */     Optional<Player> playerOpt = BaseUtil.getOnlinePlayer(playerName);
/* 193 */     playerOpt.ifPresent(player -> addPlayer(namespacedKey, player));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addPlayer(NamespacedKey namespacedKey, UUID playerUuid) {
/* 204 */     Optional<Player> onlinePlayer = BaseUtil.getOnlinePlayer(playerUuid);
/* 205 */     onlinePlayer.ifPresent(player -> addPlayer(namespacedKey, player));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addPlayerByUuid(NamespacedKey namespacedKey, List<UUID> playerUuidList) {
/* 216 */     for (UUID playerUuid : playerUuidList) {
/* 217 */       addPlayer(namespacedKey, playerUuid);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addPlayerByName(NamespacedKey namespacedKey, List<String> playerNameList) {
/* 229 */     for (String playerName : playerNameList) {
/* 230 */       addPlayer(namespacedKey, playerName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addPlayer(NamespacedKey namespacedKey, List<Player> playerList) {
/* 242 */     BossBar bossBar = getBossBar(namespacedKey);
/* 243 */     if (bossBar == null) {
/*     */       return;
/*     */     }
/* 246 */     for (Player player : playerList) {
/* 247 */       bossBar.addPlayer(player);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addAllPlayer(KeyedBossBar bossBar) {
/* 258 */     for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
/* 259 */       bossBar.addPlayer(onlinePlayer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removePlayer(NamespacedKey namespacedKey, Player player) {
/* 271 */     removePlayer(namespacedKey, Collections.singletonList(player));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removePlayer(NamespacedKey namespacedKey, String playerName) {
/* 282 */     Optional<Player> playerOpt = BaseUtil.getOnlinePlayer(playerName);
/* 283 */     playerOpt.ifPresent(player -> removePlayer(namespacedKey, player));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removePlayer(NamespacedKey namespacedKey, UUID playerUuid) {
/* 294 */     Optional<Player> playerOpt = BaseUtil.getOnlinePlayer(playerUuid);
/* 295 */     playerOpt.ifPresent(player -> removePlayer(namespacedKey, player));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removePlayerByUuid(NamespacedKey namespacedKey, List<UUID> playerUuidList) {
/* 306 */     for (UUID playerUuid : playerUuidList) {
/* 307 */       removePlayer(namespacedKey, playerUuid);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removePlayerByName(NamespacedKey namespacedKey, List<String> playerNameList) {
/* 319 */     for (String playerName : playerNameList) {
/* 320 */       removePlayer(namespacedKey, playerName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removePlayer(NamespacedKey namespacedKey, List<Player> playerList) {
/* 332 */     BossBar bossBar = getBossBar(namespacedKey);
/* 333 */     if (bossBar == null) {
/*     */       return;
/*     */     }
/* 336 */     for (Player player : playerList) {
/* 337 */       bossBar.removePlayer(player);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BossBar getBossBar(NamespacedKey namespacedKey) {
/* 349 */     return (BossBar)Bukkit.getBossBar(namespacedKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeBossBar(NamespacedKey namespacedKey) {
/* 359 */     Bukkit.removeBossBar(namespacedKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeBossBar(NamespacedKey namespacedKey, Integer delay) {
/* 370 */     HandySchedulerUtil.runTaskLater(() -> { BossBar bossBar = getBossBar(namespacedKey); bossBar.removeAll(); removeBossBar(namespacedKey); }(delay
/*     */ 
/*     */ 
/*     */         
/* 374 */         .intValue() * 20));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeAllBossBar() {
/* 383 */     Iterator<KeyedBossBar> bossBars = Bukkit.getBossBars();
/* 384 */     while (bossBars.hasNext()) {
/* 385 */       KeyedBossBar keyedBossBar = bossBars.next();
/* 386 */       keyedBossBar.removeAll();
/* 387 */       removeBossBar(keyedBossBar.getKey());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\expand\BossBarUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */