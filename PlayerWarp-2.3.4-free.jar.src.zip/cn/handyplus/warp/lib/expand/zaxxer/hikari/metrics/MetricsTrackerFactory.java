package cn.handyplus.warp.lib.expand.zaxxer.hikari.metrics;

public interface MetricsTrackerFactory {
  IMetricsTracker create(String paramString, PoolStats paramPoolStats);
}


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\expand\zaxxer\hikari\metrics\MetricsTrackerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */