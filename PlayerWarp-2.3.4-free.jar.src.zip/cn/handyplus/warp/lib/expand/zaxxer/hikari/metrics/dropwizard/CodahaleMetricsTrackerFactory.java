/*    */ package cn.handyplus.warp.lib.expand.zaxxer.hikari.metrics.dropwizard;
/*    */ 
/*    */ import cn.handyplus.warp.lib.expand.zaxxer.hikari.metrics.IMetricsTracker;
/*    */ import cn.handyplus.warp.lib.expand.zaxxer.hikari.metrics.MetricsTrackerFactory;
/*    */ import cn.handyplus.warp.lib.expand.zaxxer.hikari.metrics.PoolStats;
/*    */ import com.codahale.metrics.MetricRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CodahaleMetricsTrackerFactory
/*    */   implements MetricsTrackerFactory
/*    */ {
/*    */   private final MetricRegistry registry;
/*    */   
/*    */   public CodahaleMetricsTrackerFactory(MetricRegistry registry) {
/* 30 */     this.registry = registry;
/*    */   }
/*    */ 
/*    */   
/*    */   public MetricRegistry getRegistry() {
/* 35 */     return this.registry;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public IMetricsTracker create(String poolName, PoolStats poolStats) {
/* 41 */     return new CodaHaleMetricsTracker(poolName, poolStats, this.registry);
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\expand\zaxxer\hikari\metrics\dropwizard\CodahaleMetricsTrackerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */