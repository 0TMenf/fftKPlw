/*    */ package cn.handyplus.warp.lib.expand.zaxxer.hikari.metrics.micrometer;
/*    */ 
/*    */ import cn.handyplus.warp.lib.expand.zaxxer.hikari.metrics.IMetricsTracker;
/*    */ import cn.handyplus.warp.lib.expand.zaxxer.hikari.metrics.MetricsTrackerFactory;
/*    */ import cn.handyplus.warp.lib.expand.zaxxer.hikari.metrics.PoolStats;
/*    */ import io.micrometer.core.instrument.MeterRegistry;
/*    */ 
/*    */ 
/*    */ public class MicrometerMetricsTrackerFactory
/*    */   implements MetricsTrackerFactory
/*    */ {
/*    */   private final MeterRegistry registry;
/*    */   
/*    */   public MicrometerMetricsTrackerFactory(MeterRegistry registry) {
/* 15 */     this.registry = registry;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public IMetricsTracker create(String poolName, PoolStats poolStats) {
/* 21 */     return new MicrometerMetricsTracker(poolName, poolStats, this.registry);
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\expand\zaxxer\hikari\metrics\micrometer\MicrometerMetricsTrackerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */