/*    */ package cn.handyplus.warp.lib.expand.xseries.base;
/*    */ 
/*    */ import cn.handyplus.warp.lib.expand.xseries.base.annotations.XChange;
/*    */ import cn.handyplus.warp.lib.expand.xseries.base.annotations.XInfo;
/*    */ import cn.handyplus.warp.lib.expand.xseries.base.annotations.XMerge;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Internal
/*    */ public final class XModuleMetadata
/*    */ {
/*    */   private final boolean wasRemoved;
/*    */   private final XChange[] changes;
/*    */   private final XMerge[] merges;
/*    */   private final XInfo info;
/*    */   
/*    */   public XModuleMetadata(boolean wasRemoved, XChange[] changes, XMerge[] merges, XInfo info) {
/* 42 */     this.wasRemoved = wasRemoved;
/* 43 */     this.changes = changes;
/* 44 */     this.merges = merges;
/* 45 */     this.info = info;
/*    */   }
/*    */   
/*    */   public boolean wasRemoved() {
/* 49 */     return this.wasRemoved;
/*    */   }
/*    */   
/*    */   public XChange[] getChanges() {
/* 53 */     return this.changes;
/*    */   }
/*    */   
/*    */   public XMerge[] getMerges() {
/* 57 */     return this.merges;
/*    */   }
/*    */   
/*    */   public XInfo getInfo() {
/* 61 */     return this.info;
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\expand\xseries\base\XModuleMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */