/*     */ package cn.handyplus.warp.lib.expand.xseries.base;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Locale;
/*     */ import java.util.stream.Collectors;
/*     */ import org.jetbrains.annotations.ApiStatus.Internal;
/*     */ import org.jetbrains.annotations.Contract;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface XBase<XForm extends XBase<XForm, BukkitForm>, BukkitForm>
/*     */ {
/*     */   @NotNull
/*     */   @Contract(pure = true)
/*     */   default String friendlyName() {
/*  88 */     return Arrays.<String>stream(name().split("_"))
/*  89 */       .map(t -> t.charAt(0) + t.substring(1).toLowerCase(Locale.ENGLISH))
/*  90 */       .collect(Collectors.joining(" "));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default boolean isSupported() {
/* 111 */     return (get() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   @Contract(pure = true)
/*     */   default XForm or(XForm other) {
/* 128 */     return isSupported() ? (XForm)this : other;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Internal
/*     */   default XModuleMetadata getMetadata() {
/* 140 */     XRegistry<XForm, BukkitForm> registry = XRegistry.registryOf((Class)getClass());
/* 141 */     return registry.getOrRegisterMetadata((XForm)this, registry.getBackingField((XForm)this), false);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   @Contract(pure = true)
/*     */   String name();
/*     */   
/*     */   @Internal
/*     */   @Contract(pure = true)
/*     */   String[] getNames();
/*     */   
/*     */   @Nullable
/*     */   @Contract(pure = true)
/*     */   BukkitForm get();
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\expand\xseries\base\XBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */