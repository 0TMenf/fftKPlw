package cn.handyplus.warp.lib.expand.xseries.base.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.jetbrains.annotations.ApiStatus.Internal;

@Target({ElementType.FIELD})
@Retention(RetentionPolicy.SOURCE)
@Documented
@Internal
public @interface XInfo {
  String since();
  
  String removedSince() default "";
}


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\expand\xseries\base\annotations\XInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */