/*     */ package cn.handyplus.warp.lib.expand.xseries.base;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.jetbrains.annotations.ApiStatus.Experimental;
/*     */ import org.jetbrains.annotations.ApiStatus.Internal;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class XModule<XForm extends XModule<XForm, BukkitForm>, BukkitForm>
/*     */   implements XBase<XForm, BukkitForm>
/*     */ {
/*     */   private final BukkitForm bukkitForm;
/*     */   private final String[] names;
/*     */   
/*     */   @Internal
/*     */   protected XModule(BukkitForm bukkitForm, String[] names) {
/*  42 */     this.bukkitForm = bukkitForm;
/*  43 */     this.names = names;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public final String name() {
/*  54 */     return this.names[0];
/*     */   }
/*     */   
/*     */   @Experimental
/*     */   protected void setEnumName(XRegistry<XForm, BukkitForm> registry, String enumName) {
/*  59 */     if (this.names[0] != null)
/*  60 */       throw new IllegalStateException("Enum name already set " + enumName + " -> " + Arrays.toString(this.names)); 
/*  61 */     this.names[0] = enumName;
/*     */     
/*  63 */     BukkitForm newForm = registry.getBukkit(this.names);
/*  64 */     if (this.bukkitForm != newForm)
/*     */     {
/*  66 */       registry.std((XForm)this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Internal
/*     */   public String[] getNames() {
/*  73 */     return this.names;
/*     */   }
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final BukkitForm get() {
/*  79 */     return this.bukkitForm;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/*  84 */     return (isSupported() ? "" : "!") + getClass().getSimpleName() + '(' + name() + ')';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int hashCode() {
/*  92 */     return super.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final boolean equals(Object obj) {
/* 101 */     return super.equals(obj);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\expand\xseries\base\XModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */