package cn.handyplus.warp.lib.expand.xseries.base.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.jetbrains.annotations.ApiStatus.Internal;

@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(XMerges.class)
@Documented
@Internal
public @interface XMerge {
  String since() default "";
  
  String version();
  
  String name();
}


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\expand\xseries\base\annotations\XMerge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */