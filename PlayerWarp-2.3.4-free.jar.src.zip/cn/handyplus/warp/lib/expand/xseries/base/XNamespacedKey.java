/*     */ package cn.handyplus.warp.lib.expand.xseries.base;
/*     */ 
/*     */ import com.google.common.base.Preconditions;
/*     */ import org.bukkit.NamespacedKey;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class XNamespacedKey
/*     */ {
/*     */   private static final boolean SUPPORTS_NamespacedKey_fromString;
/*     */   
/*     */   static {
/*     */     boolean supportsFromString;
/*     */     try {
/*  36 */       Class<?> NamespacedKey = Class.forName("org.bukkit.NamespacedKey");
/*  37 */       NamespacedKey.getDeclaredMethod("fromString", new Class[] { String.class });
/*  38 */       supportsFromString = true;
/*  39 */     } catch (Throwable ex) {
/*  40 */       supportsFromString = false;
/*     */     } 
/*     */     
/*  43 */     SUPPORTS_NamespacedKey_fromString = supportsFromString;
/*     */   }
/*     */   
/*     */   private static boolean isValidNamespaceChar(char c) {
/*  47 */     return ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '.' || c == '_' || c == '-');
/*     */   }
/*     */   
/*     */   private static boolean isValidKeyChar(char c) {
/*  51 */     return (isValidNamespaceChar(c) || c == '/');
/*     */   }
/*     */   
/*     */   private static boolean isValidNamespace(String namespace) {
/*  55 */     int len = namespace.length();
/*  56 */     if (len == 0) {
/*  57 */       return false;
/*     */     }
/*     */     
/*  60 */     for (int i = 0; i < len; i++) {
/*  61 */       if (!isValidNamespaceChar(namespace.charAt(i))) {
/*  62 */         return false;
/*     */       }
/*     */     } 
/*     */     
/*  66 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean isValidKey(String key) {
/*  70 */     int len = key.length();
/*  71 */     if (len == 0) {
/*  72 */       return false;
/*     */     }
/*     */     
/*  75 */     for (int i = 0; i < len; i++) {
/*  76 */       if (!isValidKeyChar(key.charAt(i))) {
/*  77 */         return false;
/*     */       }
/*     */     } 
/*     */     
/*  81 */     return true;
/*     */   }
/*     */   
/*     */   protected static NamespacedKey fromString(@NotNull String string) {
/*  85 */     if (SUPPORTS_NamespacedKey_fromString) return NamespacedKey.fromString(string);
/*     */     
/*  87 */     Preconditions.checkArgument((string != null && !string.isEmpty()), "Input string must not be empty or null");
/*  88 */     String[] components = string.split(":", 3);
/*  89 */     if (components.length > 2) {
/*  90 */       return null;
/*     */     }
/*  92 */     String key = (components.length == 2) ? components[1] : "";
/*     */     
/*  94 */     if (components.length == 1) {
/*  95 */       String str = components[0];
/*  96 */       if (!str.isEmpty() && isValidKey(str)) {
/*  97 */         return NamespacedKey.minecraft(str);
/*     */       }
/*  99 */       return null;
/*     */     } 
/* 101 */     if (components.length == 2 && !isValidKey(key)) {
/* 102 */       return null;
/*     */     }
/* 104 */     String namespace = components[0];
/* 105 */     if (namespace.isEmpty()) {
/* 106 */       return NamespacedKey.minecraft(key);
/*     */     }
/* 108 */     return !isValidNamespace(namespace) ? null : new NamespacedKey(namespace, key);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\expand\xseries\base\XNamespacedKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */