/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import org.bukkit.World;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GameRuleUtil
/*     */ {
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_2
/*     */     //   1: iconst_5
/*     */     //   2: ixor
/*     */     //   3: iconst_3
/*     */     //   4: ishl
/*     */     //   5: iconst_4
/*     */     //   6: ixor
/*     */     //   7: iconst_5
/*     */     //   8: iconst_4
/*     */     //   9: ishl
/*     */     //   10: iconst_5
/*     */     //   11: ixor
/*     */     //   12: iconst_5
/*     */     //   13: iconst_4
/*     */     //   14: ishl
/*     */     //   15: aload_0
/*     */     //   16: checkcast java/lang/String
/*     */     //   19: dup
/*     */     //   20: astore_0
/*     */     //   21: invokevirtual length : ()I
/*     */     //   24: dup
/*     */     //   25: newarray char
/*     */     //   27: iconst_1
/*     */     //   28: dup
/*     */     //   29: pop2
/*     */     //   30: swap
/*     */     //   31: iconst_1
/*     */     //   32: isub
/*     */     //   33: dup_x2
/*     */     //   34: istore_3
/*     */     //   35: astore_1
/*     */     //   36: istore #4
/*     */     //   38: dup_x2
/*     */     //   39: pop
/*     */     //   40: istore_2
/*     */     //   41: pop
/*     */     //   42: iflt -> 82
/*     */     //   45: aload_1
/*     */     //   46: aload_0
/*     */     //   47: iload_3
/*     */     //   48: dup_x1
/*     */     //   49: invokevirtual charAt : (I)C
/*     */     //   52: iinc #3, -1
/*     */     //   55: iload_2
/*     */     //   56: ixor
/*     */     //   57: i2c
/*     */     //   58: castore
/*     */     //   59: iload_3
/*     */     //   60: iflt -> 82
/*     */     //   63: aload_1
/*     */     //   64: aload_0
/*     */     //   65: iload_3
/*     */     //   66: iinc #3, -1
/*     */     //   69: dup_x1
/*     */     //   70: invokevirtual charAt : (I)C
/*     */     //   73: iload #4
/*     */     //   75: ixor
/*     */     //   76: i2c
/*     */     //   77: castore
/*     */     //   78: iload_3
/*     */     //   79: goto -> 42
/*     */     //   82: new java/lang/String
/*     */     //   85: dup
/*     */     //   86: aload_1
/*     */     //   87: invokespecial <init> : ([C)V
/*     */     //   90: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	91	0	a	Ljava/lang/String;
/*     */   }
/*     */   
/*     */   public static void setGameRuleValue(@NotNull World world, @NotNull String ruleName, @NotNull Object value) {
/* 221 */     if (CompatCore.j) {
/*     */       iIiiiI.HiJhyb(world, ruleName, value);
/*     */       return;
/*     */     } 
/*     */     pPPppP.HiJhyb(world, ruleName, value);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\GameRuleUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */