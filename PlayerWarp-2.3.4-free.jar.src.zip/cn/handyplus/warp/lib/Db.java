/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ public class Db<T> {
/*     */   @Generated
/*     */   public XxXXXX getDbSql() {
/*   6 */     return this.PppPPP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Class<T> j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private XxXXXX PppPPP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Db(Class<T> clazz) {
/*  52 */     this.j = clazz;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 170 */     pppPpP();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public final <R> void select(DbFunction... arrayOfDbFunction) {
/*     */     ArrayList<String> arrayList = new ArrayList();
/*     */     int i = (arrayOfDbFunction = arrayOfDbFunction).length;
/*     */     byte b;
/*     */     if ((b = 0) < i) {
/*     */       DbFunction<?, ?> dbFunction = arrayOfDbFunction[b];
/*     */       b++;
/*     */       arrayList.add(xXXxxX.oooOoo(dbFunction));
/*     */     } 
/* 223 */     this.PppPPP.xXXXXx(CollUtil.listToStr(arrayList)); this.PppPPP.I().entrySet().removeIf(entry -> !a.contains(entry.getKey()));
/*     */   }
/*     */   
/*     */   public static <T> Db<T> use(Class<T> a) {
/*     */     return new Db<>(a);
/*     */   }
/*     */   
/*     */   public DbExecution<T> execution() {
/*     */     return new DbExecution<>(this.PppPPP, this.j);
/*     */   }
/*     */   
/*     */   public DbExecution<T> execution(Connection connection) {
/*     */     return new DbExecution<>(this.PppPPP, this.j, connection);
/*     */   }
/*     */   
/*     */   public Compare<T> where() {
/*     */     return new Compare<>(this.PppPPP);
/*     */   }
/*     */   
/*     */   public final <R> void select(String... arrayOfString) {
/*     */     ArrayList<?> arrayList = new ArrayList(Arrays.asList((Object[])arrayOfString));
/*     */     this.PppPPP.xXXXXx(CollUtil.listToStr(arrayList));
/*     */     this.PppPPP.I().entrySet().removeIf(entry -> !a.contains(entry.getKey()));
/*     */   }
/*     */   
/*     */   public DbExecution<T> execution(String str) {
/*     */     return new DbExecution<>(this.PppPPP, this.j, str);
/*     */   }
/*     */   
/*     */   public UpdateCondition<T> update() {
/*     */     return new UpdateCondition<>(this.PppPPP);
/*     */   }
/*     */   
/*     */   public void createTable() {
/*     */     (new DbExecution(this.PppPPP, this.j, false)).PPPPpp();
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\Db.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */