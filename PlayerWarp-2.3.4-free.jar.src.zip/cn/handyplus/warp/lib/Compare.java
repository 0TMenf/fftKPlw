/*      */ package cn.handyplus.warp.lib;
/*      */ public class Compare<T> { private final XxXXXX PppPPP;
/*      */   
/*    4 */   public Compare(XxXXXX xxXXXX) { this
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   66 */       .PppPPP = xxXXXX; }
/*      */    public <R> Compare<T> ne(int i, DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2) {
/*      */     this.PppPPP.xXxXXX(i, xXXxxX.oooOoo(dbFunction1), oooOoO.h, xXXxxX.oooOoo(dbFunction2));
/*      */     return this;
/*      */   }
/*      */   public <R> Compare<T> ne(int i, DbFunction<?, ?> dbFunction, Object object) {
/*   72 */     this.PppPPP.l(i, xXXxxX.oooOoo(dbFunction), oooOoO.h, object); return this;
/*      */   } public <R> Compare<T> gt(int i, DbFunction<?, ?> dbFunction1, Object object, DbFunction<?, ?> dbFunction2) {
/*      */     this.PppPPP.iiIiiI(i, xXXxxX.oooOoo(dbFunction1), object, oooOoO.A, xXXxxX.oooOoo(dbFunction2));
/*      */     return this;
/*      */   } public <R> Compare<T> gt(DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2) {
/*      */     return gt(true, dbFunction1, dbFunction2);
/*      */   } public <R> Compare<T> gt(int i, DbFunction<?, ?> dbFunction, Object object) {
/*      */     this.PppPPP.l(i, xXXxxX.oooOoo(dbFunction), oooOoO.A, object);
/*      */     return this;
/*      */   }
/*      */   public <R> Compare<T> lt(DbFunction<?, ?> dbFunction, Object object) {
/*      */     return lt(true, dbFunction, object);
/*      */   }
/*      */   public <R> Compare<T> gt(DbFunction<?, ?> dbFunction, Object object) {
/*      */     return gt(true, dbFunction, object);
/*      */   }
/*      */   public <R> Compare<T> eq(int i, DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2) {
/*   89 */     this.PppPPP.xXxXXX(i, xXXxxX.oooOoo(dbFunction1), oooOoO.k, xXXxxX.oooOoo(dbFunction2)); return this;
/*      */   }
/*      */   
/*      */   public <R> Compare<T> gt(int i, DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2) {
/*   93 */     this.PppPPP.xXxXXX(i, xXXxxX.oooOoo(dbFunction1), oooOoO.A, xXXxxX.oooOoo(dbFunction2)); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> gt(DbFunction<?, ?> dbFunction1, Object object, DbFunction<?, ?> dbFunction2) {
/*  122 */     return gt(true, dbFunction1, object, dbFunction2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> ne(DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2) {
/*  159 */     return ne(true, dbFunction1, dbFunction2);
/*      */   }
/*      */   
/*      */   public <R> Compare<T> ne(DbFunction<?, ?> dbFunction, Object object) {
/*  163 */     return ne(true, dbFunction, object);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> eq(DbFunction<?, ?> dbFunction, Object object) {
/*  169 */     return eq(true, dbFunction, object);
/*  170 */   } public <R> Compare<T> eq(DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2) { return eq(true, dbFunction1, dbFunction2); } public <R> Compare<T> lt(DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2) {
/*  171 */     return lt(true, dbFunction1, dbFunction2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> eq(int i, DbFunction<?, ?> dbFunction, Object object) {
/*  186 */     this.PppPPP.l(i, xXXxxX.oooOoo(dbFunction), oooOoO.k, object); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> notLike(DbFunction<?, ?> dbFunction, Object object) {
/*  239 */     return notLike(true, dbFunction, object);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> le(DbFunction<?, ?> dbFunction1, Object object, DbFunction<?, ?> dbFunction2) {
/*  248 */     return le(true, dbFunction1, object, dbFunction2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> in(DbFunction<?, ?> dbFunction, List<?> list) {
/*  264 */     return in(true, dbFunction, list);
/*      */   }
/*      */ 
/*      */   
/*      */   public <R> Compare<T> orderByDesc(DbFunction<?, ?> dbFunction) {
/*  269 */     return orderByDesc(true, dbFunction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> like(DbFunction<?, ?> dbFunction, Object object) {
/*  278 */     return like(true, dbFunction, object);
/*      */   }
/*      */ 
/*      */   
/*      */   public <R> Compare<T> ge(int i, DbFunction<?, ?> dbFunction, Object object1, Object object2) {
/*  283 */     this.PppPPP.IiIiii(i, xXXxxX.oooOoo(dbFunction), object1, oooOoO.K, object2); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> ge(int i, DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2) {
/*  309 */     this.PppPPP.xXxXXX(i, xXXxxX.oooOoo(dbFunction1), oooOoO.K, xXXxxX.oooOoo(dbFunction2)); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> le(DbFunction<?, ?> dbFunction, Object object) {
/*  322 */     return le(true, dbFunction, object);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> ge(int i, DbFunction<?, ?> dbFunction, Object object) {
/*  329 */     this.PppPPP.l(i, xXXxxX.oooOoo(dbFunction), oooOoO.K, object); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> le(int i, DbFunction<?, ?> dbFunction1, Object object, DbFunction<?, ?> dbFunction2) {
/*  339 */     this.PppPPP.iiIiiI(i, xXXxxX.oooOoo(dbFunction1), object, oooOoO.I, xXXxxX.oooOoo(dbFunction2)); return this;
/*      */   }
/*      */   public <R> Compare<T> orderByDesc(int i, DbFunction<?, ?> dbFunction) {
/*  342 */     return orderByDesc(i, xXXxxX.oooOoo(dbFunction));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> orderByAsc(DbFunction<?, ?> dbFunction) {
/*  349 */     return orderByAsc(true, dbFunction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> like(int i, DbFunction<?, ?> dbFunction, Object object) {
/*  359 */     this.PppPPP.PppPpp(i, xXXxxX.oooOoo(dbFunction), oooOoO.e, (new StringBuilder()).insert(0, "%").append(object).append("%").toString()); return this;
/*      */   } public <R> Compare<T> le(DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2) {
/*  361 */     return le(true, dbFunction1, dbFunction2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> notLike(int i, DbFunction<?, ?> dbFunction, Object object) {
/*  368 */     this.PppPPP.PppPpp(i, xXXxxX.oooOoo(dbFunction), oooOoO.E, (new StringBuilder()).insert(0, "%").append(object).append("%").toString()); return this;
/*      */   }
/*      */   
/*      */   public <R> Compare<T> orderByDesc(int i, String str) {
/*  372 */     this.PppPPP.ppPPPP(i, str, oooOoO.b); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> le(int i, DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2) {
/*  393 */     this.PppPPP.xXxXXX(i, xXXxxX.oooOoo(dbFunction1), oooOoO.I, xXXxxX.oooOoo(dbFunction2)); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> orderByAsc(int i, DbFunction<?, ?> dbFunction) {
/*  402 */     return orderByAsc(i, xXXxxX.oooOoo(dbFunction));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> orderByAsc(int i, String str) {
/*  409 */     this.PppPPP.ppPPPP(i, str, oooOoO.i); return this;
/*      */   } public <R> Compare<T> le(int i, DbFunction<?, ?> dbFunction, Object object1, Object object2) {
/*  411 */     this.PppPPP.IiIiii(i, xXXxxX.oooOoo(dbFunction), object1, oooOoO.I, object2); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> lt(int i, DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2) {
/*  430 */     this.PppPPP.xXxXXX(i, xXXxxX.oooOoo(dbFunction1), oooOoO.M, xXXxxX.oooOoo(dbFunction2)); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> lt(int i, DbFunction<?, ?> dbFunction, Object object) {
/*  449 */     this.PppPPP.l(i, xXXxxX.oooOoo(dbFunction), oooOoO.M, object); return this;
/*      */   }
/*      */   
/*      */   public <R> Compare<T> ge(DbFunction<?, ?> dbFunction, Object object1, Object object2) {
/*  453 */     return ge(true, dbFunction, object1, object2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> ge(DbFunction<?, ?> dbFunction, Object object)
/*      */   {
/*  563 */     return ge(true, dbFunction, object); } public <R> Compare<T> likeLeft(int i, DbFunction<?, ?> dbFunction, Object object) {
/*  564 */     this.PppPPP.PppPpp(i, xXXxxX.oooOoo(dbFunction), oooOoO.e, (new StringBuilder()).insert(0, "%").append(object).toString()); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> lt(DbFunction<?, ?> dbFunction1, Object object, DbFunction<?, ?> dbFunction2) {
/*  571 */     return lt(true, dbFunction1, object, dbFunction2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> orderByAsc(int i, DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2) {
/*  583 */     this.PppPPP.iiiIIi(i, xXXxxX.oooOoo(dbFunction1), xXXxxX.oooOoo(dbFunction2), oooOoO.i); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> in(int i, DbFunction<?, ?> dbFunction, List<?> list) {
/*  596 */     this.PppPPP.oOOOoO(i, xXXxxX.oooOoo(dbFunction), oooOoO.L, list); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> lt(int i, DbFunction<?, ?> dbFunction1, Object object, DbFunction<?, ?> dbFunction2) {
/*  613 */     this.PppPPP.iiIiiI(i, xXXxxX.oooOoo(dbFunction1), object, oooOoO.M, xXXxxX.oooOoo(dbFunction2)); return this;
/*      */   } public <R> Compare<T> notIn(DbFunction<?, ?> dbFunction, List<?> list) {
/*  615 */     return notIn(true, dbFunction, list);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> ge(int i, DbFunction<?, ?> dbFunction1, Object object, DbFunction<?, ?> dbFunction2) {
/*  634 */     this.PppPPP.iiIiiI(i, xXXxxX.oooOoo(dbFunction1), object, oooOoO.K, xXXxxX.oooOoo(dbFunction2)); return this;
/*      */   }
/*      */   
/*      */   public <R> Compare<T> ge(DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2) {
/*  638 */     return ge(true, dbFunction1, dbFunction2); } public <R> Compare<T> likeLeft(DbFunction<?, ?> dbFunction, Object object) {
/*  639 */     return likeLeft(true, dbFunction, object);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> le(DbFunction<?, ?> dbFunction, Object object1, Object object2) {
/*  648 */     return le(true, dbFunction, object1, object2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> le(int i, DbFunction<?, ?> dbFunction, Object object) {
/*  654 */     this.PppPPP.l(i, xXXxxX.oooOoo(dbFunction), oooOoO.I, object); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> ge(DbFunction<?, ?> dbFunction1, Object object, DbFunction<?, ?> dbFunction2) {
/*  663 */     return ge(true, dbFunction1, object, dbFunction2);
/*      */   }
/*      */   public <R> Compare<T> likeRight(int i, DbFunction<?, ?> dbFunction, Object object) {
/*  666 */     this.PppPPP.PppPpp(i, xXXxxX.oooOoo(dbFunction), oooOoO.e, object + "%"); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> notIn(int i, DbFunction<?, ?> dbFunction, List<?> list) {
/*  702 */     this.PppPPP.oOOOoO(i, xXXxxX.oooOoo(dbFunction), oooOoO.f, list); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> likeRight(DbFunction<?, ?> dbFunction, Object object) {
/*  720 */     return likeRight(true, dbFunction, object);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> limit(int i, int j) {
/*  781 */     return limit(true, i, j);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> isNull(DbFunction<?, ?> dbFunction) {
/*  821 */     return isNull(true, dbFunction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Compare<T> orderByRand(int i) {
/*  865 */     this.PppPPP.XxxXxX(i); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> isNotNull(int i, DbFunction<?, ?> dbFunction) {
/*  940 */     this.PppPPP.l(i, xXXxxX.oooOoo(dbFunction), oooOoO.g); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> groupBy(int i, DbFunction<?, ?> dbFunction) {
/*  946 */     this.PppPPP.iIiiii(i, xXXxxX.oooOoo(dbFunction)); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> isNull(int i, DbFunction<?, ?> dbFunction) {
/* 1011 */     this.PppPPP.l(i, xXXxxX.oooOoo(dbFunction), oooOoO.G); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> groupBy(DbFunction<?, ?> dbFunction) {
/* 1034 */     return groupBy(true, dbFunction);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> orderByDesc(int i, DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2) {
/* 1104 */     this.PppPPP.iiiIIi(i, xXXxxX.oooOoo(dbFunction1), xXXxxX.oooOoo(dbFunction2), oooOoO.b); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> limit(int i, int j, int k) {
/* 1117 */     this.PppPPP.oOOOOO(i, j, k); return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R> Compare<T> isNotNull(DbFunction<?, ?> dbFunction) {
/* 1156 */     return isNotNull(true, dbFunction);
/*      */   }
/*      */   
/*      */   public Compare<T> orderByRand() {
/* 1160 */     return orderByRand(true);
/*      */   } }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\Compare.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */