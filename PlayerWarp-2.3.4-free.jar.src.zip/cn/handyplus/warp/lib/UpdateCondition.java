/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpdateCondition<T>
/*     */ {
/*     */   private final XxXXXX PppPPP;
/*     */   
/*     */   public <R> UpdateCondition<T> set(int i, DbFunction<?, ?> dbFunction, Object object) {
/*  18 */     this.PppPPP.IIIIii(i, xXXxxX.oooOoo(dbFunction), object); return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> UpdateCondition<T> set(DbFunction<?, ?> dbFunction, Object object) {
/*  41 */     return set(true, dbFunction, object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UpdateCondition(XxXXXX xxXXXX) {
/* 189 */     this.PppPPP = xxXXXX;
/*     */   }
/*     */   public <R> UpdateCondition<T> add(DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2, Object object) {
/* 192 */     return add(true, dbFunction1, dbFunction2, object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> UpdateCondition<T> subtract(DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2, Object object) {
/* 210 */     return subtract(true, dbFunction1, dbFunction2, object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> UpdateCondition<T> subtract(int i, DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2, Object object) {
/* 218 */     this.PppPPP.ppPPPP(i, xXXxxX.oooOoo(dbFunction1), xXXxxX.oooOoo(dbFunction2), " - ", object); return this; } public <R> UpdateCondition<T> add(int i, DbFunction<?, ?> dbFunction1, DbFunction<?, ?> dbFunction2, Object object) {
/* 219 */     this.PppPPP.ppPPPP(i, xXXxxX.oooOoo(dbFunction1), xXXxxX.oooOoo(dbFunction2), " + ", object); return this;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\UpdateCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */