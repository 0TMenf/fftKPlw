/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import cn.handyplus.warp.service.WarpChannelService;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.configuration.ConfigurationSection;
/*     */ import org.bukkit.configuration.MemorySection;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.HumanEntity;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.InventoryHolder;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HandyInventoryUtil
/*     */ {
/*     */   public static Optional<Player> getPlayer(InventoryClickEvent a) {
/*     */     HumanEntity humanEntity;
/*  36 */     if (humanEntity = a.getWhoClicked() instanceof Player)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 185 */       return Optional.of((Player)humanEntity);
/*     */     }
/*     */     return Optional.empty();
/*     */   }
/*     */   
/*     */   public static void refreshInventory(Inventory a) {
/*     */     // Byte code:
/*     */     //   0: iconst_0
/*     */     //   1: dup
/*     */     //   2: istore_1
/*     */     //   3: aload_0
/*     */     //   4: invokeinterface getSize : ()I
/*     */     //   9: if_icmpge -> 40
/*     */     //   12: aload_0
/*     */     //   13: new org/bukkit/inventory/ItemStack
/*     */     //   16: iload_1
/*     */     //   17: dup_x1
/*     */     //   18: dup
/*     */     //   19: pop2
/*     */     //   20: dup
/*     */     //   21: iinc #1, 1
/*     */     //   24: getstatic org/bukkit/Material.AIR : Lorg/bukkit/Material;
/*     */     //   27: invokespecial <init> : (Lorg/bukkit/Material;)V
/*     */     //   30: invokeinterface setItem : (ILorg/bukkit/inventory/ItemStack;)V
/*     */     //   35: iload_1
/*     */     //   36: goto -> 3
/*     */     //   39: athrow
/*     */     //   40: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #43	-> 0
/*     */     //   #55	-> 12
/*     */     //   #43	-> 35
/*     */     //   #44	-> 40
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	41	0	a	Lorg/bukkit/inventory/Inventory;
/*     */   }
/*     */   
/*     */   public static void setButton(FileConfiguration a, HandyInventory handyInventory, String str) {
/*     */     setButton(a, handyInventory, str, null);
/*     */   }
/*     */   
/*     */   public static boolean isIndex(int a, FileConfiguration fileConfiguration, String str) { super();
/*     */     List<Integer> list = StrUtil.strToIntList((new StringBuilder()).getString(fileConfiguration.append(str).append(WarpChannelService.qzlKeO(" @`MkQ")).toString()));
/* 200 */     if (fileConfiguration.getBoolean((new StringBuilder()).insert(0, str).append(SecureUtil.qzlKeO("\b\\HXDUC")).toString(), true) && list.contains(Integer.valueOf(a))) return true;  return false; } public static void setButton(FileConfiguration a, HandyInventory handyInventory, String str, Map<String, String> map, Map<String, List<String>> map1, int i) { super(); if (!(new StringBuilder()).getBoolean(a.append(str).append(WarpChannelService.qzlKeO("\007kGoKbL")).toString(), true))
/*     */       return; 
/*     */     Inventory inventory = handyInventory.getInventory();
/*     */     Player player = handyInventory.getPlayer();
/* 204 */     List<Integer> list = StrUtil.strToIntList(a.getString((new StringBuilder()).insert(0, str).append(SecureUtil.qzlKeO("\027OWB\\^")).toString()));
/*     */ 
/*     */ 
/*     */     
/*     */     String str1 = a.getString((new StringBuilder()).insert(0, str).append(WarpChannelService.qzlKeO("\007`HcL")).toString());
/*     */ 
/*     */ 
/*     */     
/*     */     int j = a.getInt((new StringBuilder()).insert(0, str).append(SecureUtil.qzlKeO("\bXKVSWR")).toString(), 1);
/*     */ 
/*     */     
/* 215 */     String str2 = a.getString((new StringBuilder()).insert(0, str).append(WarpChannelService.qzlKeO("\007cHzL|@oE")).toString());
/*     */     
/*     */     List<String> list1 = a.getStringList((new StringBuilder()).insert(0, str).append(SecureUtil.qzlKeO("\bUIKC")).toString());
/*     */     
/*     */     int k = a.getInt((new StringBuilder()).insert(0, str).append(WarpChannelService.qzlKeO(" J{ZzFc\004cFjLb\004jHzH")).toString());
/*     */     
/*     */     i = (i != 0 || a.getBoolean((new StringBuilder()).insert(0, str).append(SecureUtil.qzlKeO("\027OJcWEQGWR")).toString())) ? 1 : 0;
/*     */     
/*     */     boolean bool1 = a.getBoolean((new StringBuilder()).insert(0, str).append(WarpChannelService.qzlKeO("\007f@jLHEoN")).toString(), true);
/*     */     
/*     */     boolean bool2 = a.getBoolean(SecureUtil.qzlKeO("NPB\\cWEQGWR"), true);
/*     */     String str3 = a.getString((new StringBuilder()).insert(0, str).append(WarpChannelService.qzlKeO(" Za\\`M")).toString());
/*     */     String str4 = a.getString((new StringBuilder()).insert(0, str).append(SecureUtil.qzlKeO("\bQCXB{GJC")).toString());
/*     */     String str5 = a.getString((new StringBuilder()).insert(0, str).append(WarpChannelService.qzlKeO("\007fLoM")).toString());
/*     */     String str6 = a.getString((new StringBuilder()).insert(0, str).append(SecureUtil.qzlKeO("\bMIVJMOIuM_UC")).toString());
/* 230 */     str = a.getString((new StringBuilder()).insert(0, str).append(WarpChannelService.qzlKeO(" @zLcdaMkE")).toString()); if (StrUtil.isNotEmpty(str5) && player != null)
/* 231 */       str5 = StrUtil.replace(str5, SecureUtil.qzlKeO("IJX_\\T"), player.getName());  for (Integer integer : list) { list1 = ItemStackUtil.loreBatchReplaceMap(list1, map1, (String)null); ItemStack itemStack = ItemStackUtil.getItemStack(str2, str1, list1, i, k, bool1, map, bool2, null, str6, str);
/*     */       itemStack.setAmount(j);
/*     */       ItemStackUtil.setSkull(itemStack, str4); }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getIndex(FileConfiguration a, String str) {
/*     */     super();
/*     */     return (new StringBuilder()).getInt(a.append(str).append(SecureUtil.qzlKeO("\027OWB\\^")).toString(), 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setCustomButton(FileConfiguration a, HandyInventory handyInventory, String str) {
/*     */     Inventory inventory = handyInventory.getInventory();
/*     */     Map<Integer, String> map1 = handyInventory.getStrMap();
/*     */     Map<Integer, String> map2 = handyInventory.getSoundMap();
/*     */     Player player = handyInventory.getPlayer();
/*     */     ConfigurationSection configurationSection;
/*     */     if ((configurationSection = a.getConfigurationSection(str)) == null) {
/*     */       return;
/*     */     }
/*     */     Map<?, ?> map;
/*     */     Iterator<String> iterator = (map = configurationSection.getValues(false)).keySet().iterator();
/*     */     while (true) {
/*     */       if (iterator.hasNext()) {
/*     */         String str1 = iterator.next();
/*     */         MemorySection memorySection;
/*     */         if ((memorySection = (MemorySection)map.get(str1)) == null);
/*     */         if (!memorySection.getBoolean(WarpChannelService.qzlKeO("kGoKbL"), true));
/*     */       } 
/*     */       break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setButton(FileConfiguration a, HandyInventory handyInventory, String str, Map<String, String> map, int i) {
/*     */     setButton(a, handyInventory, str, map, null, i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setButton(FileConfiguration a, HandyInventory handyInventory, String str, Map<String, String> map, Map<String, List<String>> map1) {
/*     */     setButton(a, handyInventory, str, map, map1, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setButton(FileConfiguration a, HandyInventory handyInventory, String str, Map<String, String> map) {
/*     */     setButton(a, handyInventory, str, map, (Map<String, List<String>>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, String> replacePageMap(HandyInventory a) {
/* 391 */     HashMap<Object, Object> hashMap = new HashMap<>(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 456 */     Integer integer1 = a.getPageNum();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 638 */     Integer integer2 = a.getPageCount();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     hashMap.put("nextPage", String.valueOf(integer1.intValue() + 1));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     hashMap.put(WarpChannelService.qzlKeO("YoNkg{D"), String.valueOf(integer1));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     hashMap.put("previousPage", (integer1.intValue() - 1 < 1) ? SecureUtil.qzlKeO("\027") : String.valueOf(integer1.intValue() - 1));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 744 */     return (Map)hashMap;
/*     */   }
/*     */   
/*     */   public static Map<Integer, String> getCustomButton(FileConfiguration a, String a) {
/*     */     // Byte code:
/*     */     //   0: new java/util/HashMap
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: astore_2
/*     */     //   8: aload_0
/*     */     //   9: aload_1
/*     */     //   10: invokevirtual getConfigurationSection : (Ljava/lang/String;)Lorg/bukkit/configuration/ConfigurationSection;
/*     */     //   13: dup
/*     */     //   14: astore_1
/*     */     //   15: ifnonnull -> 21
/*     */     //   18: aload_2
/*     */     //   19: areturn
/*     */     //   20: athrow
/*     */     //   21: aload_1
/*     */     //   22: iconst_0
/*     */     //   23: invokeinterface getValues : (Z)Ljava/util/Map;
/*     */     //   28: dup
/*     */     //   29: astore_1
/*     */     //   30: invokeinterface keySet : ()Ljava/util/Set;
/*     */     //   35: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   40: astore_3
/*     */     //   41: aload_3
/*     */     //   42: invokeinterface hasNext : ()Z
/*     */     //   47: ifeq -> 188
/*     */     //   50: aload_3
/*     */     //   51: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   56: checkcast java/lang/String
/*     */     //   59: astore #4
/*     */     //   61: aload_1
/*     */     //   62: aload #4
/*     */     //   64: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   69: checkcast org/bukkit/configuration/MemorySection
/*     */     //   72: dup
/*     */     //   73: astore #4
/*     */     //   75: ifnonnull -> 83
/*     */     //   78: aload_3
/*     */     //   79: goto -> 42
/*     */     //   82: athrow
/*     */     //   83: aload #4
/*     */     //   85: ldc_w '\HXDUC'
/*     */     //   88: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   91: iconst_1
/*     */     //   92: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
/*     */     //   95: ifne -> 102
/*     */     //   98: aload_3
/*     */     //   99: goto -> 42
/*     */     //   102: aload #4
/*     */     //   104: dup
/*     */     //   105: ldc '@`MkQ'
/*     */     //   107: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   110: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   113: invokestatic strToIntList : (Ljava/lang/String;)Ljava/util/List;
/*     */     //   116: astore #4
/*     */     //   118: ldc 'EVKTGWB'
/*     */     //   120: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   123: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   126: dup
/*     */     //   127: astore #5
/*     */     //   129: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
/*     */     //   132: ifeq -> 139
/*     */     //   135: aload_3
/*     */     //   136: goto -> 42
/*     */     //   139: aload #4
/*     */     //   141: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   146: dup
/*     */     //   147: astore #4
/*     */     //   149: invokeinterface hasNext : ()Z
/*     */     //   154: ifeq -> 41
/*     */     //   157: aload #4
/*     */     //   159: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   164: checkcast java/lang/Integer
/*     */     //   167: astore #6
/*     */     //   169: aload #4
/*     */     //   171: aload_2
/*     */     //   172: aload #6
/*     */     //   174: aload #5
/*     */     //   176: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   181: pop
/*     */     //   182: goto -> 149
/*     */     //   185: nop
/*     */     //   186: nop
/*     */     //   187: athrow
/*     */     //   188: aload_2
/*     */     //   189: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #400	-> 0
/*     */     //   #452	-> 8
/*     */     //   #262	-> 15
/*     */     //   #419	-> 18
/*     */     //   #732	-> 21
/*     */     //   #567	-> 30
/*     */     //   #770	-> 61
/*     */     //   #553	-> 75
/*     */     //   #241	-> 79
/*     */     //   #613	-> 83
/*     */     //   #560	-> 95
/*     */     //   #599	-> 99
/*     */     //   #501	-> 102
/*     */     //   #522	-> 118
/*     */     //   #352	-> 129
/*     */     //   #354	-> 136
/*     */     //   #764	-> 139
/*     */     //   #327	-> 171
/*     */     //   #454	-> 182
/*     */     //   #414	-> 185
/*     */     //   #563	-> 188
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	190	0	a	Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   0	190	1	a	Ljava/lang/String;
/*     */   }
/*     */   
/*     */   public static CompletableFuture<InventoryHolder> getInventoryHolder(Player a) {
/*     */     CompletableFuture<InventoryHolder> completableFuture = new CompletableFuture();
/*     */     Objects.requireNonNull(completableFuture);
/*     */     EntitySchedulerUtil.runSafeOnPlayerScheduler((LivingEntity)a, () -> InventoryViewUtil.getInventoryHolder(a), completableFuture::complete, false);
/*     */     return completableFuture;
/*     */   }
/*     */   
/*     */   public static void closeHandyInventory() {
/*     */     Iterator<?> iterator;
/*     */     if ((iterator = Bukkit.getOnlinePlayers().iterator()).hasNext()) {
/*     */       Player player;
/*     */       getInventoryHolder(player = (Player)iterator.next()).thenAccept(inventoryHolder -> {
/*     */             if (inventoryHolder instanceof HandyInventory)
/*     */               PlayerSchedulerUtil.syncCloseInventory(a); 
/*     */           });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\HandyInventoryUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */