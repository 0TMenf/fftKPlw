/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ public final class CollUtil {
/*   8 */   public static boolean isNotEmpty(@Nullable Collection<?> collection) { return !isEmpty(collection); } @SafeVarargs @NotNull
/*   9 */   public static <T> List<T> of(Object... a) { (new ArrayList<>(a.length))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 134 */       .addAll(Arrays.asList(a));
/*     */     return new ArrayList<>(a.length); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean contains(@NotNull List list, @NotNull String target) {
/*     */     for (String str : list) {
/*     */       if (target.equalsIgnoreCase(str)) {
/* 207 */         return true;
/*     */       }
/*     */     } 
/*     */     return false;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public static <T> String listToStr(@Nullable List<?> list) {
/*     */     return listToStr(list, InventoryCheckParam.qzlKeO("."));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public static <T> String listToStr(@Nullable List<?> list, @NotNull CharSequence delimiter) {
/*     */     if (isEmpty(list)) {
/*     */       return "";
/*     */     }
/* 223 */     return list.stream().map(String::valueOf).collect(Collectors.joining(delimiter));
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static String getContainsStr(@Nullable List<?> list, @Nullable String str) {
/*     */     if (isEmpty(list) || StrUtil.isEmpty(str))
/*     */       return null; 
/*     */     for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
/*     */       if ((str1 = (String)iterator.next()).contains(str))
/*     */         return str1; 
/*     */     } 
/*     */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static <T> T randomElement(@Nullable List<?> list) {
/*     */     if (isEmpty(list))
/*     */       return null; 
/*     */     return (T)list.get((new Random()).nextInt(list.size()));
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public static <T> List<List<T>> partition(@NotNull List list, int toIndex) {
/*     */     ArrayList<List> arrayList = new ArrayList();
/*     */     int i = list.size();
/*     */     int j;
/*     */     if ((j = 0) < list.size()) {
/*     */       if (j + toIndex > i)
/*     */         toIndex = i - j; 
/*     */       List list1 = list.subList(j, j + toIndex);
/*     */       j += toIndex;
/*     */       arrayList.add(list1);
/*     */     } 
/*     */     return (List)arrayList;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public static <T> List<List<T>> splitList(@Nullable List<?> list, int splitSize) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokestatic isEmpty : (Ljava/util/Collection;)Z
/*     */     //   4: ifeq -> 12
/*     */     //   7: invokestatic emptyList : ()Ljava/util/List;
/*     */     //   10: areturn
/*     */     //   11: athrow
/*     */     //   12: aload_0
/*     */     //   13: invokeinterface size : ()I
/*     */     //   18: dup
/*     */     //   19: istore_2
/*     */     //   20: iload_1
/*     */     //   21: iadd
/*     */     //   22: iconst_1
/*     */     //   23: isub
/*     */     //   24: iload_1
/*     */     //   25: idiv
/*     */     //   26: istore_3
/*     */     //   27: new java/util/ArrayList
/*     */     //   30: dup
/*     */     //   31: iload_3
/*     */     //   32: invokespecial <init> : (I)V
/*     */     //   35: astore_3
/*     */     //   36: iconst_0
/*     */     //   37: dup
/*     */     //   38: istore #4
/*     */     //   40: iload_2
/*     */     //   41: if_icmpge -> 93
/*     */     //   44: iload #4
/*     */     //   46: iload_1
/*     */     //   47: iadd
/*     */     //   48: iload_2
/*     */     //   49: invokestatic min : (II)I
/*     */     //   52: istore #5
/*     */     //   54: new java/util/ArrayList
/*     */     //   57: aload_3
/*     */     //   58: dup_x1
/*     */     //   59: dup
/*     */     //   60: pop2
/*     */     //   61: dup
/*     */     //   62: aload_0
/*     */     //   63: iload #4
/*     */     //   65: iload #5
/*     */     //   67: invokeinterface subList : (II)Ljava/util/List;
/*     */     //   72: invokespecial <init> : (Ljava/util/Collection;)V
/*     */     //   75: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   80: iload #4
/*     */     //   82: iload_1
/*     */     //   83: iadd
/*     */     //   84: istore #4
/*     */     //   86: pop
/*     */     //   87: iload #4
/*     */     //   89: goto -> 40
/*     */     //   92: athrow
/*     */     //   93: aload_3
/*     */     //   94: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #162	-> 0
/*     */     //   #232	-> 7
/*     */     //   #212	-> 12
/*     */     //   #205	-> 20
/*     */     //   #132	-> 27
/*     */     //   #120	-> 36
/*     */     //   #24	-> 44
/*     */     //   #197	-> 54
/*     */     //   #120	-> 80
/*     */     //   #122	-> 93
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	95	0	list	Ljava/util/List;
/*     */     //   0	95	1	splitSize	I
/*     */   }
/*     */   
/*     */   public static boolean isEmpty(@Nullable Collection collection) {
/*     */     return (collection == null || collection.isEmpty());
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static String getStr(@Nullable List<?> list, @Nullable String str) {
/*     */     if (isEmpty(list) || StrUtil.isEmpty(str))
/*     */       return null; 
/*     */     int i;
/*     */     return ((i = list.indexOf(str)) != -1) ? (String)list.get(i) : null;
/*     */   }
/*     */   
/*     */   public static boolean equals(@Nullable List list, @Nullable List list1) {
/*     */     if (list == list1)
/*     */       return true; 
/*     */     if (list == null)
/*     */       return false; 
/*     */     return list.equals(list1);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\CollUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */