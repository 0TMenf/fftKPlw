/*     */ package cn.handyplus.warp.lib;
/*     */ public final class MessageUtil {
/*     */   public static void sendMessage(String a, String str1) {
/*     */     BaseUtil.getOnlinePlayer(a).ifPresent(player -> sendMessage(player, a));
/*     */   }
/*     */   
/*     */   public static void sendDebugMessage(Player a, String str) {
/*     */     if (BaseConstants.DEBUG)
/*     */       sendMessage(a, str); 
/*     */   }
/*     */   
/*     */   public static void sendMessage(UUID a, String str) {
/*     */     BaseUtil.getOnlinePlayer(a).ifPresent(player -> sendMessage(player, a));
/*     */   }
/*     */   
/*     */   public static void sendMessage(CommandSender a, String str) {
/*     */     if (StrUtil.isEmpty(str) || a == null)
/*     */       return; 
/*     */     if (BaseUtil.supportsComponentApi()) {
/*     */       a.sendMessage(ComponentUtil.parseColor(str));
/*     */       return;
/*     */     } 
/*     */     a.sendMessage(LegacyUtil.parseColor(str));
/*     */   }
/*     */   
/*     */   public static void sendAllMessage(String a) {
/*  27 */     if (StrUtil.isEmpty(a)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 158 */     Bukkit.getOnlinePlayers().forEach(player -> sendMessage(player, a));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sendAllMessage(List<?> a) {
/*     */     if (CollUtil.isEmpty(a)) {
/*     */       return;
/*     */     }
/*     */     a.forEach(MessageUtil::sendAllMessage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sendDebugMessage(CommandSender a, String str) {
/*     */     if (BaseConstants.DEBUG) {
/*     */       sendMessage(a, str);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sendMessage(Player a, String str) {
/*     */     sendMessage(true, a, str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sendConsoleMessage(List<?> a) {
/*     */     if (CollUtil.isEmpty(a)) {
/*     */       return;
/*     */     }
/*     */     a.forEach(MessageUtil::sendConsoleMessage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sendWarnMessage(CommandSender a, String str) {
/*     */     if (BaseConstants.WARN)
/* 203 */       sendMessage(a, str); 
/*     */   } public static void sendMessage(int a, Player player, String str) {
/*     */     if (a == 0 || StrUtil.isEmpty(str))
/*     */       return; 
/*     */     if (BaseUtil.supportsComponentApi()) {
/*     */       player.sendMessage(ComponentUtil.parseColor(str));
/*     */       return;
/*     */     } 
/*     */     player.sendMessage(LegacyUtil.parseColor(str));
/*     */   }
/*     */   public static void sendMessage(Player a, List<?> list) {
/*     */     if (CollUtil.isEmpty(list))
/*     */       return; 
/*     */     list.forEach(str -> sendMessage(a, str));
/*     */   }
/*     */   public static void sendConsoleMessage(int a, String str) {
/*     */     if (a == 0 || StrUtil.isEmpty(str))
/*     */       return; 
/*     */     str = (new StringBuilder()).insert(0, ClassUtil.qzlKeO("\006]{")).append(InitApi.PLUGIN.getName()).append(WarpTpPlayerService.qzlKeO("^\013%Y")).append(str).toString();
/*     */     if (BaseUtil.supportsComponentApi()) {
/*     */       Bukkit.getConsoleSender().sendMessage(ComponentUtil.parseColor(str));
/*     */       return;
/*     */     } 
/* 226 */     Bukkit.getConsoleSender().sendMessage(LegacyUtil.parseColor(str));
/*     */   }
/*     */   public static void sendConsoleWarnMessage(String a) {
/* 229 */     if (BaseConstants.WARN)
/*     */       sendConsoleMessage(a); 
/*     */   } public static void sendConsoleMessage(String a) {
/* 232 */     sendConsoleMessage(true, a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sendTitle(Player a, String str1, String str2, int i, int j, int k) {
/* 423 */     if (BaseConstants.VERSION_ID.intValue() < VersionCheckEnum.V_1_9.getVersionId().intValue()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 672 */     if (BaseConstants.VERSION_ID.intValue() < VersionCheckEnum.V_1_11.getVersionId().intValue()) {
/*     */       a.sendTitle(LegacyUtil.parseColor(str1), LegacyUtil.parseColor(str2));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (BaseConstants.VERSION_ID.intValue() > VersionCheckEnum.V_1_10.getVersionId().intValue() && !BaseUtil.supportsComponentApi()) {
/*     */       a.sendTitle(LegacyUtil.parseColor(str1), LegacyUtil.parseColor(str2), i, j, k);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 705 */     if (BaseConstants.VERSION_ID.intValue() < VersionCheckEnum.V_1_21_8.getVersionId().intValue());
/*     */     a.showTitle(Title.title(ComponentUtil.parseColor(str1), ComponentUtil.parseColor(str2), i, j, k));
/*     */   }
/*     */   
/*     */   public static void sendAllTitle(String a, String str1, int i, int j, int k) {
/*     */     Bukkit.getOnlinePlayers().forEach(player -> sendTitle(player, a, str1, i, j, k));
/*     */   }
/*     */   
/*     */   public static void sendAllTitle(String a, String str1) {
/*     */     Bukkit.getOnlinePlayers().forEach(player -> sendTitle(player, a, str1));
/*     */   }
/*     */   
/*     */   public static void sendConsoleDebugMessage(String a) {
/*     */     if (BaseConstants.DEBUG)
/*     */       sendConsoleMessage(a); 
/*     */   }
/*     */   
/*     */   public static void sendTitle(Player a, String str1, String str2) {
/*     */     sendTitle(a, str1, str2, 10, 70, 20);
/*     */   }
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_2
/*     */     //   1: iconst_5
/*     */     //   2: ixor
/*     */     //   3: iconst_3
/*     */     //   4: iconst_5
/*     */     //   5: ixor
/*     */     //   6: iconst_4
/*     */     //   7: ishl
/*     */     //   8: iconst_3
/*     */     //   9: iconst_1
/*     */     //   10: ishl
/*     */     //   11: ixor
/*     */     //   12: iconst_2
/*     */     //   13: iconst_5
/*     */     //   14: ixor
/*     */     //   15: iconst_3
/*     */     //   16: ishl
/*     */     //   17: iconst_2
/*     */     //   18: iconst_5
/*     */     //   19: ixor
/*     */     //   20: ixor
/*     */     //   21: aload_0
/*     */     //   22: checkcast java/lang/String
/*     */     //   25: dup
/*     */     //   26: astore_0
/*     */     //   27: invokevirtual length : ()I
/*     */     //   30: dup
/*     */     //   31: newarray char
/*     */     //   33: iconst_1
/*     */     //   34: dup
/*     */     //   35: pop2
/*     */     //   36: swap
/*     */     //   37: iconst_1
/*     */     //   38: isub
/*     */     //   39: dup_x2
/*     */     //   40: istore_3
/*     */     //   41: astore_1
/*     */     //   42: istore #4
/*     */     //   44: dup_x2
/*     */     //   45: pop2
/*     */     //   46: istore_2
/*     */     //   47: iflt -> 87
/*     */     //   50: aload_1
/*     */     //   51: aload_0
/*     */     //   52: iload_3
/*     */     //   53: dup_x1
/*     */     //   54: invokevirtual charAt : (I)C
/*     */     //   57: iinc #3, -1
/*     */     //   60: iload_2
/*     */     //   61: ixor
/*     */     //   62: i2c
/*     */     //   63: castore
/*     */     //   64: iload_3
/*     */     //   65: iflt -> 87
/*     */     //   68: aload_1
/*     */     //   69: aload_0
/*     */     //   70: iload_3
/*     */     //   71: iinc #3, -1
/*     */     //   74: dup_x1
/*     */     //   75: invokevirtual charAt : (I)C
/*     */     //   78: iload #4
/*     */     //   80: ixor
/*     */     //   81: i2c
/*     */     //   82: castore
/*     */     //   83: iload_3
/*     */     //   84: goto -> 47
/*     */     //   87: new java/lang/String
/*     */     //   90: dup
/*     */     //   91: aload_1
/*     */     //   92: invokespecial <init> : ([C)V
/*     */     //   95: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	96	0	a	Ljava/lang/String;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\MessageUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */