/*     */ package cn.handyplus.warp.lib;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public class HandySchedulerUtil {
/*     */   private static ServerTypeEnum j;
/*     */   public static Plugin PPpppp;
/*     */   
/*     */   public static boolean isFolia() {
/*  10 */     return ServerTypeEnum.FOLIA.equals(j);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void runTask(@NotNull Runnable task) {
/*  30 */     if (isFolia()) {
/*  31 */       xXxXXX.oOOOOo(task); return;
/*     */     } 
/*  33 */     IiIIIi.l(task); } public static boolean isPaper() { return ServerTypeEnum.PAPER.equals(j); }
/*     */   
/*     */   public static void cancelTask() {
/*  36 */     if (isFolia()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 197 */       xXxXXX.sZxJew();
/*     */       return;
/*     */     } 
/*     */     IiIIIi.sZxJew();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void runTaskTimer(@NotNull HandyRunnable task, long delay, long a) {
/*     */     if (isFolia()) {
/*     */       xXxXXX.l(task, delay, a);
/*     */       return;
/*     */     } 
/*     */     IiIIIi.oOOOOO(task, delay, a);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void runTaskTimerAsynchronously(@NotNull Runnable task, long delay, long a) {
/*     */     if (isFolia()) {
/* 216 */       xXxXXX.l(task, delay, a);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 231 */     IiIIIi.l(task, delay, a);
/*     */   }
/*     */   
/*     */   public static void runTaskLaterAsynchronously(@NotNull Runnable task, long delay) {
/*     */     if (isFolia()) {
/*     */       xXxXXX.XXXXXX(task, delay);
/*     */       return;
/*     */     } 
/*     */     IiIIIi.l(task, delay);
/*     */   }
/*     */   
/*     */   public static void runTaskLaterAsynchronously(@NotNull HandyRunnable task, long delay) {
/*     */     if (isFolia()) {
/*     */       xXxXXX.PPpppP(task, delay);
/*     */       return;
/*     */     } 
/*     */     IiIIIi.l(task, delay);
/*     */   }
/*     */   
/*     */   public static void init(@NotNull Plugin plugin) {
/*     */     PPpppp = plugin;
/*     */     j = ServerTypeEnum.getServerType();
/*     */   }
/*     */   
/*     */   public static void runTaskLater(@NotNull Runnable task, long delay) {
/*     */     if (isFolia()) {
/*     */       xXxXXX.l(task, delay);
/*     */       return;
/*     */     } 
/*     */     IiIIIi.XxXXxx(task, delay);
/*     */   }
/*     */   
/*     */   public static void runTaskTimer(@NotNull Runnable task, long delay, long a) {
/*     */     if (isFolia()) {
/*     */       xXxXXX.IiiiIi(task, delay, a);
/*     */       return;
/*     */     } 
/*     */     IiIIIi.IiiiIi(task, delay, a);
/*     */   }
/*     */   
/*     */   public static void runTaskTimerAsynchronously(@NotNull HandyRunnable task, long delay, long a) {
/*     */     if (isFolia()) {
/*     */       xXxXXX.PPpPpP(task, delay, a);
/*     */       return;
/*     */     } 
/*     */     IiIIIi.l(task, delay, a);
/*     */   }
/*     */   
/*     */   public static void runTaskLater(@NotNull HandyRunnable task, long delay) {
/*     */     if (isFolia()) {
/*     */       xXxXXX.l(task, delay);
/*     */       return;
/*     */     } 
/*     */     IiIIIi.iIiiIi(task, delay);
/*     */   }
/*     */   
/*     */   public static void runTaskAsynchronously(@NotNull Runnable task) {
/*     */     if (isFolia()) {
/*     */       xXxXXX.l(task);
/*     */       return;
/*     */     } 
/*     */     IiIIIi.IiiiiI(task);
/*     */   }
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_3
/*     */     //   1: dup
/*     */     //   2: ishl
/*     */     //   3: iconst_2
/*     */     //   4: ixor
/*     */     //   5: iconst_4
/*     */     //   6: dup
/*     */     //   7: ishl
/*     */     //   8: iconst_3
/*     */     //   9: iconst_2
/*     */     //   10: ishl
/*     */     //   11: iconst_1
/*     */     //   12: ixor
/*     */     //   13: ixor
/*     */     //   14: iconst_2
/*     */     //   15: iconst_3
/*     */     //   16: ishl
/*     */     //   17: iconst_2
/*     */     //   18: ixor
/*     */     //   19: aload_0
/*     */     //   20: checkcast java/lang/String
/*     */     //   23: dup
/*     */     //   24: astore_0
/*     */     //   25: invokevirtual length : ()I
/*     */     //   28: dup
/*     */     //   29: newarray char
/*     */     //   31: iconst_1
/*     */     //   32: dup
/*     */     //   33: pop2
/*     */     //   34: swap
/*     */     //   35: iconst_1
/*     */     //   36: isub
/*     */     //   37: dup_x2
/*     */     //   38: istore_3
/*     */     //   39: astore_1
/*     */     //   40: istore #4
/*     */     //   42: dup_x2
/*     */     //   43: pop2
/*     */     //   44: istore_2
/*     */     //   45: iflt -> 85
/*     */     //   48: aload_1
/*     */     //   49: aload_0
/*     */     //   50: iload_3
/*     */     //   51: dup_x1
/*     */     //   52: invokevirtual charAt : (I)C
/*     */     //   55: iinc #3, -1
/*     */     //   58: iload_2
/*     */     //   59: ixor
/*     */     //   60: i2c
/*     */     //   61: castore
/*     */     //   62: iload_3
/*     */     //   63: iflt -> 85
/*     */     //   66: aload_1
/*     */     //   67: aload_0
/*     */     //   68: iload_3
/*     */     //   69: iinc #3, -1
/*     */     //   72: dup_x1
/*     */     //   73: invokevirtual charAt : (I)C
/*     */     //   76: iload #4
/*     */     //   78: ixor
/*     */     //   79: i2c
/*     */     //   80: castore
/*     */     //   81: iload_3
/*     */     //   82: goto -> 45
/*     */     //   85: new java/lang/String
/*     */     //   88: dup
/*     */     //   89: aload_1
/*     */     //   90: invokespecial <init> : ([C)V
/*     */     //   93: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	94	0	a	Ljava/lang/String;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\HandySchedulerUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */