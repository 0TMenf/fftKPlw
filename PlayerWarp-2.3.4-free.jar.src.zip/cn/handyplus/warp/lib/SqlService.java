/*   1 */ package cn.handyplus.warp.lib;public class SqlService { public List<String> l(String str1, String str2) { Connection connection = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 201 */     PreparedStatement preparedStatement = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     ResultSet resultSet = null; ArrayList<String> arrayList = new ArrayList(); try {
/*     */       resultSet = (preparedStatement = (connection = SqlManagerUtil.getInstance().xXXxxx(str2)).prepareStatement(str1)).executeQuery(); for (; resultSet.next(); str1 = resultSet.getString(InventoryViewUtil.qzlKeO("\013s\004i\005r7r\tq\r"))) {
/* 225 */         if (DbTypeEnum.SQLite.getType().equalsIgnoreCase(str2))
/*     */           str1 = resultSet.getString(SecureUtil.qzlKeO("WGTC")); 
/*     */       }  return arrayList;
/*     */     } catch (SQLException sQLException) {
/*     */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, SecureUtil.qzlKeO("A\\RmG[J\\oW@V\006叨甹弻帞"), sQLException); return arrayList;
/*     */     } finally {
/*     */       SqlManagerUtil.getInstance().xxxxXx(connection, preparedStatement, resultSet);
/* 232 */     }  } public List<Map<String, Object>> selectListMap(String str1, String str2) { Connection connection = null;
/*     */     PreparedStatement preparedStatement = null;
/*     */     ResultSet resultSet = null;
/*     */     ArrayList<Map<String, Object>> arrayList = new ArrayList();
/*     */     try {
/*     */       ResultSetMetaData resultSetMetaData = (resultSet = (preparedStatement = (connection = SqlManagerUtil.getInstance().xXXxxx(str2)).prepareStatement(str1)).executeQuery()).getMetaData();
/*     */       while (resultSet.next()) {
/*     */         boolean bool;
/*     */         HashMap<Object, Object> hashMap = new HashMap<>();
/*     */       } 
/*     */       return arrayList;
/*     */     } catch (SQLException sQLException) {
/*     */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, SecureUtil.qzlKeO("JCUCZRuOJRtGI\006叨甹弻帞"), sQLException);
/*     */       return arrayList;
/*     */     } finally {
/*     */       SqlManagerUtil.getInstance().xxxxXx(connection, preparedStatement, resultSet);
/*     */     }  }
/*     */ 
/*     */   
/*     */   public void pppppp(String str1, String str2) {
/*     */     Connection connection = null;
/*     */     PreparedStatement preparedStatement = null;
/*     */     try {
/*     */       (preparedStatement = (connection = SqlManagerUtil.getInstance().xXXxxx(str2)).prepareStatement(str1)).executeUpdate();
/*     */       return;
/*     */     } catch (SQLException sQLException) {
/*     */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, InventoryViewUtil.qzlKeO("\rd\r\035h\001s\006O\031pH反畷弞幐"), sQLException);
/*     */       return;
/*     */     } finally {
/*     */       SqlManagerUtil.getInstance().xxxxXx(connection, preparedStatement, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Map<String, Object> selectMap(String str1, String str2) {
/*     */     Connection connection = null;
/*     */     PreparedStatement preparedStatement = null;
/*     */     ResultSet resultSet = null;
/*     */     HashMap<Object, Object> hashMap = new HashMap<>();
/*     */     try {
/*     */       ResultSetMetaData resultSetMetaData = (resultSet = (preparedStatement = (connection = SqlManagerUtil.getInstance().xXXxxx(str2)).prepareStatement(str1)).executeQuery()).getMetaData();
/*     */       if ((resultSet = (preparedStatement = (connection = SqlManagerUtil.getInstance().xXXxxx(str2)).prepareStatement(str1)).executeQuery()).next())
/*     */         for (byte b = 1; b <= resultSetMetaData.getColumnCount();)
/*     */           hashMap.put(resultSetMetaData.getColumnLabel(b), resultSet.getObject(b++));  
/*     */       return (Map)hashMap;
/*     */     } catch (SQLException sQLException) {
/*     */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, InventoryViewUtil.qzlKeO("o\rp\r\034Q\tlH反畷弞幐"), sQLException);
/*     */       return (Map)hashMap;
/*     */     } finally {
/*     */       SqlManagerUtil.getInstance().xxxxXx(connection, preparedStatement, resultSet);
/*     */     } 
/*     */   }
/*     */   
/*     */   public List<Map<String, Object>> selectListMap(String str) {
/*     */     return selectListMap(str, SqlManagerUtil.getInstance().oOOOOo());
/*     */   }
/*     */   
/*     */   public Map<String, Object> selectMap(String str) {
/*     */     return selectMap(str, SqlManagerUtil.getInstance().oOOOOo());
/*     */   }
/*     */   
/*     */   public static SqlService getInstance() {
/*     */     return cn/handyplus/warp/lib/b.pPpppP();
/*     */   }
/*     */   
/*     */   private static class cn/handyplus/warp/lib/b {
/*     */     private static final SqlService XXXXXx = new SqlService(null);
/*     */   }
/*     */   
/*     */   public List<String> ppPppP(String str1, String str2) {
/*     */     Connection connection = null;
/*     */     PreparedStatement preparedStatement = null;
/*     */     ResultSet resultSet = null;
/*     */     ArrayList<String> arrayList = new ArrayList();
/*     */     try {
/*     */       resultSet = (preparedStatement = (connection = SqlManagerUtil.getInstance().xXXxxx(str2)).prepareStatement(str1)).executeQuery();
/*     */       while (resultSet.next()) {
/*     */         str1 = resultSet.getString(InventoryViewUtil.qzlKeO("+s\004i\005r7r\tq\r"));
/*     */         arrayList.add(str1);
/*     */       } 
/*     */       return arrayList;
/*     */     } catch (SQLException sQLException) {
/*     */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, SecureUtil.qzlKeO("A\\Rt_JWUrXDUCpH]CA\006叨甹弻帞"), sQLException);
/*     */       return arrayList;
/*     */     } finally {
/*     */       SqlManagerUtil.getInstance().xxxxXx(connection, preparedStatement, resultSet);
/*     */     } 
/*     */   } }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\SqlService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */