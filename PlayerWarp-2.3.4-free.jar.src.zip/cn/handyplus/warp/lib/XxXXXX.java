/*     */ package cn.handyplus.warp.lib;
/*     */ public class XxXXXX { private String F; private String h; private String m; private String D; private List<String> e; private String H; private LinkedHashMap<String, KcifTq> a;
/*     */   private LinkedHashMap<Integer, Object> L;
/*     */   private PtdKXl K;
/*     */   private LinkedHashMap<Integer, Object> j;
/*     */   private String PpppPp;
/*     */   
/*     */   @Generated
/*   9 */   public PtdKXl IiiIIi() { return this.K; }
/*     */   @Generated public void xXXXXx(String str) { this.h = str; }
/*     */   @Generated public LinkedHashMap<String, KcifTq> I() { return this.a; }
/*  12 */   @Generated public static bSqlBuilder XxXXxX() { return new bSqlBuilder(); } public void IiIiii(int i, String str, Object object1, oooOoO oooOoO1, Object object2) { if (i == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     this.H += oooOoO.c.PPPPPp() + "`" + str + "`" + " + " + "?" + oooOoO1.PPPPPp() + "?";
/*     */     l(object1);
/*     */     l(object2); }
/*     */   @Generated public XxXXXX(String str1, PtdKXl ptdKXl, String str2, LinkedHashMap<String, KcifTq> linkedHashMap, String str3, LinkedHashMap<Integer, Object> linkedHashMap1, List<String> list, LinkedHashMap<Integer, Object> linkedHashMap2, String str4, String str5, String str6) { this.D = str1;
/*     */     this.K = ptdKXl;
/*     */     this.h = str2;
/*     */     this.a = linkedHashMap;
/*     */     this.H = str3;
/*     */     this.L = linkedHashMap1;
/*     */     this.e = list;
/*     */     this.j = linkedHashMap2;
/*     */     this.m = str4;
/*     */     this.PpppPp = str5;
/*     */     this.F = str6; }
/*     */   @Generated public static class bSqlBuilder {
/*     */     @Generated private String F;
/*     */     @Generated private PtdKXl h;
/*     */     @Generated private LinkedHashMap<String, KcifTq> m;
/*     */     @Generated private LinkedHashMap<Integer, Object> D;
/*     */     @Generated private String e;
/*     */     @Generated private List<String> H;
/*     */     @Generated private String a;
/*     */     @Generated private String L;
/*     */     @Generated private LinkedHashMap<Integer, Object> K;
/*     */     @Generated private String j;
/*     */     @Generated private String XxXXXx;
/*     */     @Generated public bSqlBuilder where(String str) { this.j = str;
/*     */       return this; }
/*     */     @Generated public bSqlBuilder group(String str) { this.F = str;
/*     */       return this; } @Generated public bSqlBuilder tableName(String str) { this.XxXXXx = str;
/*     */       return this; } @Generated
/*     */     public bSqlBuilder tableInfoParam(PtdKXl ptdKXl) { this.h = ptdKXl;
/*     */       return this; } @Generated
/*     */     public XxXXXX build() { return new XxXXXX(this.XxXXXx, this.h, this.e, this.m, this.j, this.K, this.H, this.D, this.a, this.L, this.F); } @Generated
/*     */     public bSqlBuilder updatefieldList(List<String> list) { this.H = list;
/*     */       return this; } @Generated
/*     */     public bSqlBuilder fieldInfoMap(LinkedHashMap<String, KcifTq> linkedHashMap) { this.m = linkedHashMap;
/*     */       return this; } @Generated
/*     */     public String toString() { return (new StringBuilder()).insert(0, InventoryViewUtil.qzlKeO(",~;m\0042,~;m\004^\035u\004x\rn@h\t~\004y&}\005yU")).append(this.XxXXXx).append(InventoryCheckParam.qzlKeO(".kv*`'g\002l-m\033c9c&?")).append(this.h).append(InventoryViewUtil.qzlKeO("0Hz\001y\004xU")).append(this.e).append(InventoryCheckParam.qzlKeO(".kd\"g'f\002l-m\006c;?")).append(this.m).append(InventoryViewUtil.qzlKeO("0Hk\000y\032yU")).append(this.j).append(InventoryCheckParam.qzlKeO(".ku#g9g\006c;?")).append(this.K).append(InventoryViewUtil.qzlKeO("0Hi\030x\th\rz\001y\004x$u\033hU")).append(this.H).append(InventoryCheckParam.qzlKeO(".kw;f*v.D\"g'f\006c;?")).append(this.D).append(InventoryViewUtil.qzlKeO("0Hp\001q\001hU")).append(this.a).append(InventoryCheckParam.qzlKeO("g\"$p/g9?")).append(this.L).append(InventoryViewUtil.qzlKeO("0H{\032s\035lU")).append(this.F).append(")").toString(); } @Generated
/*     */     public bSqlBuilder field(String str) { this.e = str;
/*     */       return this; } @Generated
/*     */     public bSqlBuilder updateFieldMap(LinkedHashMap<Integer, Object> linkedHashMap) { this.D = linkedHashMap;
/*     */       return this; } @Generated
/*     */     public bSqlBuilder whereMap(LinkedHashMap<Integer, Object> linkedHashMap) { this.K = linkedHashMap;
/*     */       return this; } @Generated
/*     */     public bSqlBuilder order(String str) { this.L = str;
/*     */       return this; } @Generated
/*     */     public bSqlBuilder limit(String str) { this.a = str;
/*     */       return this; } } public void l(int i, String str, oooOoO oooOoO1, Object object) { if (i == 0)
/*     */       return; 
/*     */     object = l(object);
/* 204 */     this.H += oooOoO.c.PPPPPp() + "`" + str + "`" + oooOoO1.PPPPPp() + "?"; l(object); } public String l() { true; true[0] = "DELETE FROM "; true[1] = this.D; true[2] = this.H; return xxXXXx(true); }
/*     */   public void PppPpp(int i, String str, oooOoO oooOoO1, Object object) { if (i == 0)
/* 206 */       return;  this.H += oooOoO.c.PPPPPp() + "`" + str + "`" + oooOoO1.PPPPPp() + "?"; l(object); } public String I() { true; true[0] = "SELECT "; true[1] = this.h; true[2] = " FROM "; true[3] = this.D; true[4] = this.H; true[5] = this.F; true[6] = this.PpppPp; true[7] = this.m; return xxXXXx(true); }
/*     */   public String XXXXXx(String str) { true; true[0] = str; String str1 = StrUtil.isNotEmpty(str) ? String.format((String)new Object[1], true) : "COUNT(*)"; true; true[0] = "SELECT "; true[1] = str1; true[2] = " FROM "; true[3] = this.D; true[4] = this.H; return xxXXXx(true); }
/*     */   public String OoooOo() { ArrayList<String> arrayList = new ArrayList(); byte b; if ((b = 0) < this.a.size()) {
/*     */       b++; arrayList.add("?");
/*     */     }  true; true[0] = "INSERT INTO "; true[1] = this.D; true[2] = "("; true[3] = this.h; true[4] = ")"; true[5] = " VALUES ";
/*     */     true[6] = "(";
/*     */     true[7] = CollUtil.listToStr(arrayList);
/*     */     true[8] = ")";
/*     */     return xxXXXx(true); }
/*     */   @Generated public LinkedHashMap<Integer, Object> l() { return this.L; }
/*     */   public String h() { true;
/*     */     true[0] = "UPDATE ";
/*     */     true[1] = this.D;
/*     */     true[2] = " SET ";
/*     */     true[3] = CollUtil.listToStr(this.e);
/*     */     true[4] = this.H;
/*     */     return xxXXXx(true); }
/*     */   public void iiIiiI(int i, String str1, Object object, oooOoO oooOoO1, String str2) { if (i == 0)
/*     */       return; 
/*     */     this.H += oooOoO.c.PPPPPp() + "`" + str1 + "`" + " + " + "?" + oooOoO1.PPPPPp() + "`" + str2 + "`";
/*     */     l(object); }
/*     */   public void l(int i, String str, oooOoO oooOoO1) { if (i == 0)
/*     */       return; 
/*     */     this.H += oooOoO.c.PPPPPp() + "`" + str + "`" + oooOoO1.PPPPPp(); }
/* 230 */   public void xXxXXX(int i, String str1, oooOoO oooOoO1, String str2) { if (i == 0) {
/*     */       return;
/*     */     }
/*     */     this.H += oooOoO.c.PPPPPp() + "`" + str1 + "`" + oooOoO1.PPPPPp() + "`" + str2 + "`"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void iIiiii(int i, String str) {
/* 241 */     if (i == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 613 */     this.F = (new StringBuilder()).insert(0, oooOoO.d.PPPPPp()).append("`").append(str).append("`").toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ppPPPP(int i, String str1, String str2, String str3, Object object) {
/*     */     if (i == 0) {
/*     */       return;
/*     */     }
/* 663 */     this.j.put(Integer.valueOf(this.e.size()), object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void oOOOOO(int i, int j, int k) {
/*     */     if (i == 0) {
/*     */       return;
/*     */     }
/*     */     i = Math.max((j - 1) * k, 0);
/* 749 */     this; super(); ((XxXXXX)new StringBuilder()).m = append(oooOoO.OoOOoo.PPPPPp()).append(k).append(oooOoO.B.PPPPPp()).append(i).toString();
/*     */   } public void oOOOoO(int i, String str, oooOoO oooOoO1, List<?> list) { if (i == 0 || CollUtil.isEmpty(list))
/*     */       return; 
/*     */     String str1 = String.join(NetUtil.qzlKeO("\\"), Collections.nCopies(list.size(), "?"));
/*     */     this.H += oooOoO.c.PPPPPp() + "`" + str + "`" + oooOoO1.PPPPPp() + "(" + str1 + ")";
/*     */     l(list); } public void IIIIii(int i, String str, Object object) { if (i == 0)
/*     */       return; 
/*     */     object = OOOooo(object);
/*     */     this.j.put(Integer.valueOf(this.e.size()), object); } public void ppPPPP(int i, String str, oooOoO oooOoO1) { if (i == 0)
/*     */       return; 
/*     */     this.PpppPp = (new StringBuilder()).insert(0, oooOoO.D.PPPPPp()).append("`").append(str).append("`").append(oooOoO1.PPPPPp()).toString(); }
/*     */   public void XxxXxX(int i) {
/*     */     if (i == 0)
/*     */       return; 
/*     */     if (DbTypeEnum.SQLite.getType().equalsIgnoreCase(SqlManagerUtil.getInstance().oOOOOo())) {
/*     */       this.PpppPp = " ORDER BY RANDOM()";
/*     */       return;
/*     */     } 
/*     */     this.PpppPp = " ORDER BY RAND()";
/*     */   }
/*     */   public void iiiIIi(int i, String str1, String str2, oooOoO oooOoO1) {
/*     */     if (i == 0)
/*     */       return; 
/* 772 */     this.PpppPp = (new StringBuilder()).insert(0, oooOoO.D.PPPPPp()).append("`").append(str1).append("`").append(oooOoO1.PPPPPp()).append(" , ").append("`").append(str2).append("`").append(oooOoO1.PPPPPp()).toString();
/*     */   }
/*     */   
/*     */   @Generated
/*     */   public LinkedHashMap<Integer, Object> OOOoOo() {
/*     */     return this.j;
/*     */   } }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\XxXXXX.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */