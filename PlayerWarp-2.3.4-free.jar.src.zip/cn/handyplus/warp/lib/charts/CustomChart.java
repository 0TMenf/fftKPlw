/*     */ package cn.handyplus.warp.lib.charts;
/*     */ 
/*     */ import cn.handyplus.warp.lib.GameRuleUtil;
/*     */ import cn.handyplus.warp.lib.json.JsonObjectBuilder;
/*     */ import cn.handyplus.warp.util.WarpPermissionUtil;
/*     */ import java.util.function.BiConsumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CustomChart
/*     */ {
/*     */   private final String ppppPp;
/*     */   
/*     */   public CustomChart(String str) {
/*  98 */     if (str == null)
/*     */     {
/*     */ 
/*     */       
/* 102 */       throw new IllegalArgumentException(WarpPermissionUtil.qzlKeO("JKHQ]jM\003DVZW\tMFW\tAL\003GVEO"));
/*     */     }
/*     */     this.ppppPp = str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonObjectBuilder.JsonObject getRequestJsonObject(BiConsumer biConsumer, int i) {
/*     */     JsonObjectBuilder jsonObjectBuilder;
/* 150 */     (jsonObjectBuilder = new JsonObjectBuilder()).appendField(GameRuleUtil.qzlKeO("684\"!\0311"), this.ppppPp);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */       JsonObjectBuilder.JsonObject jsonObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 221 */       if ((jsonObject = getChartData()) == null)
/*     */         return null; 
/*     */       jsonObjectBuilder.appendField(WarpPermissionUtil.qzlKeO("MB]B"), jsonObject);
/*     */     } catch (Throwable throwable) {
/*     */       if (i != 0) {
/*     */         super();
/*     */         (new StringBuilder()).accept(biConsumer.append(GameRuleUtil.qzlKeO("\02649951p!?u70$u44$4p3?'p6%&$:=u3=1'$u'<$=p<4u")).append(this.ppppPp).toString(), throwable);
/*     */       } 
/*     */       return null;
/*     */     } 
/*     */     return jsonObjectBuilder.build();
/*     */   }
/*     */   
/*     */   public abstract JsonObjectBuilder.JsonObject getChartData() throws Exception;
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\charts\CustomChart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */