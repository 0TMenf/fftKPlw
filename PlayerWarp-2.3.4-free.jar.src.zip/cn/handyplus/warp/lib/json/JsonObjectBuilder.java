/*     */ package cn.handyplus.warp.lib.json;
/*     */ 
/*     */ import cn.handyplus.warp.lib.InventoryViewUtil;
/*     */ import cn.handyplus.warp.lib.SecureUtil;
/*     */ import cn.handyplus.warp.lib.d;
/*     */ import java.util.Arrays;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ public class JsonObjectBuilder
/*     */ {
/*     */   private StringBuilder j;
/*     */   private boolean oOOOOO;
/*     */   
/*     */   public JsonObjectBuilder appendField(String str1, String str2) {
/*  16 */     if (str2 == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 170 */       throw new IllegalArgumentException(SecureUtil.qzlKeO("ljiw\006OGUS\\\006TSJR\031HVR\031D\\\006WSUJ"));
/*     */     }
/*     */     super();
/*     */     str1.iIIIiI((String)new StringBuilder(), str1.append(InventoryViewUtil.qzlKeO("J")).append(HDuwPI(str2)).append(SecureUtil.qzlKeO("\004")).toString());
/*     */     return this;
/*     */   }
/*     */   public static class JsonObject { private final String xXXxXx;
/*     */     public String toString() {
/*     */       return this.xXXxXx;
/*     */     } }
/*     */   public JsonObject build() {
/*     */     if (this.j == null)
/*     */       throw new IllegalStateException(InventoryViewUtil.qzlKeO("\"O'RHt\toH}\004n\r}\feH~\ry\006<\ni\001p\034")); 
/*     */     this.j = null;
/*     */     return new JsonObject(this.j.append(SecureUtil.qzlKeO("[")).toString(), null);
/*     */   }
/*     */   public JsonObjectBuilder() {
/*     */     this;
/*     */     super();
/*     */     ((JsonObjectBuilder)new StringBuilder()).j = (StringBuilder)this;
/*     */     (false.oOOOOO = this).j.append(SecureUtil.qzlKeO("]"));
/*     */   }
/*     */   
/*     */   public JsonObjectBuilder appendField(String str, JsonObject[] arrayOfJsonObject) { if (arrayOfJsonObject == null) {
/* 194 */       throw new IllegalArgumentException(SecureUtil.qzlKeO("suvh\031PXJLCJ\006TSJR\031HVR\031D\\\006WSUJ"));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String str1 = Arrays.<JsonObject>stream(arrayOfJsonObject).map(JsonObject::toString).collect(Collectors.joining(InventoryViewUtil.qzlKeO("D")));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 217 */     super(); str.iIIIiI((String)new StringBuilder(), str.append(SecureUtil.qzlKeO("}")).append(str1).append(InventoryViewUtil.qzlKeO("5")).toString()); return this; }
/*     */   public JsonObjectBuilder appendField(String str, String[] arrayOfString) { if (arrayOfString == null)
/*     */       throw new IllegalArgumentException(SecureUtil.qzlKeO("suvh\031PXJLCJ\006TSJR\031HVR\031D\\\006WSUJ")); 
/*     */     String str1 = Arrays.<String>stream(arrayOfString).map(a -> (new StringBuilder()).insert(0, InventoryViewUtil.qzlKeO("J")).append(HDuwPI(a)).append(SecureUtil.qzlKeO("\004")).toString()).collect(Collectors.joining(InventoryViewUtil.qzlKeO("D")));
/*     */     super();
/*     */     str.iIIIiI((String)new StringBuilder(), str.append(SecureUtil.qzlKeO("}")).append(str1).append(InventoryViewUtil.qzlKeO("5")).toString());
/* 223 */     return this; } public JsonObjectBuilder appendField(String str, JsonObject jsonObject) { if (jsonObject == null)
/*     */       throw new IllegalArgumentException(InventoryViewUtil.qzlKeO("V;S&<\007~\002y\013hHq\035o\034<\006s\034<\nyHr\035p\004"));  iIIIiI(str, jsonObject.toString()); return this; }
/*     */   public JsonObjectBuilder appendNull(String str) { iIIIiI(str, InventoryViewUtil.qzlKeO("r\035p\004")); return this; }
/*     */   public JsonObjectBuilder appendField(String str, int[] arrayOfInt) { if (arrayOfInt == null)
/*     */       throw new IllegalArgumentException(SecureUtil.qzlKeO("suvh\031PXJLCJ\006TSJR\031HVR\031D\\\006WSUJ"));  String str1 = Arrays.stream(arrayOfInt).<CharSequence>mapToObj(String::valueOf).collect(Collectors.joining(InventoryViewUtil.qzlKeO("D"))); super(); str.iIIIiI((String)new StringBuilder(), str.append(SecureUtil.qzlKeO("}")).append(str1).append(InventoryViewUtil.qzlKeO("5")).toString());
/* 228 */     return this; } public JsonObjectBuilder appendField(String str, int i) { iIIIiI(str, String.valueOf(i)); return this; }
/*     */ 
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\json\JsonObjectBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */