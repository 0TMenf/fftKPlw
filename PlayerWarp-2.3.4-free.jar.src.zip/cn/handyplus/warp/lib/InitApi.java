/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import cn.handyplus.warp.lib.bukkit.Metrics;
/*     */ import cn.handyplus.warp.lib.charts.CustomChart;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InitApi
/*     */ {
/*     */   public static JavaPlugin PLUGIN;
/*     */   
/*     */   public static InitApi getInstance(JavaPlugin a) {
/*  30 */     BaseConstants.VERSION_CHECK_ENUM = VersionCheckEnum.getEnum();
/*  31 */     BaseConstants.VERSION_ID = BaseConstants.VERSION_CHECK_ENUM.getVersionId();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     HandySchedulerUtil.init((Plugin)(PLUGIN = a));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     LegacyUtil.initClasses();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 186 */     CompatCore.init(BaseConstants.VERSION_ID);
/*     */     LoginCompatUtil.init((Plugin)a);
/*     */     return oooooo;
/*     */   }
/*     */ 
/*     */   
/*     */   public InitApi initListener(String str) {
/*     */     return initListener(str, null);
/*     */   }
/*     */   
/*     */   public InitApi addMetrics(int i, List<?> list) {
/*     */     try {
/*     */       Metrics metrics = new Metrics((Plugin)PLUGIN, i);
/*     */       if (CollUtil.isNotEmpty(list)) {
/*     */         for (CustomChart customChart : list) {
/*     */           metrics.addCustomChart(customChart);
/*     */         }
/*     */       }
/* 204 */     } catch (Throwable throwable) {}
/*     */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InitApi checkVersion() {
/*     */     if (BaseConstants.IS_CHECK_UPDATE) {
/*     */       HandyHttpUtil.checkVersion(null);
/*     */     }
/* 222 */     return this;
/*     */   }
/*     */   
/*     */   public static void disable() {
/*     */     SqlManagerUtil.getInstance().close();
/*     */     HandySchedulerUtil.cancelTask();
/*     */     if (!HandySchedulerUtil.isFolia())
/*     */       HandyInventoryUtil.closeHandyInventory(); 
/*     */   }
/*     */   
/*     */   public InitApi addMetrics(int i) {
/*     */     return addMetrics(i, null);
/*     */   }
/*     */   
/*     */   public InitApi initListener(String str, List<String> list) {
/*     */     try {
/*     */       HandyInventoryWrapper.initListener(str, list);
/*     */       return this;
/*     */     } catch (Throwable throwable) {
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */   
/*     */   public InitApi initClickEvent(String str) {
/*     */     try {
/*     */       HandyInventoryWrapper.initClickEvent(str);
/*     */       return this;
/*     */     } catch (Throwable throwable) {
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */   
/*     */   public InitApi enableSql(String str) {
/*     */     List<Class<?>> list;
/*     */     if (CollUtil.isEmpty(list = ClassUtil.getInstance().getClassByAnnotation(str, (Class)TableName.class)))
/*     */       return this; 
/*     */     SqlManagerUtil.getInstance().enableSql();
/*     */     for (Iterator<Class<?>> iterator = list.iterator(); iterator.hasNext();) {
/*     */       if (((TableName)(clazz = iterator.next()).<TableName>getAnnotation(TableName.class)).create())
/*     */         Db.use(clazz).createTable(); 
/*     */     } 
/*     */     return this;
/*     */   }
/*     */   
/*     */   private static final InitApi oooooo = new InitApi();
/*     */   
/*     */   public InitApi enableBc() {
/*     */     BcUtil.registerOut();
/*     */     return this;
/*     */   }
/*     */   
/*     */   public InitApi initCommand(String str) {
/*     */     try {
/*     */       HandyCommandWrapper.initCommand(str);
/*     */       return this;
/*     */     } catch (Throwable throwable) {
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\InitApi.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */