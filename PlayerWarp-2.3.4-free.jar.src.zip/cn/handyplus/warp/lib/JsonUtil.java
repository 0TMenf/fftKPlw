/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonParser;
/*     */ import com.google.gson.reflect.TypeToken;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JsonUtil
/*     */ {
/*     */   public static String toJson(@NotNull Object obj) {
/*  31 */     return a.toJson(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T toBean(@NotNull String json, @NotNull Class t) {
/*  48 */     return (T)a.fromJson(json, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> boolean writeListToJson(@NotNull List list, File file)
/*     */   {
/*     */     
/*  83 */     try { FileWriter fileWriter = new FileWriter(file);
/*     */ 
/*     */ 
/*     */       
/*     */       try { K.toJson(list, fileWriter);
/*     */ 
/*     */         
/*  90 */         boolean bool = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 113 */         fileWriter.close(); return bool; } catch (Throwable throwable) { try { fileWriter.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */          throw throwable; }
/*     */        }
/*     */     catch (Throwable throwable) { throw throwable; }
/* 117 */      } public static Map<String, Object> toObjMap(@NotNull String json) { return (Map<String, Object>)a.fromJson(json, L); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Type WyXcdP = (new T()).getType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 134 */     j = (new h()).getType();
/*     */     L = (new a()).getType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   private static final Gson a = new Gson();
/*     */   public static Map<Integer, String> toIntMap(@NotNull String json) {
/* 144 */     return (Map<Integer, String>)a.fromJson(json, j);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTypeJsonObject(String a)
/*     */   {
/* 151 */     if (StrUtil.isEmpty(a))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 231 */       return false; }  return StrUtil.isWrap(a, '{', '}'); } public static boolean isTypeJsonArray(String a) { if (StrUtil.isEmpty(a))
/* 232 */       return false; 
/*     */     return StrUtil.isWrap(a, '[', ']'); }
/*     */ 
/*     */   
/*     */   public static Map<String, String> toMap(@NotNull String json) {
/*     */     return (Map<String, String>)a.fromJson(json, WyXcdP);
/*     */   }
/*     */   
/*     */   public static boolean isJson(String a) {
/*     */     if (StrUtil.isEmpty(a))
/*     */       return false; 
/*     */     return (isTypeJsonObject(a) || isTypeJsonArray(a));
/*     */   }
/*     */   
/*     */   private static final Gson K = (new GsonBuilder()).setPrettyPrinting().create();
/*     */   private static final Type L;
/*     */   private static final Type j;
/*     */   
/*     */   public static <T> List<T> toList(@NotNull String json, @NotNull Class t) {
/*     */     if (BaseConstants.VERSION_ID.intValue() >= VersionCheckEnum.V_1_12.getVersionId().intValue()) {
/*     */       true;
/*     */       true[0] = t;
/*     */       return (List<T>)json.fromJson((String)List.class, TypeToken.getParameterized((Type)new Type[1], true).getType());
/*     */     } 
/*     */     JsonArray jsonArray = (new JsonParser()).parse(json).getAsJsonArray();
/*     */     ArrayList<Object> arrayList = new ArrayList(jsonArray.size());
/*     */     Iterator<?> iterator;
/*     */     for (; (iterator = jsonArray.iterator()).hasNext(); arrayList.add(a.fromJson(jsonElement, t)))
/*     */       JsonElement jsonElement = (JsonElement)iterator.next(); 
/*     */     return arrayList;
/*     */   }
/*     */   
/*     */   public static Map<String, String> objectToMap(@NotNull Object obj) {
/*     */     return toMap(toJson(obj));
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\JsonUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */