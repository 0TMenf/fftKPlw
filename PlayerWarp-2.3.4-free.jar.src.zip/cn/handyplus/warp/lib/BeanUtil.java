/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BeanUtil
/*     */ {
/*     */   public static <T> T mapToBean(Class<?> a, Map map) {
/*  48 */     Method method = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 224 */       BeanInfo beanInfo = Introspector.getBeanInfo(a);
/*     */       true;
/*     */       true;
/*     */       method = (Method)(new Object[0]).newInstance(true);
/*     */       PropertyDescriptor[] arrayOfPropertyDescriptor;
/*     */       int i;
/*     */       byte b;
/*     */       for (i = (arrayOfPropertyDescriptor = beanInfo.getPropertyDescriptors()).length, b = 0; b < i; b++) {
/*     */         PropertyDescriptor propertyDescriptor;
/*     */         String str = (propertyDescriptor = arrayOfPropertyDescriptor[b]).getName();
/*     */         if (map.containsKey(str)) {
/*     */           true;
/*     */           true[0] = map.get(str);
/*     */           method.invoke(new Object[1], true);
/*     */         } 
/*     */       } 
/*     */     } catch (Exception exception) {
/*     */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, NetUtil.qzlKeO("x\021e$z2p\021{P叄畯弗幈"), exception);
/*     */     } 
/*     */     return (T)method;
/*     */   }
/*     */   
/*     */   public static Map<String, Object> beanToMap(Object a) {
/*     */     if (a == null)
/*     */       return null; 
/*     */     HashMap<?, ?> hashMap = MapUtil.of();
/*     */     try {
/*     */       BeanInfo beanInfo;
/*     */       PropertyDescriptor[] arrayOfPropertyDescriptor;
/*     */       int i;
/*     */       byte b;
/*     */       for (i = (arrayOfPropertyDescriptor = (beanInfo = Introspector.getBeanInfo(a.getClass())).getPropertyDescriptors()).length, b = 0; b < i;)
/*     */         str = (propertyDescriptor = arrayOfPropertyDescriptor[b]).getName(); 
/*     */     } catch (Exception exception) {
/*     */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, NumberUtil.qzlKeO(".3-8\0309\0017<v厝畉彎幮"), exception);
/*     */     } 
/*     */     return (Map)hashMap;
/*     */   }
/*     */   
/*     */   public static <T> T createBean(Class a) {
/*     */     T t = null;
/*     */     try {
/*     */       true;
/*     */       true;
/*     */       return (T)(new Object[0]).newInstance(true);
/*     */     } catch (Exception exception) {
/*     */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, NumberUtil.qzlKeO("5>3-\")\024)7\"v厝畉彎幮"), exception);
/*     */       return t;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\BeanUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */