/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import cn.handyplus.warp.service.WarpTpPlayerService;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.time.LocalDateTime;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Level;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ public class DbExecution<T>
/*     */   implements pPPPPP<T> {
/*     */   private final String a;
/*     */   private final boolean L;
/*     */   private final Connection K;
/*     */   private final Class<T> j;
/*     */   private final XxXXXX PppPPP;
/*     */   
/*     */   public List<Map<String, Object>> selectListMap() {
/*  33 */     PreparedStatement preparedStatement = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     null = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 157 */     ArrayList<Map<String, Object>> arrayList = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 168 */     String str = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try { str = this.PppPPP.I();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 199 */       oOooOo(preparedStatement = this.K.prepareStatement(str));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 207 */       ResultSetMetaData resultSetMetaData = (null = preparedStatement.executeQuery()).getMetaData();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       if ((null = preparedStatement.executeQuery()).next()) {
/*     */         boolean bool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 229 */         HashMap<Object, Object> hashMap = new HashMap<>();
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return arrayList; }
/*     */     catch (SQLException sQLException)
/*     */     { InitApi.PLUGIN.getLogger().log(Level.SEVERE, StrUtil.qzlKeO("F>Y>V/y2F/x:E{古畄強幣"), sQLException);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 407 */       return 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 489 */         arrayList; } finally { SqlManagerUtil.getInstance().xxxxXx(this.K, preparedStatement, null);
/*     */       XxxxXx(str, StrUtil.qzlKeO("(P7P8A\027\\(A\026T+\017{")); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<T> selectById(Integer integer) {
/*     */     this.PppPPP.l(true, "id", oooOoO.k, integer);
/*     */     return selectOne();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DbExecution(XxXXXX xxXXXX, Class<T> clazz) {
/*     */     this.PppPPP = xxXXXX;
/*     */     this.j = clazz;
/*     */     this.a = SqlManagerUtil.getInstance().oOOOOo();
/*     */     this.L = !DbTypeEnum.SQLite.getType().equalsIgnoreCase(this.a);
/*     */     this.K = SqlManagerUtil.getInstance().xXXxxx(this.a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DbExecution(XxXXXX xxXXXX, Class<T> clazz, String str) {
/*     */     this.PppPPP = xxXXXX;
/*     */     this.j = clazz;
/*     */     this.a = str;
/*     */     this.L = !DbTypeEnum.SQLite.getType().equalsIgnoreCase(str);
/*     */     this.K = SqlManagerUtil.getInstance().xXXxxx(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> selectBatchIds(List<?> list) {
/*     */     this.PppPPP.oOOOoO(true, "id", oooOoO.L, list);
/*     */     return list();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DbExecution(XxXXXX xxXXXX, Class<T> clazz, int i) {
/*     */     this.PppPPP = xxXXXX;
/*     */     this.j = clazz;
/*     */     this.a = SqlManagerUtil.getInstance().oOOOOo();
/*     */     this.L = !DbTypeEnum.SQLite.getType().equalsIgnoreCase(this.a);
/*     */     this.K = (i != 0) ? SqlManagerUtil.getInstance().xXXxxx(this.a) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void PPPPpp() {
/*     */     PtdKXl ptdKXl = this.PppPPP.IiiIIi();
/*     */     String str = this.L ? "CREATE TABLE IF NOT EXISTS `%s` (`id` INTEGER (11) AUTO_INCREMENT,PRIMARY KEY (`id`)) CHARACTER SET = utf8mb4 ENGINE=INNODB;" : "CREATE TABLE IF NOT EXISTS `%s` ( `id` INTEGER PRIMARY KEY AUTOINCREMENT);";
/*     */     true;
/*     */     true[0] = ptdKXl.PpppPp();
/*     */     str = String.format((String)new Object[1], true);
/*     */     XxxxXx(str, StrUtil.qzlKeO("V)P:A>a:W7P\bD7\017{"));
/*     */     SqlService.getInstance().pppppp(str, this.a);
/*     */     if (this.L) {
/*     */       true;
/*     */       true[0] = ptdKXl.PpppPp();
/*     */       true[1] = ptdKXl.l();
/*     */       str = String.format((String)new Object[2], true);
/*     */       XxxxXx(str, WarpTpPlayerService.qzlKeO("_bIoN@DnFfEwxrG9\013"));
/*     */       SqlService.getInstance().pppppp(str, this.a);
/*     */     } 
/*     */     IIiIiI(ptdKXl.PpppPp(), this.PppPPP.I());
/*     */     OOOOoo(ptdKXl.PpppPp());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DbExecution(XxXXXX xxXXXX, Class<T> clazz, Connection connection) {
/*     */     this.PppPPP = xxXXXX;
/*     */     this.j = clazz;
/*     */     this.a = SqlManagerUtil.getInstance().oOOOOo();
/*     */     this.L = !DbTypeEnum.SQLite.getType().equalsIgnoreCase(this.a);
/*     */     this.K = connection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int update() {
/*     */     PreparedStatement preparedStatement = null;
/*     */     String str = null;
/*     */     try {
/* 675 */       str = this.PppPPP.h(); preparedStatement = this.K.prepareStatement(str); LinkedHashMap<Integer, Object> linkedHashMap; Iterator<?> iterator; for (; (iterator = (linkedHashMap = this.PppPPP.OOOoOo()).keySet().iterator()).hasNext(); preparedStatement.setObject(integer.intValue(), linkedHashMap.get(integer))) {
/*     */         Integer integer = (Integer)iterator.next();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       ooooOo(preparedStatement, Integer.valueOf(linkedHashMap.size()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return preparedStatement.executeUpdate();
/*     */     } catch (SQLException sQLException) {
/* 766 */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, StrUtil.qzlKeO(".E?T/P{古畄強幣"), sQLException);
/*     */     } finally {
/*     */       SqlManagerUtil.getInstance().xxxxXx(this.K, preparedStatement, null);
/*     */       XxxxXx(str, StrUtil.qzlKeO("@+Q:A>\017{"));
/*     */     } 
/*     */     return 0;
/*     */   }
/*     */   
/*     */   public int updateById(Integer integer) {
/*     */     this.PppPPP.l(true, "id", oooOoO.k, integer);
/*     */     return update();
/*     */   }
/*     */   
/*     */   public int count() {
/*     */     return count(null);
/*     */   }
/*     */   
/*     */   public List<T> list() {
/*     */     return PPPPPp(true);
/*     */   }
/*     */   
/*     */   public int deleteBatchIds(List<?> list) {
/*     */     this.PppPPP.oOOOoO(true, "id", oooOoO.L, list);
/*     */     return delete();
/*     */   }
/*     */   
/*     */   public Optional<T> selectOne() {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_1
/*     */     //   2: aconst_null
/*     */     //   3: astore_2
/*     */     //   4: aconst_null
/*     */     //   5: astore_3
/*     */     //   6: aload_0
/*     */     //   7: dup
/*     */     //   8: dup_x1
/*     */     //   9: getfield PppPPP : Lcn/handyplus/warp/lib/XxXXXX;
/*     */     //   12: invokevirtual I : ()Ljava/lang/String;
/*     */     //   15: astore_3
/*     */     //   16: getfield K : Ljava/sql/Connection;
/*     */     //   19: aload_3
/*     */     //   20: invokeinterface prepareStatement : (Ljava/lang/String;)Ljava/sql/PreparedStatement;
/*     */     //   25: dup
/*     */     //   26: astore_1
/*     */     //   27: invokespecial oOooOo : (Ljava/sql/PreparedStatement;)V
/*     */     //   30: aload_1
/*     */     //   31: invokeinterface executeQuery : ()Ljava/sql/ResultSet;
/*     */     //   36: dup
/*     */     //   37: astore_2
/*     */     //   38: invokeinterface isBeforeFirst : ()Z
/*     */     //   43: ifne -> 78
/*     */     //   46: invokestatic empty : ()Ljava/util/Optional;
/*     */     //   49: astore #4
/*     */     //   51: invokestatic getInstance : ()Lcn/handyplus/warp/lib/SqlManagerUtil;
/*     */     //   54: aload_0
/*     */     //   55: getfield K : Ljava/sql/Connection;
/*     */     //   58: aload_1
/*     */     //   59: aload_2
/*     */     //   60: invokevirtual xxxxXx : (Ljava/sql/Connection;Ljava/sql/PreparedStatement;Ljava/sql/ResultSet;)V
/*     */     //   63: aload #4
/*     */     //   65: aload_0
/*     */     //   66: aload_3
/*     */     //   67: ldc_w 'XfGfHwdmN9'
/*     */     //   70: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   73: invokespecial XxxxXx : (Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   76: areturn
/*     */     //   77: athrow
/*     */     //   78: aload_0
/*     */     //   79: getfield j : Ljava/lang/Class;
/*     */     //   82: iconst_0
/*     */     //   83: anewarray java/lang/Class
/*     */     //   86: iconst_1
/*     */     //   87: dup
/*     */     //   88: pop2
/*     */     //   89: invokevirtual getDeclaredConstructor : ([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
/*     */     //   92: astore #4
/*     */     //   94: iconst_0
/*     */     //   95: aload #4
/*     */     //   97: dup_x1
/*     */     //   98: iconst_1
/*     */     //   99: invokevirtual setAccessible : (Z)V
/*     */     //   102: anewarray java/lang/Object
/*     */     //   105: iconst_1
/*     */     //   106: dup
/*     */     //   107: pop2
/*     */     //   108: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   111: astore #5
/*     */     //   113: aload_0
/*     */     //   114: getfield PppPPP : Lcn/handyplus/warp/lib/XxXXXX;
/*     */     //   117: invokevirtual I : ()Ljava/util/LinkedHashMap;
/*     */     //   120: astore #6
/*     */     //   122: aload_2
/*     */     //   123: invokeinterface next : ()Z
/*     */     //   128: ifeq -> 226
/*     */     //   131: aload #6
/*     */     //   133: invokevirtual keySet : ()Ljava/util/Set;
/*     */     //   136: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   141: dup
/*     */     //   142: astore #7
/*     */     //   144: invokeinterface hasNext : ()Z
/*     */     //   149: ifeq -> 226
/*     */     //   152: aload #7
/*     */     //   154: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   159: checkcast java/lang/String
/*     */     //   162: astore #8
/*     */     //   164: aload #6
/*     */     //   166: aload #8
/*     */     //   168: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   171: checkcast cn/handyplus/warp/lib/KcifTq
/*     */     //   174: astore #8
/*     */     //   176: aload_2
/*     */     //   177: aload #8
/*     */     //   179: invokevirtual A : ()Ljava/lang/String;
/*     */     //   182: invokeinterface getObject : (Ljava/lang/String;)Ljava/lang/Object;
/*     */     //   187: dup
/*     */     //   188: astore #9
/*     */     //   190: ifnonnull -> 199
/*     */     //   193: aload #7
/*     */     //   195: goto -> 144
/*     */     //   198: athrow
/*     */     //   199: aload_0
/*     */     //   200: aload #8
/*     */     //   202: aload #9
/*     */     //   204: invokespecial ppppPP : (Lcn/handyplus/warp/lib/KcifTq;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   207: astore #9
/*     */     //   209: aload #7
/*     */     //   211: aload #8
/*     */     //   213: invokevirtual xxXXXx : ()Ljava/lang/reflect/Field;
/*     */     //   216: aload #5
/*     */     //   218: aload #9
/*     */     //   220: invokevirtual set : (Ljava/lang/Object;Ljava/lang/Object;)V
/*     */     //   223: goto -> 144
/*     */     //   226: aload #5
/*     */     //   228: invokestatic of : (Ljava/lang/Object;)Ljava/util/Optional;
/*     */     //   231: astore #7
/*     */     //   233: invokestatic getInstance : ()Lcn/handyplus/warp/lib/SqlManagerUtil;
/*     */     //   236: aload_0
/*     */     //   237: getfield K : Ljava/sql/Connection;
/*     */     //   240: aload_1
/*     */     //   241: aload_2
/*     */     //   242: invokevirtual xxxxXx : (Ljava/sql/Connection;Ljava/sql/PreparedStatement;Ljava/sql/ResultSet;)V
/*     */     //   245: aload #7
/*     */     //   247: aload_0
/*     */     //   248: aload_3
/*     */     //   249: ldc_w '(P7P8A[>{'
/*     */     //   252: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   255: invokespecial XxxxXx : (Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   258: areturn
/*     */     //   259: astore #4
/*     */     //   261: getstatic cn/handyplus/warp/lib/InitApi.PLUGIN : Lorg/bukkit/plugin/java/JavaPlugin;
/*     */     //   264: invokevirtual getLogger : ()Ljava/util/logging/Logger;
/*     */     //   267: getstatic java/util/logging/Level.SEVERE : Ljava/util/logging/Level;
/*     */     //   270: ldc_w 'pNoN`_LEf叒甴弁帓'
/*     */     //   273: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   276: aload #4
/*     */     //   278: invokevirtual log : (Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   281: invokestatic getInstance : ()Lcn/handyplus/warp/lib/SqlManagerUtil;
/*     */     //   284: aload_0
/*     */     //   285: getfield K : Ljava/sql/Connection;
/*     */     //   288: aload_1
/*     */     //   289: aload_2
/*     */     //   290: invokevirtual xxxxXx : (Ljava/sql/Connection;Ljava/sql/PreparedStatement;Ljava/sql/ResultSet;)V
/*     */     //   293: aload_0
/*     */     //   294: aload_3
/*     */     //   295: ldc_w '(P7P8A[>{'
/*     */     //   298: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   301: invokespecial XxxxXx : (Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   304: goto -> 335
/*     */     //   307: astore #4
/*     */     //   309: invokestatic getInstance : ()Lcn/handyplus/warp/lib/SqlManagerUtil;
/*     */     //   312: aload_0
/*     */     //   313: getfield K : Ljava/sql/Connection;
/*     */     //   316: aload_1
/*     */     //   317: aload_2
/*     */     //   318: invokevirtual xxxxXx : (Ljava/sql/Connection;Ljava/sql/PreparedStatement;Ljava/sql/ResultSet;)V
/*     */     //   321: aload #4
/*     */     //   323: aload_0
/*     */     //   324: aload_3
/*     */     //   325: ldc_w 'XfGfHwdmN9'
/*     */     //   328: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   331: invokespecial XxxxXx : (Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   334: athrow
/*     */     //   335: invokestatic empty : ()Ljava/util/Optional;
/*     */     //   338: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #479	-> 0
/*     */     //   #769	-> 2
/*     */     //   #546	-> 4
/*     */     //   #423	-> 6
/*     */     //   #381	-> 16
/*     */     //   #672	-> 27
/*     */     //   #629	-> 30
/*     */     //   #343	-> 38
/*     */     //   #724	-> 46
/*     */     //   #732	-> 51
/*     */     //   #755	-> 65
/*     */     //   #724	-> 76
/*     */     //   #449	-> 78
/*     */     //   #772	-> 94
/*     */     //   #499	-> 102
/*     */     //   #458	-> 113
/*     */     //   #464	-> 122
/*     */     //   #655	-> 131
/*     */     //   #303	-> 164
/*     */     //   #461	-> 176
/*     */     //   #326	-> 190
/*     */     //   #621	-> 195
/*     */     //   #324	-> 199
/*     */     //   #430	-> 211
/*     */     //   #400	-> 223
/*     */     //   #452	-> 226
/*     */     //   #732	-> 233
/*     */     //   #755	-> 247
/*     */     //   #452	-> 258
/*     */     //   #262	-> 259
/*     */     //   #580	-> 261
/*     */     //   #732	-> 281
/*     */     //   #755	-> 293
/*     */     //   #770	-> 304
/*     */     //   #732	-> 307
/*     */     //   #755	-> 323
/*     */     //   #770	-> 334
/*     */     //   #553	-> 335
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	339	0	a	Lcn/handyplus/warp/lib/DbExecution;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   6	51	259	java/sql/SQLException
/*     */     //   6	51	259	java/lang/NoSuchMethodException
/*     */     //   6	51	259	java/lang/InstantiationException
/*     */     //   6	51	259	java/lang/IllegalAccessException
/*     */     //   6	51	259	java/lang/reflect/InvocationTargetException
/*     */     //   6	51	307	finally
/*     */     //   78	198	259	java/sql/SQLException
/*     */     //   78	198	259	java/lang/NoSuchMethodException
/*     */     //   78	198	259	java/lang/InstantiationException
/*     */     //   78	198	259	java/lang/IllegalAccessException
/*     */     //   78	198	259	java/lang/reflect/InvocationTargetException
/*     */     //   78	198	307	finally
/*     */     //   199	233	259	java/sql/SQLException
/*     */     //   199	233	259	java/lang/NoSuchMethodException
/*     */     //   199	233	259	java/lang/InstantiationException
/*     */     //   199	233	259	java/lang/IllegalAccessException
/*     */     //   199	233	259	java/lang/reflect/InvocationTargetException
/*     */     //   199	233	307	finally
/*     */     //   259	281	307	finally
/*     */     //   307	309	307	finally
/*     */   }
/*     */   
/*     */   public int count(String str) {
/*     */     return ooOOOO(str, true);
/*     */   }
/*     */   
/*     */   public boolean insertBatch(List list) {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_2
/*     */     //   2: iconst_1
/*     */     //   3: istore_3
/*     */     //   4: aload_0
/*     */     //   5: dup
/*     */     //   6: getfield PppPPP : Lcn/handyplus/warp/lib/XxXXXX;
/*     */     //   9: invokevirtual OoooOo : ()Ljava/lang/String;
/*     */     //   12: astore #4
/*     */     //   14: new java/lang/StringBuilder
/*     */     //   17: dup
/*     */     //   18: invokespecial <init> : ()V
/*     */     //   21: iconst_0
/*     */     //   22: ldc_w 'BmXfYwib_`C9'
/*     */     //   25: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   28: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   31: aload #4
/*     */     //   33: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   36: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   39: invokestatic sendConsoleDebugMessage : (Ljava/lang/String;)V
/*     */     //   42: getfield K : Ljava/sql/Connection;
/*     */     //   45: invokeinterface getAutoCommit : ()Z
/*     */     //   50: dup
/*     */     //   51: istore_3
/*     */     //   52: ifeq -> 65
/*     */     //   55: aload_0
/*     */     //   56: getfield K : Ljava/sql/Connection;
/*     */     //   59: iconst_0
/*     */     //   60: invokeinterface setAutoCommit : (Z)V
/*     */     //   65: aload_0
/*     */     //   66: dup
/*     */     //   67: getfield K : Ljava/sql/Connection;
/*     */     //   70: aload #4
/*     */     //   72: iconst_1
/*     */     //   73: invokeinterface prepareStatement : (Ljava/lang/String;I)Ljava/sql/PreparedStatement;
/*     */     //   78: astore_2
/*     */     //   79: getfield PppPPP : Lcn/handyplus/warp/lib/XxXXXX;
/*     */     //   82: invokevirtual I : ()Ljava/util/LinkedHashMap;
/*     */     //   85: invokevirtual values : ()Ljava/util/Collection;
/*     */     //   88: invokeinterface stream : ()Ljava/util/stream/Stream;
/*     */     //   93: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */     //   98: invokestatic toList : ()Ljava/util/stream/Collector;
/*     */     //   101: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */     //   106: invokestatic collectingAndThen : (Ljava/util/stream/Collector;Ljava/util/function/Function;)Ljava/util/stream/Collector;
/*     */     //   109: invokestatic groupingBy : (Ljava/util/function/Function;Ljava/util/stream/Collector;)Ljava/util/stream/Collector;
/*     */     //   112: invokeinterface collect : (Ljava/util/stream/Collector;)Ljava/lang/Object;
/*     */     //   117: checkcast java/util/Map
/*     */     //   120: astore #5
/*     */     //   122: iconst_0
/*     */     //   123: dup
/*     */     //   124: istore #6
/*     */     //   126: aload_1
/*     */     //   127: invokeinterface size : ()I
/*     */     //   132: if_icmpge -> 325
/*     */     //   135: aload_1
/*     */     //   136: iload #6
/*     */     //   138: invokeinterface get : (I)Ljava/lang/Object;
/*     */     //   143: invokestatic beanToMap : (Ljava/lang/Object;)Ljava/util/Map;
/*     */     //   146: dup
/*     */     //   147: astore #7
/*     */     //   149: invokeinterface keySet : ()Ljava/util/Set;
/*     */     //   154: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   159: astore #8
/*     */     //   161: aload #8
/*     */     //   163: invokeinterface hasNext : ()Z
/*     */     //   168: ifeq -> 282
/*     */     //   171: aload #8
/*     */     //   173: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   178: checkcast java/lang/String
/*     */     //   181: astore #9
/*     */     //   183: aload #5
/*     */     //   185: aload #9
/*     */     //   187: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   192: checkcast cn/handyplus/warp/lib/KcifTq
/*     */     //   195: dup
/*     */     //   196: astore #10
/*     */     //   198: ifnonnull -> 207
/*     */     //   201: aload #8
/*     */     //   203: goto -> 163
/*     */     //   206: athrow
/*     */     //   207: aload #7
/*     */     //   209: aload #9
/*     */     //   211: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   216: astore #9
/*     */     //   218: getstatic cn/handyplus/warp/lib/pPpPPp.h : Lcn/handyplus/warp/lib/pPpPPp;
/*     */     //   221: invokevirtual l : ()Ljava/lang/String;
/*     */     //   224: aload #10
/*     */     //   226: invokevirtual l : ()Ljava/lang/String;
/*     */     //   229: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   232: ifeq -> 263
/*     */     //   235: aload #9
/*     */     //   237: ifnull -> 263
/*     */     //   240: aload_2
/*     */     //   241: aload #10
/*     */     //   243: invokevirtual l : ()Ljava/lang/Integer;
/*     */     //   246: invokevirtual intValue : ()I
/*     */     //   249: aload #9
/*     */     //   251: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   254: invokeinterface setString : (ILjava/lang/String;)V
/*     */     //   259: goto -> 161
/*     */     //   262: athrow
/*     */     //   263: aload_2
/*     */     //   264: aload #10
/*     */     //   266: invokevirtual l : ()Ljava/lang/Integer;
/*     */     //   269: invokevirtual intValue : ()I
/*     */     //   272: aload #9
/*     */     //   274: invokeinterface setObject : (ILjava/lang/Object;)V
/*     */     //   279: goto -> 161
/*     */     //   282: aload_2
/*     */     //   283: invokeinterface addBatch : ()V
/*     */     //   288: iload #6
/*     */     //   290: ifeq -> 317
/*     */     //   293: iload #6
/*     */     //   295: iconst_1
/*     */     //   296: iadd
/*     */     //   297: sipush #500
/*     */     //   300: irem
/*     */     //   301: ifne -> 317
/*     */     //   304: aload_2
/*     */     //   305: invokeinterface executeBatch : ()[I
/*     */     //   310: aload_2
/*     */     //   311: invokeinterface clearBatch : ()V
/*     */     //   316: pop
/*     */     //   317: iinc #6, 1
/*     */     //   320: iload #6
/*     */     //   322: goto -> 126
/*     */     //   325: aload_2
/*     */     //   326: invokeinterface executeBatch : ()[I
/*     */     //   331: pop
/*     */     //   332: iload_3
/*     */     //   333: ifeq -> 345
/*     */     //   336: aload_0
/*     */     //   337: getfield K : Ljava/sql/Connection;
/*     */     //   340: invokeinterface commit : ()V
/*     */     //   345: iconst_1
/*     */     //   346: istore #6
/*     */     //   348: iload_3
/*     */     //   349: ifeq -> 366
/*     */     //   352: invokestatic getInstance : ()Lcn/handyplus/warp/lib/SqlManagerUtil;
/*     */     //   355: aload_0
/*     */     //   356: getfield K : Ljava/sql/Connection;
/*     */     //   359: iconst_1
/*     */     //   360: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*     */     //   363: invokevirtual xXXxxx : (Ljava/sql/Connection;Ljava/lang/Boolean;)V
/*     */     //   366: invokestatic getInstance : ()Lcn/handyplus/warp/lib/SqlManagerUtil;
/*     */     //   369: aload_0
/*     */     //   370: getfield K : Ljava/sql/Connection;
/*     */     //   373: aload_2
/*     */     //   374: aconst_null
/*     */     //   375: invokevirtual xxxxXx : (Ljava/sql/Connection;Ljava/sql/PreparedStatement;Ljava/sql/ResultSet;)V
/*     */     //   378: iload #6
/*     */     //   380: ireturn
/*     */     //   381: astore #4
/*     */     //   383: iload_3
/*     */     //   384: ifeq -> 411
/*     */     //   387: aload_0
/*     */     //   388: getfield K : Ljava/sql/Connection;
/*     */     //   391: invokeinterface rollback : ()V
/*     */     //   396: goto -> 411
/*     */     //   399: astore #5
/*     */     //   401: new java/lang/RuntimeException
/*     */     //   404: dup
/*     */     //   405: aload #5
/*     */     //   407: invokespecial <init> : (Ljava/lang/Throwable;)V
/*     */     //   410: athrow
/*     */     //   411: getstatic cn/handyplus/warp/lib/InitApi.PLUGIN : Lorg/bukkit/plugin/java/JavaPlugin;
/*     */     //   414: invokevirtual getLogger : ()Ljava/util/logging/Logger;
/*     */     //   417: getstatic java/util/logging/Level.SEVERE : Ljava/util/logging/Level;
/*     */     //   420: ldc_w '\5F>G/w:A8]{古畄強幣'
/*     */     //   423: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   426: aload #4
/*     */     //   428: invokevirtual log : (Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   431: iload_3
/*     */     //   432: ifeq -> 449
/*     */     //   435: invokestatic getInstance : ()Lcn/handyplus/warp/lib/SqlManagerUtil;
/*     */     //   438: aload_0
/*     */     //   439: getfield K : Ljava/sql/Connection;
/*     */     //   442: iconst_1
/*     */     //   443: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*     */     //   446: invokevirtual xXXxxx : (Ljava/sql/Connection;Ljava/lang/Boolean;)V
/*     */     //   449: invokestatic getInstance : ()Lcn/handyplus/warp/lib/SqlManagerUtil;
/*     */     //   452: aload_0
/*     */     //   453: getfield K : Ljava/sql/Connection;
/*     */     //   456: aload_2
/*     */     //   457: aconst_null
/*     */     //   458: invokevirtual xxxxXx : (Ljava/sql/Connection;Ljava/sql/PreparedStatement;Ljava/sql/ResultSet;)V
/*     */     //   461: goto -> 499
/*     */     //   464: astore #11
/*     */     //   466: iload_3
/*     */     //   467: ifeq -> 484
/*     */     //   470: invokestatic getInstance : ()Lcn/handyplus/warp/lib/SqlManagerUtil;
/*     */     //   473: aload_0
/*     */     //   474: getfield K : Ljava/sql/Connection;
/*     */     //   477: iconst_1
/*     */     //   478: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*     */     //   481: invokevirtual xXXxxx : (Ljava/sql/Connection;Ljava/lang/Boolean;)V
/*     */     //   484: invokestatic getInstance : ()Lcn/handyplus/warp/lib/SqlManagerUtil;
/*     */     //   487: aload_0
/*     */     //   488: getfield K : Ljava/sql/Connection;
/*     */     //   491: aload_2
/*     */     //   492: aconst_null
/*     */     //   493: invokevirtual xxxxXx : (Ljava/sql/Connection;Ljava/sql/PreparedStatement;Ljava/sql/ResultSet;)V
/*     */     //   496: aload #11
/*     */     //   498: athrow
/*     */     //   499: iconst_0
/*     */     //   500: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #527	-> 0
/*     */     //   #285	-> 2
/*     */     //   #412	-> 4
/*     */     //   #691	-> 14
/*     */     //   #745	-> 42
/*     */     //   #698	-> 52
/*     */     //   #612	-> 55
/*     */     //   #418	-> 65
/*     */     //   #392	-> 79
/*     */     //   #364	-> 122
/*     */     //   #622	-> 135
/*     */     //   #386	-> 149
/*     */     //   #721	-> 183
/*     */     //   #302	-> 198
/*     */     //   #435	-> 203
/*     */     //   #292	-> 207
/*     */     //   #249	-> 218
/*     */     //   #648	-> 240
/*     */     //   #480	-> 263
/*     */     //   #446	-> 279
/*     */     //   #254	-> 282
/*     */     //   #471	-> 288
/*     */     //   #598	-> 304
/*     */     //   #299	-> 310
/*     */     //   #364	-> 317
/*     */     //   #709	-> 325
/*     */     //   #584	-> 332
/*     */     //   #363	-> 336
/*     */     //   #534	-> 345
/*     */     //   #742	-> 348
/*     */     //   #278	-> 352
/*     */     //   #280	-> 366
/*     */     //   #534	-> 378
/*     */     //   #601	-> 381
/*     */     //   #557	-> 383
/*     */     //   #406	-> 387
/*     */     //   #768	-> 396
/*     */     //   #460	-> 399
/*     */     //   #387	-> 401
/*     */     //   #330	-> 411
/*     */     //   #742	-> 431
/*     */     //   #278	-> 435
/*     */     //   #280	-> 449
/*     */     //   #265	-> 461
/*     */     //   #742	-> 464
/*     */     //   #278	-> 470
/*     */     //   #280	-> 484
/*     */     //   #265	-> 496
/*     */     //   #382	-> 499
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	501	0	a	Lcn/handyplus/warp/lib/DbExecution;
/*     */     //   0	501	1	a	Ljava/util/List;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	206	381	java/sql/SQLException
/*     */     //   4	206	464	finally
/*     */     //   207	262	381	java/sql/SQLException
/*     */     //   207	262	464	finally
/*     */     //   263	348	381	java/sql/SQLException
/*     */     //   263	348	464	finally
/*     */     //   381	431	464	finally
/*     */     //   383	396	399	java/sql/SQLException
/*     */     //   464	466	464	finally
/*     */   }
/*     */   
/*     */   public int delete() {
/*     */     PreparedStatement preparedStatement = null;
/*     */     String str = null;
/*     */     try {
/*     */       str = this.PppPPP.l();
/*     */       oOooOo(preparedStatement = this.K.prepareStatement(str));
/*     */       return preparedStatement.executeUpdate();
/*     */     } catch (SQLException sQLException) {
/*     */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, StrUtil.qzlKeO("?P7P/P{古畄強幣"), sQLException);
/*     */     } finally {
/*     */       SqlManagerUtil.getInstance().xxxxXx(this.K, preparedStatement, null);
/*     */       XxxxXx(str, StrUtil.qzlKeO("Q>Y>A>\017{"));
/*     */     } 
/*     */     return 0;
/*     */   }
/*     */   
/*     */   public Page<T> page() {
/*     */     try {
/*     */       int i = ooOOOO(null, false);
/*     */       List<T> list = new ArrayList();
/*     */       if (i > 0)
/*     */         list = PPPPPp(false); 
/*     */       return new Page<>(i, list);
/*     */     } finally {
/*     */       SqlManagerUtil.getInstance().xxxxXx(this.K, null, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int insert(Object<String, Object> object) {
/*     */     PreparedStatement preparedStatement = null;
/*     */     ResultSet resultSet = null;
/*     */     try {
/*     */       String str = this.PppPPP.OoooOo();
/*     */       MessageUtil.sendConsoleDebugMessage((new StringBuilder()).insert(0, WarpTpPlayerService.qzlKeO("jEpNq_9\013")).append(str).toString());
/*     */       preparedStatement = this.K.prepareStatement(str, 1);
/*     */       Map map = (Map)this.PppPPP.I().values().stream().collect(Collectors.groupingBy(KcifTq::h, Collectors.collectingAndThen(Collectors.toList(), a -> (KcifTq)a.get(0))));
/*     */       Iterator<String> iterator = (object = (Object<String, Object>)BeanUtil.beanToMap(object)).keySet().iterator();
/*     */       while (true) {
/*     */         if (iterator.hasNext()) {
/*     */           String str1 = iterator.next();
/*     */           KcifTq kcifTq;
/*     */           if ((kcifTq = (KcifTq)map.get(str1)) == null);
/*     */           Object object1 = object.get(str1);
/*     */         } 
/*     */         break;
/*     */       } 
/*     */       int i = 0;
/*     */       resultSet = preparedStatement.getGeneratedKeys();
/*     */       preparedStatement.executeUpdate();
/*     */       if (resultSet.next())
/*     */         i = resultSet.getInt(1); 
/*     */       return i;
/*     */     } catch (SQLException sQLException) {
/*     */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, StrUtil.qzlKeO("2[(P)A{古畄強幣"), sQLException);
/*     */     } finally {
/*     */       SqlManagerUtil.getInstance().xxxxXx(this.K, preparedStatement, resultSet);
/*     */     } 
/*     */     return 0;
/*     */   }
/*     */   
/*     */   public int deleteById(Integer integer) {
/*     */     this.PppPPP.l(true, "id", oooOoO.k, integer);
/*     */     return delete();
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\DbExecution.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */