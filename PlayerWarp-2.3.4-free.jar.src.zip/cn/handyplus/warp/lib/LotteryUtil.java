/*   1 */ package cn.handyplus.warp.lib;public final class LotteryUtil { private final List<cn/handyplus/warp/lib/K> j; private double iiiIii; private static class cn/handyplus/warp/lib/K { private final double j; public cn/handyplus/warp/lib/K(double d1, double d2) { if (d1 > 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 201 */         d2)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 223 */         throw new IllegalArgumentException(WarpLikePlayerService.qzlKeO("单閖乢呪瑩ｮ\002\013\001'\003\007\002\007\001\026乢肟奈们\002\003\027'\003\007\002\007\001\026ｮ")); } 
/*     */       this.PpPPpp = d1;
/* 225 */       this.j = d2; } private final double PpPPpp; public boolean PpppPp(double d) { return (d > this.PpPPpp && d <= this.j); } } public int randomIndex() { byte b = -1; Random random; double d; if ((d = (random = new Random()).nextDouble() * this.iiiIii) == 0.0D)
/*     */       d = random.nextDouble() * this.iiiIii;  int i = this.j.size(); boolean bool; if ((bool = false) < i);
/*     */     if (b == -1)
/* 228 */       throw new IllegalArgumentException(WarpCollectionService.qzlKeO("槅玱隁吾诹罘乊吾瑁Ｗ")); 
/*     */     return b; }
/*     */ 
/*     */   
/*     */   public LotteryUtil(List list) {
/*     */     Iterator<Double> iterator;
/*     */     this;
/*     */     super();
/*     */     if (CollUtil.isNotEmpty(((LotteryUtil)new ArrayList()).j = (List<cn/handyplus/warp/lib/K>)this)) {
/*     */     
/*     */     } else {
/*     */       throw new IllegalArgumentException(SecureUtil.qzlKeO("抛奯雠吱丫胄东穃Ｇ"));
/*     */     } 
/*     */     if (list.hasNext()) {
/*     */       Double double_ = iterator.next();
/*     */       double d = this.iiiIii;
/*     */       this.iiiIii += double_.doubleValue();
/*     */     } 
/*     */   } }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\LotteryUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */