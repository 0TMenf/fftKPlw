package cn.handyplus.warp.lib;

@FunctionalInterface
public interface VoidFunc<P> {
  void call(P paramP) throws Exception;
}


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\VoidFunc.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */