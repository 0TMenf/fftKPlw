/*     */ package cn.handyplus.warp.lib;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import org.bukkit.Particle;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.attribute.Attribute;
/*     */ import org.bukkit.attribute.AttributeModifier;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public final class LegacyUtil {
/*     */   public static String getEnchantmentName(@NotNull Enchantment enchantment) {
/*  15 */     return enchantment.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class<?> K;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class<?> j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class<?> IiiIiI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getEntityTypeName(@NotNull EntityType entityType) {
/*  49 */     if (BaseConstants.VERSION_ID.intValue() > VersionCheckEnum.V_1_13_2.getVersionId().intValue())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 108 */       return entityType.getKey().getKey();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 172 */     return entityType.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Particle getDripLava() {
/*     */     if (BaseConstants.VERSION_ID.intValue() > VersionCheckEnum.V_1_20_4.getVersionId().intValue()) {
/*     */       return Particle.DRIPPING_LAVA;
/*     */     }
/* 193 */     return Particle.valueOf(HandyHttpUtil.qzlKeO("d\021i\023\017a\025a"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setMaxHealth(@NotNull LivingEntity livingEntity, double maxHealth) {
/*     */     livingEntity.setMaxHealth(maxHealth);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setGameRuleValue(@NotNull World world, @NotNull String ruleName, @NotNull Object value) {
/*     */     GameRuleUtil.setGameRuleValue(world, ruleName, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Enchantment getArrowDamage() {
/*     */     if (BaseConstants.VERSION_ID.intValue() > VersionCheckEnum.V_1_20_4.getVersionId().intValue()) {
/*     */       return Enchantment.POWER;
/*     */     }
/*     */     return getEnchantmentByName(HandyHttpUtil.qzlKeO("\002r\021o\024\007a\016a\004e"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getEnchantmentKey(@NotNull Enchantment enchantment) {
/*     */     if (BaseConstants.VERSION_ID.intValue() > VersionCheckEnum.V_1_12.getVersionId().intValue()) {
/*     */       return enchantment.getKey().getKey();
/*     */     }
/*     */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Particle getRedStone() {
/*     */     if (BaseConstants.VERSION_ID.intValue() > VersionCheckEnum.V_1_20_4.getVersionId().intValue()) {
/*     */       return Particle.DUST;
/*     */     }
/*     */     return Particle.valueOf(InventoryCheckParam.qzlKeO("\031G\017Q\037M\005G"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Enchantment getEnchantmentByName(@NotNull String name) {
/*     */     return Enchantment.getByName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Particle getFirework() {
/*     */     if (BaseConstants.VERSION_ID.intValue() > VersionCheckEnum.V_1_20_4.getVersionId().intValue()) {
/*     */       return Particle.FIREWORK;
/*     */     }
/*     */     return Particle.valueOf(InventoryCheckParam.qzlKeO("D\002P\016U\004P\000Q\024Q\033C\031I"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> getEntityTypeList() {
/*     */     if (BaseConstants.VERSION_ID.intValue() > VersionCheckEnum.V_1_13_2.getVersionId().intValue()) {
/* 489 */       return (List<String>)Arrays.<EntityType>stream(EntityType.values()).filter(a -> (a != EntityType.UNKNOWN)).map(a -> a.getKey().getKey()).collect(Collectors.toList());
/*     */     }
/*     */     return (List<String>)Arrays.<EntityType>stream(EntityType.values()).map(EntityType::getName).filter(Objects::nonNull).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Enchantment getDurability() {
/*     */     if (BaseConstants.VERSION_ID.intValue() > VersionCheckEnum.V_1_20_4.getVersionId().intValue()) {
/*     */       return Enchantment.UNBREAKING;
/*     */     }
/*     */     return getEnchantmentByName(InventoryCheckParam.qzlKeO("\017W\031C\tK\007K\037["));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> parseColor(@Nullable List<?> strList) {
/*     */     ArrayList<String> arrayList = new ArrayList();
/*     */     if (CollUtil.isEmpty(strList)) {
/*     */       return arrayList;
/*     */     }
/*     */     strList.forEach(str -> a.add(parseColor(str)));
/*     */     return arrayList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String parseColor(@Nullable String str) {
/*     */     if (StrUtil.isEmpty(str)) {
/*     */       return "";
/*     */     }
/*     */     String str1 = str.replace(InventoryCheckParam.qzlKeO("$"), HandyHttpUtil.qzlKeO(""));
/*     */     if (BaseConstants.VERSION_ID.intValue() < VersionCheckEnum.V_1_16.getVersionId().intValue()) {
/*     */       return str1;
/*     */     }
/*     */     return PpPPPp(str1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double getMaxHealth(@NotNull LivingEntity livingEntity) {
/*     */     return livingEntity.getMaxHealth();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> getEntityTypeAliveList() {
/*     */     // Byte code:
/*     */     //   0: new java/util/ArrayList
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: astore_0
/*     */     //   8: getstatic cn/handyplus/warp/lib/BaseConstants.VERSION_ID : Ljava/lang/Integer;
/*     */     //   11: invokevirtual intValue : ()I
/*     */     //   14: getstatic cn/handyplus/warp/lib/VersionCheckEnum.V_1_13_2 : Lcn/handyplus/warp/lib/VersionCheckEnum;
/*     */     //   17: invokevirtual getVersionId : ()Ljava/lang/Integer;
/*     */     //   20: invokevirtual intValue : ()I
/*     */     //   23: if_icmple -> 31
/*     */     //   26: iconst_1
/*     */     //   27: goto -> 32
/*     */     //   30: athrow
/*     */     //   31: iconst_0
/*     */     //   32: istore_1
/*     */     //   33: invokestatic values : ()[Lorg/bukkit/entity/EntityType;
/*     */     //   36: dup
/*     */     //   37: astore_2
/*     */     //   38: arraylength
/*     */     //   39: istore_3
/*     */     //   40: iconst_0
/*     */     //   41: dup
/*     */     //   42: istore #4
/*     */     //   44: iload_3
/*     */     //   45: if_icmpge -> 112
/*     */     //   48: aload_2
/*     */     //   49: iload #4
/*     */     //   51: aaload
/*     */     //   52: dup
/*     */     //   53: astore #5
/*     */     //   55: invokevirtual isAlive : ()Z
/*     */     //   58: ifeq -> 104
/*     */     //   61: aload #5
/*     */     //   63: invokevirtual isSpawnable : ()Z
/*     */     //   66: ifeq -> 104
/*     */     //   69: iload_1
/*     */     //   70: ifeq -> 92
/*     */     //   73: aload_0
/*     */     //   74: aload #5
/*     */     //   76: invokevirtual getKey : ()Lorg/bukkit/NamespacedKey;
/*     */     //   79: invokevirtual getKey : ()Ljava/lang/String;
/*     */     //   82: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   87: pop
/*     */     //   88: goto -> 104
/*     */     //   91: athrow
/*     */     //   92: aload_0
/*     */     //   93: aload #5
/*     */     //   95: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   98: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   103: pop
/*     */     //   104: iinc #4, 1
/*     */     //   107: iload #4
/*     */     //   109: goto -> 44
/*     */     //   112: aload_0
/*     */     //   113: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #334	-> 0
/*     */     //   #479	-> 8
/*     */     //   #769	-> 33
/*     */     //   #502	-> 55
/*     */     //   #423	-> 69
/*     */     //   #381	-> 73
/*     */     //   #672	-> 92
/*     */     //   #769	-> 104
/*     */     //   #340	-> 112
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PotionEffectType getPotionEffectTypeByName(@NotNull String name) {
/*     */     return PotionEffectType.getByName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PotionEffectType getIncreaseDamage() {
/*     */     if (BaseConstants.VERSION_ID.intValue() > VersionCheckEnum.V_1_20_4.getVersionId().intValue()) {
/*     */       return PotionEffectType.getByName(HandyHttpUtil.qzlKeO("0T1E-G7H"));
/*     */     }
/* 580 */     return PotionEffectType.getByName(InventoryCheckParam.qzlKeO("k%a9g*q.]/c&c,g"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Biome getBiome(@NotNull String name) throws Exception {
/*     */     Method method;
/*     */     if (K.isEnum()) {
/*     */       Biome biome;
/* 680 */       return (Biome)(biome = Enum.<Enum>valueOf((Class)K.asSubclass((Class)Enum.class), name));
/*     */     } 
/*     */     true;
/*     */     true[0] = String.class;
/*     */     true;
/*     */     true[0] = name;
/*     */     return (Biome)null.invoke(new Object[1], true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> getEnchantmentList() {
/*     */     return (List<String>)Arrays.<Enchantment>stream(Enchantment.values()).map(Enchantment::getName).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> getPotionEffectTypeList() {
/*     */     return (List<String>)Arrays.<PotionEffectType>stream(PotionEffectType.values()).map(PotionEffectType::getName).collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EntityType getEntityTypeByName(@NotNull String name) {
/*     */     return EntityType.fromName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Sound getSound(@NotNull String sound) throws Exception {
/*     */     Method method;
/*     */     if (j.isEnum()) {
/*     */       Sound sound1;
/*     */       return (Sound)(sound1 = Enum.<Enum>valueOf((Class)j.asSubclass((Class)Enum.class), sound.toUpperCase()));
/*     */     } 
/*     */     true;
/*     */     true[0] = String.class;
/* 723 */     true; true[0] = sound.toUpperCase(); return (Sound)null.invoke(new Object[1], true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initClasses() {
/*     */     try {
/*     */       j = Class.forName(HandyHttpUtil.qzlKeO(",R$\016!U(K*Tms,U-D"));
/*     */       if (BaseConstants.VERSION_ID.intValue() >= VersionCheckEnum.V_1_9.getVersionId().intValue()) {
/*     */         IiiIiI = Class.forName(InventoryCheckParam.qzlKeO("$p,,)w i\"vec?v9k)w?geC?v9k)w?g"));
/*     */       } else {
/*     */         IiiIiI = null;
/*     */       } 
/*     */       K = Class.forName(HandyHttpUtil.qzlKeO(",R$\016!U(K*TmB/O Kmb*O.E"));
/*     */       return;
/*     */     } catch (ClassNotFoundException classNotFoundException) {
/*     */       throw new RuntimeException(InventoryCheckParam.qzlKeO("既沞扼剻籹"), classNotFoundException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Attribute getAttribute(@NotNull String name) {
/*     */     if (IiiIiI == null)
/* 758 */       return null; 
/*     */     if (IiiIiI.isEnum())
/*     */       try {
/*     */         Attribute attribute;
/*     */         return (Attribute)(attribute = Enum.<Enum>valueOf((Class)IiiIiI.asSubclass((Class)Enum.class), name));
/*     */       } catch (IllegalArgumentException illegalArgumentException) {
/*     */         throw new RuntimeException((new StringBuilder()).insert(0, HandyHttpUtil.qzlKeO("沁杊扞剳皤尝怇y\000")).append(name).toString(), illegalArgumentException);
/*     */       }  
/*     */     try {
/*     */       Method method;
/*     */       true;
/*     */       true[0] = String.class;
/*     */       true;
/*     */       true[0] = name;
/*     */       return (Attribute)null.invoke(new Object[1], true);
/*     */     } catch (Exception exception) {
/*     */       throw new RuntimeException((new StringBuilder()).insert(0, HandyHttpUtil.qzlKeO("波朩戽刐尝怇y\000")).append(name).toString(), exception);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static AttributeModifier getAttributeModifier(@NotNull String name, double amount, @NotNull AttributeModifier.Operation operation, @NotNull EquipmentSlot a) {
/*     */     UUID uUID = UUID.randomUUID();
/*     */     if (BaseConstants.VERSION_ID.intValue() < VersionCheckEnum.V_1_21.getVersionId().intValue())
/*     */       return new AttributeModifier(uUID, name, amount, operation, a); 
/*     */     return new AttributeModifier(NamespacedKey.fromString(uUID.toString()), amount, operation, a.getGroup());
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\LegacyUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */