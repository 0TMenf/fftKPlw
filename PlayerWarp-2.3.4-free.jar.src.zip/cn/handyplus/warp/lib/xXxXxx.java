/*    */ package cn.handyplus.warp.lib;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class xXxXxx
/*    */ {
/*    */   public static final String S = "CREATE TABLE IF NOT EXISTS `%s` ( `id` INTEGER PRIMARY KEY AUTOINCREMENT);";
/*    */   public static final String Z = " ORDER BY RANDOM()";
/*    */   public static final String U = "INSERT INTO ";
/*    */   public static final String o = "ALTER TABLE %s ADD INDEX %s (%s);";
/*    */   public static final String t = " where 1 = 1";
/*    */   public static final String V = "'";
/*    */   public static final String q = ")";
/*    */   public static final String Y = "ALTER TABLE '%s' ADD '%s' %s(%s) %s;";
/*    */   public static final String T = "COUNT(*)";
/*    */   public static final String R = "id";
/*    */   public static final String O = " , ";
/*    */   public static final String W = " VALUES ";
/*    */   public static final String J = "UPDATE ";
/*    */   public static final String g = "`";
/*    */   public static final String d = "SHOW INDEX FROM %s;";
/*    */   public static final String M = "SELECT column_name FROM information_schema.COLUMNS WHERE table_name = '%s' AND table_schema = '%s';";
/*    */   public static final String l = " DEFAULT '%s'";
/*    */   public static final String i = " SET ";
/*    */   public static final String b = "?";
/*    */   public static final String A = " - ";
/*    */   public static final String G = " ORDER BY RAND()";
/*    */   public static final int B = 500;
/*    */   public static final String f = " AUTO_INCREMENT";
/* 65 */   public static final Integer I = Integer.valueOf(16383);
/*    */   public static final String k = " FROM ";
/*    */   public static final String E = "ALTER TABLE `%s` MODIFY `%s` %s(%s) %s;";
/*    */   public static final String c = "(";
/*    */   public static final String C = " COMMENT '%s'";
/*    */   public static final String F = "DELETE FROM ";
/*    */   public static final String h = "COUNT(DISTINCT `%s`)";
/*    */   public static final String m = "ALTER TABLE `%s` COMMENT '%s';";
/*    */   public static final String D = "%";
/*    */   public static final String e = "SELECT ";
/*    */   public static final String H = "CREATE TABLE IF NOT EXISTS `%s` (`id` INTEGER (11) AUTO_INCREMENT,PRIMARY KEY (`id`)) CHARACTER SET = utf8mb4 ENGINE=INNODB;";
/*    */   public static final String a = "PRAGMA table_info ( %s )";
/*    */   public static final String L = "NOT NULL";
/*    */   public static final String K = "ALTER TABLE `%s` ADD `%s` %s(%s) %s;";
/*    */   public static final String j = " = ";
/*    */   public static final String OOoooO = " + ";
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\xXxXxx.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */