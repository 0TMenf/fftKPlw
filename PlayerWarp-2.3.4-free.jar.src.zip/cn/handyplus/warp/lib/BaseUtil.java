/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import cn.handyplus.warp.service.WarpCollectionService;
/*     */ import java.io.File;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Level;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.OfflinePlayer;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.block.Biome;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BaseUtil
/*     */ {
/*     */   public static String getLangMsg(@Nullable String langKey, @Nullable Map<?, ?> replaceMap) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: ldc ''
/*     */     //   3: invokestatic getLangMsg : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   6: astore_2
/*     */     //   7: aload_1
/*     */     //   8: invokestatic isNotEmpty : (Ljava/util/Map;)Z
/*     */     //   11: ifeq -> 68
/*     */     //   14: aload_1
/*     */     //   15: invokeinterface keySet : ()Ljava/util/Set;
/*     */     //   20: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   25: dup
/*     */     //   26: astore_3
/*     */     //   27: invokeinterface hasNext : ()Z
/*     */     //   32: ifeq -> 68
/*     */     //   35: aload_3
/*     */     //   36: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   41: checkcast java/lang/String
/*     */     //   44: astore #4
/*     */     //   46: aload_2
/*     */     //   47: aload_1
/*     */     //   48: aload #4
/*     */     //   50: dup_x1
/*     */     //   51: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   56: checkcast java/lang/String
/*     */     //   59: invokestatic replace : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   62: astore_2
/*     */     //   63: aload_3
/*     */     //   64: goto -> 27
/*     */     //   67: athrow
/*     */     //   68: aload_2
/*     */     //   69: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #85	-> 0
/*     */     //   #73	-> 7
/*     */     //   #28	-> 14
/*     */     //   #226	-> 46
/*     */     //   #91	-> 64
/*     */     //   #213	-> 68
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	70	0	langKey	Ljava/lang/String;
/*     */     //   0	70	1	replaceMap	Ljava/util/Map;
/*     */   }
/*     */   
/*     */   public static Boolean isPlayer(@NotNull CommandSender sender) {
/*     */     return Boolean.valueOf(sender instanceof Player);
/*     */   }
/*     */   
/*     */   public static Optional<Player> getOnlinePlayer(@NotNull String playerName) {
/*     */     Player player;
/*  47 */     if ((player = Bukkit.getPlayerExact(playerName)) == null || 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 208 */       !player.isOnline())
/*     */       return Optional.empty(); 
/*     */     return Optional.of(player); }
/*     */   public static OfflinePlayer getOfflinePlayer(@NotNull String playerName) {
/*     */     return Bukkit.getOfflinePlayer(playerName);
/*     */   } public static String stripColor(@Nullable String str) {
/*     */     if (StrUtil.isEmpty(str))
/*     */       return ""; 
/*     */     if (supportsComponentApi())
/*     */       return ComponentUtil.stripColor(str); 
/*     */     return ChatColor.stripColor(LegacyUtil.parseColor(str));
/*     */   } @NotNull
/*     */   public static String getDisplayName(@Nullable ItemStack itemStack) { if (itemStack == null)
/*     */       itemStack = new ItemStack(Material.AIR); 
/*     */     ItemMeta itemMeta = ItemStackUtil.getItemMeta(itemStack);
/*     */     String str2 = itemStack.getType().name();
/*     */     if (itemMeta.hasDisplayName())
/*     */       return itemMeta.getDisplayName(); 
/*     */     if (BaseConstants.VERSION_ID.intValue() >= VersionCheckEnum.V_1_20_5.getVersionId().intValue() && itemMeta.hasItemName()) {
/* 227 */       return itemMeta.getItemName();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String str1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (StrUtil.isNotEmpty(str1 = TranslationUtil.getMaterialTranslation(str2))) {
/*     */       return str1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 360 */     if (!BaseConstants.ITEM_JSON_CACHE_MAP.isEmpty())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 591 */       if ((str1 = BaseConstants.ITEM_JSON_CACHE_MAP.get(str2)) != null) {
/*     */         return str1;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 617 */     if (!BaseConstants.CLOUD_ITEM_JSON_CACHE_MAP.isEmpty())
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       if (itemStack.getDurability() > 0)
/*     */       {
/*     */         if (StrUtil.isNotEmpty(str1 = BaseConstants.CLOUD_ITEM_JSON_CACHE_MAP.get((new StringBuilder()).insert(0, str2).append(WarpCollectionService.qzlKeO("i")).append(itemStack.getDurability()).toString())))
/*     */         {
/* 769 */           return str1; }  }  if ((str1 = BaseConstants.CLOUD_ITEM_JSON_CACHE_MAP.get(str2)) != null)
/* 770 */         return str1;  }  return str2; } public static void readJsonFileToJsonCacheMap(@NotNull File file) { try { Optional<String> optional; (optional = readJsonFile(file)).ifPresent(a -> BaseConstants.JSON_CACHE_MAP = JsonUtil.toMap(a)); return; } catch (Throwable throwable) {}
/*     */     MessageUtil.sendConsoleDebugMessage(NetUtil.qzlKeO("讋參\031a\025x^\003z\036弗幈")); }
/*     */ 
/*     */   
/*     */   public static OfflinePlayer getOfflinePlayer(@NotNull UUID playerUuid) {
/*     */     return Bukkit.getOfflinePlayer(playerUuid);
/*     */   }
/*     */   
/*     */   public static String getLangMsg(@Nullable String langKey, @Nullable String defaultMsg) {
/*     */     if (StrUtil.isEmpty(langKey))
/*     */       return defaultMsg; 
/*     */     FileConfiguration fileConfiguration;
/*     */     if ((fileConfiguration = BaseConstants.LANG_CONFIG) == null)
/*     */       return defaultMsg; 
/*     */     return fileConfiguration.getString(langKey, defaultMsg);
/*     */   }
/*     */   
/*     */   public static List<String> stripColor(@Nullable List<?> list) {
/*     */     // Byte code:
/*     */     //   0: new java/util/ArrayList
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: astore_1
/*     */     //   8: aload_0
/*     */     //   9: invokestatic isEmpty : (Ljava/util/Collection;)Z
/*     */     //   12: ifeq -> 18
/*     */     //   15: aload_1
/*     */     //   16: areturn
/*     */     //   17: athrow
/*     */     //   18: aload_0
/*     */     //   19: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   24: dup
/*     */     //   25: astore_2
/*     */     //   26: invokeinterface hasNext : ()Z
/*     */     //   31: ifeq -> 60
/*     */     //   34: aload_2
/*     */     //   35: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   40: checkcast java/lang/String
/*     */     //   43: astore_3
/*     */     //   44: aload_2
/*     */     //   45: aload_1
/*     */     //   46: aload_3
/*     */     //   47: invokestatic stripColor : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   50: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   55: pop
/*     */     //   56: goto -> 26
/*     */     //   59: athrow
/*     */     //   60: aload_1
/*     */     //   61: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #215	-> 0
/*     */     //   #141	-> 8
/*     */     //   #177	-> 15
/*     */     //   #99	-> 18
/*     */     //   #118	-> 45
/*     */     //   #27	-> 56
/*     */     //   #116	-> 60
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	62	0	list	Ljava/util/List;
/*     */   }
/*     */   
/*     */   public static Boolean isNotPlayer(@NotNull CommandSender sender) {
/*     */     return Boolean.valueOf(!isPlayer(sender).booleanValue());
/*     */   }
/*     */   
/*     */   public static String getLangMsg(@Nullable String langKey) {
/*     */     return getLangMsg(langKey, "");
/*     */   }
/*     */   
/*     */   public static Optional<Player> getOnlinePlayer(@NotNull UUID playerUuid) {
/*     */     Player player;
/*     */     if ((player = Bukkit.getPlayer(playerUuid)) == null || !player.isOnline())
/*     */       return Optional.empty(); 
/*     */     return Optional.of(player);
/*     */   }
/*     */   
/*     */   public static String headComponent(@Nullable String str, @Nullable String playerName) {
/*     */     if (StrUtil.isEmpty(str) || StrUtil.isEmpty(playerName) || !isLatestVersion())
/*     */       return str; 
/*     */     return StrUtil.replace(str, WarpCollectionService.qzlKeO("/S&R"), (new StringBuilder()).insert(0, NetUtil.qzlKeO(")\030p\021qJ")).append(playerName).append(WarpCollectionService.qzlKeO("\b")).toString());
/*     */   }
/*     */   
/*     */   public static int getTwoPluginVersion(@NotNull Plugin plugin) {
/*     */     return Integer.parseInt(plugin.getDescription().getVersion().split(WarpCollectionService.qzlKeO("\033\030"))[1]);
/*     */   }
/*     */   
/*     */   public static Optional<Biome> getBiome(@NotNull String biome) {
/*     */     try {
/*     */       return Optional.of(LegacyUtil.getBiome(biome));
/*     */     } catch (Exception exception) {}
/*     */     if (BaseConstants.DEBUG)
/*     */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, NetUtil.qzlKeO("\027p\004W\031z\035pP叄畯弗幈"), exception); 
/*     */     return Optional.empty();
/*     */   }
/*     */   
/*     */   public static Optional<EntityType> getEntityType(@NotNull String key) {
/*     */     try {
/*     */       return Optional.of(EntityType.valueOf(key.toUpperCase()));
/*     */     } catch (IllegalArgumentException illegalArgumentException) {
/*     */       return Optional.empty();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void sendTip(@NotNull CommandSender sender) {
/*     */     String str = BaseConstants.CONFIG.getString("signType", "mac");
/*     */     str = "mac".equalsIgnoreCase(str) ? NetUtil.getLocalMacAddress() : HandyHttpUtil.getIp();
/*     */     if (isPlayer(sender).booleanValue() && BaseConstants.VERSION_ID.intValue() >= VersionCheckEnum.V_1_15.getVersionId().intValue()) {
/*     */       RgbTextUtil rgbTextUtil = RgbTextUtil.init(str);
/*     */       String str1 = getLangMsg(WarpCollectionService.qzlKeO("$Y7O"), NetUtil.qzlKeO("VgP5P3HNVt烉凮好刣V--"));
/*     */       rgbTextUtil.send(sender);
/*     */       rgbTextUtil.addExtra(RgbTextUtil.init(str1).addClickCopyToClipboard(str));
/*     */     } 
/*     */     MessageUtil.sendMessage(sender, str);
/*     */   }
/*     */   
/*     */   public static Integer convertVersion(@NotNull String version) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: ldc 'N.I;-'
/*     */     //   3: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   6: ldc ''
/*     */     //   8: invokevirtual replaceAll : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   11: dup
/*     */     //   12: astore_1
/*     */     //   13: ldc '.'
/*     */     //   15: invokevirtual contains : (Ljava/lang/CharSequence;)Z
/*     */     //   18: ifne -> 30
/*     */     //   21: aload_1
/*     */     //   22: invokestatic parseInt : (Ljava/lang/String;)I
/*     */     //   25: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   28: areturn
/*     */     //   29: athrow
/*     */     //   30: new java/lang/StringBuilder
/*     */     //   33: dup
/*     */     //   34: invokespecial <init> : ()V
/*     */     //   37: astore_2
/*     */     //   38: aload_1
/*     */     //   39: ldc ''
/*     */     //   41: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   44: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
/*     */     //   47: dup
/*     */     //   48: astore_1
/*     */     //   49: arraylength
/*     */     //   50: istore_3
/*     */     //   51: iconst_0
/*     */     //   52: dup
/*     */     //   53: istore #4
/*     */     //   55: iload_3
/*     */     //   56: if_icmpge -> 99
/*     */     //   59: aload_1
/*     */     //   60: iload #4
/*     */     //   62: aaload
/*     */     //   63: dup
/*     */     //   64: astore #5
/*     */     //   66: invokevirtual length : ()I
/*     */     //   69: iconst_1
/*     */     //   70: if_icmpne -> 83
/*     */     //   73: aload_2
/*     */     //   74: ldc '@'
/*     */     //   76: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   79: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   82: pop
/*     */     //   83: aload_2
/*     */     //   84: iinc #4, 1
/*     */     //   87: aload #5
/*     */     //   89: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   92: pop
/*     */     //   93: iload #4
/*     */     //   95: goto -> 55
/*     */     //   98: athrow
/*     */     //   99: aload_2
/*     */     //   100: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   103: invokestatic parseInt : (Ljava/lang/String;)I
/*     */     //   106: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   109: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #394	-> 0
/*     */     //   #415	-> 13
/*     */     //   #610	-> 21
/*     */     //   #341	-> 30
/*     */     //   #663	-> 38
/*     */     //   #434	-> 48
/*     */     //   #507	-> 66
/*     */     //   #284	-> 73
/*     */     //   #757	-> 83
/*     */     //   #434	-> 92
/*     */     //   #616	-> 99
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	110	0	version	Ljava/lang/String;
/*     */   }
/*     */   
/*     */   public static String spriteComponent(@Nullable String str, @NotNull ItemStack itemStack) {
/*     */     if (StrUtil.isEmpty(str) || !isLatestVersion())
/*     */       return str; 
/*     */     String str1 = itemStack.getType().name().toLowerCase();
/*     */     if (itemStack.getType().isBlock())
/*     */       String str3 = (new StringBuilder()).insert(0, NetUtil.qzlKeO("Lf\000g\031a\025/\022y\037v\033fJw\034z\023~_")).append(str1).append(WarpCollectionService.qzlKeO("\b")).toString(); 
/*     */     String str2 = (new StringBuilder()).insert(0, NetUtil.qzlKeO("Lf\000g\031a\025/Rx\031{\025v\002t\026aJ|\004p\035fR/\031a\025x_")).append(str1).append(WarpCollectionService.qzlKeO("\b")).toString();
/*     */     return StrUtil.replace(str, NetUtil.qzlKeO("f\000g\031a\025"), str2);
/*     */   }
/*     */   
/*     */   public static void readJsonFileToItemJsonCacheMap(@NotNull File file) {
/*     */     Optional<String> optional;
/*     */     if ((optional = readJsonFile(file)).isPresent() && ((String)optional.get()).length() > 1)
/*     */       try {
/*     */         BaseConstants.ITEM_JSON_CACHE_MAP = JsonUtil.toMap(optional.get());
/*     */         return;
/*     */       } catch (Throwable throwable) {} 
/*     */   }
/*     */   
/*     */   public static boolean isHigherVersion() {
/*     */     return (supportsComponentApi() && BaseConstants.VERSION_ID.intValue() >= VersionCheckEnum.V_1_20_4.getVersionId().intValue());
/*     */   }
/*     */   
/*     */   public static boolean isLatestVersion() {
/*     */     return (supportsComponentApi() && BaseConstants.VERSION_ID.intValue() >= VersionCheckEnum.V_1_21_9.getVersionId().intValue());
/*     */   }
/*     */   
/*     */   public static Optional<String> readJsonFile(@NotNull File fileName) {
/*     */     // Byte code:
/*     */     //   0: new java/io/FileReader
/*     */     //   3: dup
/*     */     //   4: aload_0
/*     */     //   5: invokespecial <init> : (Ljava/io/File;)V
/*     */     //   8: astore_1
/*     */     //   9: new java/io/InputStreamReader
/*     */     //   12: dup
/*     */     //   13: aload_0
/*     */     //   14: invokevirtual toPath : ()Ljava/nio/file/Path;
/*     */     //   17: iconst_0
/*     */     //   18: anewarray java/nio/file/OpenOption
/*     */     //   21: iconst_1
/*     */     //   22: dup
/*     */     //   23: pop2
/*     */     //   24: invokestatic newInputStream : (Ljava/nio/file/Path;[Ljava/nio/file/OpenOption;)Ljava/io/InputStream;
/*     */     //   27: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
/*     */     //   30: invokespecial <init> : (Ljava/io/InputStream;Ljava/nio/charset/Charset;)V
/*     */     //   33: astore_2
/*     */     //   34: new java/lang/StringBuilder
/*     */     //   37: dup
/*     */     //   38: invokespecial <init> : ()V
/*     */     //   41: astore #4
/*     */     //   43: aload_2
/*     */     //   44: invokevirtual read : ()I
/*     */     //   47: dup
/*     */     //   48: istore_3
/*     */     //   49: iconst_m1
/*     */     //   50: if_icmpeq -> 66
/*     */     //   53: aload_2
/*     */     //   54: aload #4
/*     */     //   56: iload_3
/*     */     //   57: i2c
/*     */     //   58: invokevirtual append : (C)Ljava/lang/StringBuilder;
/*     */     //   61: pop
/*     */     //   62: goto -> 44
/*     */     //   65: athrow
/*     */     //   66: aload_1
/*     */     //   67: invokevirtual close : ()V
/*     */     //   70: aload #4
/*     */     //   72: aload_2
/*     */     //   73: invokevirtual close : ()V
/*     */     //   76: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   79: invokestatic of : (Ljava/lang/Object;)Ljava/util/Optional;
/*     */     //   82: areturn
/*     */     //   83: athrow
/*     */     //   84: astore_1
/*     */     //   85: getstatic cn/handyplus/warp/lib/InitApi.PLUGIN : Lorg/bukkit/plugin/java/JavaPlugin;
/*     */     //   88: invokevirtual getLogger : ()Ljava/util/logging/Logger;
/*     */     //   91: getstatic java/util/logging/Level.SEVERE : Ljava/util/logging/Level;
/*     */     //   94: ldc_w 'D"W#|4Y)p.Z"厖甩彅帎'
/*     */     //   97: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   100: aload_1
/*     */     //   101: invokevirtual log : (Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   104: invokestatic empty : ()Ljava/util/Optional;
/*     */     //   107: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #562	-> 0
/*     */     //   #764	-> 9
/*     */     //   #454	-> 34
/*     */     //   #414	-> 43
/*     */     //   #563	-> 54
/*     */     //   #504	-> 66
/*     */     //   #749	-> 72
/*     */     //   #258	-> 76
/*     */     //   #497	-> 84
/*     */     //   #366	-> 85
/*     */     //   #753	-> 104
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	108	0	fileName	Ljava/io/File;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   0	65	84	java/lang/Exception
/*     */     //   66	82	84	java/lang/Exception
/*     */   }
/*     */   
/*     */   public static boolean supportsComponentApi() {
/*     */     return ((HandySchedulerUtil.isFolia() || HandySchedulerUtil.isPaper()) && BaseConstants.VERSION_ID.intValue() >= VersionCheckEnum.V_1_16_5.getVersionId().intValue());
/*     */   }
/*     */   
/*     */   public static Optional<Sound> getSound(@NotNull String sound) {
/*     */     try {
/*     */       return Optional.of(LegacyUtil.getSound(sound));
/*     */     } catch (Exception exception) {}
/*     */     if (BaseConstants.DEBUG)
/*     */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, WarpCollectionService.qzlKeO("Q\"B\024Y2X#\026厖甩彅帎"), exception); 
/*     */     return Optional.empty();
/*     */   }
/*     */   
/*     */   public static int getFirstPluginVersion(@NotNull Plugin plugin) {
/*     */     return Integer.parseInt(plugin.getDescription().getVersion().split(NetUtil.qzlKeO("I^"))[0]);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\BaseUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */