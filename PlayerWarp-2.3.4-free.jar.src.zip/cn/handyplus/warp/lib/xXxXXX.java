/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.bukkit.Bukkit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class xXxXXX
/*     */ {
/*     */   public static void l(Runnable a, long l) {
/*  18 */     l = xxxxXx(l);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  52 */     Bukkit.getGlobalRegionScheduler().runDelayed(HandySchedulerUtil.PPpppp, scheduledTask -> a.run(), l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void PPpppP(HandyRunnable a, long l) {
/*     */     l = xxxxXx(l);
/*  87 */     a.setupTask(Bukkit.getAsyncScheduler().runDelayed(HandySchedulerUtil.PPpppp, scheduledTask -> a.run(), l * 50L, TimeUnit.MILLISECONDS));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void l(HandyRunnable a, long l) {
/*     */     l = xxxxXx(l);
/*     */     a.setupTask(Bukkit.getGlobalRegionScheduler().runDelayed(HandySchedulerUtil.PPpppp, scheduledTask -> a.run(), l));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void PPpPpP(HandyRunnable a, long l1, long l2) {
/*     */     l1 = xxxxXx(l1);
/* 167 */     a.setupTask(Bukkit.getAsyncScheduler().runAtFixedRate(HandySchedulerUtil.PPpppp, scheduledTask -> a.run(), l1 * 50L, l2 * 50L, TimeUnit.MILLISECONDS));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sZxJew() {
/*     */     Bukkit.getGlobalRegionScheduler().cancelTasks(HandySchedulerUtil.PPpppp);
/*     */     Bukkit.getAsyncScheduler().cancelTasks(HandySchedulerUtil.PPpppp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void l(HandyRunnable a, long l1, long l2) {
/*     */     l1 = xxxxXx(l1);
/* 225 */     a.setupTask(Bukkit.getGlobalRegionScheduler().runAtFixedRate(HandySchedulerUtil.PPpppp, scheduledTask -> a.run(), l1, l2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void XXXXXX(Runnable a, long l) {
/* 233 */     l = xxxxXx(l);
/*     */     Bukkit.getAsyncScheduler().runDelayed(HandySchedulerUtil.PPpppp, scheduledTask -> a.run(), l * 50L, TimeUnit.MILLISECONDS);
/*     */   }
/*     */   
/*     */   public static void l(Runnable a, long l1, long l2) {
/*     */     l1 = xxxxXx(l1);
/*     */     Bukkit.getAsyncScheduler().runAtFixedRate(HandySchedulerUtil.PPpppp, scheduledTask -> a.run(), l1 * 50L, l2 * 50L, TimeUnit.MILLISECONDS);
/*     */   }
/*     */   
/*     */   public static void oOOOOo(Runnable a) {
/*     */     Bukkit.getGlobalRegionScheduler().run(HandySchedulerUtil.PPpppp, scheduledTask -> a.run());
/*     */   }
/*     */   
/*     */   public static void l(Runnable a) {
/*     */     Bukkit.getAsyncScheduler().runNow(HandySchedulerUtil.PPpppp, scheduledTask -> a.run());
/*     */   }
/*     */   
/*     */   public static void IiiiIi(Runnable a, long l1, long l2) {
/*     */     l1 = xxxxXx(l1);
/*     */     Bukkit.getGlobalRegionScheduler().runAtFixedRate(HandySchedulerUtil.PPpppp, scheduledTask -> a.run(), l1, l2);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\xXxXXX.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */