/*     */ package cn.handyplus.warp.lib;public enum HookPluginEnum { FANCY_NPCS, SX_ATTRIBUTE, PLAYER_CHAT, ATTRIBUTE_SYSTEM, LUCK_PERMS, MMO_ITEMS, ITEMS_ADDER, CRAFT_ENGINE, OAUTH_LOGIN, PLACEHOLDER_API, PLAYER_TASK, ATTRIBUTE_PLUS, SUPER_TRAILS,
/*     */   Jobs,
/*     */   CITIZENS,
/*   4 */   VAULT(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), WORLD_EDIT(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), ADAPT(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), SAGA_LORE_STATS(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), Z_NPC_S_PLUS(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), COINS_ENGINE(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), PLAYER_TITLE(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), PLAYER_RACE(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), MY_PET(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), PLAYER_CURRENCY(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), DEEP_SEEK(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), PLAYER_INTENSIFY(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), PROTOCOL_LIB(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), MYTHIC_MOBS(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), AUTH_ME(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), PLAYER_POINTS(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), NBT_API(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), FANCY_HOLOGRAMS(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), ADYESHACH(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), GEMS_ECONOMY(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), DECENT_HOLOGRAMS(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), HOLOGRAPHIC_DISPLAYS(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), LIBS_DISGUISES(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), CUSTOM_FISHING(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), PLAYER_GUILD(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), SUPER_TRAILS_PRO(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), CMI(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), PLAYER_PARTICLES(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), MONSTER_API(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), PLAYER_SCOREBOARD(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), DISCORD_SRV(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), CAT_SEED_LOGIN(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), WORLD_BORDER(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), MONSTER_PLUS(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), MULTIVERSE_CORE(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), MYTHIC_LIB(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b")), MC_MMO(WarpLikePlayerService.qzlKeO("9\003\032\016\033"), WarpChannelService.qzlKeO("_o\\b]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\031\003\032\016\033$\016\013\003\027\035\007\"\021\b"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String IiiIii;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public String getName() {
/*  45 */     return this.IiiIii;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   HookPluginEnum(String str1, String str2, String str3) {
/*     */     this.IiiIii = str1;
/*     */     this.j = str2;
/*     */     this.L = str3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public String getFailMsg() {
/* 126 */     return this.L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 150 */     PLACEHOLDER_API = new HookPluginEnum(WarpChannelService.qzlKeO("yBhMlFfBmK{Qh^`"), 1, WarpLikePlayerService.qzlKeO("2\003\003\f\007\007\r\003\006\n\020.2&"), WarpChannelService.qzlKeO("~EoJkAaEjL|h^`]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\022\003\003\f\007\007\r\003\006\n\020.2&$\016\013\003\027\035\007\"\021\b"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     PLAYER_POINTS = new HookPluginEnum(WarpChannelService.qzlKeO("yBhWl\\v^fGgZz"), 2, WarpLikePlayerService.qzlKeO("2\003\003\026\007\0352\000\013\001\026\034"), WarpChannelService.qzlKeO("~EoPk[^FgGzZ]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\022\003\003\026\007\0352\000\013\001\026\034$\016\013\003\027\035\007\"\021\b"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 183 */     MYTHIC_MOBS = new HookPluginEnum(WarpChannelService.qzlKeO("dW}F`MvCfLz"), 3, WarpLikePlayerService.qzlKeO("/\026\026\007\013\f/\000\000\034"), WarpChannelService.qzlKeO("CPzAgJCFlZ]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("/\026\026\007\013\f/\000\000\034$\016\013\003\027\035\007\"\021\b"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     CITIZENS = new HookPluginEnum(WarpChannelService.qzlKeO("M`Z`Tl@z"), 4, WarpLikePlayerService.qzlKeO("!\006\026\006\030\n\f\034"), WarpChannelService.qzlKeO("M@z@tL`Z]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("!\006\026\006\030\n\f\034$\016\013\003\027\035\007\"\021\b"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ATTRIBUTE_PLUS = new HookPluginEnum(WarpChannelService.qzlKeO("O}Z{Gk[}Kv^e[z"), 5, WarpLikePlayerService.qzlKeO(".\026\033\020\006\000\032\026\n2\003\027\034"), WarpChannelService.qzlKeO("Hz]|@l\\zL^E{Z]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\016\026\033\020\006\000\032\026\n2\003\027\034$\016\013\003\027\035\007\"\021\b"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ATTRIBUTE_SYSTEM = new HookPluginEnum(WarpChannelService.qzlKeO("O}Z{Gk[}Kv]p]}Kd"), 6, WarpLikePlayerService.qzlKeO(".\026\033\020\006\000\032\026\n1\026\021\033\007\002"), WarpChannelService.qzlKeO("Hz]|@l\\zL]P}]kD]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\016\026\033\020\006\000\032\026\n1\026\021\033\007\002$\016\013\003\027\035\007\"\021\b"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     SX_ATTRIBUTE = new HookPluginEnum(WarpChannelService.qzlKeO("]qQhZ}\\`L|Zl"), 7, WarpLikePlayerService.qzlKeO("17O.\026\033\020\006\000\032\026\n"), WarpChannelService.qzlKeO("Zvhz]|@l\\zL]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\034\032.\026\033\020\006\000\032\026\n$\016\013\003\027\035\007\"\021\b"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     PLAYER_CURRENCY = new HookPluginEnum(WarpChannelService.qzlKeO("yBhWl\\vM|\\{KgMp"), 8, WarpLikePlayerService.qzlKeO("2\003\003\026\007\035!\032\020\035\007\001\001\026"), WarpChannelService.qzlKeO("~EoPk[M\\|[kGmP]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\022\003\003\026\007\035!\032\020\035\007\001\001\026$\016\013\003\027\035\007\"\021\b"));
/*     */     MMO_ITEMS = new HookPluginEnum(WarpChannelService.qzlKeO("dCfQ`ZlCz"), 9, WarpLikePlayerService.qzlKeO("/\"-&\026\n\017\034"), WarpChannelService.qzlKeO("cDa`zLcZ]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\017\002\r&\026\n\017\034$\016\013\003\027\035\007\"\021\b"));
/*     */     PLAYER_PARTICLES = new HookPluginEnum(WarpChannelService.qzlKeO("^eOpK{QyO{Z`MeKz"), 10, WarpLikePlayerService.qzlKeO("?\016\016\033\n\020?\003\035\026\006\001\003\007\034"), WarpChannelService.qzlKeO("YbHwL|yo[z@mEkZ]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\037\016\016\033\n\020?\003\035\026\006\001\003\007\034$\016\013\003\027\035\007\"\021\b"));
/*     */     SUPER_TRAILS = new HookPluginEnum(WarpChannelService.qzlKeO("]|^l\\vZ{O`Bz"), 11, WarpLikePlayerService.qzlKeO("<\027\037\007\0356\035\003\006\016\034"), WarpChannelService.qzlKeO("Z{Yk[Z[o@bZ]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\034\027\037\007\0356\035\003\006\016\034$\016\013\003\027\035\007\"\021\b"));
/*     */     SUPER_TRAILS_PRO = new HookPluginEnum(WarpChannelService.qzlKeO("]|^l\\vZ{O`BzQy\\f"), 12, WarpLikePlayerService.qzlKeO("1\032\022\n\020;\020\016\013\003\021?\020\000"), WarpChannelService.qzlKeO("Z{Yk[Z[o@bZ]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\034\027\037\007\0356\035\003\006\016\034$\016\013\003\027\035\007\"\021\b"));
/*     */     PLAYER_GUILD = new HookPluginEnum(WarpChannelService.qzlKeO("^eOpK{Qn[`Bm"), 13, WarpLikePlayerService.qzlKeO("?\016\016\033\n\020(\027\006\016\013"), WarpChannelService.qzlKeO("YbHwL|n{@bM]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\037\016\016\033\n\020(\027\006\016\013$\016\013\003\027\035\007\"\021\b"));
/*     */     MULTIVERSE_CORE = new HookPluginEnum(WarpChannelService.qzlKeO("d[eZ`Xl\\zKvMf\\l"), 14, WarpLikePlayerService.qzlKeO("\"\027\003\026\006\024\n\020\034\007B!\000\020\n"), WarpChannelService.qzlKeO("c\\b]g_k[}LMF|L]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\017\032\016\033\013\031\007\035\021\n!\000\020\n$\016\013\003\027\035\007\"\021\b"));
/*     */     WORLD_BORDER = new HookPluginEnum(WarpChannelService.qzlKeO("Yf\\eJvLf\\mK{"), 15, WarpLikePlayerService.qzlKeO("8\r\035\016\013 \000\020\013\007\035"), WarpChannelService.qzlKeO("^a[bMLF|Mk[]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\030\r\035\016\013 \000\020\013\007\035$\016\013\003\027\035\007\"\021\b"));
/*     */     PLAYER_TITLE = new HookPluginEnum(WarpChannelService.qzlKeO("^eOpK{Q}G}Bl"), 16, WarpLikePlayerService.qzlKeO("?\016\016\033\n\020;\013\033\016\n"), WarpChannelService.qzlKeO("YbHwL|}g]bL]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\037\016\016\033\n\020;\013\033\016\n$\016\013\003\027\035\007\"\021\b"));
/*     */     PLAYER_TASK = new HookPluginEnum(WarpChannelService.qzlKeO("yBhWl\\vZh]b"), 17, WarpLikePlayerService.qzlKeO("2\003\003\026\007\0356\016\021\004"), WarpChannelService.qzlKeO("~EoPk[ZH}B]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\022\003\003\026\007\0356\016\021\004$\016\013\003\027\035\007\"\021\b"));
/*     */     PLAYER_RACE = new HookPluginEnum(WarpChannelService.qzlKeO("yBhWl\\v\\hMl"), 18, WarpLikePlayerService.qzlKeO("2\003\003\026\007\0350\016\001\n"), WarpChannelService.qzlKeO("~EoPk[\\HmL]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\022\003\003\026\007\0350\016\001\n$\016\013\003\027\035\007\"\021\b"));
/*     */     WORLD_EDIT = new HookPluginEnum(WarpChannelService.qzlKeO("Yf\\eJvKmG}"), 19, WarpLikePlayerService.qzlKeO("8\r\035\016\013'\013\013\033"), WarpChannelService.qzlKeO("^a[bMKMg]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\030\r\035\016\013'\013\013\033$\016\013\003\027\035\007\"\021\b"));
/*     */     PLAYER_CHAT = new HookPluginEnum(WarpChannelService.qzlKeO("yBhWl\\vMaO}"), 20, WarpLikePlayerService.qzlKeO("2\003\003\026\007\035!\007\003\033"), WarpChannelService.qzlKeO("~EoPk[MAo]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\022\003\003\026\007\035!\007\003\033$\016\013\003\027\035\007\"\021\b"));
/*     */     ADAPT = new HookPluginEnum(WarpChannelService.qzlKeO("hJh^}"), 21, WarpLikePlayerService.qzlKeO(".\006\016\022\033"), WarpChannelService.qzlKeO("HjH~]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\016\006\016\022\033$\016\013\003\027\035\007\"\021\b"));
/*     */     MC_MMO = new HookPluginEnum(WarpChannelService.qzlKeO("CjQdCf"), 22, WarpLikePlayerService.qzlKeO("\002\001\"/ "), WarpChannelService.qzlKeO("DmdCf]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\002\001\"/ $\016\013\003\027\035\007\"\021\b"));
/*     */     Jobs = new HookPluginEnum(WarpChannelService.qzlKeO("DFlZ"), 23, WarpLikePlayerService.qzlKeO("(\000\000\034"), WarpChannelService.qzlKeO("dFlZ]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\b\000\000\034$\016\013\003\027\035\007\"\021\b"));
/*     */     ADYESHACH = new HookPluginEnum(WarpChannelService.qzlKeO("hJpKzFhMa"), 24, WarpLikePlayerService.qzlKeO(".\006\026\007\034\n\016\001\007"), WarpChannelService.qzlKeO("HjPkZfHmA]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\016\006\026\007\034\n\016\001\007$\016\013\003\027\035\007\"\021\b"));
/*     */     Z_NPC_S_PLUS = new HookPluginEnum(WarpChannelService.qzlKeO("Tv@yMv]v^e[z"), 25, WarpLikePlayerService.qzlKeO("5,?!\0342\003\027\034"), WarpChannelService.qzlKeO("S@yMZ^E{Z]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\025,?!\0342\003\027\034$\016\013\003\027\035\007\"\021\b"));
/*     */     FANCY_NPCS = new HookPluginEnum(WarpChannelService.qzlKeO("Hh@jWv@yMz"), 26, WarpLikePlayerService.qzlKeO(")\003\001\001\026,\037\001\034"), WarpChannelService.qzlKeO("OoGmP@YmZ]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\t\003\001\001\026,\037\001\034$\016\013\003\027\035\007\"\021\b"));
/*     */     NBT_API = new HookPluginEnum(WarpChannelService.qzlKeO("gL}Qh^`"), 27, WarpLikePlayerService.qzlKeO(",-6.2&"), WarpChannelService.qzlKeO("`Kzh~@]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\f\r\026.\022\006$\016\013\003\027\035\007\"\021\b"));
/*     */     PLAYER_INTENSIFY = new HookPluginEnum(WarpChannelService.qzlKeO("^eOpK{Q`@}Kg]`Hp"), 28, WarpLikePlayerService.qzlKeO("?\016\016\033\n\020&\f\033\007\001\021\006\004\026"), WarpChannelService.qzlKeO("YbHwL|``]kG}@hP]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\037\016\016\033\n\020&\f\033\007\001\021\006\004\026$\016\013\003\027\035\007\"\021\b"));
/*     */     LIBS_DISGUISES = new HookPluginEnum(WarpChannelService.qzlKeO("B`LzQmGzI|GzKz"), 29, WarpLikePlayerService.qzlKeO("#\013\r\021+\013\034\005\032\013\034\007\034"), WarpChannelService.qzlKeO("EgK}mgZi\\gZkZ]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\003\013\r\021+\013\034\005\032\013\034\007\034$\016\013\003\027\035\007\"\021\b"));
/*     */     MONSTER_PLUS = new HookPluginEnum(WarpChannelService.qzlKeO("Cf@zZl\\v^e[z"), 30, WarpLikePlayerService.qzlKeO("\"\r\001\021\033\007\0352\003\027\034"), WarpChannelService.qzlKeO("DaG}]k[^E{Z]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\002\r\001\021\033\007\0352\003\027\034$\016\013\003\027\035\007\"\021\b"));
/*     */     MY_PET = new HookPluginEnum(WarpChannelService.qzlKeO("CpQyK}"), 31, WarpLikePlayerService.qzlKeO("\"\033?\007\033"), WarpChannelService.qzlKeO("Dwyk]]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\002\033?\007\033$\016\013\003\027\035\007\"\021\b"));
/*     */     MYTHIC_LIB = new HookPluginEnum(WarpChannelService.qzlKeO("CpZaGjQeGk"), 32, WarpLikePlayerService.qzlKeO("\"\033\033\n\006\001#\013\r"), WarpChannelService.qzlKeO("Dw]f@megK]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\002\033\033\n\006\001#\013\r$\016\013\003\027\035\007\"\021\b"));
/*     */     SAGA_LORE_STATS = new HookPluginEnum(WarpChannelService.qzlKeO("zOnOvBf\\lQzZhZz"), 33, WarpLikePlayerService.qzlKeO("<\003\b\003#\r\035\007<\026\016\026\034"), WarpChannelService.qzlKeO("ZoNoea[kzzHzZ]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\034\003\b\003#\r\035\007<\026\016\026\034$\016\013\003\027\035\007\"\021\b"));
/*     */     AUTH_ME = new HookPluginEnum(WarpChannelService.qzlKeO("h[}FvCl"), 34, "AuthMe", WarpLikePlayerService.qzlKeO("\003\032\026\007/\n1\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("o\\zACLHHgE{[kd}N"));
/*     */     CAT_SEED_LOGIN = new HookPluginEnum(WarpLikePlayerService.qzlKeO("!.601*'+=#-(+!"), 35, "CatSeedLogin", WarpChannelService.qzlKeO("mHzzkLjeaNgG]\\mJkLjd}N"), WarpLikePlayerService.qzlKeO("\001\016\026<\007\n\006#\r\b\013\001$\016\013\003\027\035\007\"\021\b"));
/*     */     OAUTH_LOGIN = new HookPluginEnum(WarpChannelService.qzlKeO("fO|ZaQeAnGg"), 36, "OauthLogin", WarpLikePlayerService.qzlKeO("\r\016\027\033\n#\r\b\013\0011\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("aH{]feaNgGHHgE{[kd}N"));
/*     */     CUSTOM_FISHING = new HookPluginEnum(WarpLikePlayerService.qzlKeO("!:1;-\"=)+<*&,("), 37, WarpChannelService.qzlKeO("j{ZzFcogZf@`N"), WarpLikePlayerService.qzlKeO("\f\027\034\026\000\017)\013\034\n\006\f\b1\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("J{ZzFcogZf@`NHHgE{[kd}N"));
/*     */     LUCK_PERMS = new HookPluginEnum(WarpLikePlayerService.qzlKeO(".:!$=?'=/<"), 38, WarpChannelService.qzlKeO("e{Jeyk[cZ"), WarpLikePlayerService.qzlKeO("\003\027\f\t?\007\035\017\0341\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("E{Jeyk[cZHHgE{[kd}N"));
/*     */     CRAFT_ENGINE = new HookPluginEnum(WarpLikePlayerService.qzlKeO("!=#)60'!%&,*"), 39, WarpChannelService.qzlKeO("j|Hh]KGi@`L"), WarpLikePlayerService.qzlKeO("\f\020\016\004\033'\001\005\006\f\n1\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("J|Hh]KGi@`LHHgE{[kd}N"));
/*     */     DISCORD_SRV = new HookPluginEnum(WarpLikePlayerService.qzlKeO("++<! 0+=<09"), 40, WarpChannelService.qzlKeO("J@}Ja[jz\\"), WarpLikePlayerService.qzlKeO("\006\006\021\f\r\035\006<091\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("j@}Ja[jz\\HHgE{[kd}N"));
/*     */     DEEP_SEEK = new HookPluginEnum(WarpLikePlayerService.qzlKeO("+'*201*'$"), 41, WarpChannelService.qzlKeO("JLkY]LkB"), WarpLikePlayerService.qzlKeO("\006\n\007\0371\n\007\0041\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("jLkY]LkBHHgE{[kd}N"));
/*     */     DECENT_HOLOGRAMS = new HookPluginEnum(WarpLikePlayerService.qzlKeO("&*!*,;='-#-(0./<"), 42, WarpChannelService.qzlKeO("mkJkGzaaEaN|HcZ"), WarpLikePlayerService.qzlKeO("\013\007\f\007\001\026'\r\003\r\b\020\016\017\0341\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("MkJkGzaaEaN|HcZHHgE{[kd}N"));
/*     */     HOLOGRAPHIC_DISPLAYS = new HookPluginEnum(WarpLikePlayerService.qzlKeO("* . %=#?*&!0&&1?..;<"), 43, WarpChannelService.qzlKeO("aaEaN|H~AgJJ@}YbHwZ"), WarpLikePlayerService.qzlKeO("\007\r\003\r\b\020\016\022\007\013\f&\006\021\037\016\016\033\0341\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("AaEaN|H~AgJJ@}YbHwZHHgE{[kd}N"));
/*     */     CMI = new HookPluginEnum(WarpLikePlayerService.qzlKeO(",/&"), 44, WarpChannelService.qzlKeO("jC`"), WarpLikePlayerService.qzlKeO("\f\017\0061\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("Jc@HHgE{[kd}N"));
/*     */     FANCY_HOLOGRAMS = new HookPluginEnum(WarpLikePlayerService.qzlKeO(")#!!6='-#-(0./<"), 45, WarpChannelService.qzlKeO("HH`JwaaEaN|HcZ"), WarpLikePlayerService.qzlKeO("\004\016\f\f\033'\r\003\r\b\020\016\017\0341\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("hH`JwaaEaN|HcZHHgE{[kd}N"));
/*     */     MONSTER_API = new HookPluginEnum(WarpLikePlayerService.qzlKeO("\"-!1;'==.2&"), 46, WarpChannelService.qzlKeO("CF`ZzL|h^`"), WarpLikePlayerService.qzlKeO("\017\000\f\034\026\n\020.2&1\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("cF`ZzL|h^`HHgE{[kd}N"));
/*     */     GEMS_ECONOMY = new HookPluginEnum(WarpLikePlayerService.qzlKeO("%*/<=*! , /6"), 47, WarpChannelService.qzlKeO("nkD}lmF`FcP"), WarpLikePlayerService.qzlKeO("\b\007\002\021*\001\000\f\000\017\0261\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("NkD}lmF`FcPHHgE{[kd}N"));
/*     */     COINS_ENGINE = new HookPluginEnum(WarpLikePlayerService.qzlKeO("! +!10'!%&,*"), 48, WarpChannelService.qzlKeO("ja@`ZKGi@`L"), WarpLikePlayerService.qzlKeO("\f\r\006\f\034'\001\005\006\f\n1\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("Ja@`ZKGi@`LHHgE{[kd}N"));
/*     */     PROTOCOL_LIB = new HookPluginEnum(WarpLikePlayerService.qzlKeO("2=-;-,-#=#+-"), 49, WarpChannelService.qzlKeO("y|FzFmFbegK"), WarpLikePlayerService.qzlKeO("\037\020\000\026\000\001\000\016#\013\r1\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("Y|FzFmFbegKHHgE{[kd}N"));
/*     */     PLAYER_SCOREBOARD = new HookPluginEnum(WarpLikePlayerService.qzlKeO("?..;*001,-='--.0+"), 50, WarpChannelService.qzlKeO("^EoPk[]Ja[kKaH|M"), WarpLikePlayerService.qzlKeO("\022\003\003\026\007\0351\f\r\035\007\r\r\016\020\0131\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("~EoPk[]Ja[kKaH|MHHgE{[kd}N"));
/*     */     ITEMS_ADDER = new HookPluginEnum(WarpLikePlayerService.qzlKeO("&6*/<=.&+'="), 51, WarpChannelService.qzlKeO("G]kD}hjMk["), WarpLikePlayerService.qzlKeO("\013\033\007\002\021.\006\013\007\0351\032\001\f\007\n\006\"\021\b"), WarpChannelService.qzlKeO("g]kD}hjMk[HHgE{[kd}N"));
/*     */     K = oOOoOo();
/*     */   }
/*     */   
/*     */   @Generated
/*     */   public String getSuccessMsg() {
/*     */     return this.j;
/*     */   } }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\HookPluginEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */