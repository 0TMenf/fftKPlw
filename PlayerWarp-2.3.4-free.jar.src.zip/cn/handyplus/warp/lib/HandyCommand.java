package cn.handyplus.warp.lib;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.bukkit.permissions.PermissionDefault;

@Documented
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface HandyCommand {
  String[] aliases() default {""};
  
  PermissionDefault PERMISSION_DEFAULT() default PermissionDefault.OP;
  
  String description() default "";
  
  String permissionMessage() default "§4你没有权限执行该命令";
  
  String permission() default "";
  
  String name();
  
  String usage() default "";
}


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\HandyCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */