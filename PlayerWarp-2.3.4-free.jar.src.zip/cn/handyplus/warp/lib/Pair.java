/*    */ package cn.handyplus.warp.lib;public class Pair<K, V> {
/*    */   @Generated
/*    */   public V getValue() {
/*  4 */     return this.ppPPpp;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final K j;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final V ppPPpp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <K, V> Pair<K, V> of(Object a, Object object1) {
/* 76 */     return new Pair<>((K)a, (V)object1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Generated
/*    */   public K getKey() {
/* 95 */     return this.j;
/*    */   }
/*    */   
/*    */   public static String qzlKeO(String a) {
/*    */     // Byte code:
/*    */     //   0: iconst_4
/*    */     //   1: dup
/*    */     //   2: ishl
/*    */     //   3: iconst_3
/*    */     //   4: iconst_5
/*    */     //   5: ixor
/*    */     //   6: iconst_1
/*    */     //   7: ishl
/*    */     //   8: ixor
/*    */     //   9: iconst_3
/*    */     //   10: iconst_5
/*    */     //   11: ixor
/*    */     //   12: iconst_3
/*    */     //   13: ishl
/*    */     //   14: iconst_2
/*    */     //   15: ixor
/*    */     //   16: iconst_2
/*    */     //   17: iconst_5
/*    */     //   18: ixor
/*    */     //   19: iconst_4
/*    */     //   20: ishl
/*    */     //   21: iconst_4
/*    */     //   22: iconst_1
/*    */     //   23: ishl
/*    */     //   24: ixor
/*    */     //   25: aload_0
/*    */     //   26: checkcast java/lang/String
/*    */     //   29: dup
/*    */     //   30: astore_0
/*    */     //   31: invokevirtual length : ()I
/*    */     //   34: dup
/*    */     //   35: newarray char
/*    */     //   37: iconst_1
/*    */     //   38: dup
/*    */     //   39: pop2
/*    */     //   40: swap
/*    */     //   41: iconst_1
/*    */     //   42: isub
/*    */     //   43: dup_x2
/*    */     //   44: istore_3
/*    */     //   45: astore_1
/*    */     //   46: istore #4
/*    */     //   48: dup_x2
/*    */     //   49: pop2
/*    */     //   50: istore_2
/*    */     //   51: iflt -> 91
/*    */     //   54: aload_1
/*    */     //   55: aload_0
/*    */     //   56: iload_3
/*    */     //   57: dup_x1
/*    */     //   58: invokevirtual charAt : (I)C
/*    */     //   61: iinc #3, -1
/*    */     //   64: iload_2
/*    */     //   65: ixor
/*    */     //   66: i2c
/*    */     //   67: castore
/*    */     //   68: iload_3
/*    */     //   69: iflt -> 91
/*    */     //   72: aload_1
/*    */     //   73: aload_0
/*    */     //   74: iload_3
/*    */     //   75: iinc #3, -1
/*    */     //   78: dup_x1
/*    */     //   79: invokevirtual charAt : (I)C
/*    */     //   82: iload #4
/*    */     //   84: ixor
/*    */     //   85: i2c
/*    */     //   86: castore
/*    */     //   87: iload_3
/*    */     //   88: goto -> 51
/*    */     //   91: new java/lang/String
/*    */     //   94: dup
/*    */     //   95: aload_1
/*    */     //   96: invokespecial <init> : ([C)V
/*    */     //   99: areturn
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	100	0	a	Ljava/lang/String;
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\Pair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */