/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryType;
/*     */ import org.bukkit.inventory.InventoryHolder;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InventoryViewUtil
/*     */ {
/*     */   public static InventoryType getInventoryType(@NotNull Player player) {
/* 134 */     if (CompatCore.pppPPP) {
/*     */       return IIiIiI.XXXXXx(player);
/*     */     }
/*     */     return iiiIiI.XXXXXx(player);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_4
/*     */     //   1: dup
/*     */     //   2: ishl
/*     */     //   3: iconst_3
/*     */     //   4: ixor
/*     */     //   5: iconst_3
/*     */     //   6: iconst_5
/*     */     //   7: ixor
/*     */     //   8: iconst_4
/*     */     //   9: ishl
/*     */     //   10: iconst_4
/*     */     //   11: iconst_1
/*     */     //   12: ishl
/*     */     //   13: ixor
/*     */     //   14: iconst_3
/*     */     //   15: dup
/*     */     //   16: ishl
/*     */     //   17: iconst_4
/*     */     //   18: ixor
/*     */     //   19: aload_0
/*     */     //   20: checkcast java/lang/String
/*     */     //   23: dup
/*     */     //   24: astore_0
/*     */     //   25: invokevirtual length : ()I
/*     */     //   28: dup
/*     */     //   29: newarray char
/*     */     //   31: iconst_1
/*     */     //   32: dup
/*     */     //   33: pop2
/*     */     //   34: swap
/*     */     //   35: iconst_1
/*     */     //   36: isub
/*     */     //   37: dup_x2
/*     */     //   38: istore_3
/*     */     //   39: astore_1
/*     */     //   40: istore #4
/*     */     //   42: dup_x2
/*     */     //   43: pop
/*     */     //   44: istore_2
/*     */     //   45: pop
/*     */     //   46: iflt -> 86
/*     */     //   49: aload_1
/*     */     //   50: aload_0
/*     */     //   51: iload_3
/*     */     //   52: dup_x1
/*     */     //   53: invokevirtual charAt : (I)C
/*     */     //   56: iinc #3, -1
/*     */     //   59: iload_2
/*     */     //   60: ixor
/*     */     //   61: i2c
/*     */     //   62: castore
/*     */     //   63: iload_3
/*     */     //   64: iflt -> 86
/*     */     //   67: aload_1
/*     */     //   68: aload_0
/*     */     //   69: iload_3
/*     */     //   70: iinc #3, -1
/*     */     //   73: dup_x1
/*     */     //   74: invokevirtual charAt : (I)C
/*     */     //   77: iload #4
/*     */     //   79: ixor
/*     */     //   80: i2c
/*     */     //   81: castore
/*     */     //   82: iload_3
/*     */     //   83: goto -> 46
/*     */     //   86: new java/lang/String
/*     */     //   89: dup
/*     */     //   90: aload_1
/*     */     //   91: invokespecial <init> : ([C)V
/*     */     //   94: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	95	0	a	Ljava/lang/String;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InventoryHolder getInventoryHolder(@NotNull Player player) {
/* 209 */     if (CompatCore.pppPPP)
/*     */       return IIiIiI.IIIIIi(player); 
/*     */     return iiiIiI.IIIIIi(player);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\InventoryViewUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */