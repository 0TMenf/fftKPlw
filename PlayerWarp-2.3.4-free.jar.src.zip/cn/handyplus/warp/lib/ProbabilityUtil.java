/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ProbabilityUtil
/*     */ {
/*     */   private final Random xXXXXX;
/*     */   
/*     */   public static ProbabilityUtil getInstance() {
/*  35 */     return cn/handyplus/warp/lib/g.iIIiii();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean pickIndex(int a, int a) {
/*     */     // Byte code:
/*     */     //   0: iload_1
/*     */     //   1: iload_2
/*     */     //   2: if_icmplt -> 7
/*     */     //   5: iload_2
/*     */     //   6: istore_1
/*     */     //   7: iconst_2
/*     */     //   8: newarray int
/*     */     //   10: iconst_1
/*     */     //   11: dup
/*     */     //   12: pop2
/*     */     //   13: dup
/*     */     //   14: iconst_0
/*     */     //   15: iload_1
/*     */     //   16: iastore
/*     */     //   17: dup
/*     */     //   18: iconst_1
/*     */     //   19: iload_2
/*     */     //   20: iload_1
/*     */     //   21: isub
/*     */     //   22: iastore
/*     */     //   23: astore_1
/*     */     //   24: aload_0
/*     */     //   25: aload_1
/*     */     //   26: invokespecial iIIIiI : ([I)I
/*     */     //   29: ifne -> 35
/*     */     //   32: iconst_1
/*     */     //   33: ireturn
/*     */     //   34: athrow
/*     */     //   35: iconst_0
/*     */     //   36: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #86	-> 0
/*     */     //   #210	-> 5
/*     */     //   #228	-> 7
/*     */     //   #136	-> 24
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	37	0	a	Lcn/handyplus/warp/lib/ProbabilityUtil;
/*     */     //   0	37	1	a	I
/*     */     //   0	37	2	a	I
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class cn/handyplus/warp/lib/g
/*     */   {
/* 107 */     private static final ProbabilityUtil pPPppP = new ProbabilityUtil(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean pickIndex(double d) {
/* 134 */     if (d == 0.0D) {
/*     */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     BigDecimal bigDecimal = BigDecimal.ONE.divide(new BigDecimal(d + ""), RoundingMode.UP);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 170 */     return pickIndex(1, bigDecimal.intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean pickSyncIndex(int i, int j) {
/*     */     return pickIndex(i, j);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean pickSyncIndex(double d) {
/* 223 */     return pickIndex(d);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\ProbabilityUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */