/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import cn.handyplus.oauth.login.event.AuthPlayerLoginEvent;
/*     */ import cn.handyplus.oauth.login.event.AuthPlayerRegisterEvent;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OauthLoginEvnetListener
/*     */   implements Listener
/*     */ {
/*     */   @EventHandler
/*     */   public void onRegEvent(AuthPlayerRegisterEvent authPlayerRegisterEvent) {
/*  51 */     Bukkit.getServer().getPluginManager().callEvent(new HandyRegisterEvent(authPlayerRegisterEvent.getPlayer()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onLoginEvent(AuthPlayerLoginEvent authPlayerLoginEvent) {
/* 100 */     Bukkit.getServer().getPluginManager().callEvent(new HandyLoginEvent(authPlayerLoginEvent.getPlayer()));
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\OauthLoginEvnetListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */