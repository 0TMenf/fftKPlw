package cn.handyplus.warp.lib;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Documented
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface HandyListener {
  VersionCheckEnum version() default VersionCheckEnum.V_1_6;
}


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\HandyListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */