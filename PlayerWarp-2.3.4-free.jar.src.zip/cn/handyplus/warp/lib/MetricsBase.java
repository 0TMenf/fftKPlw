/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import cn.handyplus.warp.lib.charts.CustomChart;
/*     */ import cn.handyplus.warp.lib.json.JsonObjectBuilder;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MetricsBase
/*     */ {
/*     */   private final String I;
/*     */   private final boolean k;
/*     */   private final Supplier<Boolean> E;
/*     */   private static final String c = "https://bStats.org/api/v2/data/%s";
/*     */   private final boolean C;
/*     */   private final Consumer<String> F;
/*     */   private final Consumer<JsonObjectBuilder> h;
/*     */   public static final String METRICS_VERSION = "3.1.0";
/*     */   private final Set<CustomChart> m;
/*     */   private final Consumer<JsonObjectBuilder> D;
/*     */   private final boolean e;
/*     */   private final Consumer<Runnable> H;
/*     */   private final ScheduledExecutorService a;
/*     */   private final boolean L;
/*     */   private final int K;
/*     */   private final String j;
/*     */   private final BiConsumer<String, Throwable> XXxxxx;
/*     */   
/*     */   public void shutdown() {
/*  53 */     this.a.shutdown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCustomChart(CustomChart customChart) {
/*  63 */     this.m.add(customChart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MetricsBase(String str1, String str2, int i, int j, Consumer<JsonObjectBuilder> consumer1, Consumer<JsonObjectBuilder> consumer2, Consumer<Runnable> consumer, Supplier<Boolean> supplier, BiConsumer<String, Throwable> biConsumer, Consumer<String> consumer3, int k, int m, int n, int i1) {
/*     */     this;
/*     */     super();
/*     */     ScheduledThreadPoolExecutor scheduledThreadPoolExecutor = new ScheduledThreadPoolExecutor(1, a -> {
/*     */           (new Thread(a, Page.qzlKeO("A_WmW\016AFxQe@"))).setDaemon(true);
/*     */           return (ThreadFactory)new Thread(a, Page.qzlKeO("A_WmW\016AFxQe@"));
/*     */         });
/* 211 */     scheduledThreadPoolExecutor.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);
/*     */ 
/*     */     
/*     */     this.a = scheduledThreadPoolExecutor;
/*     */ 
/*     */     
/*     */     this.I = str1;
/*     */ 
/*     */     
/*     */     this.j = str2;
/*     */     
/* 222 */     this.K = i;
/*     */     this.L = j;
/*     */     this.h = consumer1;
/*     */     this.D = consumer2;
/*     */     this.H = consumer;
/*     */     this.E = supplier;
/*     */     this.XXxxxx = biConsumer;
/*     */     this.F = consumer3;
/*     */     this.e = k;
/*     */     this.C = m;
/*     */     this.k = n;
/*     */     if (i1 == 0)
/*     */       ooOoOO(); 
/*     */     if (j != 0)
/*     */       h(); 
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\MetricsBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */