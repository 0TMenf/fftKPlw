/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import cn.handyplus.warp.service.WarpLikePlayerService;
/*     */ import java.util.Iterator;
/*     */ import org.bukkit.configuration.ConfigurationSection;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HandyPermissionUtil
/*     */ {
/*     */   public static int getIntNumber(Player player, @NotNull FileConfiguration config, @NotNull String type) {
/*  44 */     return getDoubleNumber(player, config, type).intValue();
/*     */   }
/*     */   
/*     */   public static long getLongNumber(Player player, @NotNull FileConfiguration config, @NotNull String type) {
/*  48 */     return getDoubleNumber(player, config, type).longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getReverseIntNumber(Player player, @NotNull FileConfiguration config, @NotNull String type) {
/* 106 */     return getReverseDoubleNumber(player, config, type).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Double getReverseDoubleNumber(Player player, @NotNull FileConfiguration config, @NotNull String type) {
/* 121 */     return PPPPPP(player, config, type, Pair.qzlKeO("p"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Double getDoubleNumber(Player player, @NotNull FileConfiguration config, @NotNull String type) {
/* 142 */     return PPPPPP(player, config, type, WarpLikePlayerService.qzlKeO("Q"));
/*     */   } public static long getReverseLongNumber(Player player, @NotNull FileConfiguration config, @NotNull String type) {
/* 144 */     return getReverseDoubleNumber(player, config, type).longValue();
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\HandyPermissionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */