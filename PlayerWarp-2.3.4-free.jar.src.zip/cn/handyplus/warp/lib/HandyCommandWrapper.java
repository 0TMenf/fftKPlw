/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ public final class HandyCommandWrapper {
/*     */   public static boolean onCommand(CommandSender a, Command command, String str1, String[] arrayOfString, String str2) {
/*   5 */     return HandyCommandFactory.XXXxXx().XxXXXx(a, command, str1, arrayOfString, str2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initCommand(String a) {
/*     */     // Byte code:
/*     */     //   0: invokestatic getInstance : ()Lcn/handyplus/warp/lib/ClassUtil;
/*     */     //   3: aload_0
/*     */     //   4: ldc cn/handyplus/warp/lib/HandyCommand
/*     */     //   6: invokevirtual getClassByAnnotation : (Ljava/lang/String;Ljava/lang/Class;)Ljava/util/List;
/*     */     //   9: dup
/*     */     //   10: astore_1
/*     */     //   11: invokestatic isNotEmpty : (Ljava/util/Collection;)Z
/*     */     //   14: ifeq -> 222
/*     */     //   17: aload_1
/*     */     //   18: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   23: astore_2
/*     */     //   24: aload_2
/*     */     //   25: invokeinterface hasNext : ()Z
/*     */     //   30: ifeq -> 222
/*     */     //   33: aload_2
/*     */     //   34: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   39: checkcast java/lang/Class
/*     */     //   42: dup
/*     */     //   43: astore_3
/*     */     //   44: ldc cn/handyplus/warp/lib/HandyCommand
/*     */     //   46: invokevirtual getAnnotation : (Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
/*     */     //   49: checkcast cn/handyplus/warp/lib/HandyCommand
/*     */     //   52: dup
/*     */     //   53: astore #4
/*     */     //   55: invokeinterface name : ()Ljava/lang/String;
/*     */     //   60: invokestatic getPluginCommand : (Ljava/lang/String;)Lorg/bukkit/command/PluginCommand;
/*     */     //   63: dup
/*     */     //   64: astore #5
/*     */     //   66: ifnull -> 24
/*     */     //   69: aload_3
/*     */     //   70: invokevirtual newInstance : ()Ljava/lang/Object;
/*     */     //   73: dup
/*     */     //   74: astore #6
/*     */     //   76: instanceof org/bukkit/command/CommandExecutor
/*     */     //   79: ifeq -> 92
/*     */     //   82: aload #5
/*     */     //   84: aload #6
/*     */     //   86: checkcast org/bukkit/command/CommandExecutor
/*     */     //   89: invokevirtual setExecutor : (Lorg/bukkit/command/CommandExecutor;)V
/*     */     //   92: aload #6
/*     */     //   94: instanceof org/bukkit/command/TabExecutor
/*     */     //   97: ifeq -> 110
/*     */     //   100: aload #5
/*     */     //   102: aload #6
/*     */     //   104: checkcast org/bukkit/command/TabExecutor
/*     */     //   107: invokevirtual setTabCompleter : (Lorg/bukkit/command/TabCompleter;)V
/*     */     //   110: aload #4
/*     */     //   112: invokeinterface aliases : ()[Ljava/lang/String;
/*     */     //   117: arraylength
/*     */     //   118: ifle -> 137
/*     */     //   121: aload #5
/*     */     //   123: aload #4
/*     */     //   125: invokeinterface aliases : ()[Ljava/lang/String;
/*     */     //   130: invokestatic asList : ([Ljava/lang/Object;)Ljava/util/List;
/*     */     //   133: invokevirtual setAliases : (Ljava/util/List;)Lorg/bukkit/command/Command;
/*     */     //   136: pop
/*     */     //   137: aload #5
/*     */     //   139: aload #4
/*     */     //   141: invokeinterface description : ()Ljava/lang/String;
/*     */     //   146: invokevirtual setDescription : (Ljava/lang/String;)Lorg/bukkit/command/Command;
/*     */     //   149: aload #5
/*     */     //   151: aload #4
/*     */     //   153: invokeinterface usage : ()Ljava/lang/String;
/*     */     //   158: invokevirtual setUsage : (Ljava/lang/String;)Lorg/bukkit/command/Command;
/*     */     //   161: aload #5
/*     */     //   163: aload #4
/*     */     //   165: invokeinterface permissionMessage : ()Ljava/lang/String;
/*     */     //   170: invokevirtual setPermissionMessage : (Ljava/lang/String;)Lorg/bukkit/command/Command;
/*     */     //   173: pop
/*     */     //   174: pop2
/*     */     //   175: aload #4
/*     */     //   177: invokeinterface permission : ()Ljava/lang/String;
/*     */     //   182: invokestatic isNotEmpty : (Ljava/lang/CharSequence;)Z
/*     */     //   185: ifeq -> 24
/*     */     //   188: aload #5
/*     */     //   190: aload #4
/*     */     //   192: dup_x1
/*     */     //   193: invokeinterface permission : ()Ljava/lang/String;
/*     */     //   198: invokevirtual setPermission : (Ljava/lang/String;)V
/*     */     //   201: invokeinterface permission : ()Ljava/lang/String;
/*     */     //   206: aconst_null
/*     */     //   207: aload #4
/*     */     //   209: invokeinterface PERMISSION_DEFAULT : ()Lorg/bukkit/permissions/PermissionDefault;
/*     */     //   214: invokestatic registerPermission : (Ljava/lang/String;Ljava/lang/String;Lorg/bukkit/permissions/PermissionDefault;)Lorg/bukkit/permissions/Permission;
/*     */     //   217: pop
/*     */     //   218: goto -> 24
/*     */     //   221: athrow
/*     */     //   222: invokestatic getInstance : ()Lcn/handyplus/warp/lib/ClassUtil;
/*     */     //   225: aload_0
/*     */     //   226: ldc_w cn/handyplus/warp/lib/IHandyCommandEvent
/*     */     //   229: invokevirtual getClassByIsAssignableFrom : (Ljava/lang/String;Ljava/lang/Class;)Ljava/util/List;
/*     */     //   232: dup
/*     */     //   233: astore_2
/*     */     //   234: invokestatic isNotEmpty : (Ljava/util/Collection;)Z
/*     */     //   237: ifeq -> 305
/*     */     //   240: new java/util/ArrayList
/*     */     //   243: dup
/*     */     //   244: invokespecial <init> : ()V
/*     */     //   247: astore_3
/*     */     //   248: aload_2
/*     */     //   249: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   254: dup
/*     */     //   255: astore #4
/*     */     //   257: invokeinterface hasNext : ()Z
/*     */     //   262: ifeq -> 298
/*     */     //   265: aload #4
/*     */     //   267: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   272: checkcast java/lang/Class
/*     */     //   275: astore #5
/*     */     //   277: aload_3
/*     */     //   278: aload #5
/*     */     //   280: invokevirtual newInstance : ()Ljava/lang/Object;
/*     */     //   283: checkcast cn/handyplus/warp/lib/IHandyCommandEvent
/*     */     //   286: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   291: pop
/*     */     //   292: aload #4
/*     */     //   294: goto -> 257
/*     */     //   297: athrow
/*     */     //   298: invokestatic XXXxXx : ()Lcn/handyplus/warp/lib/HandyCommandFactory;
/*     */     //   301: aload_3
/*     */     //   302: invokevirtual IIIIII : (Ljava/util/List;)V
/*     */     //   305: invokestatic getInstance : ()Lcn/handyplus/warp/lib/ClassUtil;
/*     */     //   308: aload_0
/*     */     //   309: ldc cn/handyplus/warp/lib/HandySubCommand
/*     */     //   311: invokevirtual getMethodByAnnotation : (Ljava/lang/String;Ljava/lang/Class;)Ljava/util/Map;
/*     */     //   314: dup
/*     */     //   315: astore_3
/*     */     //   316: invokeinterface isEmpty : ()Z
/*     */     //   321: ifne -> 483
/*     */     //   324: new java/util/ArrayList
/*     */     //   327: dup
/*     */     //   328: invokespecial <init> : ()V
/*     */     //   331: astore #4
/*     */     //   333: aload_3
/*     */     //   334: invokeinterface keySet : ()Ljava/util/Set;
/*     */     //   339: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   344: astore #5
/*     */     //   346: aload #5
/*     */     //   348: invokeinterface hasNext : ()Z
/*     */     //   353: ifeq -> 427
/*     */     //   356: aload #5
/*     */     //   358: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   363: checkcast java/lang/Class
/*     */     //   366: astore #6
/*     */     //   368: aload_3
/*     */     //   369: aload #6
/*     */     //   371: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   376: checkcast java/util/List
/*     */     //   379: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   384: dup
/*     */     //   385: astore_2
/*     */     //   386: invokeinterface hasNext : ()Z
/*     */     //   391: ifeq -> 346
/*     */     //   394: aload_2
/*     */     //   395: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   400: checkcast java/lang/reflect/Method
/*     */     //   403: astore #7
/*     */     //   405: aload_2
/*     */     //   406: aload #4
/*     */     //   408: aload #6
/*     */     //   410: aload #7
/*     */     //   412: invokestatic ppPPPp : (Ljava/lang/Class;Ljava/lang/reflect/Method;)Lcn/handyplus/warp/lib/HandySubCommandParam;
/*     */     //   415: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   420: pop
/*     */     //   421: goto -> 386
/*     */     //   424: nop
/*     */     //   425: nop
/*     */     //   426: athrow
/*     */     //   427: aload #4
/*     */     //   429: invokeinterface stream : ()Ljava/util/stream/Stream;
/*     */     //   434: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */     //   439: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */     //   444: invokestatic toList : ()Ljava/util/stream/Collector;
/*     */     //   447: <illegal opcode> apply : ()Ljava/util/function/Function;
/*     */     //   452: invokestatic collectingAndThen : (Ljava/util/stream/Collector;Ljava/util/function/Function;)Ljava/util/stream/Collector;
/*     */     //   455: invokestatic groupingBy : (Ljava/util/function/Function;Ljava/util/stream/Collector;)Ljava/util/stream/Collector;
/*     */     //   458: invokestatic groupingBy : (Ljava/util/function/Function;Ljava/util/stream/Collector;)Ljava/util/stream/Collector;
/*     */     //   461: invokeinterface collect : (Ljava/util/stream/Collector;)Ljava/lang/Object;
/*     */     //   466: checkcast java/util/Map
/*     */     //   469: astore #5
/*     */     //   471: invokestatic XXXxXx : ()Lcn/handyplus/warp/lib/HandyCommandFactory;
/*     */     //   474: aload #5
/*     */     //   476: invokevirtual xxxXxx : (Ljava/util/Map;)V
/*     */     //   479: return
/*     */     //   480: astore_1
/*     */     //   481: aload_1
/*     */     //   482: athrow
/*     */     //   483: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #30	-> 0
/*     */     //   #31	-> 11
/*     */     //   #54	-> 17
/*     */     //   #64	-> 44
/*     */     //   #7	-> 55
/*     */     //   #86	-> 66
/*     */     //   #210	-> 69
/*     */     //   #186	-> 76
/*     */     //   #228	-> 82
/*     */     //   #109	-> 92
/*     */     //   #94	-> 100
/*     */     //   #48	-> 110
/*     */     //   #154	-> 121
/*     */     //   #58	-> 137
/*     */     //   #80	-> 149
/*     */     //   #1	-> 161
/*     */     //   #201	-> 175
/*     */     //   #223	-> 188
/*     */     //   #218	-> 201
/*     */     //   #137	-> 218
/*     */     //   #121	-> 222
/*     */     //   #225	-> 234
/*     */     //   #191	-> 240
/*     */     //   #166	-> 248
/*     */     //   #152	-> 277
/*     */     //   #47	-> 294
/*     */     //   #208	-> 298
/*     */     //   #192	-> 305
/*     */     //   #220	-> 316
/*     */     //   #56	-> 324
/*     */     //   #190	-> 333
/*     */     //   #8	-> 368
/*     */     //   #106	-> 406
/*     */     //   #145	-> 421
/*     */     //   #59	-> 424
/*     */     //   #174	-> 427
/*     */     //   #81	-> 471
/*     */     //   #55	-> 479
/*     */     //   #233	-> 483
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	484	0	a	Ljava/lang/String;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   0	221	480	java/lang/Throwable
/*     */     //   222	297	480	java/lang/Throwable
/*     */     //   298	424	480	java/lang/Throwable
/*     */     //   427	479	480	java/lang/Throwable
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void injectCommand(List a) {
/*     */     try {
/*     */       Field field;
/*  53 */       (field = Bukkit.getServer().getClass().getDeclaredField(BcUtil.qzlKeO("\033$\025&\031%\034\006\031;"))).setAccessible(true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 155 */       CommandMap commandMap = (CommandMap)(field = Bukkit.getServer().getClass().getDeclaredField(BcUtil.qzlKeO("\033$\025&\031%\034\006\031;"))).get(Bukkit.getServer());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       for (String str : a) {
/* 204 */         s s = new s(str);
/*     */         commandMap.register(InitApi.PLUGIN.getDescription().getName(), s);
/*     */       } 
/*     */     } catch (Throwable throwable) {
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean onSubCommand(String a, CommandSender commandSender, Command command, String str1, String[] arrayOfString, String str2) {
/*     */     return HandyCommandFactory.XXXxXx().PpPPPp(a, commandSender, command, str1, arrayOfString, str2);
/*     */   }
/*     */   
/*     */   public static void injectCommand(String a) {
/*     */     injectCommand(Collections.singletonList(a));
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\HandyCommandWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */