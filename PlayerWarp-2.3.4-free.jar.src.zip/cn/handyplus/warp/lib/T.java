package cn.handyplus.warp.lib;

import com.google.gson.reflect.TypeToken;
import java.util.Map;

public class T extends TypeToken<Map<String, String>> {}


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\T.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */