package cn.handyplus.warp.lib;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
public @interface TableField {
  int length() default 0;
  
  boolean notNull() default false;
  
  IndexEnum indexEnum() default IndexEnum.NOT;
  
  String fieldDefault() default "";
  
  String comment() default "";
  
  String value();
}


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\TableField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */