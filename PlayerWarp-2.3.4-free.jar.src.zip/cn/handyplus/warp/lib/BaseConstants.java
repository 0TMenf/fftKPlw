/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ 
/*     */ public final class BaseConstants {
/*     */   public static final String POINT = ".";
/*   9 */   public static Map<String, String> JSON_CACHE_MAP = new HashMap<>();
/*     */   
/*     */   public static final int DROP_ITEM_BATCH_SIZE = 64;
/*     */   
/*     */   public static FileConfiguration STORAGE_CONFIG;
/*     */   
/*     */   public static final String SIGN_TYPE = "signType";
/*     */   
/*     */   public static final String PREVIOUS_PAGE = "previousPage";
/*     */   
/*     */   public static final String COLON = ":";
/*     */   
/*     */   public static boolean DEBUG;
/*     */   
/*     */   public static Map<String, String> CLOUD_ITEM_JSON_CACHE_MAP;
/*     */   
/*     */   public static FileConfiguration LANG_CONFIG;
/*     */   
/*     */   public static final int GUI_SIZE_54 = 54;
/*     */   
/*     */   public static final int DEFAULT_DIV_SCALE = 2;
/*     */   
/*     */   public static final int GUI_SIZE_27 = 27;
/*     */   
/*     */   public static Integer VERSION_ID;
/*     */   
/*     */   public static boolean IS_CHECK_UPDATE_TO_OP_MSG;
/*     */   
/*     */   public static boolean IS_CHECK_UPDATE;
/*     */   public static final String CLASS = "class";
/*     */   public static FileConfiguration CONFIG;
/*     */   public static final String NEXT_PAGE = "nextPage";
/*     */   public static final int DROP_ITEM_BATCH_THRESHOLD = 300;
/*     */   
/*     */   static {
/*  44 */     CLOUD_ITEM_JSON_CACHE_MAP = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 218 */     DEBUG = false;
/*     */     WARN = false;
/*     */     IS_CHECK_UPDATE = false;
/*     */     IS_CHECK_UPDATE_TO_OP_MSG = false;
/*     */   }
/*     */   
/*     */   public static Map<String, String> ITEM_JSON_CACHE_MAP = new HashMap<>();
/*     */   public static final String MAC = "mac";
/*     */   public static VersionCheckEnum VERSION_CHECK_ENUM;
/*     */   public static boolean WARN;
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\BaseConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */