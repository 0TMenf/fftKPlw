/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import java.util.Map;
/*     */ import lombok.Generated;
/*     */ import org.bukkit.attribute.Attribute;
/*     */ import org.bukkit.attribute.AttributeModifier;
/*     */ import org.bukkit.inventory.EquipmentSlot;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum AttributeCompatEnum
/*     */ {
/*     */   FOLLOW_RANGE,
/*     */   ATTACK_SPEED,
/*     */   MOVEMENT_EFFICIENCY,
/*     */   EXPLOSION_KNOCKBACK_RESISTANCE,
/*     */   KNOCKBACK_RESISTANCE,
/*     */   GRAVITY,
/*     */   FALL_DAMAGE_MULTIPLIER,
/*     */   MINING_EFFICIENCY,
/*     */   BURNING_TIME,
/*     */   WATER_MOVEMENT_EFFICIENCY,
/*     */   SAFE_FALL_DISTANCE,
/*     */   FLYING_SPEED,
/*     */   ARMOR_TOUGHNESS,
/*     */   SWEEPING_DAMAGE_RATIO,
/*     */   WAYPOINT_TRANSMIT_RANGE,
/*     */   STEP_HEIGHT,
/*     */   SCALE,
/*     */   JUMP_STRENGTH,
/* 101 */   MAX_HEALTH(Pair.qzlKeO("5\r \0230\t9\000,\004"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7T-]$H "), Pair.qzlKeO("畓爑盈杸奫蠸醃")), OXYGEN_BONUS(Pair.qzlKeO("5\r \0230\t9\000,\004"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7T-]$H "), Pair.qzlKeO("畓爑盈杸奫蠸醃")), WAYPOINT_RECEIVE_RANGE(Pair.qzlKeO("5\r \0230\t9\000,\004"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7T-]$H "), Pair.qzlKeO("畓爑盈杸奫蠸醃")), MOVEMENT_SPEED(Pair.qzlKeO("5\r \0230\t9\000,\004"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7T-]$H "), Pair.qzlKeO("畓爑盈杸奫蠸醃")), ATTACK_DAMAGE(Pair.qzlKeO("5\r \0230\t9\000,\004"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7T-]$H "), Pair.qzlKeO("畓爑盈杸奫蠸醃")), MAX_ABSORPTION(Pair.qzlKeO("5\r \0230\t9\000,\004"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7T-]$H "), Pair.qzlKeO("畓爑盈杸奫蠸醃")), ATTACK_KNOCKBACK(Pair.qzlKeO("5\r \0230\t9\000,\004"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7T-]$H "), Pair.qzlKeO("畓爑盈杸奫蠸醃")), ENTITY_INTERACTION_RANGE(Pair.qzlKeO("5\r \0230\t9\000,\004"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7T-]$H "), Pair.qzlKeO("畓爑盈杸奫蠸醃")), BLOCK_BREAK_SPEED(Pair.qzlKeO("5\r \0230\t9\000,\004"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7T-]$H "), Pair.qzlKeO("畓爑盈杸奫蠸醃")), ARMOR(Pair.qzlKeO("5\r \0230\t9\000,\004"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7T-]$H "), Pair.qzlKeO("畓爑盈杸奫蠸醃")), SNEAKING_SPEED(Pair.qzlKeO("5\r \0230\t9\000,\004"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7T-]$H "), Pair.qzlKeO("畓爑盈杸奫蠸醃")), SUBMERGED_MINING_SPEED(Pair.qzlKeO("5\r \0230\t9\000,\004"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7T-]$H "), Pair.qzlKeO("畓爑盈杸奫蠸醃")), TEMPT_RANGE(Pair.qzlKeO("5\r \0230\t9\000,\004"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7T-]$H "), Pair.qzlKeO("畓爑盈杸奫蠸醃")), BLOCK_INTERACTION_RANGE(Pair.qzlKeO("5\r \0230\t9\000,\004"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7T-]$H "), Pair.qzlKeO("畓爑盈杸奫蠸醃")), SPAWN_REINFORCEMENTS(Pair.qzlKeO("5\r \0230\t9\000,\004"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7T-]$H "), Pair.qzlKeO("畓爑盈杸奫蠸醃")), LUCK(Pair.qzlKeO("5\r \0230\t9\000,\004"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7T-]$H "), Pair.qzlKeO("畓爑盈杸奫蠸醃"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String K;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String IIIIii;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*     */     FOLLOW_RANGE = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("Z'P$S?C:]&[-"), 1, Pair.qzlKeO(">\0034\0007\033'\0369\002?\t"), InventoryViewUtil.qzlKeO("[-R-N!_7Z'P$S?C:]&[-"), Pair.qzlKeO("弟乸书畧爥欛坤趧雃儎亚畧爥W件盼斺偡盈趧雃荻嚸"));
/* 134 */     KNOCKBACK_RESISTANCE = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("W&S+W*]+W7N-O!O<]&_-"), 2, Pair.qzlKeO("3\0027\0173\0169\0173\023*\t+\005+\0309\002;\t"), InventoryViewUtil.qzlKeO("[-R-N!_7W&S+W*]+W7N-O!O<]&_-"), Pair.qzlKeO("弫畓爑裧敃冷盼斺偡盈冃遌拯恫"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MOVEMENT_SPEED = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("Q'J-Q-R<C;L-Y,"), 3, Pair.qzlKeO("5\003.\t5\t6\030'\037(\t=\b"), InventoryViewUtil.qzlKeO("[-R-N!_7Q'J-Q-R<C;L-Y,"), Pair.qzlKeO("畓爑盈禃勤遧廪"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     FLYING_SPEED = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("Z$E!R/C;L-Y,"), 4, Pair.qzlKeO(">\000!\0056\013'\037(\t=\b"), InventoryViewUtil.qzlKeO("[-R-N!_7Z$E!R/C;L-Y,"), Pair.qzlKeO("寒伫盈颦蠀遧廪"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ATTACK_DAMAGE = new AttributeCompatEnum(InventoryViewUtil.qzlKeO(")H<]+W7X)Q)[-"), 5, Pair.qzlKeO("\r,\0309\0173\023<\r5\r?\t"), InventoryViewUtil.qzlKeO("/Y&Y:U+C)H<]+W7X)Q)[-"), Pair.qzlKeO("弟畧爥敃冷儎亚畧爥W寒伫斺戸遬扨盈作寿"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 170 */     ATTACK_KNOCKBACK = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("]<H)_#C#R'_#^)_#"), 6, Pair.qzlKeO("9\030,\r;\007'\0076\003;\007:\r;\007"), InventoryViewUtil.qzlKeO("[-R-N!_7]<H)_#C#R'_#^)_#"), Pair.qzlKeO("畓爑盈敃冷冃遌勣廪"));
/*     */ 
/*     */ 
/*     */     
/*     */     ATTACK_SPEED = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("]<H)_#C;L-Y,"), 7, Pair.qzlKeO("9\030,\r;\007'\037(\t=\b"), InventoryViewUtil.qzlKeO("[-R-N!_7]<H)_#C;L-Y,"), Pair.qzlKeO("畓爑盈敃冷遧珋"));
/*     */ 
/*     */ 
/*     */     
/*     */     ARMOR = new AttributeCompatEnum(InventoryViewUtil.qzlKeO(")N%S:"), 8, Pair.qzlKeO("\r*\0017\036"), InventoryViewUtil.qzlKeO("/Y&Y:U+C)N%S:"), Pair.qzlKeO("拜畾盼陾忙偰"));
/*     */ 
/*     */ 
/*     */     
/*     */     ARMOR_TOUGHNESS = new AttributeCompatEnum(InventoryViewUtil.qzlKeO(")N%S:C<S=[ R-O;"), 9, Pair.qzlKeO("\r*\0017\036'\0307\031?\0046\t+\037"), InventoryViewUtil.qzlKeO("/Y&Y:U+C)N%S:C<S=[ R-O;"), Pair.qzlKeO("拨畊盈鞟恫"));
/*     */ 
/*     */ 
/*     */     
/*     */     FALL_DAMAGE_MULTIPLIER = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("Z)P$C,]%]/Y7Q=P<U8P!Y:"), 10, Pair.qzlKeO(">\r4\000'\b9\0019\013=\0235\0314\0301\0344\005=\036"), InventoryViewUtil.qzlKeO("[-R-N!_7Z)P$C,]%]/Y7Q=P<U8P!Y:"), Pair.qzlKeO("實伟盼圬葅佨寋偁壦嘤"));
/*     */ 
/*     */     
/*     */     LUCK = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("P=_#"), 11, Pair.qzlKeO("4\031;\007"), InventoryViewUtil.qzlKeO("[-R-N!_7P=_#"), Pair.qzlKeO("畓爑盈厗肱盼揅葅爥"));
/*     */ 
/*     */     
/*     */     MAX_ABSORPTION = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("Q)D7]*O'N8H!S&"), 12, Pair.qzlKeO("5\r \0239\016+\003*\034,\0057\002"), InventoryViewUtil.qzlKeO("[-R-N!_7Q)D7]*O'N8H!S&"), Pair.qzlKeO("寒伫盈杸奫呀敺偄ｄ匋拨畊呴敎ｅ"));
/*     */ 
/*     */     
/*     */     SAFE_FALL_DISTANCE = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("O)Z-C.]$P7X!O<]&_-"), 13, Pair.qzlKeO("+\r>\t'\n9\0004\023<\005+\0309\002;\t"), InventoryViewUtil.qzlKeO("[-R-N!_7O)Z-C.]$P7X!O<]&_-"), Pair.qzlKeO("實伟厗亩團葱聴乁厯佨寋盈骠廪"));
/*     */ 
/*     */     
/*     */     SCALE = new AttributeCompatEnum(InventoryViewUtil.qzlKeO(";_)P-"), 14, Pair.qzlKeO("\037;\r4\t"), InventoryViewUtil.qzlKeO("/Y&Y:U+C;_)P-"), Pair.qzlKeO("寒伫盈皀宵奟屃"));
/*     */ 
/*     */     
/*     */     STEP_HEIGHT = new AttributeCompatEnum(InventoryViewUtil.qzlKeO(";H-L7T-U/T<"), 15, Pair.qzlKeO("\037,\t(\0230\t1\0130\030"), InventoryViewUtil.qzlKeO("/Y&Y:U+C;H-L7T-U/T<"), Pair.qzlKeO("寒伫厣亝趤跲盈骠廪"));
/*     */ 
/*     */     
/*     */     GRAVITY = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("/N)J!H1"), 16, Pair.qzlKeO("\013*\r.\005,\025"), InventoryViewUtil.qzlKeO("/Y&Y:U+C/N)J!H1"), Pair.qzlKeO("旱勘坤實伟乲盈醵勗"));
/*     */ 
/*     */     
/*     */     JUMP_STRENGTH = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("\"I%L7O<N-R/H "), 17, Pair.qzlKeO("\006-\001(\023+\030*\t6\013,\004"), InventoryViewUtil.qzlKeO("/Y&Y:U+C\"I%L7O<N-R/H "), Pair.qzlKeO("寒伫趿趻盈勣醃"));
/*     */ 
/*     */     
/* 210 */     BURNING_TIME = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("^=N&U&[7H!Q-"), 18, Pair.qzlKeO(":\031*\0021\002?\023,\0055\t"), InventoryViewUtil.qzlKeO("[-R-N!_7^=N&U&[7H!Q-"), Pair.qzlKeO("寒伫坤眸瀧呶侑捹熏炟盈斎閸"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     EXPLOSION_KNOCKBACK_RESISTANCE = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("Y0L$S;U'R7W&S+W*]+W7N-O!O<]&_-"), 19, Pair.qzlKeO("=\024(\0007\0371\0036\0233\0027\0173\0169\0173\023*\t+\005+\0309\002;\t"), InventoryViewUtil.qzlKeO("[-R-N!_7Y0L$S;U'R7W&S+W*]+W7N-O!O<]&_-"), Pair.qzlKeO("宵牾烴遘扜盼冷選盈拯恫"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     MOVEMENT_EFFICIENCY = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("%S>Y%Y&H7Y.Z!_!Y&_1"), 20, Pair.qzlKeO("\0017\032=\001=\002,\023=\n>\005;\005=\002;\025"), InventoryViewUtil.qzlKeO("/Y&Y:U+C%S>Y%Y&H7Y.Z!_!Y&_1"), Pair.qzlKeO("坤嚈雲坈弮乕盈禃勤遧廪"));
/*     */     OXYGEN_BONUS = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("S0E/Y&C*S&I;"), 21, Pair.qzlKeO("7\024!\013=\002'\0167\002-\037"), InventoryViewUtil.qzlKeO("[-R-N!_7S0E/Y&C*S&I;"), Pair.qzlKeO("汸乳伳畐盈江汘"));
/*     */     WATER_MOVEMENT_EFFICIENCY = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("?]<Y:C%S>Y%Y&H7Y.Z!_!Y&_1"), 22, Pair.qzlKeO("\0339\030=\036'\0017\032=\001=\002,\023=\n>\005;\005=\002;\025"), InventoryViewUtil.qzlKeO("/Y&Y:U+C?]<Y:C%S>Y%Y&H7Y.Z!_!Y&_1"), Pair.qzlKeO("坐汸乕禷勐盈遧廪"));
/*     */     TEMPT_RANGE = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("<Y%L<C:]&[-"), 23, Pair.qzlKeO("\030=\001(\030'\0369\002?\t"), InventoryViewUtil.qzlKeO("/Y&Y:U+C<Y%L<C:]&[-"), Pair.qzlKeO("畓爑厛讉宰荻嚸"));
/*     */     BLOCK_INTERACTION_RANGE = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("*P'_#C!R<Y:]+H!S&C:]&[-"), 24, Pair.qzlKeO("\0164\003;\007'\0056\030=\0369\017,\0057\002'\0369\002?\t"), InventoryViewUtil.qzlKeO("L$]1Y:C*P'_#C!R<Y:]+H!S&C:]&[-"), Pair.qzlKeO("珥寎厣亝親厲盈旁圛趥秷"));
/*     */     ENTITY_INTERACTION_RANGE = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("Y&H!H1C!R<Y:]+H!S&C:]&[-"), 25, Pair.qzlKeO("=\002,\005,\025'\0056\030=\0369\017,\0057\002'\0369\002?\t"), InventoryViewUtil.qzlKeO("8P)E-N7Y&H!H1C!R<Y:]+H!S&C:]&[-"), Pair.qzlKeO("珥寎厣亝親厲盈實伟趥秷"));
/*     */     BLOCK_BREAK_SPEED = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("*P'_#C*N-]#C;L-Y,"), 26, Pair.qzlKeO("\0164\003;\007'\016*\t9\007'\037(\t=\b"), InventoryViewUtil.qzlKeO("L$]1Y:C*P'_#C*N-]#C;L-Y,"), Pair.qzlKeO("珥寎硸圷旵圯盈遧廪"));
/*     */     MINING_EFFICIENCY = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("%U&U&[7Y.Z!_!Y&_1"), 27, Pair.qzlKeO("\0011\0021\002?\023=\n>\005;\005=\002;\025"), InventoryViewUtil.qzlKeO("L$]1Y:C%U&U&[7Y.Z!_!Y&_1"), Pair.qzlKeO("欯砖嶩儏盈据瞳遧廪"));
/*     */     SNEAKING_SPEED = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("O&Y)W!R/C;L-Y,"), 28, Pair.qzlKeO("+\002=\r3\0056\013'\037(\t=\b"), InventoryViewUtil.qzlKeO("8P)E-N7O&Y)W!R/C;L-Y,"), Pair.qzlKeO("漤蠀遧廪"));
/*     */     SUBMERGED_MINING_SPEED = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("O=^%Y:[-X7Q!R!R/C;L-Y,"), 29, Pair.qzlKeO("+\031:\001=\036?\t<\0235\0056\0056\013'\037(\t=\b"), InventoryViewUtil.qzlKeO("8P)E-N7O=^%Y:[-X7Q!R!R/C;L-Y,"), Pair.qzlKeO("汌乇据揔遧廪"));
/*     */     SWEEPING_DAMAGE_RATIO = new AttributeCompatEnum(InventoryViewUtil.qzlKeO(";K-Y8U&[7X)Q)[-C:]<U'"), 30, Pair.qzlKeO("\037/\t=\0341\002?\023<\r5\r?\t'\0369\0301\003"), InventoryViewUtil.qzlKeO("L$]1Y:C;K-Y8U&[7X)Q)[-C:]<U'"), Pair.qzlKeO("橒戧作寿"));
/*     */     SPAWN_REINFORCEMENTS = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("O8]?R7N-U&Z'N+Y%Y&H;"), 31, Pair.qzlKeO("+\0349\0336\023*\t1\002>\003*\017=\001=\002,\037"), InventoryViewUtil.qzlKeO("2S%^!Y7O8]?R7N-U&Z'N+Y%Y&H;"), Pair.qzlKeO("傹局壒掌盈冘珋"));
/*     */     WAYPOINT_TRANSMIT_RANGE = new AttributeCompatEnum(InventoryViewUtil.qzlKeO("?]1L'U&H7H:]&O%U<C:]&[-"), 32, Pair.qzlKeO("\0339\025(\0031\002,\023,\0369\002+\0011\030'\0369\002?\t"), "", InventoryViewUtil.qzlKeO("宂伻似適跳忬炥盬朜奏似迻茟嚜"));
/*     */     WAYPOINT_RECEIVE_RANGE = new AttributeCompatEnum(Pair.qzlKeO("/\r!\0347\0056\030'\036=\017=\005.\t'\0369\002?\t"), 33, InventoryViewUtil.qzlKeO("K)E8S!R<C:Y+Y!J-C:]&[-"), "", Pair.qzlKeO("實伟揝敺趗忈烁暸旈盈杸奫荻嚸"));
/*     */     L = PPPpPP();
/*     */   }
/*     */   
/*     */   public Attribute resolve() {
/*     */     return LegacyUtil.getAttribute((BaseConstants.VERSION_ID.intValue() < VersionCheckEnum.V_1_21_3.getVersionId().intValue()) ? this.K : this.IIIIii);
/*     */   }
/*     */   
/*     */   public static AttributeCompatEnum getByName(@NotNull String name) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokevirtual toUpperCase : ()Ljava/lang/String;
/*     */     //   4: astore_0
/*     */     //   5: invokestatic values : ()[Lcn/handyplus/warp/lib/AttributeCompatEnum;
/*     */     //   8: dup
/*     */     //   9: astore_1
/*     */     //   10: arraylength
/*     */     //   11: istore_2
/*     */     //   12: iconst_0
/*     */     //   13: dup
/*     */     //   14: istore_3
/*     */     //   15: iload_2
/*     */     //   16: if_icmpge -> 47
/*     */     //   19: aload_1
/*     */     //   20: iload_3
/*     */     //   21: aaload
/*     */     //   22: dup
/*     */     //   23: astore #4
/*     */     //   25: invokevirtual getOldName : ()Ljava/lang/String;
/*     */     //   28: aload_0
/*     */     //   29: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
/*     */     //   32: ifeq -> 39
/*     */     //   35: aload #4
/*     */     //   37: areturn
/*     */     //   38: athrow
/*     */     //   39: iinc #3, 1
/*     */     //   42: iload_3
/*     */     //   43: goto -> 15
/*     */     //   46: athrow
/*     */     //   47: aload_0
/*     */     //   48: invokestatic valueOf : (Ljava/lang/String;)Lcn/handyplus/warp/lib/AttributeCompatEnum;
/*     */     //   51: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #138	-> 0
/*     */     //   #219	-> 5
/*     */     //   #198	-> 25
/*     */     //   #214	-> 35
/*     */     //   #219	-> 39
/*     */     //   #184	-> 47
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	52	0	name	Ljava/lang/String;
/*     */   }
/*     */   
/*     */   public static void addAttributeModifier(@NotNull Map<EquipmentSlot, Map<String, Double>> slotAttrList, @NotNull ItemStack itemStack) {
/*     */     ppppPp(slotAttrList, itemStack, false);
/*     */   }
/*     */   
/*     */   @Generated
/*     */   public String getDesc() {
/*     */     return this.j;
/*     */   }
/*     */   
/*     */   @Generated
/*     */   AttributeCompatEnum(String str1, String str2, String str3) {
/*     */     this.IIIIii = str1;
/*     */     this.K = str2;
/*     */     this.j = str3;
/*     */   }
/*     */   
/*     */   @Generated
/*     */   public String getOldName() {
/*     */     return this.K;
/*     */   }
/*     */   
/*     */   public static void setAttributeModifier(@NotNull Map<EquipmentSlot, Map<String, Double>> slotAttrList, @NotNull ItemStack itemStack) {
/*     */     ppppPp(slotAttrList, itemStack, true);
/*     */   }
/*     */   
/*     */   @Generated
/*     */   public String getNewName() {
/*     */     return this.IIIIii;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\AttributeCompatEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */