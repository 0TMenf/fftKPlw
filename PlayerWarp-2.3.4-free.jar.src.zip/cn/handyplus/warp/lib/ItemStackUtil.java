/*      */ package cn.handyplus.warp.lib;public final class ItemStackUtil {
/*      */   public static ItemStack getItemStack(String a, String str1, List<String> list, int i, int j, int k, Map<String, String> map, int m, String str2) {
/*    3 */     return getItemStack(a, str1, list, i, j, k, map, m, str2, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ItemStack getItemStack(String a, String str1, List<String> list, int i, int j, int k, Map<String, String> map, int m) {
/*   15 */     return getItemStack(a, str1, list, i, j, k, map, m, null);
/*      */   } public static ItemStack getItemStack(String a, String str1, List<String> list, Boolean bool, int i, int j, Map<String, String> map) {
/*   17 */     return getItemStack(a, str1, list, bool.booleanValue(), i, j, map, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ItemStack getItemStack(String a, String str1, List<String> list, Boolean bool, int i)
/*      */   {
/*   53 */     return getItemStack(a, str1, list, bool, i, false); } public static String itemStackSerialize(ItemStack a) {
/*   54 */     (new YamlConfiguration())
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   64 */       .set(BcUtil.qzlKeO("\021?\035&"), a);
/*      */     return (new YamlConfiguration()).saveToString();
/*      */   }
/*      */   public static ItemStack getItemStack(String a, String str1, List<String> list, Boolean bool) {
/*   68 */     return getItemStack(a, str1, list, bool, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ItemStack getItemStack(String a) {
/*   81 */     return getItemStack(a, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ItemStack itemStackDeserialize(String a) {
/*  154 */     return itemStackDeserialize(a, Material.AIR);
/*      */   }
/*      */   
/*      */   public static ItemStack getItemStack(String a, String str1, List<String> list, Boolean bool, int i, int j) {
/*  158 */     return getItemStack(a, str1, list, bool, i, j, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ItemStack getItemStack(String a, String str1, List<String> list, int i, int j, int k, Map<String, String> map, int m, String str2, String str3) {
/*  171 */     return getItemStack(a, str1, list, i, j, k, map, m, str2, str3, null);
/*      */   }
/*      */   
/*      */   public static ItemStack getItemStack(String a, String str1) {
/*  175 */     return getItemStack(a, str1, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ItemStack itemStackDeserialize(String a, Material material)
/*      */   {
/*  200 */     YamlConfiguration yamlConfiguration = new YamlConfiguration(); try {
/*      */       yamlConfiguration.loadFromString(a); return yamlConfiguration.getItemStack(NetUtil.qzlKeO("|\004p\035"), new ItemStack(material));
/*      */     } catch (Exception exception) {} ItemStack itemStack;
/*  203 */     return itemStack = new ItemStack(material); } public static ItemStack getItemStack(String a, String str1, List<String> list) { return getItemStack(a, str1, list, Boolean.valueOf(false)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setItemInMainHand(PlayerInventory a, ItemStack itemStack) {
/*  238 */     if (BaseConstants.VERSION_ID.intValue() < VersionCheckEnum.V_1_9.getVersionId().intValue()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  395 */       a.setItemInHand(itemStack);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  582 */     a.setItemInMainHand(itemStack);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Boolean containsItem(PlayerInventory a, ItemStack itemStack, Integer integer, int i) {
/*      */     // Byte code:
/*      */     //   0: getstatic cn/handyplus/warp/lib/BaseConstants.VERSION_ID : Ljava/lang/Integer;
/*      */     //   3: invokevirtual intValue : ()I
/*      */     //   6: getstatic cn/handyplus/warp/lib/VersionCheckEnum.V_1_8_8 : Lcn/handyplus/warp/lib/VersionCheckEnum;
/*      */     //   9: invokevirtual getVersionId : ()Ljava/lang/Integer;
/*      */     //   12: invokevirtual intValue : ()I
/*      */     //   15: if_icmpgt -> 30
/*      */     //   18: aload_0
/*      */     //   19: invokeinterface getContents : ()[Lorg/bukkit/inventory/ItemStack;
/*      */     //   24: astore #4
/*      */     //   26: goto -> 38
/*      */     //   29: athrow
/*      */     //   30: aload_0
/*      */     //   31: invokeinterface getStorageContents : ()[Lorg/bukkit/inventory/ItemStack;
/*      */     //   36: astore #4
/*      */     //   38: iconst_0
/*      */     //   39: istore #5
/*      */     //   41: aload #4
/*      */     //   43: dup
/*      */     //   44: astore #4
/*      */     //   46: arraylength
/*      */     //   47: istore #6
/*      */     //   49: iconst_0
/*      */     //   50: dup
/*      */     //   51: istore #7
/*      */     //   53: iload #6
/*      */     //   55: if_icmpge -> 146
/*      */     //   58: aload #4
/*      */     //   60: iload #7
/*      */     //   62: aaload
/*      */     //   63: dup
/*      */     //   64: astore #8
/*      */     //   66: ifnull -> 138
/*      */     //   69: getstatic org/bukkit/Material.AIR : Lorg/bukkit/Material;
/*      */     //   72: aload #8
/*      */     //   74: invokevirtual getType : ()Lorg/bukkit/Material;
/*      */     //   77: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   80: ifeq -> 87
/*      */     //   83: goto -> 138
/*      */     //   86: athrow
/*      */     //   87: iload_3
/*      */     //   88: ifeq -> 103
/*      */     //   91: aload #8
/*      */     //   93: aload_1
/*      */     //   94: invokevirtual isSimilar : (Lorg/bukkit/inventory/ItemStack;)Z
/*      */     //   97: ifne -> 115
/*      */     //   100: goto -> 138
/*      */     //   103: aload #8
/*      */     //   105: aload_1
/*      */     //   106: invokestatic isSimilar : (Lorg/bukkit/inventory/ItemStack;Lorg/bukkit/inventory/ItemStack;)Z
/*      */     //   109: ifne -> 115
/*      */     //   112: goto -> 138
/*      */     //   115: iload #5
/*      */     //   117: aload #8
/*      */     //   119: invokevirtual getAmount : ()I
/*      */     //   122: iadd
/*      */     //   123: dup
/*      */     //   124: istore #5
/*      */     //   126: aload_2
/*      */     //   127: invokevirtual intValue : ()I
/*      */     //   130: if_icmplt -> 138
/*      */     //   133: iload #5
/*      */     //   135: goto -> 148
/*      */     //   138: iinc #7, 1
/*      */     //   141: iload #7
/*      */     //   143: goto -> 53
/*      */     //   146: iload #5
/*      */     //   148: aload_2
/*      */     //   149: invokevirtual intValue : ()I
/*      */     //   152: if_icmplt -> 159
/*      */     //   155: iconst_1
/*      */     //   156: goto -> 160
/*      */     //   159: iconst_0
/*      */     //   160: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*      */     //   163: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #294	-> 0
/*      */     //   #322	-> 18
/*      */     //   #298	-> 30
/*      */     //   #358	-> 38
/*      */     //   #376	-> 41
/*      */     //   #268	-> 66
/*      */     //   #351	-> 83
/*      */     //   #726	-> 87
/*      */     //   #468	-> 91
/*      */     //   #711	-> 100
/*      */     //   #681	-> 103
/*      */     //   #403	-> 112
/*      */     //   #716	-> 115
/*      */     //   #653	-> 126
/*      */     //   #685	-> 135
/*      */     //   #376	-> 138
/*      */     //   #644	-> 146
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	164	0	a	Lorg/bukkit/inventory/PlayerInventory;
/*      */     //   0	164	1	a	Lorg/bukkit/inventory/ItemStack;
/*      */     //   0	164	2	a	Ljava/lang/Integer;
/*      */     //   0	164	3	a	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean addItem(Player a, ItemStack itemStack, int i) {
/*      */     return addItem(a, itemStack, i, BaseUtil.getLangMsg(BcUtil.qzlKeO("\031/\034\002\f.\025\006\013,")));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean addItem(Player a, ItemStack itemStack) {
/*      */     return addItem(a, itemStack, BaseUtil.getLangMsg(BcUtil.qzlKeO("\031/\034\002\f.\025\006\013,")));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setPersistentData(ItemStack a, String str1, String str2) {
/*      */     ItemMetaUtil.setPersistentData(a.getItemMeta(), str1, str2);
/*  660 */     a.setItemMeta(a.getItemMeta());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @NotNull
/*      */   public static ItemMeta getItemMeta(@Nullable ItemStack itemStack) {
/*      */     if (itemStack == null) {
/*      */       itemStack = new ItemStack(Material.STONE);
/*      */     }
/*      */     ItemMeta itemMeta;
/*      */     if ((itemMeta = itemStack.getItemMeta()) == null) {
/*      */       return Objects.<ItemMeta>requireNonNull((new ItemStack(Material.STONE)).getItemMeta());
/*      */     }
/*      */     return itemMeta;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Material getMaterial(String a) {
/*      */     return getMaterial(a, Material.STONE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean addItem(Player a, String str, int i) {
/*      */     return addItem(a, itemStackDeserialize(str), i, BaseUtil.getLangMsg(NetUtil.qzlKeO("t\024q9a\025x=f\027")));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ItemStack getItemByMaterial(String a, Material material) {
/*      */     if (StrUtil.isEmpty(a)) {
/*      */       return new ItemStack(material);
/*      */     }
/*      */     Material material1;
/*      */     if ((material1 = IiIIIi(a)) != null) {
/*      */       return new ItemStack(material1);
/*      */     }
/*      */     if (BaseConstants.VERSION_ID.intValue() < VersionCheckEnum.V_1_8.getVersionId().intValue()) {
/*      */       return OoOOoO(a, material);
/*      */     }
/*      */     return ((XMaterial)XMaterial.matchXMaterial(a).orElse(XMaterial.matchXMaterial(material))).parseItem();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ItemStack getItemByMaterial(String a) {
/*      */     return getItemByMaterial(a, Material.STONE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Optional<String> getPersistentData(ItemStack a, String str) {
/*      */     return ItemMetaUtil.getPersistentData(a.getItemMeta(), str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getItemAmount(Player a, ItemStack itemStack) {
/*      */     return getItemAmount(a, itemStack, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> loreBatchReplaceMap(String a, Map a, String a) {
/*      */     // Byte code:
/*      */     //   0: new java/util/ArrayList
/*      */     //   3: dup
/*      */     //   4: invokespecial <init> : ()V
/*      */     //   7: astore_3
/*      */     //   8: aload_0
/*      */     //   9: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
/*      */     //   12: ifeq -> 26
/*      */     //   15: aload_3
/*      */     //   16: dup
/*      */     //   17: aload_0
/*      */     //   18: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   23: pop
/*      */     //   24: areturn
/*      */     //   25: athrow
/*      */     //   26: aload_1
/*      */     //   27: ifnull -> 39
/*      */     //   30: aload_1
/*      */     //   31: invokeinterface isEmpty : ()Z
/*      */     //   36: ifeq -> 50
/*      */     //   39: aload_3
/*      */     //   40: dup
/*      */     //   41: aload_0
/*      */     //   42: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   47: pop
/*      */     //   48: areturn
/*      */     //   49: athrow
/*      */     //   50: aload_2
/*      */     //   51: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
/*      */     //   54: ifeq -> 60
/*      */     //   57: ldc ''
/*      */     //   59: astore_2
/*      */     //   60: aload_1
/*      */     //   61: invokeinterface keySet : ()Ljava/util/Set;
/*      */     //   66: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   71: astore #4
/*      */     //   73: aload #4
/*      */     //   75: invokeinterface hasNext : ()Z
/*      */     //   80: ifeq -> 230
/*      */     //   83: aload #4
/*      */     //   85: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   90: checkcast java/lang/String
/*      */     //   93: astore #5
/*      */     //   95: new java/lang/StringBuilder
/*      */     //   98: aload_0
/*      */     //   99: dup_x1
/*      */     //   100: dup
/*      */     //   101: pop2
/*      */     //   102: dup
/*      */     //   103: invokespecial <init> : ()V
/*      */     //   106: ldc '\0'
/*      */     //   108: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   111: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   114: aload #5
/*      */     //   116: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   119: ldc '\\r'
/*      */     //   121: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   124: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   127: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   130: invokevirtual contains : (Ljava/lang/CharSequence;)Z
/*      */     //   133: ifeq -> 73
/*      */     //   136: aload_1
/*      */     //   137: aload #5
/*      */     //   139: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   144: checkcast java/util/List
/*      */     //   147: dup
/*      */     //   148: astore #6
/*      */     //   150: invokestatic isEmpty : (Ljava/util/Collection;)Z
/*      */     //   153: ifeq -> 174
/*      */     //   156: aload_3
/*      */     //   157: dup
/*      */     //   158: aload_0
/*      */     //   159: aload #5
/*      */     //   161: aload_2
/*      */     //   162: invokestatic replace : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   165: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   170: pop
/*      */     //   171: goto -> 231
/*      */     //   174: aload #6
/*      */     //   176: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   181: dup
/*      */     //   182: astore #6
/*      */     //   184: invokeinterface hasNext : ()Z
/*      */     //   189: ifeq -> 230
/*      */     //   192: aload #6
/*      */     //   194: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   199: checkcast java/lang/String
/*      */     //   202: astore #7
/*      */     //   204: aload #6
/*      */     //   206: aload_3
/*      */     //   207: aload_0
/*      */     //   208: aload #5
/*      */     //   210: aload #7
/*      */     //   212: invokestatic replace : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   215: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   220: pop
/*      */     //   221: goto -> 184
/*      */     //   224: nop
/*      */     //   225: nop
/*      */     //   226: nop
/*      */     //   227: nop
/*      */     //   228: nop
/*      */     //   229: athrow
/*      */     //   230: aload_3
/*      */     //   231: invokestatic isEmpty : (Ljava/util/Collection;)Z
/*      */     //   234: ifeq -> 245
/*      */     //   237: aload_3
/*      */     //   238: aload_0
/*      */     //   239: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   244: pop
/*      */     //   245: aload_3
/*      */     //   246: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #575	-> 0
/*      */     //   #409	-> 8
/*      */     //   #600	-> 15
/*      */     //   #417	-> 24
/*      */     //   #740	-> 26
/*      */     //   #396	-> 39
/*      */     //   #508	-> 48
/*      */     //   #439	-> 50
/*      */     //   #573	-> 57
/*      */     //   #689	-> 60
/*      */     //   #597	-> 95
/*      */     //   #296	-> 136
/*      */     //   #674	-> 150
/*      */     //   #583	-> 156
/*      */     //   #365	-> 174
/*      */     //   #765	-> 206
/*      */     //   #462	-> 221
/*      */     //   #747	-> 224
/*      */     //   #516	-> 227
/*      */     //   #570	-> 230
/*      */     //   #374	-> 237
/*      */     //   #269	-> 245
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	247	0	a	Ljava/lang/String;
/*      */     //   0	247	1	a	Ljava/util/Map;
/*      */     //   0	247	2	a	Ljava/lang/String;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> loreBatchReplaceMap(List<?> a, Map<String, List<String>> a, String a) {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokestatic isEmpty : (Ljava/util/Collection;)Z
/*      */     //   4: ifne -> 20
/*      */     //   7: aload_1
/*      */     //   8: ifnull -> 20
/*      */     //   11: aload_1
/*      */     //   12: invokeinterface isEmpty : ()Z
/*      */     //   17: ifeq -> 23
/*      */     //   20: aload_0
/*      */     //   21: areturn
/*      */     //   22: athrow
/*      */     //   23: new java/util/ArrayList
/*      */     //   26: dup
/*      */     //   27: invokespecial <init> : ()V
/*      */     //   30: astore_3
/*      */     //   31: aload_0
/*      */     //   32: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   37: dup
/*      */     //   38: astore #4
/*      */     //   40: invokeinterface hasNext : ()Z
/*      */     //   45: ifeq -> 80
/*      */     //   48: aload #4
/*      */     //   50: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   55: checkcast java/lang/String
/*      */     //   58: astore #5
/*      */     //   60: aload #4
/*      */     //   62: aload_3
/*      */     //   63: aload #5
/*      */     //   65: aload_1
/*      */     //   66: aload_2
/*      */     //   67: invokestatic loreBatchReplaceMap : (Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)Ljava/util/List;
/*      */     //   70: invokeinterface addAll : (Ljava/util/Collection;)Z
/*      */     //   75: pop
/*      */     //   76: goto -> 40
/*      */     //   79: athrow
/*      */     //   80: aload_3
/*      */     //   81: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #577	-> 0
/*      */     //   #319	-> 20
/*      */     //   #576	-> 23
/*      */     //   #627	-> 31
/*      */     //   #682	-> 62
/*      */     //   #331	-> 76
/*      */     //   #429	-> 80
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	82	0	a	Ljava/util/List;
/*      */     //   0	82	1	a	Ljava/util/Map;
/*      */     //   0	82	2	a	Ljava/lang/String;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Boolean removeItem(Player a, ItemStack itemStack, Integer integer) {
/*      */     return removeItem(a, itemStack, integer, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean addItem(Player a, String str) {
/*      */     return addItem(a, itemStackDeserialize(str), BaseUtil.getLangMsg(NetUtil.qzlKeO("t\024q9a\025x=f\027")));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean addItem(Player a, ItemStack itemStack, int i, String str) {
/*      */     if (Material.AIR.equals(itemStack.getType())) {
/*      */       return false;
/*      */     }
/*      */     List<ItemStack> list;
/*  768 */     if (CollUtil.isEmpty(list = PPPpPP(a, itemStack, i)))
/*      */       return false;  VRePVZ(a, list); MessageUtil.sendMessage(a, str); return true;
/*      */   }
/*      */   public static List<String> loreReplaceMap(List<?> a, Map<?, ?> a) { // Byte code:
/*      */     //   0: new java/util/ArrayList
/*      */     //   3: dup
/*      */     //   4: invokespecial <init> : ()V
/*      */     //   7: astore_2
/*      */     //   8: aload_0
/*      */     //   9: invokestatic isEmpty : (Ljava/util/Collection;)Z
/*      */     //   12: ifeq -> 18
/*      */     //   15: aload_2
/*      */     //   16: areturn
/*      */     //   17: athrow
/*      */     //   18: aload_1
/*      */     //   19: invokestatic isNotEmpty : (Ljava/util/Map;)Z
/*      */     //   22: ifeq -> 187
/*      */     //   25: aload_0
/*      */     //   26: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   31: dup
/*      */     //   32: astore_3
/*      */     //   33: invokeinterface hasNext : ()Z
/*      */     //   38: ifeq -> 195
/*      */     //   41: aload_3
/*      */     //   42: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   47: checkcast java/lang/String
/*      */     //   50: astore #4
/*      */     //   52: aload_1
/*      */     //   53: invokeinterface keySet : ()Ljava/util/Set;
/*      */     //   58: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   63: astore #5
/*      */     //   65: aload #5
/*      */     //   67: invokeinterface hasNext : ()Z
/*      */     //   72: ifeq -> 171
/*      */     //   75: aload #5
/*      */     //   77: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   82: checkcast java/lang/String
/*      */     //   85: astore #6
/*      */     //   87: aload #4
/*      */     //   89: invokestatic isNotEmpty : (Ljava/lang/CharSequence;)Z
/*      */     //   92: ifeq -> 65
/*      */     //   95: new java/lang/StringBuilder
/*      */     //   98: aload #4
/*      */     //   100: dup_x1
/*      */     //   101: dup
/*      */     //   102: pop2
/*      */     //   103: dup
/*      */     //   104: invokespecial <init> : ()V
/*      */     //   107: ldc '\0'
/*      */     //   109: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   112: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   115: aload #6
/*      */     //   117: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   120: ldc '\\r'
/*      */     //   122: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   125: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   128: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   131: invokevirtual contains : (Ljava/lang/CharSequence;)Z
/*      */     //   134: ifeq -> 65
/*      */     //   137: aload_1
/*      */     //   138: aload #6
/*      */     //   140: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   145: ifnull -> 65
/*      */     //   148: aload #4
/*      */     //   150: aload_1
/*      */     //   151: aload #6
/*      */     //   153: dup_x1
/*      */     //   154: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   159: checkcast java/lang/String
/*      */     //   162: invokestatic replace : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   165: astore #4
/*      */     //   167: goto -> 65
/*      */     //   170: athrow
/*      */     //   171: aload_2
/*      */     //   172: aload #4
/*      */     //   174: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   179: pop
/*      */     //   180: aload_3
/*      */     //   181: goto -> 33
/*      */     //   184: nop
/*      */     //   185: nop
/*      */     //   186: athrow
/*      */     //   187: aload_2
/*      */     //   188: aload_0
/*      */     //   189: invokeinterface addAll : (Ljava/util/Collection;)Z
/*      */     //   194: pop
/*      */     //   195: aload_2
/*      */     //   196: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #615	-> 0
/*      */     //   #585	-> 8
/*      */     //   #398	-> 15
/*      */     //   #748	-> 18
/*      */     //   #487	-> 25
/*      */     //   #578	-> 52
/*      */     //   #308	-> 87
/*      */     //   #735	-> 148
/*      */     //   #614	-> 167
/*      */     //   #547	-> 171
/*      */     //   #695	-> 181
/*      */     //   #679	-> 187
/*      */     //   #236	-> 195
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	197	0	a	Ljava/util/List;
/*      */     //   0	197	1	a	Ljava/util/Map; } public static int getItemAmount(Player a, ItemStack a, int a) { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: ifnull -> 13
/*      */     //   4: aload_0
/*      */     //   5: invokeinterface isOnline : ()Z
/*      */     //   10: ifne -> 16
/*      */     //   13: iconst_0
/*      */     //   14: ireturn
/*      */     //   15: athrow
/*      */     //   16: aload_0
/*      */     //   17: invokeinterface getInventory : ()Lorg/bukkit/inventory/PlayerInventory;
/*      */     //   22: astore_3
/*      */     //   23: getstatic cn/handyplus/warp/lib/BaseConstants.VERSION_ID : Ljava/lang/Integer;
/*      */     //   26: invokevirtual intValue : ()I
/*      */     //   29: getstatic cn/handyplus/warp/lib/VersionCheckEnum.V_1_8_8 : Lcn/handyplus/warp/lib/VersionCheckEnum;
/*      */     //   32: invokevirtual getVersionId : ()Ljava/lang/Integer;
/*      */     //   35: invokevirtual intValue : ()I
/*      */     //   38: if_icmpgt -> 53
/*      */     //   41: aload_3
/*      */     //   42: invokeinterface getContents : ()[Lorg/bukkit/inventory/ItemStack;
/*      */     //   47: astore #4
/*      */     //   49: goto -> 61
/*      */     //   52: athrow
/*      */     //   53: aload_3
/*      */     //   54: invokeinterface getStorageContents : ()[Lorg/bukkit/inventory/ItemStack;
/*      */     //   59: astore #4
/*      */     //   61: iconst_0
/*      */     //   62: istore_3
/*      */     //   63: aload #4
/*      */     //   65: dup
/*      */     //   66: astore #4
/*      */     //   68: arraylength
/*      */     //   69: istore #5
/*      */     //   71: iconst_0
/*      */     //   72: dup
/*      */     //   73: istore #6
/*      */     //   75: iload #5
/*      */     //   77: if_icmpge -> 152
/*      */     //   80: aload #4
/*      */     //   82: iload #6
/*      */     //   84: aaload
/*      */     //   85: dup
/*      */     //   86: astore #7
/*      */     //   88: ifnull -> 144
/*      */     //   91: getstatic org/bukkit/Material.AIR : Lorg/bukkit/Material;
/*      */     //   94: aload #7
/*      */     //   96: invokevirtual getType : ()Lorg/bukkit/Material;
/*      */     //   99: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   102: ifeq -> 108
/*      */     //   105: goto -> 144
/*      */     //   108: iload_2
/*      */     //   109: ifeq -> 124
/*      */     //   112: aload #7
/*      */     //   114: aload_1
/*      */     //   115: invokevirtual isSimilar : (Lorg/bukkit/inventory/ItemStack;)Z
/*      */     //   118: ifne -> 136
/*      */     //   121: goto -> 144
/*      */     //   124: aload #7
/*      */     //   126: aload_1
/*      */     //   127: invokestatic isSimilar : (Lorg/bukkit/inventory/ItemStack;Lorg/bukkit/inventory/ItemStack;)Z
/*      */     //   130: ifne -> 136
/*      */     //   133: goto -> 144
/*      */     //   136: iload_3
/*      */     //   137: aload #7
/*      */     //   139: invokevirtual getAmount : ()I
/*      */     //   142: iadd
/*      */     //   143: istore_3
/*      */     //   144: iinc #6, 1
/*      */     //   147: iload #6
/*      */     //   149: goto -> 75
/*      */     //   152: iload_3
/*      */     //   153: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #657	-> 0
/*      */     //   #746	-> 13
/*      */     //   #697	-> 16
/*      */     //   #251	-> 23
/*      */     //   #482	-> 41
/*      */     //   #453	-> 53
/*      */     //   #286	-> 61
/*      */     //   #416	-> 63
/*      */     //   #422	-> 88
/*      */     //   #437	-> 105
/*      */     //   #626	-> 108
/*      */     //   #448	-> 133
/*      */     //   #305	-> 136
/*      */     //   #416	-> 144
/*      */     //   #703	-> 152
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	154	0	a	Lorg/bukkit/entity/Player;
/*      */     //   0	154	1	a	Lorg/bukkit/inventory/ItemStack;
/*      */     //   0	154	2	a	I } public static ItemStack getItemStack(String a, String str1, List<String> list, int i, int j, int k, Map<String, String> map, int m, String str2, String str3, String str4) { ItemStack itemStack; ItemMeta itemMeta = getItemMeta(itemStack = getItemByMaterial(a)); ItemMetaUtil.setDisplayName(itemMeta, str1); ItemMetaUtil.setLore(itemMeta, loreReplaceMap(list, map)); if (i != 0)
/*  772 */       ItemMetaUtil.setEnchant(itemMeta);  if (m != 0) ItemMetaUtil.hideEnchant(itemMeta);  if (k != 0)
/*      */       ItemMetaUtil.hideAttributes(itemMeta);  ItemMetaUtil.setPersistentData(itemMeta, str2, BcUtil.qzlKeO("\0132\013?\035&")); ItemMetaUtil.setCustomModelData(itemMeta, j); ItemMetaUtil.setTooltipStyle(itemMeta, str3); ItemMetaUtil.setItemModel(itemMeta, str4); itemStack.setItemMeta(itemMeta); return itemStack; } public static boolean addItem(Player a, ItemStack itemStack, String str) { true; true[0] = itemStack; HashMap<?, ?> hashMap; if ((hashMap = (new ItemStack[1]).addItem(true)).isEmpty())
/*      */       return false;  PlayerSchedulerUtil.dropItem(a, new ArrayList<>((Collection)hashMap.values())); MessageUtil.sendMessage(a, str); return true; }
/*  775 */   public static void setOwner(ItemStack a, String str) { if (a == null || StrUtil.isEmpty(str)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ItemMeta itemMeta;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  857 */     if (!(itemMeta = a.getItemMeta() instanceof SkullMeta)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  942 */     SkullMeta skullMeta = (SkullMeta)itemMeta;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1153 */     ItemMetaUtil.setOwner(skullMeta, str); a.setItemMeta((ItemMeta)skullMeta); }
/*      */ 
/*      */   
/*      */   public static Material getMaterial(String a, Material material) {
/*      */     if (StrUtil.isEmpty(a))
/*      */       return material; 
/*      */     Material material1;
/*      */     if ((material1 = IiIIIi(a)) != null)
/*      */       return material1; 
/*      */     if (BaseConstants.VERSION_ID.intValue() < VersionCheckEnum.V_1_8.getVersionId().intValue())
/*      */       return material; 
/*      */     return ((XMaterial)XMaterial.matchXMaterial(a).orElse(XMaterial.matchXMaterial(material))).get();
/*      */   }
/*      */   
/*      */   public static Boolean removeItem(Player a, ItemStack a, Integer a, int a) {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: ifnull -> 13
/*      */     //   4: aload_0
/*      */     //   5: invokeinterface isOnline : ()Z
/*      */     //   10: ifne -> 19
/*      */     //   13: iconst_0
/*      */     //   14: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*      */     //   17: areturn
/*      */     //   18: athrow
/*      */     //   19: aload_2
/*      */     //   20: invokevirtual intValue : ()I
/*      */     //   23: iconst_1
/*      */     //   24: if_icmpge -> 59
/*      */     //   27: new java/lang/RuntimeException
/*      */     //   30: dup
/*      */     //   31: new java/lang/StringBuilder
/*      */     //   34: dup
/*      */     //   35: invokespecial <init> : ()V
/*      */     //   38: iconst_0
/*      */     //   39: ldc_w '攀釚乽胨乊贊攀/P'
/*      */     //   42: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   45: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   48: aload_2
/*      */     //   49: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*      */     //   52: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   55: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   58: athrow
/*      */     //   59: aload_0
/*      */     //   60: invokeinterface getInventory : ()Lorg/bukkit/inventory/PlayerInventory;
/*      */     //   65: astore #4
/*      */     //   67: getstatic cn/handyplus/warp/lib/BaseConstants.VERSION_ID : Ljava/lang/Integer;
/*      */     //   70: invokevirtual intValue : ()I
/*      */     //   73: getstatic cn/handyplus/warp/lib/VersionCheckEnum.V_1_8_8 : Lcn/handyplus/warp/lib/VersionCheckEnum;
/*      */     //   76: invokevirtual getVersionId : ()Ljava/lang/Integer;
/*      */     //   79: invokevirtual intValue : ()I
/*      */     //   82: if_icmpgt -> 98
/*      */     //   85: aload #4
/*      */     //   87: invokeinterface getContents : ()[Lorg/bukkit/inventory/ItemStack;
/*      */     //   92: astore #5
/*      */     //   94: goto -> 107
/*      */     //   97: athrow
/*      */     //   98: aload #4
/*      */     //   100: invokeinterface getStorageContents : ()[Lorg/bukkit/inventory/ItemStack;
/*      */     //   105: astore #5
/*      */     //   107: iconst_0
/*      */     //   108: istore #6
/*      */     //   110: new java/util/ArrayList
/*      */     //   113: dup
/*      */     //   114: invokespecial <init> : ()V
/*      */     //   117: astore #7
/*      */     //   119: aload #5
/*      */     //   121: dup
/*      */     //   122: astore #5
/*      */     //   124: arraylength
/*      */     //   125: istore #8
/*      */     //   127: iconst_0
/*      */     //   128: dup
/*      */     //   129: istore #9
/*      */     //   131: iload #8
/*      */     //   133: if_icmpge -> 233
/*      */     //   136: aload #5
/*      */     //   138: iload #9
/*      */     //   140: aaload
/*      */     //   141: dup
/*      */     //   142: astore #10
/*      */     //   144: ifnull -> 225
/*      */     //   147: getstatic org/bukkit/Material.AIR : Lorg/bukkit/Material;
/*      */     //   150: aload #10
/*      */     //   152: invokevirtual getType : ()Lorg/bukkit/Material;
/*      */     //   155: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   158: ifeq -> 164
/*      */     //   161: goto -> 225
/*      */     //   164: iload_3
/*      */     //   165: ifeq -> 180
/*      */     //   168: aload #10
/*      */     //   170: aload_1
/*      */     //   171: invokevirtual isSimilar : (Lorg/bukkit/inventory/ItemStack;)Z
/*      */     //   174: ifne -> 192
/*      */     //   177: goto -> 225
/*      */     //   180: aload #10
/*      */     //   182: aload_1
/*      */     //   183: invokestatic isSimilar : (Lorg/bukkit/inventory/ItemStack;Lorg/bukkit/inventory/ItemStack;)Z
/*      */     //   186: ifne -> 192
/*      */     //   189: goto -> 225
/*      */     //   192: iload #6
/*      */     //   194: aload #10
/*      */     //   196: invokevirtual getAmount : ()I
/*      */     //   199: iadd
/*      */     //   200: dup
/*      */     //   201: istore #6
/*      */     //   203: aload #7
/*      */     //   205: aload #10
/*      */     //   207: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   212: pop
/*      */     //   213: aload_2
/*      */     //   214: invokevirtual intValue : ()I
/*      */     //   217: if_icmplt -> 225
/*      */     //   220: iload #6
/*      */     //   222: goto -> 235
/*      */     //   225: iinc #9, 1
/*      */     //   228: iload #9
/*      */     //   230: goto -> 131
/*      */     //   233: iload #6
/*      */     //   235: aload_2
/*      */     //   236: invokevirtual intValue : ()I
/*      */     //   239: if_icmpne -> 302
/*      */     //   242: aload #7
/*      */     //   244: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   249: dup
/*      */     //   250: astore #5
/*      */     //   252: invokeinterface hasNext : ()Z
/*      */     //   257: ifeq -> 297
/*      */     //   260: aload #5
/*      */     //   262: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   267: checkcast org/bukkit/inventory/ItemStack
/*      */     //   270: astore #8
/*      */     //   272: aload #4
/*      */     //   274: iconst_1
/*      */     //   275: anewarray org/bukkit/inventory/ItemStack
/*      */     //   278: iconst_1
/*      */     //   279: dup
/*      */     //   280: pop2
/*      */     //   281: dup
/*      */     //   282: iconst_0
/*      */     //   283: aload #8
/*      */     //   285: aastore
/*      */     //   286: invokeinterface removeItem : ([Lorg/bukkit/inventory/ItemStack;)Ljava/util/HashMap;
/*      */     //   291: pop
/*      */     //   292: aload #5
/*      */     //   294: goto -> 252
/*      */     //   297: iconst_1
/*      */     //   298: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*      */     //   301: areturn
/*      */     //   302: iload #6
/*      */     //   304: aload_2
/*      */     //   305: invokevirtual intValue : ()I
/*      */     //   308: if_icmple -> 430
/*      */     //   311: aload #7
/*      */     //   313: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   318: astore #5
/*      */     //   320: aload #5
/*      */     //   322: invokeinterface hasNext : ()Z
/*      */     //   327: ifeq -> 425
/*      */     //   330: aload #5
/*      */     //   332: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   337: checkcast org/bukkit/inventory/ItemStack
/*      */     //   340: astore #8
/*      */     //   342: aload_2
/*      */     //   343: invokevirtual intValue : ()I
/*      */     //   346: ifne -> 354
/*      */     //   349: iconst_1
/*      */     //   350: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*      */     //   353: areturn
/*      */     //   354: aload_2
/*      */     //   355: invokevirtual intValue : ()I
/*      */     //   358: aload #8
/*      */     //   360: invokevirtual getAmount : ()I
/*      */     //   363: if_icmplt -> 403
/*      */     //   366: aload_2
/*      */     //   367: invokevirtual intValue : ()I
/*      */     //   370: aload #8
/*      */     //   372: invokevirtual getAmount : ()I
/*      */     //   375: isub
/*      */     //   376: invokestatic valueOf : (I)Ljava/lang/Integer;
/*      */     //   379: astore_2
/*      */     //   380: aload #4
/*      */     //   382: iconst_1
/*      */     //   383: anewarray org/bukkit/inventory/ItemStack
/*      */     //   386: iconst_1
/*      */     //   387: dup
/*      */     //   388: pop2
/*      */     //   389: dup
/*      */     //   390: iconst_0
/*      */     //   391: aload #8
/*      */     //   393: aastore
/*      */     //   394: invokeinterface removeItem : ([Lorg/bukkit/inventory/ItemStack;)Ljava/util/HashMap;
/*      */     //   399: pop
/*      */     //   400: goto -> 320
/*      */     //   403: aload #8
/*      */     //   405: dup
/*      */     //   406: invokevirtual getAmount : ()I
/*      */     //   409: aload_2
/*      */     //   410: invokevirtual intValue : ()I
/*      */     //   413: isub
/*      */     //   414: invokevirtual setAmount : (I)V
/*      */     //   417: iconst_0
/*      */     //   418: invokestatic valueOf : (I)Ljava/lang/Integer;
/*      */     //   421: astore_2
/*      */     //   422: goto -> 320
/*      */     //   425: iconst_1
/*      */     //   426: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*      */     //   429: areturn
/*      */     //   430: iconst_0
/*      */     //   431: invokestatic valueOf : (Z)Ljava/lang/Boolean;
/*      */     //   434: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #749	-> 0
/*      */     //   #258	-> 13
/*      */     //   #366	-> 19
/*      */     //   #739	-> 27
/*      */     //   #472	-> 59
/*      */     //   #391	-> 67
/*      */     //   #456	-> 85
/*      */     //   #413	-> 98
/*      */     //   #604	-> 107
/*      */     //   #276	-> 110
/*      */     //   #744	-> 119
/*      */     //   #729	-> 144
/*      */     //   #707	-> 161
/*      */     //   #623	-> 164
/*      */     //   #647	-> 189
/*      */     //   #272	-> 192
/*      */     //   #329	-> 203
/*      */     //   #743	-> 213
/*      */     //   #536	-> 222
/*      */     //   #744	-> 225
/*      */     //   #488	-> 233
/*      */     //   #525	-> 242
/*      */     //   #279	-> 272
/*      */     //   #291	-> 294
/*      */     //   #511	-> 297
/*      */     //   #325	-> 302
/*      */     //   #244	-> 311
/*      */     //   #273	-> 342
/*      */     //   #309	-> 349
/*      */     //   #603	-> 354
/*      */     //   #656	-> 366
/*      */     //   #257	-> 380
/*      */     //   #275	-> 403
/*      */     //   #394	-> 417
/*      */     //   #415	-> 422
/*      */     //   #610	-> 425
/*      */     //   #589	-> 430
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	435	0	a	Lorg/bukkit/entity/Player;
/*      */     //   0	435	1	a	Lorg/bukkit/inventory/ItemStack;
/*      */     //   0	435	2	a	Ljava/lang/Integer;
/*      */     //   0	435	3	a	I
/*      */   }
/*      */   
/*      */   public static ItemStack getItemInMainHand(PlayerInventory a) {
/*      */     if (BaseConstants.VERSION_ID.intValue() < VersionCheckEnum.V_1_9.getVersionId().intValue())
/*      */       return a.getItemInHand(); 
/*      */     return a.getItemInMainHand();
/*      */   }
/*      */   
/*      */   public static void setSkull(ItemStack a, String str) {
/*      */     if (a == null || StrUtil.isEmpty(str))
/*      */       return; 
/*      */     ItemMeta itemMeta;
/*      */     if (!(itemMeta = a.getItemMeta() instanceof SkullMeta))
/*      */       return; 
/*      */     SkullMeta skullMeta = (SkullMeta)itemMeta;
/*      */     ItemMetaUtil.setSkull(skullMeta, str);
/*      */     a.setItemMeta((ItemMeta)skullMeta);
/*      */   }
/*      */   
/*      */   public static boolean isSimilar(ItemStack a, ItemStack itemStack1) {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: aload_1
/*      */     //   2: if_acmpne -> 8
/*      */     //   5: iconst_1
/*      */     //   6: ireturn
/*      */     //   7: athrow
/*      */     //   8: aload_0
/*      */     //   9: ifnull -> 16
/*      */     //   12: aload_1
/*      */     //   13: ifnonnull -> 19
/*      */     //   16: iconst_0
/*      */     //   17: ireturn
/*      */     //   18: athrow
/*      */     //   19: aload_0
/*      */     //   20: invokevirtual getType : ()Lorg/bukkit/Material;
/*      */     //   23: aload_1
/*      */     //   24: invokevirtual getType : ()Lorg/bukkit/Material;
/*      */     //   27: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   30: ifne -> 35
/*      */     //   33: iconst_0
/*      */     //   34: ireturn
/*      */     //   35: getstatic cn/handyplus/warp/lib/BaseConstants.VERSION_ID : Ljava/lang/Integer;
/*      */     //   38: invokevirtual intValue : ()I
/*      */     //   41: getstatic cn/handyplus/warp/lib/VersionCheckEnum.V_1_13 : Lcn/handyplus/warp/lib/VersionCheckEnum;
/*      */     //   44: invokevirtual getVersionId : ()Ljava/lang/Integer;
/*      */     //   47: invokevirtual intValue : ()I
/*      */     //   50: if_icmpge -> 84
/*      */     //   53: aload_0
/*      */     //   54: invokevirtual getData : ()Lorg/bukkit/material/MaterialData;
/*      */     //   57: astore_2
/*      */     //   58: aload_1
/*      */     //   59: invokevirtual getData : ()Lorg/bukkit/material/MaterialData;
/*      */     //   62: astore_3
/*      */     //   63: aload_2
/*      */     //   64: ifnull -> 84
/*      */     //   67: aload_3
/*      */     //   68: ifnull -> 84
/*      */     //   71: aload_2
/*      */     //   72: invokevirtual getData : ()B
/*      */     //   75: aload_3
/*      */     //   76: invokevirtual getData : ()B
/*      */     //   79: if_icmpeq -> 84
/*      */     //   82: iconst_0
/*      */     //   83: ireturn
/*      */     //   84: aload_0
/*      */     //   85: invokevirtual getItemMeta : ()Lorg/bukkit/inventory/meta/ItemMeta;
/*      */     //   88: astore_2
/*      */     //   89: aload_1
/*      */     //   90: invokevirtual getItemMeta : ()Lorg/bukkit/inventory/meta/ItemMeta;
/*      */     //   93: astore_3
/*      */     //   94: aload_2
/*      */     //   95: aload_3
/*      */     //   96: if_acmpne -> 101
/*      */     //   99: iconst_1
/*      */     //   100: ireturn
/*      */     //   101: aload_2
/*      */     //   102: ifnull -> 109
/*      */     //   105: aload_3
/*      */     //   106: ifnonnull -> 111
/*      */     //   109: iconst_0
/*      */     //   110: ireturn
/*      */     //   111: aload_2
/*      */     //   112: invokeinterface getDisplayName : ()Ljava/lang/String;
/*      */     //   117: aload_3
/*      */     //   118: invokeinterface getDisplayName : ()Ljava/lang/String;
/*      */     //   123: invokestatic equals : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
/*      */     //   126: ifne -> 131
/*      */     //   129: iconst_0
/*      */     //   130: ireturn
/*      */     //   131: aload_2
/*      */     //   132: invokeinterface getLore : ()Ljava/util/List;
/*      */     //   137: aload_3
/*      */     //   138: invokeinterface getLore : ()Ljava/util/List;
/*      */     //   143: invokestatic equals : (Ljava/util/List;Ljava/util/List;)Z
/*      */     //   146: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #899	-> 0
/*      */     //   #1025	-> 5
/*      */     //   #843	-> 8
/*      */     //   #832	-> 16
/*      */     //   #869	-> 19
/*      */     //   #777	-> 33
/*      */     //   #1006	-> 35
/*      */     //   #834	-> 53
/*      */     //   #788	-> 58
/*      */     //   #1074	-> 63
/*      */     //   #964	-> 82
/*      */     //   #1005	-> 84
/*      */     //   #1016	-> 89
/*      */     //   #952	-> 94
/*      */     //   #1174	-> 99
/*      */     //   #986	-> 101
/*      */     //   #966	-> 109
/*      */     //   #1141	-> 111
/*      */     //   #821	-> 129
/*      */     //   #1184	-> 131
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	147	0	a	Lorg/bukkit/inventory/ItemStack;
/*      */     //   0	147	1	a	Lorg/bukkit/inventory/ItemStack;
/*      */   }
/*      */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\ItemStackUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */