/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ public enum ServerTypeEnum {
/*   4 */   FOLIA(WarpCollectionService.qzlKeO("_(\0307W7S5[$\0307W7S5\0303^5S&R\"R5S _(X4\030\025S _(X.L\"R\024S5@\"D")), BUKKIT(WarpCollectionService.qzlKeO("_(\0307W7S5[$\0307W7S5\0303^5S&R\"R5S _(X4\030\025S _(X.L\"R\024S5@\"D")), SPIGOT(WarpCollectionService.qzlKeO("_(\0307W7S5[$\0307W7S5\0303^5S&R\"R5S _(X4\030\025S _(X.L\"R\024S5@\"D")),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 221 */   PAPER(WarpCollectionService.qzlKeO("U([iR\"E3D(O4B(]>YiF&F\"Dif&F\"D\004Y)P.Q")); private final String j;
/*     */   public static ServerTypeEnum getServerType() {
/*     */     if (OoOoOo(FOLIA.j))
/*     */       return FOLIA; 
/*     */     if (OoOoOo(PAPER.j))
/*     */       return PAPER; 
/*     */     if (OoOoOo(SPIGOT.j))
/* 228 */       return SPIGOT; 
/*     */     return BUKKIT;
/*     */   }
/*     */   
/*     */   ServerTypeEnum(String str1) {
/*     */     this.j = str1;
/*     */   }
/*     */   
/*     */   static {
/*     */     SPIGOT = new ServerTypeEnum(Pair.qzlKeO("+\0341\0137\030"), 2, WarpCollectionService.qzlKeO("Y5QiE7_ Y3[$\030\024F.Q(B\004Y)P.Q"));
/*     */     BUKKIT = new ServerTypeEnum(Pair.qzlKeO(":\0313\0071\030"), 3, WarpCollectionService.qzlKeO("Y5QiT2],_3\030\005C,].B"));
/*     */     OooOOo = iiIiIi();
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\ServerTypeEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */