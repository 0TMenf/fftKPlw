/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import cn.handyplus.warp.service.WarpCollectionService;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.spec.PKCS8EncodedKeySpec;
/*     */ import java.security.spec.X509EncodedKeySpec;
/*     */ import java.util.Base64;
/*     */ import java.util.Optional;
/*     */ import java.util.logging.Level;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SecureUtil
/*     */ {
/*     */   private static final String IIiIiI = "HANDY_LIB_SECRET";
/*     */   
/*     */   public static Optional<String> md5(String a) {
/*     */     try {
/*     */       MessageDigest messageDigest;
/* 228 */       return Optional.of(xXxXxX((messageDigest = MessageDigest.getInstance(WarpCollectionService.qzlKeO("{\003\003"))).digest(a.getBytes())));
/*     */     } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
/*     */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, Pair.qzlKeO("\025(Ml厩畓彺年"), noSuchAlgorithmException); return Optional.empty();
/*     */     }  } public static String decryptWithPublicKey(String a, String str1) { try {
/* 232 */       byte[] arrayOfByte2 = Base64.getDecoder().decode(str1); X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec(arrayOfByte2); PublicKey publicKey = KeyFactory.getInstance(Pair.qzlKeO("\036+\r")).generatePublic(x509EncodedKeySpec); Cipher.getInstance(WarpCollectionService.qzlKeO("\025e\006\031\002u\005\031\027}\004evf&R#_)Q")).init(2, publicKey); byte[] arrayOfByte1 = Cipher.getInstance(WarpCollectionService.qzlKeO("\025e\006\031\002u\005\031\027}\004evf&R#_)Q")).doFinal(Base64.getDecoder().decode(a)); return new String(arrayOfByte1, StandardCharsets.UTF_8);
/*     */     } catch (Throwable throwable) {
/*     */       throw throwable;
/*     */     }  }
/*     */ 
/*     */   
/*     */   public static String md5Str(String a) {
/*     */     return md5(a).orElse(null);
/*     */   }
/*     */   
/*     */   public static String encrypt(String a) {
/*     */     return encrypt("HANDY_LIB_SECRET", a);
/*     */   }
/*     */   
/*     */   public static String decrypt(String a, String str1) {
/*     */     try {
/*     */       SecretKeySpec secretKeySpec = new SecretKeySpec(a.getBytes(), Pair.qzlKeO("\r=\037"));
/*     */       Cipher.getInstance(WarpCollectionService.qzlKeO("\006s\024\031\002u\005\031\027}\004erf&R#_)Q")).init(2, secretKeySpec);
/*     */       byte[] arrayOfByte = Cipher.getInstance(WarpCollectionService.qzlKeO("\006s\024\031\002u\005\031\027}\004erf&R#_)Q")).doFinal(Base64.getDecoder().decode(str1));
/*     */       return new String(arrayOfByte, StandardCharsets.UTF_8);
/*     */     } catch (Throwable throwable) {
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String decrypt(String a) {
/*     */     return decrypt("HANDY_LIB_SECRET", a);
/*     */   }
/*     */   
/*     */   public static String encrypt(String a, String str1) {
/*     */     try {
/*     */       SecretKeySpec secretKeySpec = new SecretKeySpec(a.getBytes(), Pair.qzlKeO("\r=\037"));
/*     */       Cipher cipher = Cipher.getInstance(WarpCollectionService.qzlKeO("\006s\024\031\002u\005\031\027}\004erf&R#_)Q"));
/*     */       cipher.init(1, secretKeySpec);
/*     */       byte[] arrayOfByte = cipher.doFinal(str1.getBytes(StandardCharsets.UTF_8));
/*     */       return Base64.getEncoder().encodeToString(arrayOfByte);
/*     */     } catch (Throwable throwable) {
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String encryptWithPrivateKey(String a, String str1) {
/*     */     try {
/*     */       byte[] arrayOfByte2 = Base64.getDecoder().decode(str1);
/*     */       PKCS8EncodedKeySpec pKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(arrayOfByte2);
/*     */       PrivateKey privateKey = KeyFactory.getInstance(Pair.qzlKeO("\036+\r")).generatePrivate(pKCS8EncodedKeySpec);
/*     */       Cipher cipher = Cipher.getInstance(WarpCollectionService.qzlKeO("\025e\006\031\002u\005\031\027}\004evf&R#_)Q"));
/*     */       cipher.init(1, privateKey);
/*     */       byte[] arrayOfByte1 = cipher.doFinal(a.getBytes(StandardCharsets.UTF_8));
/*     */       return Base64.getEncoder().encodeToString(arrayOfByte1);
/*     */     } catch (Throwable throwable) {
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_4
/*     */     //   1: iconst_3
/*     */     //   2: ishl
/*     */     //   3: iconst_3
/*     */     //   4: iconst_5
/*     */     //   5: ixor
/*     */     //   6: ixor
/*     */     //   7: iconst_1
/*     */     //   8: iconst_3
/*     */     //   9: ishl
/*     */     //   10: iconst_2
/*     */     //   11: iconst_5
/*     */     //   12: ixor
/*     */     //   13: iconst_3
/*     */     //   14: ishl
/*     */     //   15: iconst_1
/*     */     //   16: ixor
/*     */     //   17: aload_0
/*     */     //   18: checkcast java/lang/String
/*     */     //   21: dup
/*     */     //   22: astore_0
/*     */     //   23: invokevirtual length : ()I
/*     */     //   26: dup
/*     */     //   27: newarray char
/*     */     //   29: iconst_1
/*     */     //   30: dup
/*     */     //   31: pop2
/*     */     //   32: swap
/*     */     //   33: iconst_1
/*     */     //   34: isub
/*     */     //   35: dup_x2
/*     */     //   36: istore_3
/*     */     //   37: astore_1
/*     */     //   38: istore #4
/*     */     //   40: dup_x2
/*     */     //   41: pop2
/*     */     //   42: istore_2
/*     */     //   43: iflt -> 83
/*     */     //   46: aload_1
/*     */     //   47: aload_0
/*     */     //   48: iload_3
/*     */     //   49: dup_x1
/*     */     //   50: invokevirtual charAt : (I)C
/*     */     //   53: iinc #3, -1
/*     */     //   56: iload_2
/*     */     //   57: ixor
/*     */     //   58: i2c
/*     */     //   59: castore
/*     */     //   60: iload_3
/*     */     //   61: iflt -> 83
/*     */     //   64: aload_1
/*     */     //   65: aload_0
/*     */     //   66: iload_3
/*     */     //   67: iinc #3, -1
/*     */     //   70: dup_x1
/*     */     //   71: invokevirtual charAt : (I)C
/*     */     //   74: iload #4
/*     */     //   76: ixor
/*     */     //   77: i2c
/*     */     //   78: castore
/*     */     //   79: iload_3
/*     */     //   80: goto -> 43
/*     */     //   83: new java/lang/String
/*     */     //   86: dup
/*     */     //   87: aload_1
/*     */     //   88: invokespecial <init> : ([C)V
/*     */     //   91: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	92	0	a	Ljava/lang/String;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\SecureUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */