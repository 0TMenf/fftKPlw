/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.SocketException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NetUtil
/*     */ {
/*     */   public static String getLocalMacAddress() {
/*  61 */     return xXxXxx(IIIIiI())
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 101 */       .orElseGet(HandyHttpUtil::getIp);
/*     */   }
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_2
/*     */     //   1: iconst_5
/*     */     //   2: ixor
/*     */     //   3: iconst_3
/*     */     //   4: ishl
/*     */     //   5: iconst_3
/*     */     //   6: ixor
/*     */     //   7: iconst_2
/*     */     //   8: iconst_5
/*     */     //   9: ixor
/*     */     //   10: iconst_4
/*     */     //   11: ishl
/*     */     //   12: iconst_2
/*     */     //   13: iconst_3
/*     */     //   14: ishl
/*     */     //   15: iconst_5
/*     */     //   16: ixor
/*     */     //   17: aload_0
/*     */     //   18: checkcast java/lang/String
/*     */     //   21: dup
/*     */     //   22: astore_0
/*     */     //   23: invokevirtual length : ()I
/*     */     //   26: dup
/*     */     //   27: newarray char
/*     */     //   29: iconst_1
/*     */     //   30: dup
/*     */     //   31: pop2
/*     */     //   32: swap
/*     */     //   33: iconst_1
/*     */     //   34: isub
/*     */     //   35: dup_x2
/*     */     //   36: istore_3
/*     */     //   37: astore_1
/*     */     //   38: istore #4
/*     */     //   40: dup_x2
/*     */     //   41: pop
/*     */     //   42: istore_2
/*     */     //   43: pop
/*     */     //   44: iflt -> 84
/*     */     //   47: aload_1
/*     */     //   48: aload_0
/*     */     //   49: iload_3
/*     */     //   50: dup_x1
/*     */     //   51: invokevirtual charAt : (I)C
/*     */     //   54: iinc #3, -1
/*     */     //   57: iload_2
/*     */     //   58: ixor
/*     */     //   59: i2c
/*     */     //   60: castore
/*     */     //   61: iload_3
/*     */     //   62: iflt -> 84
/*     */     //   65: aload_1
/*     */     //   66: aload_0
/*     */     //   67: iload_3
/*     */     //   68: iinc #3, -1
/*     */     //   71: dup_x1
/*     */     //   72: invokevirtual charAt : (I)C
/*     */     //   75: iload #4
/*     */     //   77: ixor
/*     */     //   78: i2c
/*     */     //   79: castore
/*     */     //   80: iload_3
/*     */     //   81: goto -> 44
/*     */     //   84: new java/lang/String
/*     */     //   87: dup
/*     */     //   88: aload_1
/*     */     //   89: invokespecial <init> : ([C)V
/*     */     //   92: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	93	0	a	Ljava/lang/String;
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   private static interface cn/handyplus/warp/lib/G<T> {
/*     */     boolean IIiiiI(T param1T);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\NetUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */