/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public final class MapUtil
/*     */ {
/*     */   public static <K, V> HashMap<K, V> of(Object a, Object object1) {
/*   9 */     (new HashMap<>(oOOOOO(1)))
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 134 */       .put(a, object1);
/*     */     return (HashMap)new HashMap<>(oOOOOO(1));
/*     */   }
/*     */ 
/*     */   
/*     */   public static <K, V> HashMap<K, V> of(Object a, Object object1, Object object2, Object object3) {
/*     */     hashMap.put(object2, object3);
/*     */     HashMap<Object, Object> hashMap;
/*     */     return (HashMap<K, V>)(hashMap = new HashMap<>(oOOOOO(2))).put(a, object1);
/*     */   }
/*     */   
/*     */   public static <K, V> HashMap<K, V> of(Object a, Object object1, Object object2, Object object3, Object object4, Object object5) {
/*     */     hashMap.put(object4, object5);
/*     */     hashMap.put(object2, object3);
/*     */     HashMap<Object, Object> hashMap;
/*     */     return (HashMap<K, V>)(hashMap = new HashMap<>(oOOOOO(3))).put(a, object1);
/*     */   }
/*     */   
/*     */   public static <K, V> HashMap<K, V> of(Object a, Object object1, Object object2, Object object3, Object object4, Object object5, Object object6, Object object7) {
/*     */     HashMap<Object, Object> hashMap;
/* 154 */     hashMap.put(object6, object7);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     hashMap.put(object4, object5);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 178 */     return (HashMap<K, V>)hashMap.put(object2, object3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNotEmpty(Map<?, ?> a) {
/*     */     return !isEmpty(a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <K, V> HashMap<K, V> of() {
/*     */     return new HashMap<>(oOOOOO(0));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEmpty(Map a) {
/*     */     return (null == a || a.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Integer wMlgvU = Integer.valueOf(3);
/*     */ 
/*     */ 
/*     */   
/*     */   public static <K, V> HashMap<K, V> newHashMapWithExpectedSize(int a) {
/*     */     return new HashMap<>(oOOOOO(a));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static <K, V> HashMap<K, V> of(Object a, Object object1, Object object2, Object object3, Object object4, Object object5, Object object6, Object object7, Object object8, Object object9) {
/*     */     HashMap<Object, Object> hashMap;
/*     */     hashMap.put(object8, object9);
/*     */     hashMap.put(object6, object7);
/*     */     hashMap.put(object4, object5);
/* 218 */     return (HashMap<K, V>)hashMap.put(object2, object3);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\MapUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */