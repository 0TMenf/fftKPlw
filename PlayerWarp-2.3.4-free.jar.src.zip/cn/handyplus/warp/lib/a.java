package cn.handyplus.warp.lib;

import com.google.gson.reflect.TypeToken;
import java.util.Map;

public class a extends TypeToken<Map<String, Object>> {}


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */