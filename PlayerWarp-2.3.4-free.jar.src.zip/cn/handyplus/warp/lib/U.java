/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class U
/*     */   extends HandyRunnable
/*     */ {
/*     */   public void run() {
/*     */     try {
/*  60 */       HttpUtil.downloadFile(this.j.getUrl(), InitApi.PLUGIN.getDataFolder(), (new StringBuilder()).insert(0, this.j.getValue()).append(MessageUtil.qzlKeO(")UtPi")).toString());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       File file;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 140 */       if ((file = new File(InitApi.PLUGIN.getDataFolder(), (new StringBuilder()).insert(0, this.j.getValue()).append(RgbTextUtil.qzlKeO("\022+O.R")).toString())).exists()) {
/*     */         BaseUtil.readJsonFileToJsonCacheMap(file);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       cancel();
/*     */ 
/*     */       
/*     */       return;
/*     */     } catch (Exception exception) {
/*     */       this.IiIIiI.getAndDecrement();
/*     */ 
/*     */       
/*     */       if (this.IiIIiI.get() < 1)
/* 155 */         cancel(); 
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   public U(LanguageTypeEnum paramLanguageTypeEnum, AtomicInteger paramAtomicInteger) {}
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\U.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */