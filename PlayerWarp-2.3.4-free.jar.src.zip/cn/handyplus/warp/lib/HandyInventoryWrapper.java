/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HandyInventoryWrapper
/*     */ {
/*     */   public static void initListener(String a, List<?> list) {
/*     */     try {
/*     */       List<Class<?>> list1;
/*  30 */       if (CollUtil.isEmpty(
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  44 */           list1 = ClassUtil.getInstance().getClassByAnnotation(a, (Class)HandyListener.class))) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  64 */       Iterator<Class<?>> iterator = list1.iterator(); while (true) { if (iterator.hasNext()) { Class<Listener> clazz = (Class)iterator.next();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           if (CollUtil.isNotEmpty(list) && list.contains(clazz.getName())) {
/*     */           
/*     */           } else {
/*     */             HandyListener handyListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 186 */             if ((handyListener = (HandyListener)clazz.getAnnotation(HandyListener.class)) != null && 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 228 */               BaseConstants.VERSION_ID.intValue() >= handyListener.version().getVersionId().intValue())
/*     */               Bukkit.getServer().getPluginManager().registerEvents(clazz.newInstance(), (Plugin)InitApi.PLUGIN); 
/*     */             continue;
/*     */           }  }
/*     */         
/*     */         break; }
/*     */     
/*     */     } catch (Throwable throwable) {
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void initClickEvent(String a) {
/*     */     try {
/*     */       List<Class<IHandyClickEvent>> list;
/*     */       if (CollUtil.isEmpty(list = ClassUtil.getInstance().getClassByIsAssignableFrom(a, IHandyClickEvent.class)))
/*     */         return; 
/*     */       ArrayList<IHandyClickEvent> arrayList = new ArrayList();
/*     */       Iterator<Class<IHandyClickEvent>> iterator;
/*     */       if ((iterator = list.iterator()).hasNext()) {
/*     */         Class<IHandyClickEvent> clazz = iterator.next();
/*     */         arrayList.add(clazz.newInstance());
/*     */       } 
/*     */       HandyClickFactory.iIiIiI().IIIIII(arrayList);
/*     */       return;
/*     */     } catch (Throwable throwable) {
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\HandyInventoryWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */