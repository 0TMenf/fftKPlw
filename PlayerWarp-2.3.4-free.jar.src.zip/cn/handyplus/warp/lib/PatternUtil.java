/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PatternUtil
/*     */ {
/*     */   public static final Pattern BIG_DECIMAL_NUMERIC;
/*     */   public static final Pattern TIME_WITH_UNIT;
/*     */   
/*     */   public static String replaceAll(String a, String str1) {
/*  38 */     super(); return (new StringBuilder()).replaceAll(a.append(BcUtil.qzlKeO("Pt\021b")).append(Pattern.quote(str1)).toString(), "").trim();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  46 */     BIG_DECIMAL_NUMERIC = Pattern.compile(BcUtil.qzlKeO("Ut$/Sc$e$/SbGc#.=\026#`U\026G\027\034`Qt"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     RPG_PATTERN = Pattern.compile(NumberUtil.qzlKeO("\027pë\013o\r|{u7a0\r{\n\0137e1~sl\027fao-{*\027a\020\021-+ei"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     LINE_PATTERN = Pattern.compile(BcUtil.qzlKeO("\024P\027\017b"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     HUMP_PATTERN = Pattern.compile(NumberUtil.qzlKeO("\r\r{\026\013"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     TEMPLATE_EXPRESSION_REGEX = Pattern.compile(BcUtil.qzlKeO("$o$0PeRtQ6"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     AT_WORD_PATTERN = Pattern.compile(NumberUtil.qzlKeO("\f~\020!g"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     HTTP_CHARSET = Pattern.compile(BcUtil.qzlKeO("(\020*\n8\035?Ec#\027\017\027U\026Sb"), 2);
/*     */     DIGITS_ONLY = Pattern.compile(NumberUtil.qzlKeO("\n(}"));
/*     */     TIME_WITH_UNIT = Pattern.compile(BcUtil.qzlKeO("P\027\034`Qc#8\025#\034<52%b"));
/*     */   }
/*     */   
/*     */   public static final Pattern VERSION_PATTERN = Pattern.compile(NumberUtil.qzlKeO("\020~\001\025vvdip )$??#8r\n(}\020x\0202g~\020x\0202gs\020"));
/*     */   public static final Pattern LINE_PATTERN;
/*     */   public static final Pattern TEMPLATE_EXPRESSION_REGEX;
/*     */   public static final Pattern HUMP_PATTERN;
/*     */   public static final Pattern DIGITS_ONLY;
/*     */   public static final Pattern HTTP_CHARSET;
/*     */   public static final Pattern RPG_PATTERN;
/*     */   public static final Pattern AT_WORD_PATTERN;
/*     */   
/*     */   public static List<String> extractAtTags(String a) {
/*     */     // Byte code:
/*     */     //   0: new java/util/ArrayList
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: astore_1
/*     */     //   8: getstatic cn/handyplus/warp/lib/PatternUtil.AT_WORD_PATTERN : Ljava/util/regex/Pattern;
/*     */     //   11: aload_0
/*     */     //   12: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
/*     */     //   15: dup
/*     */     //   16: astore_2
/*     */     //   17: invokevirtual find : ()Z
/*     */     //   20: ifeq -> 40
/*     */     //   23: aload_1
/*     */     //   24: aload_2
/*     */     //   25: dup_x1
/*     */     //   26: iconst_1
/*     */     //   27: invokevirtual group : (I)Ljava/lang/String;
/*     */     //   30: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   35: pop
/*     */     //   36: goto -> 17
/*     */     //   39: athrow
/*     */     //   40: aload_1
/*     */     //   41: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #103	-> 0
/*     */     //   #149	-> 8
/*     */     //   #194	-> 17
/*     */     //   #176	-> 23
/*     */     //   #5	-> 40
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	42	0	a	Ljava/lang/String;
/*     */   }
/*     */   
/*     */   public static boolean isMatch(@NotNull String regex, String input) {
/*     */     if (StrUtil.isEmpty(input))
/*     */       return false; 
/*     */     try {
/*     */       return Pattern.matches(regex, input);
/*     */     } catch (PatternSyntaxException patternSyntaxException) {
/*     */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String replaceFirst(String a, String str1) {
/*     */     super();
/*     */     return (new StringBuilder()).replaceFirst(a.append(NumberUtil.qzlKeO("di%")).append(Pattern.quote(str1)).toString(), "").trim();
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\PatternUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */