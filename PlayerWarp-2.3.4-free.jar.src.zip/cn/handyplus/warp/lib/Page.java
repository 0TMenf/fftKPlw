/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import cn.handyplus.warp.service.WarpTpPlayerService;
/*     */ import java.util.List;
/*     */ import lombok.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Page<T>
/*     */ {
/*     */   private int j;
/*     */   private List<T> xXxXXX;
/*     */   
/*     */   @Generated
/*     */   public List<T> getRecords() {
/*  41 */     return this.xXxXXX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public Page(int i, List<T> list) {
/*  95 */     this.j = i; this.xXxXXX = list;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTotalPages(int i) {
/* 101 */     return (this.j + i - 1) / i; } @Generated
/* 102 */   public void setRecords(List<T> list) { this.xXxXXX = list; } @Generated public int hashCode() { int i = 59; i = (i = 1) * 59 + getTotal(); List<T> list = getRecords(); return i = i * 59 + ((list == null) ? 43 : list.hashCode()); } @Generated public boolean equals(Object object) { if (object == this) return true;  if (!(object instanceof Page)) return false;  if (!(object = object).OoOOoo(this)) return false;  if (getTotal() != object.getTotal()) return false;  List<T> list = getRecords(); object = object.getRecords(); return !((list == null) ? (object != null) : !list.equals(object)); } @Generated public String toString() { return (new StringBuilder()).insert(0, WarpTpPlayerService.qzlKeO("{bLf\003wDwJo\026")).append(getTotal()).append(HandyHttpUtil.qzlKeO("o\0001E O1D0\035")).append(getRecords()).append(")").toString(); } @Generated public boolean OoOOoo(Object object) { return object instanceof Page; } @Generated public void setTotal(int i) { this.j = i; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public int getTotal() {
/* 150 */     return this.j;
/*     */   }
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_1
/*     */     //   1: iconst_3
/*     */     //   2: ishl
/*     */     //   3: iconst_4
/*     */     //   4: ixor
/*     */     //   5: iconst_3
/*     */     //   6: iconst_5
/*     */     //   7: ixor
/*     */     //   8: iconst_3
/*     */     //   9: ishl
/*     */     //   10: iconst_3
/*     */     //   11: ixor
/*     */     //   12: iconst_4
/*     */     //   13: iconst_3
/*     */     //   14: ishl
/*     */     //   15: iconst_3
/*     */     //   16: ixor
/*     */     //   17: aload_0
/*     */     //   18: checkcast java/lang/String
/*     */     //   21: dup
/*     */     //   22: astore_0
/*     */     //   23: invokevirtual length : ()I
/*     */     //   26: dup
/*     */     //   27: newarray char
/*     */     //   29: iconst_1
/*     */     //   30: dup
/*     */     //   31: pop2
/*     */     //   32: swap
/*     */     //   33: iconst_1
/*     */     //   34: isub
/*     */     //   35: dup_x2
/*     */     //   36: istore_3
/*     */     //   37: astore_1
/*     */     //   38: istore #4
/*     */     //   40: dup_x2
/*     */     //   41: pop2
/*     */     //   42: istore_2
/*     */     //   43: iflt -> 83
/*     */     //   46: aload_1
/*     */     //   47: aload_0
/*     */     //   48: iload_3
/*     */     //   49: dup_x1
/*     */     //   50: invokevirtual charAt : (I)C
/*     */     //   53: iinc #3, -1
/*     */     //   56: iload_2
/*     */     //   57: ixor
/*     */     //   58: i2c
/*     */     //   59: castore
/*     */     //   60: iload_3
/*     */     //   61: iflt -> 83
/*     */     //   64: aload_1
/*     */     //   65: aload_0
/*     */     //   66: iload_3
/*     */     //   67: iinc #3, -1
/*     */     //   70: dup_x1
/*     */     //   71: invokevirtual charAt : (I)C
/*     */     //   74: iload #4
/*     */     //   76: ixor
/*     */     //   77: i2c
/*     */     //   78: castore
/*     */     //   79: iload_3
/*     */     //   80: goto -> 43
/*     */     //   83: new java/lang/String
/*     */     //   86: dup
/*     */     //   87: aload_1
/*     */     //   88: invokespecial <init> : ([C)V
/*     */     //   91: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	92	0	a	Ljava/lang/String;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\Page.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */