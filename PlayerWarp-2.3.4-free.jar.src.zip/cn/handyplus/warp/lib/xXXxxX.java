/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import cn.handyplus.warp.service.WarpCollectionService;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.invoke.SerializedLambda;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class xXXxxX
/*     */ {
/*     */   public static <T> String oooOoo(DbFunction a) {
/*  18 */     Class<?> clazz = a.getClass();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String str2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  52 */     if ((str2 = OoOooO.get(clazz)) != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 170 */       return str2;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */       true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       method = WarpCollectionService.qzlKeO("0D.B\"d\"F+W$S").getDeclaredMethod((String)new Class[0], true);
/*     */     } catch (NoSuchMethodException noSuchMethodException) {
/*     */       throw new RuntimeException(noSuchMethodException);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     boolean bool = method.isAccessible(); method.setAccessible(true); try {
/*     */       true; serializedLambda = (SerializedLambda)a.invoke(new Object[0], true);
/*     */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {
/*     */       throw new RuntimeException(illegalAccessException);
/*     */     }  method.setAccessible(bool); String str3 = serializedLambda.getImplMethodName().substring(BcUtil.qzlKeO(",\035?").length()); super(); Method method;
/*     */     SerializedLambda serializedLambda;
/*     */     str3 = str3.replaceFirst(str3.append(str3.charAt(0)).append("").toString(), (str3.charAt(0) + "").toLowerCase());
/*     */     
/* 218 */     try { Field field = Class.forName(serializedLambda.getImplClass().replace(WarpCollectionService.qzlKeO("\031"), ".")).getDeclaredField(str3); } catch (ClassNotFoundException|NoSuchFieldException classNotFoundException) { throw new RuntimeException(classNotFoundException); }  TableField tableField; if ((tableField = field.<Annotation>getAnnotation(TableField.class)) == null || StrUtil.isEmpty(tableField.value()))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 225 */       throw new RuntimeException(BcUtil.qzlKeO("\037\031)\024.>\"\035'\034k乂稱"));
/*     */     }
/*     */     String str1 = tableField.value();
/*     */     OoOooO.put(clazz, str1);
/*     */     return str1;
/*     */   }
/*     */   
/*     */   private static final Map<Class<?>, String> OoOooO = new ConcurrentHashMap<>();
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\xXXxxX.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */