/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import com.google.common.collect.ImmutableMap;
/*     */ import com.google.common.collect.Iterables;
/*     */ import com.google.common.io.ByteArrayDataInput;
/*     */ import com.google.common.io.ByteArrayDataOutput;
/*     */ import com.google.common.io.ByteStreams;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.logging.Level;
/*     */ import lombok.Generated;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ public final class BcUtil
/*     */ {
/*     */   private static final String H = "PlayerList";
/*     */   private static final String a = "GetServer";
/*     */   private static final String L = "Connect";
/*     */   private static final String K = "PlayerCount";
/*     */   public static final String BUNGEE_CORD_CHANNEL = "BungeeCord";
/*     */   private static final String j = "Forward";
/*     */   private static final String xxXxxx = "ALL";
/*     */   
/*     */   public static void registerOut() {
/*  31 */     Bukkit.getMessenger().registerOutgoingPluginChannel((Plugin)InitApi.PLUGIN, "BungeeCord");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Optional<String> getContentByForward(byte[] a) {
/*     */     ByteArrayDataInput byteArrayDataInput;
/* 149 */     String str = (byteArrayDataInput = ByteStreams.newDataInput(a)).readUTF();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     if (!"BungeeCord".equals(str)) {
/*     */       return Optional.empty();
/*     */     }
/*     */     true;
/*     */     boolean bool;
/*     */     (new byte[byteArrayDataInput.readShort()]).readFully(bool = true);
/*     */     return Optional.of(ByteStreams.newDataInput(bool).readUTF());
/*     */   }
/*     */ 
/*     */   
/*     */   public static void sendPlayerCount() {
/*     */     Player player;
/*     */     if ((player = (Player)Iterables.getFirst(Bukkit.getOnlinePlayers(), null)) == null) {
/*     */       return;
/*     */     }
/*     */     ByteArrayDataOutput byteArrayDataOutput = ByteStreams.newDataOutput();
/*     */     byteArrayDataOutput.writeUTF("PlayerCount");
/*     */     byteArrayDataOutput.writeUTF("ALL");
/*     */     player.sendPluginMessage((Plugin)InitApi.PLUGIN, "BungeeCord", byteArrayDataOutput.toByteArray());
/*     */   }
/*     */ 
/*     */   
/*     */   public static void sendParamForward(Player a, BcMessageParam bcMessageParam) {
/*     */     sendForward(a, JsonUtil.toJson(bcMessageParam));
/*     */   }
/*     */   
/*     */   public static void unregisterOut() {
/*     */     Bukkit.getMessenger().unregisterOutgoingPluginChannel((Plugin)InitApi.PLUGIN, "BungeeCord");
/*     */   }
/*     */   
/*     */   public static void sendParamForward(CommandSender a, BcMessageParam bcMessageParam) {
/*     */     sendForward(a, JsonUtil.toJson(bcMessageParam));
/*     */   }
/*     */   
/*     */   public static Optional<BcMessageParam> getParamByForward(byte[] a) {
/*     */     Optional<String> optional;
/* 230 */     if (!(optional = getContentByForward(a)).isPresent()) return Optional.empty();  MessageUtil.sendConsoleDebugMessage((new StringBuilder()).insert(0, RgbTextUtil.qzlKeO("淉恓凄宅乻\006")).append(optional.get()).toString()); BcMessageParam bcMessageParam; if ((bcMessageParam = JsonUtil.toBean(optional.get(), BcMessageParam.class)) == null || StrUtil.isEmpty(bcMessageParam.getPluginName()) || !InitApi.PLUGIN.getName().equals(bcMessageParam.getPluginName()))
/*     */       return Optional.empty();  return Optional.of(bcMessageParam); } public static void sendGetServer() { Player player; if ((player = (Player)Iterables.getFirst(Bukkit.getOnlinePlayers(), null)) == null)
/* 232 */       return;  ByteArrayDataOutput byteArrayDataOutput = ByteStreams.newDataOutput(); byteArrayDataOutput.writeUTF("GetServer"); player.sendPluginMessage((Plugin)InitApi.PLUGIN, "BungeeCord", byteArrayDataOutput.toByteArray()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sendForward(Player a, String str) {
/*     */     ByteArrayDataOutput byteArrayDataOutput1 = ByteStreams.newDataOutput();
/*     */     byteArrayDataOutput1.writeUTF("Forward");
/*     */     byteArrayDataOutput1.writeUTF("ALL");
/*     */     byteArrayDataOutput1.writeUTF("BungeeCord");
/*     */     ByteArrayDataOutput byteArrayDataOutput2;
/*     */     (byteArrayDataOutput2 = ByteStreams.newDataOutput()).writeUTF(str);
/*     */     byteArrayDataOutput1.writeShort(((byteArrayDataOutput2 = ByteStreams.newDataOutput()).toByteArray()).length);
/*     */     byteArrayDataOutput1.write(byteArrayDataOutput2.toByteArray());
/*     */     a.sendPluginMessage((Plugin)InitApi.PLUGIN, "BungeeCord", byteArrayDataOutput1.toByteArray());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Optional<String> getServerName(byte[] a) {
/*     */     ByteArrayDataInput byteArrayDataInput;
/*     */     String str = (byteArrayDataInput = ByteStreams.newDataInput(a)).readUTF();
/*     */     if (!"GetServer".equals(str)) {
/*     */       return Optional.empty();
/*     */     }
/*     */     return Optional.of(byteArrayDataInput.readUTF());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void tpConnect(Player a, String str) {
/*     */     ByteArrayDataOutput byteArrayDataOutput = ByteStreams.newDataOutput();
/*     */     byteArrayDataOutput.writeUTF("Connect");
/*     */     byteArrayDataOutput.writeUTF(str);
/*     */     a.sendPluginMessage((Plugin)InitApi.PLUGIN, "BungeeCord", byteArrayDataOutput.toByteArray());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sendForward(CommandSender a, String str) {
/*     */     Player player = BaseUtil.isPlayer(a).booleanValue() ? (Player)a : (Player)Iterables.getFirst(Bukkit.getOnlinePlayers(), null);
/*     */     if (player == null) {
/*     */       return;
/*     */     }
/*     */     sendForward(player, str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, Integer> getPlayerCount(byte[] a) {
/*     */     try {
/*     */       ByteArrayDataInput byteArrayDataInput;
/*     */       String str = (byteArrayDataInput = ByteStreams.newDataInput(a)).readUTF();
/*     */       if (!"PlayerCount".equals(str)) {
/*     */         return MapUtil.of();
/*     */       }
/*     */       str = byteArrayDataInput.readUTF();
/*     */       int i = byteArrayDataInput.readInt();
/*     */       return (Map<String, Integer>)ImmutableMap.of(str, Integer.valueOf(i));
/* 489 */     } catch (Exception exception) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 628 */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, StrUtil.qzlKeO("<P/e7T\"P)v4@5A{古畄強幣"), exception);
/*     */       return MapUtil.of();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void sendPlayerList() {
/*     */     Player player;
/*     */     if ((player = (Player)Iterables.getFirst(Bukkit.getOnlinePlayers(), null)) == null) {
/*     */       return;
/*     */     }
/*     */     ByteArrayDataOutput byteArrayDataOutput = ByteStreams.newDataOutput();
/*     */     byteArrayDataOutput.writeUTF("PlayerList");
/*     */     byteArrayDataOutput.writeUTF("ALL");
/*     */     player.sendPluginMessage((Plugin)InitApi.PLUGIN, "BungeeCord", byteArrayDataOutput.toByteArray());
/*     */   }
/*     */   
/*     */   public static List<String> getPlayerList(byte[] a) {
/*     */     try {
/*     */       ByteArrayDataInput byteArrayDataInput;
/*     */       String str = (byteArrayDataInput = ByteStreams.newDataInput(a)).readUTF();
/*     */       if (!"PlayerList".equals(str)) {
/*     */         return new ArrayList<>();
/*     */       }
/*     */       str = byteArrayDataInput.readUTF();
/*     */       return StrUtil.strToStrList(byteArrayDataInput.readUTF(), RgbTextUtil.qzlKeO("\020"));
/*     */     } catch (Exception exception) {
/*     */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, StrUtil.qzlKeO("R>A\013Y:L>G\027\\(A{古畄強幣"), exception);
/*     */       return new ArrayList<>();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_4
/*     */     //   1: dup
/*     */     //   2: ishl
/*     */     //   3: iconst_2
/*     */     //   4: dup
/*     */     //   5: ishl
/*     */     //   6: iconst_3
/*     */     //   7: ixor
/*     */     //   8: ixor
/*     */     //   9: iconst_4
/*     */     //   10: dup
/*     */     //   11: ishl
/*     */     //   12: iconst_4
/*     */     //   13: iconst_1
/*     */     //   14: ishl
/*     */     //   15: ixor
/*     */     //   16: iconst_2
/*     */     //   17: iconst_5
/*     */     //   18: ixor
/*     */     //   19: iconst_4
/*     */     //   20: ishl
/*     */     //   21: iconst_4
/*     */     //   22: iconst_1
/*     */     //   23: ishl
/*     */     //   24: ixor
/*     */     //   25: aload_0
/*     */     //   26: checkcast java/lang/String
/*     */     //   29: dup
/*     */     //   30: astore_0
/*     */     //   31: invokevirtual length : ()I
/*     */     //   34: dup
/*     */     //   35: newarray char
/*     */     //   37: iconst_1
/*     */     //   38: dup
/*     */     //   39: pop2
/*     */     //   40: swap
/*     */     //   41: iconst_1
/*     */     //   42: isub
/*     */     //   43: dup_x2
/*     */     //   44: istore_3
/*     */     //   45: astore_1
/*     */     //   46: istore #4
/*     */     //   48: dup_x2
/*     */     //   49: pop2
/*     */     //   50: istore_2
/*     */     //   51: iflt -> 91
/*     */     //   54: aload_1
/*     */     //   55: aload_0
/*     */     //   56: iload_3
/*     */     //   57: dup_x1
/*     */     //   58: invokevirtual charAt : (I)C
/*     */     //   61: iinc #3, -1
/*     */     //   64: iload_2
/*     */     //   65: ixor
/*     */     //   66: i2c
/*     */     //   67: castore
/*     */     //   68: iload_3
/*     */     //   69: iflt -> 91
/*     */     //   72: aload_1
/*     */     //   73: aload_0
/*     */     //   74: iload_3
/*     */     //   75: iinc #3, -1
/*     */     //   78: dup_x1
/*     */     //   79: invokevirtual charAt : (I)C
/*     */     //   82: iload #4
/*     */     //   84: ixor
/*     */     //   85: i2c
/*     */     //   86: castore
/*     */     //   87: iload_3
/*     */     //   88: goto -> 51
/*     */     //   91: new java/lang/String
/*     */     //   94: dup
/*     */     //   95: aload_1
/*     */     //   96: invokespecial <init> : ([C)V
/*     */     //   99: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	100	0	a	Ljava/lang/String;
/*     */   }
/*     */   
/*     */   public static class BcMessageParam
/*     */   {
/*     */     private String a;
/*     */     private String L;
/*     */     private Long K;
/*     */     private String j;
/*     */     private String pPpppp;
/*     */     
/*     */     @Generated
/*     */     public String getPluginName() {
/*     */       return this.a;
/*     */     }
/*     */     
/*     */     @Generated
/*     */     public Long getTimestamp() {
/*     */       return this.K;
/*     */     }
/*     */     
/*     */     @Generated
/*     */     public String getMessage() {
/*     */       return this.L;
/*     */     }
/*     */     
/*     */     @Generated
/*     */     public String getPlayerName() {
/*     */       return this.pPpppp;
/*     */     }
/*     */     
/*     */     @Generated
/*     */     public String getType() {
/*     */       return this.j;
/*     */     }
/*     */     
/*     */     @Generated
/*     */     public void setMessage(String str)
/*     */     {
/* 699 */       this.L = str; } @Generated public void setPluginName(String str) { this.a = str; } @Generated public void setTimestamp(Long long_) { this.K = long_; } @Generated public void setPlayerName(String str) { this.pPpppp = str; } @Generated public void setType(String str) { this.j = str; }
/*     */   
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\BcUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */