/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import com.google.gson.JsonObject;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.logging.Level;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HandyHttpUtil
/*     */ {
/*     */   private static final String K = "https://admin.ljxmc.top/api/public/getIp";
/*     */   private static final String j = "https://admin.ljxmc.top/api/public/getItemName";
/*     */   private static final String OoOOoO = "https://ricedoc.handyplus.cn/version.json";
/*     */   
/*     */   public static void checkVersion(Player a) {
/*  43 */     if (a != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 124 */       if (!a.isOp()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       if (!BaseConstants.IS_CHECK_UPDATE_TO_OP_MSG) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     HandySchedulerUtil.runTaskAsynchronously(() -> { String str = InitApi.PLUGIN.getDescription().getVersion(); Optional<String> optional; if (!(optional = IiiIIi()).isPresent())
/*     */             return;  if (BaseUtil.convertVersion((String)optional.get()).intValue() > BaseUtil.convertVersion(str).intValue()) {
/*     */             RgbTextUtil rgbTextUtil = RgbTextUtil.init((new StringBuilder()).insert(0, StrUtil.qzlKeO("}\002\004j\004j\004j\004j\004j\004j\004j\004j\004\032{\023>")).append(InitApi.PLUGIN.getDescription().getName()).append(BcUtil.qzlKeO("^|X\027'\024'\024'\024'\024'\024'\024'\024'\024'A")).toString()); str = (new StringBuilder()).insert(0, StrUtil.qzlKeO("\023lI{\023:朵旫牽杷\017{\023?")).append(optional.get()).append(BcUtil.qzlKeO("k^*弫分爰杧Bk^/")).append(str).append(StrUtil.qzlKeO("\025}T烢凎}Q}[欿失枾眾}T暯斅凞完{\023lIQ")).toString(); super(); rgbTextUtil.addExtra(RgbTextUtil.init(StrUtil.qzlKeO("}\002v\030v\030v\030v\030v\030v\030v\030v\030v\030v\030v\030v\030v\030v\030v\030v\030v\030v\030v\030v\030v\030v\030v\030v")));
/*     */           } 
/*     */         }); } public static void getCloudI18nJson(LanguageTypeEnum a) { if (BaseConstants.VERSION_ID.intValue() < VersionCheckEnum.V_1_13.getVersionId().intValue())
/* 215 */       return;  AtomicInteger atomicInteger = new AtomicInteger(6); HandySchedulerUtil.runTaskTimerAsynchronously(new U(a, atomicInteger), 40L, 1200L); }
/*     */ 
/*     */   
/*     */   public static String getIp() {
/*     */     try {
/*     */       return HttpUtil.get("https://admin.ljxmc.top/api/public/getIp");
/*     */     } catch (Exception exception) {
/* 222 */       InitApi.PLUGIN.getLogger().log(Level.SEVERE, BcUtil.qzlKeO(",\035?1;X厚畧彉幀g讏耟粃彋厩聎"), exception);
/*     */       return "";
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void getCloudItem(LanguageTypeEnum a) {
/*     */     if (BaseConstants.VERSION_ID.intValue() >= VersionCheckEnum.V_1_13.getVersionId().intValue())
/*     */       return; 
/*     */     AtomicInteger atomicInteger = new AtomicInteger(6);
/*     */     HandySchedulerUtil.runTaskTimerAsynchronously(new N(a, atomicInteger), 60L, 1200L);
/*     */   }
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_4
/*     */     //   1: iconst_3
/*     */     //   2: ishl
/*     */     //   3: iconst_5
/*     */     //   4: iconst_3
/*     */     //   5: ishl
/*     */     //   6: iconst_4
/*     */     //   7: ixor
/*     */     //   8: iconst_4
/*     */     //   9: dup
/*     */     //   10: ishl
/*     */     //   11: iconst_3
/*     */     //   12: ixor
/*     */     //   13: aload_0
/*     */     //   14: checkcast java/lang/String
/*     */     //   17: dup
/*     */     //   18: astore_0
/*     */     //   19: invokevirtual length : ()I
/*     */     //   22: dup
/*     */     //   23: newarray char
/*     */     //   25: iconst_1
/*     */     //   26: dup
/*     */     //   27: pop2
/*     */     //   28: swap
/*     */     //   29: iconst_1
/*     */     //   30: isub
/*     */     //   31: dup_x2
/*     */     //   32: istore_3
/*     */     //   33: astore_1
/*     */     //   34: istore #4
/*     */     //   36: dup_x2
/*     */     //   37: pop2
/*     */     //   38: istore_2
/*     */     //   39: iflt -> 79
/*     */     //   42: aload_1
/*     */     //   43: aload_0
/*     */     //   44: iload_3
/*     */     //   45: dup_x1
/*     */     //   46: invokevirtual charAt : (I)C
/*     */     //   49: iinc #3, -1
/*     */     //   52: iload_2
/*     */     //   53: ixor
/*     */     //   54: i2c
/*     */     //   55: castore
/*     */     //   56: iload_3
/*     */     //   57: iflt -> 79
/*     */     //   60: aload_1
/*     */     //   61: aload_0
/*     */     //   62: iload_3
/*     */     //   63: iinc #3, -1
/*     */     //   66: dup_x1
/*     */     //   67: invokevirtual charAt : (I)C
/*     */     //   70: iload #4
/*     */     //   72: ixor
/*     */     //   73: i2c
/*     */     //   74: castore
/*     */     //   75: iload_3
/*     */     //   76: goto -> 39
/*     */     //   79: new java/lang/String
/*     */     //   82: dup
/*     */     //   83: aload_1
/*     */     //   84: invokespecial <init> : ([C)V
/*     */     //   87: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	88	0	a	Ljava/lang/String;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\HandyHttpUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */