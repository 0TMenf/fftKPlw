package cn.handyplus.warp.lib;

import com.google.gson.reflect.TypeToken;
import java.util.Map;

public class h extends TypeToken<Map<Integer, String>> {}


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\h.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */