/*     */ package cn.handyplus.warp.lib;public class PtdKXl { private String j; private String XxXXXx;
/*     */   
/*     */   @Generated
/*   4 */   public PtdKXl(String str1, String str2) { this.XxXXXx = str1; this.j = str2; } @Generated public static foParam$TableInfoParamBuilder OoOOoo() { return new foParam$TableInfoParamBuilder(); } @Generated public static class foParam$TableInfoParamBuilder { @Generated private String j; @Generated public String toString() { return (new StringBuilder()).insert(0, Page.qzlKeO("XBnOijbEcsmQmN\"wmA`FEMjL\\B~BaayJ`GiQ$WmA`FBBaF1")).append(this.j).append(BcUtil.qzlKeO("gX?\031)\024.;$\025&\035%\fv")).append(this.XxXxxX).append(")").toString(); } @Generated private String XxXxxX; @Generated public foParam$TableInfoParamBuilder tableComment(String str) { this.XxXxxX = str; return this; } @Generated public foParam$TableInfoParamBuilder tableName(String str) { this.j = str; return this; } @Generated public PtdKXl build() { return new PtdKXl(this.j, this.XxXxxX); }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public String l() {
/*  35 */     return this.j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public void l(String str)
/*     */   {
/*  95 */     this.XxXXXx = str; } @Generated public void IIiiIi(String str) { this.j = str; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Generated
/*     */   public String PpppPp() {
/* 165 */     return this.XxXXXx;
/*     */   } }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\PtdKXl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */