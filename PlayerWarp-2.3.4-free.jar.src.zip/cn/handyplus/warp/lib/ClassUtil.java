/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import cn.handyplus.warp.service.WarpTpPlayerService;
/*     */ import java.io.File;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.net.URLDecoder;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClassUtil
/*     */ {
/*     */   private static final String L = ".class";
/*     */   private final File K;
/*     */   private static ClassUtil j;
/*     */   private final ClassLoader pPPPpP = InitApi.PLUGIN.getClass().getClassLoader();
/*     */   
/*     */   public <T> List<Class<T>> getClassByIsAssignableFrom(String a, Class a) {
/*     */     // Byte code:
/*     */     //   0: new java/util/ArrayList
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: astore_3
/*     */     //   8: aload_0
/*     */     //   9: getfield K : Ljava/io/File;
/*     */     //   12: invokevirtual toURI : ()Ljava/net/URI;
/*     */     //   15: invokevirtual toURL : ()Ljava/net/URL;
/*     */     //   18: astore #4
/*     */     //   20: new java/net/URLClassLoader
/*     */     //   23: dup
/*     */     //   24: iconst_1
/*     */     //   25: anewarray java/net/URL
/*     */     //   28: iconst_1
/*     */     //   29: dup
/*     */     //   30: pop2
/*     */     //   31: dup
/*     */     //   32: iconst_0
/*     */     //   33: aload #4
/*     */     //   35: aastore
/*     */     //   36: aload_0
/*     */     //   37: getfield pPPPpP : Ljava/lang/ClassLoader;
/*     */     //   40: invokespecial <init> : ([Ljava/net/URL;Ljava/lang/ClassLoader;)V
/*     */     //   43: astore #5
/*     */     //   45: new java/util/jar/JarInputStream
/*     */     //   48: dup
/*     */     //   49: aload #4
/*     */     //   51: invokevirtual openStream : ()Ljava/io/InputStream;
/*     */     //   54: invokespecial <init> : (Ljava/io/InputStream;)V
/*     */     //   57: astore #4
/*     */     //   59: aload #4
/*     */     //   61: invokevirtual getNextJarEntry : ()Ljava/util/jar/JarEntry;
/*     */     //   64: dup
/*     */     //   65: astore #6
/*     */     //   67: ifnonnull -> 76
/*     */     //   70: aload #4
/*     */     //   72: goto -> 149
/*     */     //   75: athrow
/*     */     //   76: aload_0
/*     */     //   77: aload #6
/*     */     //   79: invokespecial IIIiiI : (Ljava/util/jar/JarEntry;)Ljava/lang/String;
/*     */     //   82: dup
/*     */     //   83: astore #7
/*     */     //   85: ifnonnull -> 94
/*     */     //   88: aload #4
/*     */     //   90: goto -> 61
/*     */     //   93: athrow
/*     */     //   94: aload #7
/*     */     //   96: aload_1
/*     */     //   97: invokevirtual startsWith : (Ljava/lang/String;)Z
/*     */     //   100: ifeq -> 59
/*     */     //   103: iconst_0
/*     */     //   104: aload #7
/*     */     //   106: dup_x1
/*     */     //   107: ldc '.class'
/*     */     //   109: invokevirtual lastIndexOf : (Ljava/lang/String;)I
/*     */     //   112: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   115: astore #8
/*     */     //   117: aload #5
/*     */     //   119: aload #8
/*     */     //   121: invokevirtual loadClass : (Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   124: astore #8
/*     */     //   126: aload_2
/*     */     //   127: aload #8
/*     */     //   129: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
/*     */     //   132: ifeq -> 59
/*     */     //   135: aload_3
/*     */     //   136: aload #8
/*     */     //   138: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   143: pop
/*     */     //   144: goto -> 59
/*     */     //   147: nop
/*     */     //   148: athrow
/*     */     //   149: invokevirtual close : ()V
/*     */     //   152: aload #5
/*     */     //   154: goto -> 182
/*     */     //   157: astore #6
/*     */     //   159: aload #4
/*     */     //   161: invokevirtual close : ()V
/*     */     //   164: aload #6
/*     */     //   166: goto -> 179
/*     */     //   169: astore #7
/*     */     //   171: aload #6
/*     */     //   173: dup
/*     */     //   174: aload #7
/*     */     //   176: invokevirtual addSuppressed : (Ljava/lang/Throwable;)V
/*     */     //   179: athrow
/*     */     //   180: nop
/*     */     //   181: athrow
/*     */     //   182: invokevirtual close : ()V
/*     */     //   185: aload_3
/*     */     //   186: areturn
/*     */     //   187: astore #4
/*     */     //   189: aload #5
/*     */     //   191: invokevirtual close : ()V
/*     */     //   194: aload #4
/*     */     //   196: goto -> 209
/*     */     //   199: astore #6
/*     */     //   201: aload #4
/*     */     //   203: dup
/*     */     //   204: aload #6
/*     */     //   206: invokevirtual addSuppressed : (Ljava/lang/Throwable;)V
/*     */     //   209: athrow
/*     */     //   210: athrow
/*     */     //   211: athrow
/*     */     //   212: astore_3
/*     */     //   213: aload_3
/*     */     //   214: athrow
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #63	-> 0
/*     */     //   #90	-> 8
/*     */     //   #113	-> 20
/*     */     //   #23	-> 45
/*     */     //   #29	-> 59
/*     */     //   #155	-> 67
/*     */     //   #19	-> 72
/*     */     //   #123	-> 76
/*     */     //   #20	-> 85
/*     */     //   #215	-> 90
/*     */     //   #177	-> 94
/*     */     //   #71	-> 103
/*     */     //   #99	-> 117
/*     */     //   #118	-> 126
/*     */     //   #27	-> 135
/*     */     //   #158	-> 144
/*     */     //   #230	-> 147
/*     */     //   #113	-> 157
/*     */     //   #230	-> 180
/*     */     //   #113	-> 187
/*     */     //   #193	-> 210
/*     */     //   #60	-> 212
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	215	0	a	Lcn/handyplus/warp/lib/ClassUtil;
/*     */     //   0	215	1	a	Ljava/lang/String;
/*     */     //   0	215	2	a	Ljava/lang/Class;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   0	75	212	java/lang/Throwable
/*     */     //   45	75	187	java/lang/Throwable
/*     */     //   59	75	157	java/lang/Throwable
/*     */     //   76	93	157	java/lang/Throwable
/*     */     //   76	93	187	java/lang/Throwable
/*     */     //   76	93	212	java/lang/Throwable
/*     */     //   94	147	157	java/lang/Throwable
/*     */     //   94	147	187	java/lang/Throwable
/*     */     //   94	147	212	java/lang/Throwable
/*     */     //   149	180	187	java/lang/Throwable
/*     */     //   149	180	212	java/lang/Throwable
/*     */     //   159	164	169	java/lang/Throwable
/*     */     //   182	210	212	java/lang/Throwable
/*     */     //   189	194	199	java/lang/Throwable
/*     */   }
/*     */   
/*     */   public List<Class<?>> getClassByAnnotation(String str, Class clazz) {
/*     */     
/*     */     try { URLClassLoader uRLClassLoader;
/*  80 */       ArrayList arrayList = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       URL uRL = this.K.toURI().toURL();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 201 */       true; true[0] = uRL; super(true, this.pPPPpP);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 223 */       try { JarInputStream jarInputStream = new JarInputStream(uRL.openStream()); try { while (true)
/* 224 */             JarEntry jarEntry;  } catch (Throwable throwable) { try { jarInputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Throwable throwable) { try { uRLClassLoader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Throwable throwable) { throw throwable; }
/*     */   
/*     */   }
/*     */   
/*     */   public static ClassUtil getInstance() {
/*     */     if (j == null)
/*     */       j = new ClassUtil(); 
/*     */     return j;
/*     */   }
/*     */   
/*     */   public Map<Class<?>, List<Method>> getMethodByAnnotation(String a, Class a) {
/*     */     // Byte code:
/*     */     //   0: invokestatic of : ()Ljava/util/HashMap;
/*     */     //   3: astore_3
/*     */     //   4: aload_0
/*     */     //   5: getfield K : Ljava/io/File;
/*     */     //   8: invokevirtual toURI : ()Ljava/net/URI;
/*     */     //   11: invokevirtual toURL : ()Ljava/net/URL;
/*     */     //   14: astore #4
/*     */     //   16: new java/net/URLClassLoader
/*     */     //   19: dup
/*     */     //   20: iconst_1
/*     */     //   21: anewarray java/net/URL
/*     */     //   24: iconst_1
/*     */     //   25: dup
/*     */     //   26: pop2
/*     */     //   27: dup
/*     */     //   28: iconst_0
/*     */     //   29: aload #4
/*     */     //   31: aastore
/*     */     //   32: aload_0
/*     */     //   33: getfield pPPPpP : Ljava/lang/ClassLoader;
/*     */     //   36: invokespecial <init> : ([Ljava/net/URL;Ljava/lang/ClassLoader;)V
/*     */     //   39: astore #5
/*     */     //   41: new java/util/jar/JarInputStream
/*     */     //   44: dup
/*     */     //   45: aload #4
/*     */     //   47: invokevirtual openStream : ()Ljava/io/InputStream;
/*     */     //   50: invokespecial <init> : (Ljava/io/InputStream;)V
/*     */     //   53: astore #4
/*     */     //   55: aload #4
/*     */     //   57: invokevirtual getNextJarEntry : ()Ljava/util/jar/JarEntry;
/*     */     //   60: dup
/*     */     //   61: astore #6
/*     */     //   63: ifnonnull -> 72
/*     */     //   66: aload #4
/*     */     //   68: goto -> 195
/*     */     //   71: athrow
/*     */     //   72: aload_0
/*     */     //   73: aload #6
/*     */     //   75: invokespecial IIIiiI : (Ljava/util/jar/JarEntry;)Ljava/lang/String;
/*     */     //   78: dup
/*     */     //   79: astore #7
/*     */     //   81: ifnonnull -> 90
/*     */     //   84: aload #4
/*     */     //   86: goto -> 57
/*     */     //   89: athrow
/*     */     //   90: aload #7
/*     */     //   92: aload_1
/*     */     //   93: invokevirtual startsWith : (Ljava/lang/String;)Z
/*     */     //   96: ifeq -> 55
/*     */     //   99: new java/util/ArrayList
/*     */     //   102: dup
/*     */     //   103: invokespecial <init> : ()V
/*     */     //   106: astore #8
/*     */     //   108: iconst_0
/*     */     //   109: aload #7
/*     */     //   111: dup_x1
/*     */     //   112: ldc '.class'
/*     */     //   114: invokevirtual lastIndexOf : (Ljava/lang/String;)I
/*     */     //   117: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   120: astore #9
/*     */     //   122: aload #5
/*     */     //   124: aload #9
/*     */     //   126: invokevirtual loadClass : (Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   129: dup
/*     */     //   130: astore #9
/*     */     //   132: invokevirtual getDeclaredMethods : ()[Ljava/lang/reflect/Method;
/*     */     //   135: invokestatic of : ([Ljava/lang/Object;)Ljava/util/stream/Stream;
/*     */     //   138: aload_2
/*     */     //   139: <illegal opcode> test : (Ljava/lang/Class;)Ljava/util/function/Predicate;
/*     */     //   144: invokeinterface filter : (Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
/*     */     //   149: invokestatic toList : ()Ljava/util/stream/Collector;
/*     */     //   152: invokeinterface collect : (Ljava/util/stream/Collector;)Ljava/lang/Object;
/*     */     //   157: checkcast java/util/List
/*     */     //   160: dup
/*     */     //   161: astore #10
/*     */     //   163: invokestatic isNotEmpty : (Ljava/util/Collection;)Z
/*     */     //   166: ifeq -> 179
/*     */     //   169: aload #8
/*     */     //   171: aload #10
/*     */     //   173: invokeinterface addAll : (Ljava/util/Collection;)Z
/*     */     //   178: pop
/*     */     //   179: aload_3
/*     */     //   180: aload #9
/*     */     //   182: aload #8
/*     */     //   184: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   189: pop
/*     */     //   190: goto -> 55
/*     */     //   193: nop
/*     */     //   194: athrow
/*     */     //   195: invokevirtual close : ()V
/*     */     //   198: aload #5
/*     */     //   200: goto -> 228
/*     */     //   203: astore #6
/*     */     //   205: aload #4
/*     */     //   207: invokevirtual close : ()V
/*     */     //   210: aload #6
/*     */     //   212: goto -> 225
/*     */     //   215: astore #7
/*     */     //   217: aload #6
/*     */     //   219: dup
/*     */     //   220: aload #7
/*     */     //   222: invokevirtual addSuppressed : (Ljava/lang/Throwable;)V
/*     */     //   225: athrow
/*     */     //   226: nop
/*     */     //   227: athrow
/*     */     //   228: invokevirtual close : ()V
/*     */     //   231: aload_3
/*     */     //   232: areturn
/*     */     //   233: astore #4
/*     */     //   235: aload #5
/*     */     //   237: invokevirtual close : ()V
/*     */     //   240: aload #4
/*     */     //   242: goto -> 255
/*     */     //   245: astore #6
/*     */     //   247: aload #4
/*     */     //   249: dup
/*     */     //   250: aload #6
/*     */     //   252: invokevirtual addSuppressed : (Ljava/lang/Throwable;)V
/*     */     //   255: athrow
/*     */     //   256: athrow
/*     */     //   257: athrow
/*     */     //   258: astore_3
/*     */     //   259: aload_3
/*     */     //   260: athrow
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #198	-> 0
/*     */     //   #214	-> 4
/*     */     //   #50	-> 16
/*     */     //   #144	-> 41
/*     */     //   #184	-> 55
/*     */     //   #75	-> 63
/*     */     //   #38	-> 68
/*     */     //   #72	-> 72
/*     */     //   #107	-> 81
/*     */     //   #130	-> 86
/*     */     //   #127	-> 90
/*     */     //   #117	-> 99
/*     */     //   #78	-> 108
/*     */     //   #203	-> 122
/*     */     //   #222	-> 132
/*     */     //   #103	-> 135
/*     */     //   #149	-> 163
/*     */     //   #194	-> 169
/*     */     //   #156	-> 179
/*     */     //   #11	-> 190
/*     */     //   #217	-> 193
/*     */     //   #50	-> 203
/*     */     //   #217	-> 226
/*     */     //   #50	-> 233
/*     */     //   #139	-> 256
/*     */     //   #131	-> 258
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	261	0	a	Lcn/handyplus/warp/lib/ClassUtil;
/*     */     //   0	261	1	a	Ljava/lang/String;
/*     */     //   0	261	2	a	Ljava/lang/Class;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   0	71	258	java/lang/Throwable
/*     */     //   41	71	233	java/lang/Throwable
/*     */     //   55	71	203	java/lang/Throwable
/*     */     //   72	89	203	java/lang/Throwable
/*     */     //   72	89	233	java/lang/Throwable
/*     */     //   72	89	258	java/lang/Throwable
/*     */     //   90	193	203	java/lang/Throwable
/*     */     //   90	193	233	java/lang/Throwable
/*     */     //   90	193	258	java/lang/Throwable
/*     */     //   195	226	233	java/lang/Throwable
/*     */     //   195	226	258	java/lang/Throwable
/*     */     //   205	210	215	java/lang/Throwable
/*     */     //   228	256	258	java/lang/Throwable
/*     */     //   235	240	245	java/lang/Throwable
/*     */   }
/*     */   
/*     */   public static String qzlKeO(String a) {
/*     */     // Byte code:
/*     */     //   0: iconst_4
/*     */     //   1: iconst_3
/*     */     //   2: ishl
/*     */     //   3: iconst_2
/*     */     //   4: iconst_5
/*     */     //   5: ixor
/*     */     //   6: iconst_4
/*     */     //   7: ishl
/*     */     //   8: iconst_5
/*     */     //   9: ixor
/*     */     //   10: iconst_3
/*     */     //   11: iconst_5
/*     */     //   12: ixor
/*     */     //   13: iconst_4
/*     */     //   14: ishl
/*     */     //   15: iconst_5
/*     */     //   16: iconst_1
/*     */     //   17: ishl
/*     */     //   18: ixor
/*     */     //   19: aload_0
/*     */     //   20: checkcast java/lang/String
/*     */     //   23: dup
/*     */     //   24: astore_0
/*     */     //   25: invokevirtual length : ()I
/*     */     //   28: dup
/*     */     //   29: newarray char
/*     */     //   31: iconst_1
/*     */     //   32: dup
/*     */     //   33: pop2
/*     */     //   34: swap
/*     */     //   35: iconst_1
/*     */     //   36: isub
/*     */     //   37: dup_x2
/*     */     //   38: istore_3
/*     */     //   39: astore_1
/*     */     //   40: istore #4
/*     */     //   42: dup_x2
/*     */     //   43: pop2
/*     */     //   44: istore_2
/*     */     //   45: iflt -> 85
/*     */     //   48: aload_1
/*     */     //   49: aload_0
/*     */     //   50: iload_3
/*     */     //   51: dup_x1
/*     */     //   52: invokevirtual charAt : (I)C
/*     */     //   55: iinc #3, -1
/*     */     //   58: iload_2
/*     */     //   59: ixor
/*     */     //   60: i2c
/*     */     //   61: castore
/*     */     //   62: iload_3
/*     */     //   63: iflt -> 85
/*     */     //   66: aload_1
/*     */     //   67: aload_0
/*     */     //   68: iload_3
/*     */     //   69: iinc #3, -1
/*     */     //   72: dup_x1
/*     */     //   73: invokevirtual charAt : (I)C
/*     */     //   76: iload #4
/*     */     //   78: ixor
/*     */     //   79: i2c
/*     */     //   80: castore
/*     */     //   81: iload_3
/*     */     //   82: goto -> 45
/*     */     //   85: new java/lang/String
/*     */     //   88: dup
/*     */     //   89: aload_1
/*     */     //   90: invokespecial <init> : ([C)V
/*     */     //   93: areturn
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	94	0	a	Ljava/lang/String;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\ClassUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */