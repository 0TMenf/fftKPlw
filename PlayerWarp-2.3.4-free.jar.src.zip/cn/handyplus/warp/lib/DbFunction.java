package cn.handyplus.warp.lib;

import java.io.Serializable;
import java.util.function.Function;

@FunctionalInterface
public interface DbFunction<T, R> extends Function<T, R>, Serializable {}


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\DbFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */