/*     */ package cn.handyplus.warp.lib.bukkit;
/*     */ 
/*     */ import cn.handyplus.warp.lib.MetricsBase;
/*     */ import cn.handyplus.warp.lib.RgbTextUtil;
/*     */ import cn.handyplus.warp.lib.charts.CustomChart;
/*     */ import cn.handyplus.warp.lib.json.JsonObjectBuilder;
/*     */ import cn.handyplus.warp.service.WarpChannelService;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Objects;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Level;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Metrics
/*     */ {
/*     */   private final MetricsBase j;
/*     */   private final Plugin ETzeLJ;
/*     */   
/*     */   public void addCustomChart(CustomChart customChart) {
/* 175 */     this.j.addCustomChart(customChart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Metrics(Plugin plugin, int i) {
/*     */     boolean bool;
/* 183 */     this.ETzeLJ = plugin; File file = new File(plugin.getDataFolder().getParentFile(), WarpChannelService.qzlKeO("lzzHzZ")); YamlConfiguration yamlConfiguration; if (!(yamlConfiguration = YamlConfiguration.loadConfiguration(file = new File(file, RgbTextUtil.qzlKeO("\"S/Z([oE,P")))).isSet(WarpChannelService.qzlKeO("}L|_k[[\\gM"))) {
/*     */       yamlConfiguration.addDefault(RgbTextUtil.qzlKeO("Y/]#P$X"), Boolean.valueOf(true)); yamlConfiguration.addDefault(WarpChannelService.qzlKeO("}L|_k[[\\gM"), UUID.randomUUID().toString()); yamlConfiguration.addDefault(RgbTextUtil.qzlKeO("P.[\007](P$X\023Y0I$O5O"), Boolean.valueOf(false)); yamlConfiguration.addDefault(WarpChannelService.qzlKeO("EaN]L`]JHzH"), Boolean.valueOf(false)); yamlConfiguration.addDefault(RgbTextUtil.qzlKeO("P.[\023Y2L.R2Y\022H H4O\025Y9H"), Boolean.valueOf(false)); yamlConfiguration.options().header(WarpChannelService.qzlKeO("lzzHzZ.\001f]zY}\023!\006lzzHzZ F|N'\tmFbEkJzZ.ZaDk\tlH}@m\tgGhF|Do]gF`\thF|\t~E{NgG.H{]fF|Z\"\tb@eL.Aa^\004DoGw\t~LaYbL.\\}L.]fLg[.Yb\\i@`\toGj\tzAk@|\tzFzHb\t~EoPk[.Ja\\`] \tG])Z.[kJaDcL`MkM.]a\teLkY.K]]o]}#kGoKbLj\005.K{].@h\twF{\016|L.Ga].JaDhF|]oKbL.^g]f\tzAgZ\"\twF{\tmH`\tz\\|G.]f@}\t}Lz]gGi\taOh\007.}fL|L.@}\t`F\004Yk[hF|DoGmL.YkGoEzP.H}ZaJgHzLj\ty@zA.Ao_gGi\tcLz[gJ}\tkGoKbLj\005.H`M.Mo]o\t}L`].]a\tlzzHzZ.@}\th\\bEw#oGaGwDa\\}\007")).copyDefaults(true);
/*     */       try {
/* 186 */         yamlConfiguration.save(file);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 228 */       catch (IOException iOException) {} boolean bool1 = yamlConfiguration.getBoolean(RgbTextUtil.qzlKeO("Y/]#P$X"), true); String str = yamlConfiguration.getString(WarpChannelService.qzlKeO("}L|_k[[\\gM")); bool = yamlConfiguration.getBoolean(RgbTextUtil.qzlKeO("P.[\007](P$X\023Y0I$O5O"), false); boolean bool2 = yamlConfiguration.getBoolean(WarpChannelService.qzlKeO("EaN]L`]JHzH"), false); boolean bool3 = yamlConfiguration.getBoolean(RgbTextUtil.qzlKeO("P.[\023Y2L.R2Y\022H H4O\025Y9H"), false); boolean bool4 = false; try {
/*     */         bool4 = (Class.forName(WarpChannelService.qzlKeO("@a\007~H~L|Dm\007~H~L|\007zA|LoMkM|Li@aG}\007\\Li@aGgSkM]L|_k[")) != null) ? true : false;
/*     */       } catch (Exception exception) {} Objects.requireNonNull(bool4 ? plugin : plugin); this.j = new MetricsBase(RgbTextUtil.qzlKeO("#I*W(H"), str, i, bool1, jsonObjectBuilder -> {
/*     */             jsonObjectBuilder.appendField(WarpChannelService.qzlKeO("~EoPk[ODa\\`]"), iiiiIi()); jsonObjectBuilder.appendField(WarpChannelService.qzlKeO("Ja[kja\\`]"), Runtime.getRuntime().availableProcessors()); jsonObjectBuilder.appendField(WarpChannelService.qzlKeO("F}k[}@aG"), System.getProperty(RgbTextUtil.qzlKeO(".OoJ$N2U.R"))); jsonObjectBuilder.appendField(WarpChannelService.qzlKeO("aZO[mA"), System.getProperty(RgbTextUtil.qzlKeO("S2\022 N\"T"))); jsonObjectBuilder.appendField(WarpChannelService.qzlKeO("aZ@HcL"), System.getProperty(RgbTextUtil.qzlKeO("S2\022/],Y")));
/*     */           }jsonObjectBuilder -> jsonObjectBuilder.appendField(RgbTextUtil.qzlKeO("L-I&U/j$N2U.R"), this.ETzeLJ.getDescription().getVersion()), runnable -> Bukkit.getScheduler().runTask(a, runnable), bool4 ? plugin : plugin::isEnabled, (str, throwable) -> this.ETzeLJ.getLogger().log(Level.WARNING, str, throwable), str -> this.ETzeLJ.getLogger().log(Level.INFO, str), bool, bool2, bool3, false); return;
/* 233 */     }  } public void shutdown() { this.j.shutdown(); }
/*     */ 
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\bukkit\Metrics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */