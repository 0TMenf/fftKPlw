/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import lombok.Generated;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum LanguageTypeEnum
/*     */ {
/*     */   KW_GB,
/*     */   AZ_AZ,
/*     */   IO_EN,
/*     */   EN_UD,
/*     */   SE_NO,
/*     */   ESAN,
/*     */   DA_DK,
/*     */   OC_FR,
/*     */   KK_KZ,
/*     */   TH_TH,
/*     */   HI_IN,
/*     */   FRA_DE,
/*     */   KO_KR,
/*     */   QYA_AA,
/*     */   JBO_EN,
/*     */   NDS_DE,
/*     */   SO_SO,
/*     */   ES_AR,
/*     */   SXU,
/*     */   ES_UY,
/*     */   ZLM_ARAB,
/*     */   NN_NO,
/*     */   ES_CL,
/*     */   LB_LU,
/*     */   EN_PT,
/*     */   NL_BE,
/*     */   BA_RU,
/*     */   AR_SA,
/*     */   LA_LA,
/*     */   TOK,
/*     */   HY_AM,
/*     */   TR_TR,
/*     */   OVD,
/*     */   GA_IE,
/*     */   DE_DE,
/*     */   KA_GE,
/*     */   IG_NG,
/*     */   EL_GR,
/*     */   MS_MY,
/*     */   BAR,
/*     */   KN_IN,
/*     */   RY_UA,
/*     */   SR_CS,
/*     */   FUR_IT,
/*     */   TA_IN,
/*     */   JA_JP,
/*     */   MT_MT,
/*     */   TLH_AA,
/*     */   SK_SK,
/*     */   YI_DE,
/*     */   GD_GB,
/*     */   ES_ES,
/*     */   VI_VN,
/*     */   IT_IT,
/*     */   BG_BG,
/*     */   HE_IL,
/*     */   ENP,
/*     */   ES_EC,
/*     */   MN_MN,
/*     */   NO_NO,
/*     */   NAH,
/*     */   EN_AU,
/*     */   KSH,
/*     */   IS_IS,
/*     */   ENWS,
/*     */   DE_AT,
/*     */   UK_UA,
/*     */   BS_BA,
/*     */   EO_UY,
/*     */   BRB,
/*     */   SQ_AL,
/*     */   FR_CA,
/*     */   TL_PH,
/*     */   ID_ID,
/*     */   LT_LT,
/*     */   EN_NZ,
/*     */   VEC_IT,
/*     */   EU_ES,
/*     */   FA_IR,
/*     */   FIL_PH,
/*     */   SAH_SAH,
/*     */   LV_LV,
/*     */   LO_LA,
/*     */   LMO,
/*     */   PL_PL,
/*     */   LZH,
/*     */   FO_FO,
/*     */   RPR,
/*     */   BE_BY,
/*     */   PT_PT,
/*     */   NL_NL,
/*     */   SR_SP,
/*     */   RU_RU,
/*     */   FY_NL,
/*     */   VP_VL,
/* 148 */   AF_ZA(Pair.qzlKeO("-\036\023\002-")), SV_SE(Pair.qzlKeO("-\036\023\002-")), VAL_ES(Pair.qzlKeO("-\036\023\002-")), LI_LI(Pair.qzlKeO("-\036\023\002-")), HR_HR(Pair.qzlKeO("-\036\023\002-")), FR_FR(Pair.qzlKeO("-\036\023\002-")), ES_MX(Pair.qzlKeO("-\036\023\002-")), CS_CZ(Pair.qzlKeO("-\036\023\002-")), HU_HU(Pair.qzlKeO("-\036\023\002-")), ISV(Pair.qzlKeO("-\036\023\002-")), ZH_TW(Pair.qzlKeO("-\036\023\002-")), ZH_HK(Pair.qzlKeO("-\036\023\002-")), PT_BR(Pair.qzlKeO("-\036\023\002-")), SL_SI(Pair.qzlKeO("-\036\023\002-")), HAW_US(Pair.qzlKeO("-\036\023\002-")), SZL(Pair.qzlKeO("-\036\023\002-")), GL_ES(Pair.qzlKeO("-\036\023\002-")), ET_EE(Pair.qzlKeO("-\036\023\002-")), MK_MK(Pair.qzlKeO("-\036\023\002-")), EN_GB(Pair.qzlKeO("-\036\023\002-")), CA_ES(Pair.qzlKeO("-\036\023\002-")), YO_NG(Pair.qzlKeO("-\036\023\002-")), CY_GB(Pair.qzlKeO("-\036\023\002-")), ZH_CN(Pair.qzlKeO("-\036\023\002-")), RO_RO(Pair.qzlKeO("-\036\023\002-")), ES_VE(Pair.qzlKeO("-\036\023\002-")), EN_CA(Pair.qzlKeO("-\036\023\002-")), TT_RU(Pair.qzlKeO("-\036\023\002-")), DE_CH(Pair.qzlKeO("-\036\023\002-")), FI_FI(Pair.qzlKeO("-\036\023\002-")), AST_ES(Pair.qzlKeO("-\036\023\002-")), LOL_US(Pair.qzlKeO("-\036\023\002-")), BR_FR(Pair.qzlKeO("-\036\023\002-"));
/*     */   
/*     */   private final String L;
/*     */   
/*     */   private static final String K = "https://ricedoc.handyplus.cn/i18n/zh_cn/%s.json";
/*     */   
/*     */   private static final String j = "https://raw.githubusercontent.com/InventivetalentDev/minecraft-assets/%s/assets/minecraft/lang/%s.json";
/*     */ 
/*     */   
/*     */   @Generated
/*     */   LanguageTypeEnum(String str1) {
/*     */     this.L = str1;
/*     */   }
/*     */ 
/*     */   
/*     */   static {
/*     */     AR_SA = new LanguageTypeEnum(Pair.qzlKeO("\r*\023+\r"), 1, Pair.qzlKeO("-\n\023\013-"));
/* 165 */     AST_ES = new LanguageTypeEnum(Pair.qzlKeO("9\037,\023=\037"), 2, Pair.qzlKeO("\031?\f\023\035?"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 209 */     AZ_AZ = new LanguageTypeEnum(Pair.qzlKeO("\r\"\0239\026"), 3, Pair.qzlKeO("-\002\023\0316")); BA_RU = new LanguageTypeEnum(Pair.qzlKeO("\0169\023*\031"), 4, Pair.qzlKeO(".\031\023\n9")); BAR = new LanguageTypeEnum(Pair.qzlKeO("\0169\036"), 5, Pair.qzlKeO(".\031>")); BE_BY = new LanguageTypeEnum(Pair.qzlKeO("\016=\023:\025"), 6, Pair.qzlKeO(".\035\023\0325")); BG_BG = new LanguageTypeEnum(Pair.qzlKeO("\016?\023:\013"), 7, Pair.qzlKeO(".\037\023\032+")); BR_FR = new LanguageTypeEnum(Pair.qzlKeO("\016*\023>\036"), 8, Pair.qzlKeO(".\n\023\036>")); BRB = new LanguageTypeEnum(Pair.qzlKeO("\016*\016"), 9, Pair.qzlKeO(".\n.")); BS_BA = new LanguageTypeEnum(Pair.qzlKeO("\016+\023:\r"), 10, Pair.qzlKeO(".\013\023\032-")); CA_ES = new LanguageTypeEnum(Pair.qzlKeO("\0179\023=\037"), 11, Pair.qzlKeO("/\031\023\035?")); CS_CZ = new LanguageTypeEnum(Pair.qzlKeO("\017+\023;\026"), 12, Pair.qzlKeO("/\013\023\0336")); CY_GB = new LanguageTypeEnum(Pair.qzlKeO("\017!\023?\016"), 13, Pair.qzlKeO("/\001\023\037.")); DA_DK = new LanguageTypeEnum(Pair.qzlKeO("\b9\023<\007"), 14, Pair.qzlKeO("(\031\023\034'")); DE_AT = new LanguageTypeEnum(Pair.qzlKeO("\b=\0239\030"), 15, Pair.qzlKeO("(\035\023\0318")); DE_CH = new LanguageTypeEnum(Pair.qzlKeO("\b=\023;\004"), 16, Pair.qzlKeO("(\035\023\033$")); DE_DE = new LanguageTypeEnum(Pair.qzlKeO("\b=\023<\t"), 17, Pair.qzlKeO("(\035\023\034)"));
/* 210 */     EL_GR = new LanguageTypeEnum(Pair.qzlKeO("\t4\023?\036"), 18, Pair.qzlKeO(")\024\023\037>"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     EN_AU = new LanguageTypeEnum(Pair.qzlKeO("\t6\0239\031"), 19, Pair.qzlKeO(")\026\023\0319")); EN_CA = new LanguageTypeEnum(Pair.qzlKeO("\t6\023;\r"), 20, Pair.qzlKeO(")\026\023\033-")); EN_GB = new LanguageTypeEnum(Pair.qzlKeO("\t6\023?\016"), 21, Pair.qzlKeO(")\026\023\037.")); EN_NZ = new LanguageTypeEnum(Pair.qzlKeO("\t6\0236\026"), 22, Pair.qzlKeO(")\026\023\0266")); EN_PT = new LanguageTypeEnum(Pair.qzlKeO("\t6\023(\030"), 23, Pair.qzlKeO(")\026\023\b8")); EN_UD = new LanguageTypeEnum(Pair.qzlKeO("\t6\023-\b"), 24, Pair.qzlKeO(")\026\023\r(")); ENP = new LanguageTypeEnum(Pair.qzlKeO("\t6\034"), 25, Pair.qzlKeO(")\026<")); ENWS = new LanguageTypeEnum(Pair.qzlKeO("=\002/\037"), 26, Pair.qzlKeO("\035\"\017?")); EO_UY = new LanguageTypeEnum(Pair.qzlKeO("\t7\023-\025"), 27, Pair.qzlKeO(")\027\023\r5")); ES_AR = new LanguageTypeEnum(Pair.qzlKeO("\t+\0239\036"), 28, Pair.qzlKeO(")\013\023\031>")); ES_CL = new LanguageTypeEnum(Pair.qzlKeO("\t+\023;\000"), 29, Pair.qzlKeO(")\013\023\033 ")); ES_EC = new LanguageTypeEnum(Pair.qzlKeO("\t+\023=\017"), 30, Pair.qzlKeO(")\013\023\035/")); ES_ES = new LanguageTypeEnum(Pair.qzlKeO("\t+\023=\037"), 31, Pair.qzlKeO(")\013\023\035?")); ES_MX = new LanguageTypeEnum(Pair.qzlKeO("\t+\0235\024"), 32, Pair.qzlKeO(")\013\023\0254")); ES_UY = new LanguageTypeEnum(Pair.qzlKeO("\t+\023-\025"), 33, Pair.qzlKeO(")\013\023\r5"));
/*     */     ES_VE = new LanguageTypeEnum(Pair.qzlKeO("\t+\023.\t"), 34, Pair.qzlKeO(")\013\023\016)"));
/*     */     ESAN = new LanguageTypeEnum(Pair.qzlKeO("=\0379\002"), 35, Pair.qzlKeO("\035?\031\""));
/*     */     ET_EE = new LanguageTypeEnum(Pair.qzlKeO("\t,\023=\t"), 36, Pair.qzlKeO(")\f\023\035)"));
/*     */     EU_ES = new LanguageTypeEnum(Pair.qzlKeO("\t-\023=\037"), 37, Pair.qzlKeO(")\r\023\035?"));
/* 233 */     FA_IR = new LanguageTypeEnum(Pair.qzlKeO("\n9\0231\036"), 38, Pair.qzlKeO("*\031\023\021>"));
/*     */ 
/*     */ 
/*     */     
/*     */     FI_FI = new LanguageTypeEnum(Pair.qzlKeO("\n1\023>\005"), 39, Pair.qzlKeO("*\021\023\036%"));
/*     */ 
/*     */ 
/*     */     
/*     */     FIL_PH = new LanguageTypeEnum(Pair.qzlKeO(">\0054\023(\004"), 40, Pair.qzlKeO("\036%\024\023\b$"));
/*     */ 
/*     */ 
/*     */     
/*     */     FO_FO = new LanguageTypeEnum(Pair.qzlKeO("\n7\023>\003"), 41, Pair.qzlKeO("*\027\023\036#"));
/*     */ 
/*     */ 
/*     */     
/*     */     FR_CA = new LanguageTypeEnum(Pair.qzlKeO("\n*\023;\r"), 42, Pair.qzlKeO("*\n\023\033-"));
/*     */ 
/*     */ 
/*     */     
/*     */     FR_FR = new LanguageTypeEnum(Pair.qzlKeO("\n*\023>\036"), 43, Pair.qzlKeO("*\n\023\036>"));
/*     */ 
/*     */ 
/*     */     
/*     */     FRA_DE = new LanguageTypeEnum(Pair.qzlKeO(">\0369\023<\t"), 44, Pair.qzlKeO("\036>\031\023\034)"));
/*     */ 
/*     */ 
/*     */     
/*     */     FUR_IT = new LanguageTypeEnum(Pair.qzlKeO(">\031*\0231\030"), 45, Pair.qzlKeO("\0369\n\023\0218"));
/*     */ 
/*     */ 
/*     */     
/*     */     FY_NL = new LanguageTypeEnum(Pair.qzlKeO("\n!\0236\000"), 46, Pair.qzlKeO("*\001\023\026 "));
/*     */ 
/*     */ 
/*     */     
/*     */     GA_IE = new LanguageTypeEnum(Pair.qzlKeO("\0139\0231\t"), 47, Pair.qzlKeO("+\031\023\021)"));
/*     */ 
/*     */ 
/*     */     
/*     */     GD_GB = new LanguageTypeEnum(Pair.qzlKeO("\013<\023?\016"), 48, Pair.qzlKeO("+\034\023\037."));
/*     */ 
/*     */ 
/*     */     
/*     */     GL_ES = new LanguageTypeEnum(Pair.qzlKeO("\0134\023=\037"), 49, Pair.qzlKeO("+\024\023\035?"));
/*     */ 
/*     */ 
/*     */     
/*     */     HAW_US = new LanguageTypeEnum(Pair.qzlKeO("0\r/\023-\037"), 50, Pair.qzlKeO("\020-\017\023\r?"));
/*     */ 
/*     */ 
/*     */     
/*     */     HE_IL = new LanguageTypeEnum(Pair.qzlKeO("\004=\0231\000"), 51, Pair.qzlKeO("$\035\023\021 "));
/*     */ 
/*     */ 
/*     */     
/*     */     HI_IN = new LanguageTypeEnum(Pair.qzlKeO("\0041\0231\002"), 52, Pair.qzlKeO("$\021\023\021\""));
/*     */ 
/*     */ 
/*     */     
/*     */     HR_HR = new LanguageTypeEnum(Pair.qzlKeO("\004*\0230\036"), 53, Pair.qzlKeO("$\n\023\020>"));
/*     */ 
/*     */ 
/*     */     
/*     */     HU_HU = new LanguageTypeEnum(Pair.qzlKeO("\004-\0230\031"), 54, Pair.qzlKeO("$\r\023\0209"));
/*     */ 
/*     */ 
/*     */     
/*     */     HY_AM = new LanguageTypeEnum(Pair.qzlKeO("\004!\0239\001"), 55, Pair.qzlKeO("$\001\023\031!"));
/*     */ 
/*     */ 
/*     */     
/*     */     ID_ID = new LanguageTypeEnum(Pair.qzlKeO("\005<\0231\b"), 56, Pair.qzlKeO("%\034\023\021("));
/*     */ 
/*     */ 
/*     */     
/*     */     IG_NG = new LanguageTypeEnum(Pair.qzlKeO("\005?\0236\013"), 57, Pair.qzlKeO("%\037\023\026+"));
/*     */ 
/*     */ 
/*     */     
/*     */     IO_EN = new LanguageTypeEnum(Pair.qzlKeO("\0057\023=\002"), 58, Pair.qzlKeO("%\027\023\035\""));
/*     */ 
/*     */ 
/*     */     
/*     */     IS_IS = new LanguageTypeEnum(Pair.qzlKeO("\005+\0231\037"), 59, Pair.qzlKeO("%\013\023\021?"));
/*     */ 
/*     */ 
/*     */     
/*     */     ISV = new LanguageTypeEnum(Pair.qzlKeO("\005+\032"), 60, Pair.qzlKeO("%\013:"));
/*     */ 
/*     */ 
/*     */     
/*     */     IT_IT = new LanguageTypeEnum(Pair.qzlKeO("\005,\0231\030"), 61, Pair.qzlKeO("%\f\023\0218"));
/*     */ 
/*     */ 
/*     */     
/*     */     JA_JP = new LanguageTypeEnum(Pair.qzlKeO("\0069\0232\034"), 62, Pair.qzlKeO("&\031\023\022<"));
/*     */ 
/*     */ 
/*     */     
/*     */     JBO_EN = new LanguageTypeEnum(Pair.qzlKeO("2\0167\023=\002"), 63, Pair.qzlKeO("\022.\027\023\035\""));
/*     */ 
/*     */ 
/*     */     
/*     */     KA_GE = new LanguageTypeEnum(Pair.qzlKeO("\0079\023?\t"), 64, Pair.qzlKeO("'\031\023\037)"));
/*     */ 
/*     */ 
/*     */     
/*     */     KK_KZ = new LanguageTypeEnum(Pair.qzlKeO("\0073\0233\026"), 65, Pair.qzlKeO("'\023\023\0236"));
/*     */ 
/*     */ 
/*     */     
/*     */     KN_IN = new LanguageTypeEnum(Pair.qzlKeO("\0076\0231\002"), 66, Pair.qzlKeO("'\026\023\021\""));
/*     */ 
/*     */ 
/*     */     
/*     */     KO_KR = new LanguageTypeEnum(Pair.qzlKeO("\0077\0233\036"), 67, Pair.qzlKeO("'\027\023\023>"));
/*     */ 
/*     */ 
/*     */     
/*     */     KSH = new LanguageTypeEnum(Pair.qzlKeO("\007+\004"), 68, Pair.qzlKeO("'\013$"));
/*     */ 
/*     */ 
/*     */     
/*     */     KW_GB = new LanguageTypeEnum(Pair.qzlKeO("\007/\023?\016"), 69, Pair.qzlKeO("'\017\023\037."));
/*     */ 
/*     */ 
/*     */     
/*     */     LA_LA = new LanguageTypeEnum(Pair.qzlKeO("\0009\0234\r"), 70, Pair.qzlKeO(" \031\023\024-"));
/*     */ 
/*     */ 
/*     */     
/*     */     LB_LU = new LanguageTypeEnum(Pair.qzlKeO("\000:\0234\031"), 71, Pair.qzlKeO(" \032\023\0249"));
/*     */ 
/*     */ 
/*     */     
/*     */     LI_LI = new LanguageTypeEnum(Pair.qzlKeO("\0001\0234\005"), 72, Pair.qzlKeO(" \021\023\024%"));
/*     */ 
/*     */ 
/*     */     
/*     */     LMO = new LanguageTypeEnum(Pair.qzlKeO("\0005\003"), 73, Pair.qzlKeO(" \025#"));
/*     */ 
/*     */ 
/*     */     
/*     */     LO_LA = new LanguageTypeEnum(Pair.qzlKeO("\0007\0234\r"), 74, Pair.qzlKeO(" \027\023\024-"));
/*     */ 
/*     */ 
/*     */     
/*     */     LOL_US = new LanguageTypeEnum(Pair.qzlKeO("4\0034\023-\037"), 75, Pair.qzlKeO("\024#\024\023\r?"));
/*     */ 
/*     */ 
/*     */     
/*     */     LT_LT = new LanguageTypeEnum(Pair.qzlKeO("\000,\0234\030"), 76, Pair.qzlKeO(" \f\023\0248"));
/*     */ 
/*     */ 
/*     */     
/*     */     LV_LV = new LanguageTypeEnum(Pair.qzlKeO("\000.\0234\032"), 77, Pair.qzlKeO(" \016\023\024:"));
/*     */ 
/*     */ 
/*     */     
/*     */     LZH = new LanguageTypeEnum(Pair.qzlKeO("\000\"\004"), 78, Pair.qzlKeO(" \002$"));
/*     */ 
/*     */ 
/*     */     
/*     */     MK_MK = new LanguageTypeEnum(Pair.qzlKeO("\0013\0235\007"), 79, Pair.qzlKeO("!\023\023\025'"));
/*     */ 
/*     */ 
/*     */     
/*     */     MN_MN = new LanguageTypeEnum(Pair.qzlKeO("\0016\0235\002"), 80, Pair.qzlKeO("!\026\023\025\""));
/*     */ 
/*     */ 
/*     */     
/*     */     MS_MY = new LanguageTypeEnum(Pair.qzlKeO("\001+\0235\025"), 81, Pair.qzlKeO("!\013\023\0255"));
/*     */ 
/*     */ 
/*     */     
/*     */     MT_MT = new LanguageTypeEnum(Pair.qzlKeO("\001,\0235\030"), 82, Pair.qzlKeO("!\f\023\0258"));
/*     */ 
/*     */ 
/*     */     
/*     */     NAH = new LanguageTypeEnum(Pair.qzlKeO("\0029\004"), 83, Pair.qzlKeO("\"\031$"));
/*     */ 
/*     */ 
/*     */     
/*     */     NDS_DE = new LanguageTypeEnum(Pair.qzlKeO("6\b+\023<\t"), 84, Pair.qzlKeO("\026(\013\023\034)"));
/*     */ 
/*     */     
/*     */     NL_BE = new LanguageTypeEnum(Pair.qzlKeO("\0024\023:\t"), 85, Pair.qzlKeO("\"\024\023\032)"));
/*     */ 
/*     */     
/*     */     NL_NL = new LanguageTypeEnum(Pair.qzlKeO("\0024\0236\000"), 86, Pair.qzlKeO("\"\024\023\026 "));
/*     */ 
/*     */     
/*     */     NN_NO = new LanguageTypeEnum(Pair.qzlKeO("\0026\0236\003"), 87, Pair.qzlKeO("\"\026\023\026#"));
/*     */ 
/*     */     
/*     */     NO_NO = new LanguageTypeEnum(Pair.qzlKeO("\0027\0236\003"), 88, Pair.qzlKeO("\"\027\023\026#"));
/*     */ 
/*     */     
/*     */     OC_FR = new LanguageTypeEnum(Pair.qzlKeO("\003;\023>\036"), 89, Pair.qzlKeO("#\033\023\036>"));
/*     */ 
/*     */     
/*     */     OVD = new LanguageTypeEnum(Pair.qzlKeO("\003.\b"), 90, Pair.qzlKeO("#\016("));
/*     */ 
/*     */     
/*     */     PL_PL = new LanguageTypeEnum(Pair.qzlKeO("\0344\023(\000"), 91, Pair.qzlKeO("<\024\023\b "));
/*     */ 
/*     */     
/*     */     PT_BR = new LanguageTypeEnum(Pair.qzlKeO("\034,\023:\036"), 92, Pair.qzlKeO("<\f\023\032>"));
/*     */ 
/*     */     
/*     */     PT_PT = new LanguageTypeEnum(Pair.qzlKeO("\034,\023(\030"), 93, Pair.qzlKeO("<\f\023\b8"));
/*     */ 
/*     */     
/*     */     QYA_AA = new LanguageTypeEnum(Pair.qzlKeO(")\0259\0239\r"), 94, Pair.qzlKeO("\t5\031\023\031-"));
/*     */ 
/*     */     
/*     */     RO_RO = new LanguageTypeEnum(Pair.qzlKeO("\0367\023*\003"), 95, Pair.qzlKeO(">\027\023\n#"));
/*     */ 
/*     */     
/*     */     RPR = new LanguageTypeEnum(Pair.qzlKeO("\036(\036"), 96, Pair.qzlKeO(">\b>"));
/*     */ 
/*     */     
/*     */     RU_RU = new LanguageTypeEnum(Pair.qzlKeO("\036-\023*\031"), 97, Pair.qzlKeO(">\r\023\n9"));
/*     */ 
/*     */     
/*     */     RY_UA = new LanguageTypeEnum(Pair.qzlKeO("\036!\023-\r"), 98, Pair.qzlKeO(">\001\023\r-"));
/*     */ 
/*     */     
/*     */     SAH_SAH = new LanguageTypeEnum(Pair.qzlKeO("\0379\004'\0379\004"), 99, Pair.qzlKeO("?\031$'?\031$"));
/*     */ 
/*     */     
/*     */     SE_NO = new LanguageTypeEnum(Pair.qzlKeO("\037=\0236\003"), 100, Pair.qzlKeO("?\035\023\026#"));
/*     */ 
/*     */     
/*     */     SK_SK = new LanguageTypeEnum(Pair.qzlKeO("\0373\023+\007"), 101, Pair.qzlKeO("?\023\023\013'"));
/*     */ 
/*     */     
/*     */     SL_SI = new LanguageTypeEnum(Pair.qzlKeO("\0374\023+\005"), 102, Pair.qzlKeO("?\024\023\013%"));
/*     */ 
/*     */     
/*     */     SO_SO = new LanguageTypeEnum(Pair.qzlKeO("\0377\023+\003"), 103, Pair.qzlKeO("?\027\023\013#"));
/*     */ 
/*     */     
/*     */     SQ_AL = new LanguageTypeEnum(Pair.qzlKeO("\037)\0239\000"), 104, Pair.qzlKeO("?\t\023\031 "));
/*     */ 
/*     */     
/*     */     SR_CS = new LanguageTypeEnum(Pair.qzlKeO("\037*\023;\037"), 105, Pair.qzlKeO("?\n\023\033?"));
/*     */ 
/*     */     
/*     */     SR_SP = new LanguageTypeEnum(Pair.qzlKeO("\037*\023+\034"), 106, Pair.qzlKeO("?\n\023\013<"));
/*     */ 
/*     */     
/*     */     SV_SE = new LanguageTypeEnum(Pair.qzlKeO("\037.\023+\t"), 107, Pair.qzlKeO("?\016\023\013)"));
/*     */ 
/*     */     
/* 489 */     SXU = new LanguageTypeEnum(Pair.qzlKeO("\037 \031"), 108, Pair.qzlKeO("?\0009"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     SZL = new LanguageTypeEnum(Pair.qzlKeO("\037\"\000"), 109, Pair.qzlKeO("?\002 "));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 591 */     TA_IN = new LanguageTypeEnum(Pair.qzlKeO("\0309\0231\002"), 110, Pair.qzlKeO("8\031\023\021\""));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TH_TH = new LanguageTypeEnum(Pair.qzlKeO("\0300\023,\004"), 111, Pair.qzlKeO("8\020\023\f$"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TL_PH = new LanguageTypeEnum(Pair.qzlKeO("\0304\023(\004"), 112, Pair.qzlKeO("8\024\023\b$"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 617 */     TLH_AA = new LanguageTypeEnum(Pair.qzlKeO(",\0000\0239\r"), 113, Pair.qzlKeO("\f \020\023\031-"));
/*     */     
/*     */     TOK = new LanguageTypeEnum(Pair.qzlKeO("\0307\007"), 114, Pair.qzlKeO("8\027'"));
/*     */     
/*     */     TR_TR = new LanguageTypeEnum(Pair.qzlKeO("\030*\023,\036"), 115, Pair.qzlKeO("8\n\023\f>"));
/*     */     
/*     */     TT_RU = new LanguageTypeEnum(Pair.qzlKeO("\030,\023*\031"), 116, Pair.qzlKeO("8\f\023\n9"));
/*     */     
/*     */     UK_UA = new LanguageTypeEnum(Pair.qzlKeO("\0313\023-\r"), 117, Pair.qzlKeO("9\023\023\r-"));
/*     */     
/*     */     VAL_ES = new LanguageTypeEnum(Pair.qzlKeO(".\r4\023=\037"), 118, Pair.qzlKeO("\016-\024\023\035?"));
/*     */     
/* 629 */     VEC_IT = new LanguageTypeEnum(Pair.qzlKeO(".\t;\0231\030"), 119, Pair.qzlKeO("\016)\033\023\0218"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 724 */     VI_VN = new LanguageTypeEnum(Pair.qzlKeO("\0321\023.\002"), 120, Pair.qzlKeO(":\021\023\016\""));
/*     */     VP_VL = new LanguageTypeEnum(Pair.qzlKeO("\032(\023.\000"), 121, Pair.qzlKeO(":\b\023\016 "));
/*     */     YI_DE = new LanguageTypeEnum(Pair.qzlKeO("\0251\023<\t"), 122, Pair.qzlKeO("5\021\023\034)"));
/*     */     YO_NG = new LanguageTypeEnum(Pair.qzlKeO("\0257\0236\013"), 123, Pair.qzlKeO("5\027\023\026+"));
/*     */     ZH_CN = new LanguageTypeEnum(Pair.qzlKeO("\0260\023;\002"), 124, Pair.qzlKeO("6\020\023\033\""));
/*     */     ZH_HK = new LanguageTypeEnum(Pair.qzlKeO("\0260\0230\007"), 125, Pair.qzlKeO("6\020\023\020'"));
/*     */     ZH_TW = new LanguageTypeEnum(Pair.qzlKeO("\0260\023,\033"), 126, Pair.qzlKeO("6\020\023\f;"));
/*     */     ZLM_ARAB = new LanguageTypeEnum(Pair.qzlKeO("\"\0005\0239\0369\016"), 127, Pair.qzlKeO("\002 \025\023\031>\031."));
/*     */     pPpppp = pPPppP();
/*     */   }
/*     */   
/*     */   public String getUrl() {
/*     */     if (this.L.equalsIgnoreCase(ZH_CN.L)) {
/*     */       true;
/*     */       true[0] = BaseConstants.VERSION_CHECK_ENUM.getMainVersion();
/*     */       return String.format((String)new Object[1], true);
/*     */     } 
/*     */     true;
/*     */     true[0] = BaseConstants.VERSION_CHECK_ENUM.getVersion();
/*     */     true[1] = this.L;
/*     */     return String.format((String)new Object[2], true);
/*     */   }
/*     */   
/*     */   @Generated
/*     */   public String getValue() {
/*     */     return this.L;
/*     */   }
/*     */   
/*     */   public static LanguageTypeEnum getByValue(String a) {
/*     */     // Byte code:
/*     */     //   0: invokestatic values : ()[Lcn/handyplus/warp/lib/LanguageTypeEnum;
/*     */     //   3: dup
/*     */     //   4: astore_1
/*     */     //   5: arraylength
/*     */     //   6: istore_2
/*     */     //   7: iconst_0
/*     */     //   8: dup
/*     */     //   9: istore_3
/*     */     //   10: iload_2
/*     */     //   11: if_icmpge -> 42
/*     */     //   14: aload_1
/*     */     //   15: iload_3
/*     */     //   16: aaload
/*     */     //   17: dup
/*     */     //   18: astore #4
/*     */     //   20: getfield L : Ljava/lang/String;
/*     */     //   23: aload_0
/*     */     //   24: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
/*     */     //   27: ifeq -> 34
/*     */     //   30: aload #4
/*     */     //   32: areturn
/*     */     //   33: athrow
/*     */     //   34: iinc #3, 1
/*     */     //   37: iload_3
/*     */     //   38: goto -> 10
/*     */     //   41: athrow
/*     */     //   42: aconst_null
/*     */     //   43: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #425	-> 0
/*     */     //   #452	-> 20
/*     */     //   #262	-> 30
/*     */     //   #425	-> 34
/*     */     //   #699	-> 42
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	44	0	a	Ljava/lang/String;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\LanguageTypeEnum.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */