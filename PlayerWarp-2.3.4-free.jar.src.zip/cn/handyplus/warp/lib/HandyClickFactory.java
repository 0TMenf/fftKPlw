/*     */ package cn.handyplus.warp.lib;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.InventoryHolder;
/*     */ 
/*     */ public class HandyClickFactory {
/*   6 */   private static final Map<String, IHandyClickEvent> gbjsip = new HashMap<>();
/*   7 */   public void IIIIII(List<?> list) { if (CollUtil.isEmpty(list)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Iterator<?> iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 186 */     if ((iterator = list.iterator()).hasNext()) { IHandyClickEvent iHandyClickEvent = (IHandyClickEvent)iterator.next();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 228 */       gbjsip.put(iHandyClickEvent.guiType(), iHandyClickEvent); }
/*     */      InitApi.PLUGIN.getServer().getPluginManager().registerEvents(new HandyInventoryListener(), (Plugin)InitApi.PLUGIN); } public InventoryCheckParam ppPpPp(InventoryClickEvent inventoryClickEvent) { InventoryCheckParam inventoryCheckParam = new InventoryCheckParam(); inventoryCheckParam.setCheck(false); InventoryHolder inventoryHolder; if (!(inventoryHolder = inventoryClickEvent.getInventory().getHolder() instanceof HandyInventory))
/*     */       return inventoryCheckParam;  inventoryHolder = inventoryHolder; Optional<Player> optional; if (!(optional = HandyInventoryUtil.getPlayer(inventoryClickEvent)).isPresent())
/*     */       return inventoryCheckParam;  if (inventoryClickEvent.getClick().isShiftClick() || inventoryClickEvent.getClick().isKeyboardClick() || ClickType.DOUBLE_CLICK.equals(inventoryClickEvent.getClick())) { inventoryClickEvent.setCancelled(true); return inventoryCheckParam; }
/*     */      ItemStack itemStack; if ((itemStack = inventoryClickEvent.getCurrentItem()) == null || Material.AIR.equals(itemStack.getType())) { inventoryClickEvent.setCancelled(inventoryHolder.isToCancel()); return inventoryCheckParam; }
/* 233 */      if (inventoryClickEvent.isCancelled())
/*     */       return inventoryCheckParam; 
/*     */     inventoryHolder.setPlayer(optional.get());
/*     */     String str = (new StringBuilder()).insert(0, inventoryHolder.getGuiType()).append(Pair.qzlKeO("\023")).append(inventoryHolder.getPlayer().getUniqueId()).toString();
/*     */     inventoryHolder.setLockKey(str);
/*     */     inventoryCheckParam.setCheck(true);
/*     */     inventoryCheckParam.setHandyInventory((HandyInventory)inventoryHolder);
/*     */     return inventoryCheckParam; }
/*     */ 
/*     */   
/*     */   public static HandyClickFactory iIiIiI() {
/*     */     return j;
/*     */   }
/*     */   
/*     */   public void IIIiiI(HandyInventory handyInventory, InventoryClickEvent inventoryClickEvent) {
/*     */     IHandyClickEvent iHandyClickEvent;
/*     */     if ((iHandyClickEvent = gbjsip.get(handyInventory.getGuiType())) == null)
/*     */       return; 
/*     */     if (iHandyClickEvent.isAsync()) {
/*     */       oOoooO(iHandyClickEvent, handyInventory, inventoryClickEvent);
/*     */       return;
/*     */     } 
/*     */     l(iHandyClickEvent, handyInventory, inventoryClickEvent);
/*     */   }
/*     */   
/*     */   private static final HandyClickFactory j = new HandyClickFactory();
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\HandyClickFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */