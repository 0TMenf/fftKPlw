/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Collection;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AssertUtil
/*     */ {
/*     */   public static void notTrue(int a, String str) {
/*  16 */     if (a != 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 170 */       throw new RuntimeException(str); } 
/*     */   }
/*     */   public static Player notPlayer(CommandSender a, String str) {
/*     */     if (BaseUtil.isNotPlayer(a).booleanValue()) {
/* 174 */       throw new RuntimeException(str);
/*     */     }
/*     */     return (Player)a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer isPositiveToInt(String a, String str1) {
/*     */     Integer integer;
/*     */     if ((integer = isNumericToInt(a, str1)).intValue() <= 0) {
/*     */       throw new RuntimeException(str1);
/*     */     }
/*     */     return integer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal isNumericToBigDecimal(String a, String str1) {
/*     */     return NumberUtil.isNumericToBigDecimal(a).<Throwable>orElseThrow(() -> new RuntimeException(a));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void notEmpty(String a, String str1) {
/*     */     if (StrUtil.isEmpty(a)) {
/*     */       throw new RuntimeException(str1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void notNull(Object a, String str) {
/*     */     if (a == null)
/* 210 */       throw new RuntimeException(str); 
/*     */   }
/*     */   
/*     */   public static Long isPositiveToLong(String a, String str1) {
/*     */     Long long_;
/*     */     if ((long_ = isNumericToLong(a, str1)).longValue() <= 0L)
/*     */       throw new RuntimeException(str1); 
/*     */     return long_;
/*     */   }
/*     */   
/*     */   public static BigDecimal isPositiveToBigDecimal(String a, String str1) {
/*     */     BigDecimal bigDecimal;
/*     */     if ((bigDecimal = isNumericToBigDecimal(a, str1)).compareTo(BigDecimal.ZERO) <= 0)
/*     */       throw new RuntimeException(str1); 
/*     */     return bigDecimal;
/*     */   }
/*     */   
/*     */   public static <T> void notNull(Collection<?> a, String str) {
/*     */     if (CollUtil.isEmpty(a))
/*     */       throw new RuntimeException(str); 
/*     */   }
/*     */   
/*     */   public static void isTrue(int a, String str) {
/*     */     notTrue(false, (a == 0) ? str : str);
/*     */   }
/*     */   
/*     */   public static Integer isNumericToInt(String a, String str1) {
/*     */     return Integer.valueOf(((BigDecimal)NumberUtil.isNumericToBigDecimal(a).<Throwable>orElseThrow(() -> new RuntimeException(a))).intValue());
/*     */   }
/*     */   
/*     */   public static Long isNumericToLong(String a, String str1) {
/*     */     return Long.valueOf(((BigDecimal)NumberUtil.isNumericToBigDecimal(a).<Throwable>orElseThrow(() -> new RuntimeException(a))).longValue());
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\AssertUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */