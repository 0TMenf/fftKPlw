/*     */ package cn.handyplus.warp.lib;
/*     */ 
/*     */ import cn.handyplus.warp.util.WarpPermissionUtil;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileReader;
/*     */ import java.util.Map;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.yaml.snakeyaml.Yaml;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class YmlUtil
/*     */ {
/*     */   public static void beanToYml(Object a, String str1, String str2) {
/*     */     try {
/*  89 */       FileConfiguration fileConfiguration = HandyConfigUtil.load(str1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 223 */       HandyConfigUtil.createNewFile(str1 = setYml(str1)); if (fileConfiguration == null)
/*     */         return;  PropertyDescriptor[] arrayOfPropertyDescriptor; int i; byte b;
/* 225 */       for (i = (arrayOfPropertyDescriptor = Introspector.getBeanInfo(a.getClass()).getPropertyDescriptors()).length, b = 0; b < i;)
/*     */         str = (propertyDescriptor = arrayOfPropertyDescriptor[b]).getName(); 
/*     */     } catch (Throwable throwable) {
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static <T> T ymlToBean(String a, Class<T> clazz) {
/*     */     try {
/*     */       return ymlToBean(a, clazz, null);
/*     */     } catch (Throwable throwable) {
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static <T> T ymlToBean(String a, Class clazz, String str1) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokestatic setYml : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   4: dup
/*     */     //   5: astore_0
/*     */     //   6: invokestatic load : (Ljava/lang/String;)Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   9: astore_3
/*     */     //   10: aload_1
/*     */     //   11: dup
/*     */     //   12: invokestatic createBean : (Ljava/lang/Class;)Ljava/lang/Object;
/*     */     //   15: astore_1
/*     */     //   16: invokestatic getBeanInfo : (Ljava/lang/Class;)Ljava/beans/BeanInfo;
/*     */     //   19: invokeinterface getPropertyDescriptors : ()[Ljava/beans/PropertyDescriptor;
/*     */     //   24: dup
/*     */     //   25: astore #4
/*     */     //   27: arraylength
/*     */     //   28: istore #5
/*     */     //   30: iconst_0
/*     */     //   31: dup
/*     */     //   32: istore #6
/*     */     //   34: iload #5
/*     */     //   36: if_icmpge -> 144
/*     */     //   39: aload #4
/*     */     //   41: iload #6
/*     */     //   43: aaload
/*     */     //   44: dup
/*     */     //   45: astore #7
/*     */     //   47: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   50: astore #8
/*     */     //   52: ldc 'class'
/*     */     //   54: aload #8
/*     */     //   56: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
/*     */     //   59: ifeq -> 66
/*     */     //   62: goto -> 135
/*     */     //   65: athrow
/*     */     //   66: aload_2
/*     */     //   67: invokestatic isNotEmpty : (Ljava/lang/CharSequence;)Z
/*     */     //   70: ifeq -> 100
/*     */     //   73: new java/lang/StringBuilder
/*     */     //   76: dup
/*     */     //   77: invokespecial <init> : ()V
/*     */     //   80: iconst_0
/*     */     //   81: aload_2
/*     */     //   82: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   85: ldc '.'
/*     */     //   87: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   90: aload #8
/*     */     //   92: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   95: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   98: astore #8
/*     */     //   100: aload_3
/*     */     //   101: aload #8
/*     */     //   103: invokevirtual contains : (Ljava/lang/String;)Z
/*     */     //   106: ifeq -> 135
/*     */     //   109: aload #7
/*     */     //   111: invokevirtual getWriteMethod : ()Ljava/lang/reflect/Method;
/*     */     //   114: aload_1
/*     */     //   115: iconst_1
/*     */     //   116: anewarray java/lang/Object
/*     */     //   119: iconst_1
/*     */     //   120: dup
/*     */     //   121: pop2
/*     */     //   122: dup
/*     */     //   123: iconst_0
/*     */     //   124: aload_3
/*     */     //   125: aload #8
/*     */     //   127: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
/*     */     //   130: aastore
/*     */     //   131: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   134: pop
/*     */     //   135: iinc #6, 1
/*     */     //   138: iload #6
/*     */     //   140: goto -> 34
/*     */     //   143: athrow
/*     */     //   144: aload_1
/*     */     //   145: areturn
/*     */     //   146: astore_3
/*     */     //   147: aload_3
/*     */     //   148: athrow
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #50	-> 0
/*     */     //   #144	-> 6
/*     */     //   #175	-> 10
/*     */     //   #184	-> 16
/*     */     //   #75	-> 19
/*     */     //   #38	-> 25
/*     */     //   #87	-> 47
/*     */     //   #72	-> 52
/*     */     //   #107	-> 62
/*     */     //   #211	-> 66
/*     */     //   #127	-> 73
/*     */     //   #78	-> 100
/*     */     //   #203	-> 109
/*     */     //   #38	-> 135
/*     */     //   #149	-> 144
/*     */     //   #198	-> 146
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	149	0	a	Ljava/lang/String;
/*     */     //   0	149	1	a	Ljava/lang/Class;
/*     */     //   0	149	2	a	Ljava/lang/String;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   0	65	146	java/lang/Throwable
/*     */     //   66	143	146	java/lang/Throwable
/*     */     //   144	145	146	java/lang/Throwable
/*     */   }
/*     */   
/*     */   public static Map<String, Object> ymlToMap(String a) {
/*     */     try {
/*     */       return (Map<String, Object>)(new Yaml()).load(new BufferedReader(new FileReader(InitApi.PLUGIN.getDataFolder() + HandyHttpUtil.qzlKeO("\017") + setYml(a))));
/*     */     } catch (Throwable throwable) {
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String setYml(String a) {
/*     */     if (!a.contains(WarpPermissionUtil.qzlKeO("\007ZDO")))
/*     */       a = (new StringBuilder()).insert(0, a).append(HandyHttpUtil.qzlKeO("mY.L")).toString(); 
/*     */     return a;
/*     */   }
/*     */   
/*     */   public static void beanToYml(Object a, String str) {
/*     */     try {
/*     */       beanToYml(a, str, null);
/*     */       return;
/*     */     } catch (Throwable throwable) {
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\lib\YmlUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */