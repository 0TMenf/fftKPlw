/*    */ package cn.handyplus.warp.event;
/*    */ 
/*    */ import cn.handyplus.warp.lib.HandySchedulerUtil;
/*    */ import lombok.Generated;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WarpDeleteSuccessEvent
/*    */   extends Event
/*    */ {
/*    */   private final Player player;
/*    */   private final Integer warpId;
/*    */   private final boolean isOpDel;
/* 19 */   private static final HandlerList HANDLERS = new HandlerList(); @Generated
/* 20 */   public Player getPlayer() { return this.player; } @Generated
/* 21 */   public Integer getWarpId() { return this.warpId; } @Generated
/* 22 */   public boolean isOpDel() { return this.isOpDel; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WarpDeleteSuccessEvent(Player player, Integer warpId, boolean isOpDel) {
/* 32 */     this.player = player;
/* 33 */     this.warpId = warpId;
/* 34 */     this.isOpDel = isOpDel;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public HandlerList getHandlers() {
/* 39 */     return HANDLERS;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 43 */     return HANDLERS;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void callBuffEvent(Player player, Integer warpId, boolean isOpDel) {
/* 52 */     HandySchedulerUtil.runTask(() -> Bukkit.getServer().getPluginManager().callEvent(new WarpDeleteSuccessEvent(player, warpId, isOpDel)));
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\event\WarpDeleteSuccessEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */