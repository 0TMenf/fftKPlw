package cn.handyplus.warp.event;


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\event\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */