/*    */ package cn.handyplus.warp.event;
/*    */ 
/*    */ import cn.handyplus.warp.lib.BaseUtil;
/*    */ import cn.handyplus.warp.lib.MessageUtil;
/*    */ import cn.handyplus.warp.util.WarpUtil;
/*    */ import lombok.Generated;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Cancellable;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ public class WarpTpEvent
/*    */   extends Event
/*    */   implements Cancellable
/*    */ {
/*    */   private final Player player;
/*    */   private final Location location;
/*    */   private final String warpName;
/*    */   private boolean cancelled;
/* 23 */   private static final HandlerList HANDLERS = new HandlerList(); @Generated
/* 24 */   public Player getPlayer() { return this.player; } @Generated
/* 25 */   public Location getLocation() { return this.location; } @Generated
/* 26 */   public String getWarpName() { return this.warpName; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WarpTpEvent(Player player, Location location, String warpName) {
/* 37 */     super(!Bukkit.isPrimaryThread());
/* 38 */     this.player = player;
/* 39 */     this.location = location;
/* 40 */     this.warpName = warpName;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public HandlerList getHandlers() {
/* 45 */     return HANDLERS;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 49 */     return HANDLERS;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isCancelled() {
/* 54 */     return this.cancelled;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setCancelled(boolean cancelled) {
/* 59 */     this.cancelled = cancelled;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void success() {
/* 68 */     String warpTpTitle = BaseUtil.getLangMsg("warpTpTitle", "${name}");
/* 69 */     warpTpTitle = warpTpTitle.replace("${name}", this.warpName);
/*    */     
/* 71 */     String welcomeTitle = BaseUtil.getLangMsg("welcomeTitle", "");
/* 72 */     welcomeTitle = welcomeTitle.replace("${player}", this.player.getName());
/* 73 */     welcomeTitle = welcomeTitle.replace("${name}", this.warpName);
/* 74 */     MessageUtil.sendTitle(this.player, warpTpTitle, welcomeTitle);
/*    */     
/* 76 */     WarpUtil.executionCommand(this.player, "tpAfterCommand", this.warpName, this.location.getWorld().getName(), "");
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\event\WarpTpEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */