/*    */ package cn.handyplus.warp.event;
/*    */ 
/*    */ import cn.handyplus.warp.lib.HandySchedulerUtil;
/*    */ import lombok.Generated;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ import org.jetbrains.annotations.NotNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WarpCreateSuccessEvent
/*    */   extends Event
/*    */ {
/*    */   private final Player player;
/*    */   private final Integer warpId;
/* 19 */   private static final HandlerList HANDLERS = new HandlerList(); @Generated
/* 20 */   public Player getPlayer() { return this.player; } @Generated
/* 21 */   public Integer getWarpId() { return this.warpId; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WarpCreateSuccessEvent(Player player, Integer warpId) {
/* 30 */     this.player = player;
/* 31 */     this.warpId = warpId;
/*    */   }
/*    */   
/*    */   @NotNull
/*    */   public HandlerList getHandlers() {
/* 36 */     return HANDLERS;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 40 */     return HANDLERS;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void callBuffEvent(Player player, Integer warpId) {
/* 49 */     HandySchedulerUtil.runTask(() -> Bukkit.getServer().getPluginManager().callEvent(new WarpCreateSuccessEvent(player, warpId)));
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\event\WarpCreateSuccessEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */