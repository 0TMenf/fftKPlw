/*     */ package cn.handyplus.warp.command.player;
/*     */ import cn.handyplus.warp.constants.WarpTypeEnum;
/*     */ import cn.handyplus.warp.inventory.OpenGui;
/*     */ import cn.handyplus.warp.lib.AssertUtil;
/*     */ import cn.handyplus.warp.lib.BaseUtil;
/*     */ import cn.handyplus.warp.lib.BcUtil;
/*     */ import cn.handyplus.warp.lib.IHandyCommandEvent;
/*     */ import cn.handyplus.warp.lib.RgbTextUtil;
/*     */ import cn.handyplus.warp.param.OpenParam;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ 
/*     */ public class CollectionCommand implements IHandyCommandEvent {
/*     */   public void onCommand(CommandSender commandSender, Command command, String str, String[] arrayOfString) {
/*  16 */     Player player = AssertUtil.notPlayer(commandSender, BaseUtil.getLangMsg(BcUtil.qzlKeO("\026$('\0312\0359>*\021'\r9\035\006\013,")));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 170 */     String str1 = getArg(arrayOfString, 1).orElse(WarpTypeEnum.ALL.getType());
/*     */     OpenParam openParam = OpenParam.builder().isCollection(Boolean.valueOf(true)).searchType(str1).build();
/*     */     Inventory inventory = OpenGui.getInstance().createGui(player, openParam);
/*     */     PlayerSchedulerUtil.syncOpenInventory(player, inventory);
/*     */   }
/*     */   
/*     */   public String permission() {
/*     */     return RgbTextUtil.qzlKeO("L-]8Y3k N1\022\"S-P$_5U.R");
/*     */   }
/*     */   
/*     */   public String command() {
/*     */     return BcUtil.qzlKeO("\033$\024'\035(\f\"\027%");
/*     */   }
/*     */   
/*     */   public boolean isAsync() {
/*     */     return true;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\command\player\CollectionCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */