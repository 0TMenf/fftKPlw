/*     */ package cn.handyplus.warp.command.player;
/*     */ import cn.handyplus.warp.enter.WarpPlayer;
/*     */ 
/*     */ public class TpCommand implements IHandyCommandEvent {
/*     */   public String permission() {
/*   6 */     return SecureUtil.qzlKeO("VUG@CKqXTI\bMV");
/*     */   }
/*     */   public boolean isAsync() {
/*   9 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender commandSender, Command command, String str, String[] arrayOfString) {
/*  26 */     AssertUtil.notTrue((arrayOfString.length < 2), BaseUtil.getLangMsg(Pair.qzlKeO("<\031>\031!>-\021 \r>\035\001\013+")));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     Player player = AssertUtil.notPlayer(commandSender, BaseUtil.getLangMsg(SecureUtil.qzlKeO("WIiJX_\\TGPJLT\\kJA")));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String str1 = arrayOfString[1];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     List<WarpPlayer> list;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (CollUtil.isEmpty(list = WarpPlayerService.getInstance().findNotExpirationByName(str1))) {
/*     */       MessageUtil.sendMessage(player, BaseUtil.getLangMsg(Pair.qzlKeO("\"\027\033\031>\b\001\013+")));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     WarpPlayer warpPlayer = list.get(0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 186 */     if (WarpUtil.tpCheck(player, warpPlayer))
/*     */       WarpUtil.runTaskTp(player, warpPlayer); 
/*     */   }
/*     */   
/*     */   public String command() {
/*     */     return Pair.qzlKeO("\f<");
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\command\player\TpCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */