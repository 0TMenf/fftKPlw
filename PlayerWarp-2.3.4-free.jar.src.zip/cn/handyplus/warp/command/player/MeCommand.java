/*    */ package cn.handyplus.warp.command.player;
/*    */ import cn.handyplus.warp.constants.WarpTypeEnum;
/*    */ import cn.handyplus.warp.inventory.MeGui;
/*    */ import cn.handyplus.warp.lib.AssertUtil;
/*    */ import cn.handyplus.warp.lib.BaseUtil;
/*    */ import cn.handyplus.warp.lib.IHandyCommandEvent;
/*    */ import cn.handyplus.warp.param.OpenParam;
/*    */ import cn.handyplus.warp.service.WarpTpPlayerService;
/*    */ import cn.handyplus.warp.util.WarpPermissionUtil;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.Inventory;
/*    */ 
/*    */ public class MeCommand implements IHandyCommandEvent {
/*    */   public void onCommand(CommandSender commandSender, Command command, String str, String[] arrayOfString) {
/* 16 */     Player player = AssertUtil.notPlayer(commandSender, BaseUtil.getLangMsg(WarpTpPlayerService.qzlKeO("mDSGbRfYEJjGvYffpL")));
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 26 */     OpenParam openParam = OpenParam.builder().isCollection(Boolean.valueOf(false)).searchType(WarpTypeEnum.ALL.getType()).build();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 43 */     Inventory inventory = MeGui.getInstance().createGui(player, openParam);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 55 */     PlayerSchedulerUtil.syncOpenInventory(player, inventory);
/*    */   }
/*    */   public String permission() {
/*    */     return WarpPermissionUtil.qzlKeO("SEBPF[tHQY\rDF");
/*    */   }
/*    */   public boolean isAsync() {
/* 61 */     return true;
/*    */   }
/*    */   
/*    */   public String command() {
/*    */     return WarpTpPlayerService.qzlKeO("nN");
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\command\player\MeCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */