/*     */ package cn.handyplus.warp.command.player;
/*     */ 
/*     */ import cn.handyplus.warp.enter.WarpPlayer;
/*     */ import cn.handyplus.warp.lib.AssertUtil;
/*     */ import cn.handyplus.warp.lib.BaseUtil;
/*     */ import cn.handyplus.warp.lib.IHandyCommandEvent;
/*     */ import cn.handyplus.warp.lib.MessageUtil;
/*     */ import cn.handyplus.warp.lib.SecureUtil;
/*     */ import cn.handyplus.warp.service.WarpPlayerService;
/*     */ import cn.handyplus.warp.util.WarpUtil;
/*     */ import java.util.Optional;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TpIdCommand
/*     */   implements IHandyCommandEvent
/*     */ {
/*     */   public String command() {
/*  41 */     return SecureUtil.qzlKeO("MVpB");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAsync() {
/* 101 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender commandSender, Command command, String str, String[] arrayOfString) {
/* 170 */     AssertUtil.notTrue((arrayOfString.length < 2), BaseUtil.getLangMsg(SecureUtil.qzlKeO("VXTXKGPJLT\\kJA")));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Integer integer = AssertUtil.isPositiveToInt(arrayOfString[1], BaseUtil.getLangMsg(SecureUtil.qzlKeO("XKVSWRGPJLT\\kJA")));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Player player = AssertUtil.notPlayer(commandSender, BaseUtil.getLangMsg(SecureUtil.qzlKeO("WIiJX_\\TGPJLT\\kJA")));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Optional<?> optional;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (!(optional = WarpPlayerService.getInstance().findById(integer)).isPresent()) {
/*     */       MessageUtil.sendMessage(player, BaseUtil.getLangMsg(SecureUtil.qzlKeO("HVqXTIkJA")));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     WarpPlayer warpPlayer = (WarpPlayer)optional.get();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     if (WarpUtil.tpCheck(player, warpPlayer))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 228 */       WarpUtil.runTaskTp(player, warpPlayer);
/*     */     }
/*     */   }
/*     */   
/*     */   public String permission() {
/*     */     return SecureUtil.qzlKeO("VUG@CKqXTI\bMVpB");
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\command\player\TpIdCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */