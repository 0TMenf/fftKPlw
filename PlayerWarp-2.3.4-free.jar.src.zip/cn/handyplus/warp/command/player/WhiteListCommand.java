/*     */ package cn.handyplus.warp.command.player;
/*     */ 
/*     */ import cn.handyplus.warp.lib.ClassUtil;
/*     */ import cn.handyplus.warp.lib.IHandyCommandEvent;
/*     */ import cn.handyplus.warp.lib.Page;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WhiteListCommand
/*     */   implements IHandyCommandEvent
/*     */ {
/*     */   public boolean isAsync() {
/*  18 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender commandSender, Command command, String str, String[] arrayOfString) {
/*     */     // Byte code:
/*     */     //   0: aload #4
/*     */     //   2: arraylength
/*     */     //   3: iconst_4
/*     */     //   4: if_icmpge -> 12
/*     */     //   7: iconst_1
/*     */     //   8: goto -> 13
/*     */     //   11: athrow
/*     */     //   12: iconst_0
/*     */     //   13: ldc 'PRM,ALRmG'
/*     */     //   15: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   18: invokestatic getLangMsg : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   21: invokestatic notTrue : (ZLjava/lang/String;)V
/*     */     //   24: aload #4
/*     */     //   26: iconst_1
/*     */     //   27: aaload
/*     */     //   28: invokevirtual toLowerCase : ()Ljava/lang/String;
/*     */     //   31: astore_2
/*     */     //   32: ldc 'JhemJ`V~FAPk'
/*     */     //   34: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   37: ldc 'I]'
/*     */     //   39: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   42: aload #4
/*     */     //   44: dup_x2
/*     */     //   45: iconst_2
/*     */     //   46: aaload
/*     */     //   47: invokestatic of : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/HashMap;
/*     */     //   50: invokestatic getLangMsg : (Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;
/*     */     //   53: astore_3
/*     */     //   54: iconst_2
/*     */     //   55: aaload
/*     */     //   56: aload_3
/*     */     //   57: invokestatic isPositiveToInt : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Integer;
/*     */     //   60: astore #5
/*     */     //   62: invokestatic getInstance : ()Lcn/handyplus/warp/service/WarpPlayerService;
/*     */     //   65: aload #5
/*     */     //   67: invokevirtual findById : (Ljava/lang/Integer;)Ljava/util/Optional;
/*     */     //   70: dup
/*     */     //   71: astore #6
/*     */     //   73: invokevirtual isPresent : ()Z
/*     */     //   76: ifne -> 86
/*     */     //   79: aload_1
/*     */     //   80: aload_3
/*     */     //   81: invokestatic sendMessage : (Lorg/bukkit/command/CommandSender;Ljava/lang/String;)V
/*     */     //   84: return
/*     */     //   85: athrow
/*     */     //   86: aload_1
/*     */     //   87: invokestatic isPlayer : (Lorg/bukkit/command/CommandSender;)Ljava/lang/Boolean;
/*     */     //   90: invokevirtual booleanValue : ()Z
/*     */     //   93: ifeq -> 132
/*     */     //   96: aload_1
/*     */     //   97: checkcast org/bukkit/entity/Player
/*     */     //   100: astore #7
/*     */     //   102: aload #6
/*     */     //   104: invokevirtual get : ()Ljava/lang/Object;
/*     */     //   107: checkcast cn/handyplus/warp/enter/WarpPlayer
/*     */     //   110: invokevirtual getPlayerUuid : ()Ljava/util/UUID;
/*     */     //   113: aload #7
/*     */     //   115: invokeinterface getUniqueId : ()Ljava/util/UUID;
/*     */     //   120: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   123: ifne -> 132
/*     */     //   126: aload_1
/*     */     //   127: aload_3
/*     */     //   128: invokestatic sendMessage : (Lorg/bukkit/command/CommandSender;Ljava/lang/String;)V
/*     */     //   131: return
/*     */     //   132: aload #4
/*     */     //   134: iconst_3
/*     */     //   135: aaload
/*     */     //   136: dup
/*     */     //   137: astore #7
/*     */     //   139: invokestatic getOfflinePlayer : (Ljava/lang/String;)Lorg/bukkit/OfflinePlayer;
/*     */     //   142: astore_3
/*     */     //   143: aload_2
/*     */     //   144: astore_2
/*     */     //   145: iconst_m1
/*     */     //   146: istore #6
/*     */     //   148: aload_2
/*     */     //   149: invokevirtual hashCode : ()I
/*     */     //   152: lookupswitch default -> 221, 96417 -> 180, 99339 -> 206
/*     */     //   180: aload_2
/*     */     //   181: iconst_0
/*     */     //   182: ifne -> 203
/*     */     //   185: ldc 'mGh'
/*     */     //   187: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   190: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   193: ifeq -> 221
/*     */     //   196: iconst_0
/*     */     //   197: dup
/*     */     //   198: istore #6
/*     */     //   200: goto -> 223
/*     */     //   203: goto -> 181
/*     */     //   206: aload_2
/*     */     //   207: ldc 'DL'
/*     */     //   209: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   212: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   215: ifeq -> 221
/*     */     //   218: iconst_1
/*     */     //   219: istore #6
/*     */     //   221: iload #6
/*     */     //   223: lookupswitch default -> 392, 0 -> 248, 1 -> 353
/*     */     //   248: invokestatic getInstance : ()Lcn/handyplus/warp/service/WarpWhiteListService;
/*     */     //   251: iconst_0
/*     */     //   252: ifne -> 350
/*     */     //   255: aload #5
/*     */     //   257: aload_3
/*     */     //   258: invokeinterface getUniqueId : ()Ljava/util/UUID;
/*     */     //   263: invokevirtual findByWarpIdAndPlayerUuid : (Ljava/lang/Integer;Ljava/util/UUID;)Ljava/util/Optional;
/*     */     //   266: invokevirtual isPresent : ()Z
/*     */     //   269: ifeq -> 285
/*     */     //   272: aload_1
/*     */     //   273: ldc '{KeWipy@oFiGAPk'
/*     */     //   275: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   278: invokestatic getLangMsg : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   281: invokestatic sendMessage : (Lorg/bukkit/command/CommandSender;Ljava/lang/String;)V
/*     */     //   284: return
/*     */     //   285: new cn/handyplus/warp/enter/WarpWhiteList
/*     */     //   288: dup
/*     */     //   289: invokespecial <init> : ()V
/*     */     //   292: astore_2
/*     */     //   293: aload_1
/*     */     //   294: aload_3
/*     */     //   295: aload_2
/*     */     //   296: dup_x1
/*     */     //   297: aload_3
/*     */     //   298: aload_2
/*     */     //   299: aload #5
/*     */     //   301: invokevirtual setWarpPlayerId : (Ljava/lang/Integer;)V
/*     */     //   304: invokeinterface getName : ()Ljava/lang/String;
/*     */     //   309: invokevirtual setPlayerName : (Ljava/lang/String;)V
/*     */     //   312: invokeinterface getUniqueId : ()Ljava/util/UUID;
/*     */     //   317: invokevirtual setPlayerUuid : (Ljava/util/UUID;)V
/*     */     //   320: invokestatic getInstance : ()Lcn/handyplus/warp/service/WarpWhiteListService;
/*     */     //   323: aload_2
/*     */     //   324: invokevirtual add : (Lcn/handyplus/warp/enter/WarpWhiteList;)Z
/*     */     //   327: ifeq -> 338
/*     */     //   330: ldc 'WIE9U\\tCEmG'
/*     */     //   332: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   335: goto -> 343
/*     */     //   338: ldc '{KeWiemJ`V~FAPk'
/*     */     //   340: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   343: invokestatic getLangMsg : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   346: invokestatic sendMessage : (Lorg/bukkit/command/CommandSender;Ljava/lang/String;)V
/*     */     //   349: return
/*     */     //   350: goto -> 251
/*     */     //   353: invokestatic getInstance : ()Lcn/handyplus/warp/service/WarpWhiteListService;
/*     */     //   356: aload #5
/*     */     //   358: aload_3
/*     */     //   359: invokeinterface getUniqueId : ()Ljava/util/UUID;
/*     */     //   364: invokevirtual deleteByWarpIdAndPlayerUuid : (Ljava/lang/Integer;Ljava/util/UUID;)V
/*     */     //   367: ldc 'HTdL9U\\tCEmG'
/*     */     //   369: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   372: ldc '(XbBaFq'
/*     */     //   374: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   377: aload #7
/*     */     //   379: invokestatic of : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/HashMap;
/*     */     //   382: invokestatic getLangMsg : (Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;
/*     */     //   385: astore_2
/*     */     //   386: aload_1
/*     */     //   387: aload_2
/*     */     //   388: invokestatic sendMessage : (Lorg/bukkit/command/CommandSender;Ljava/lang/String;)V
/*     */     //   391: return
/*     */     //   392: ldc 'YE,ALRmG'
/*     */     //   394: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   397: ldc '(XxZ|Fq'
/*     */     //   399: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   402: aload #4
/*     */     //   404: iconst_1
/*     */     //   405: aaload
/*     */     //   406: ldc 'N[I]'
/*     */     //   408: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   411: ldc 'BhG,L~hF`'
/*     */     //   413: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   416: invokestatic of : (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/HashMap;
/*     */     //   419: invokestatic getLangMsg : (Ljava/lang/String;Ljava/util/Map;)Ljava/lang/String;
/*     */     //   422: astore_2
/*     */     //   423: aload_1
/*     */     //   424: aload_2
/*     */     //   425: invokestatic sendMessage : (Lorg/bukkit/command/CommandSender;Ljava/lang/String;)V
/*     */     //   428: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #55	-> 0
/*     */     //   #44	-> 24
/*     */     //   #31	-> 32
/*     */     //   #54	-> 54
/*     */     //   #64	-> 62
/*     */     //   #86	-> 73
/*     */     //   #210	-> 79
/*     */     //   #186	-> 84
/*     */     //   #109	-> 86
/*     */     //   #178	-> 96
/*     */     //   #48	-> 102
/*     */     //   #154	-> 126
/*     */     //   #224	-> 131
/*     */     //   #201	-> 132
/*     */     //   #223	-> 139
/*     */     //   #218	-> 143
/*     */     //   #137	-> 248
/*     */     //   #200	-> 272
/*     */     //   #121	-> 284
/*     */     //   #191	-> 285
/*     */     //   #166	-> 294
/*     */     //   #152	-> 304
/*     */     //   #47	-> 312
/*     */     //   #208	-> 320
/*     */     //   #34	-> 327
/*     */     //   #163	-> 349
/*     */     //   #220	-> 353
/*     */     //   #56	-> 367
/*     */     //   #190	-> 386
/*     */     //   #8	-> 391
/*     */     //   #145	-> 392
/*     */     //   #59	-> 423
/*     */     //   #161	-> 428
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	429	0	a	Lcn/handyplus/warp/command/player/WhiteListCommand;
/*     */     //   0	429	1	a	Lorg/bukkit/command/CommandSender;
/*     */     //   0	429	2	a	Lorg/bukkit/command/Command;
/*     */     //   0	429	3	a	Ljava/lang/String;
/*     */     //   0	429	4	a	[Ljava/lang/String;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String command() {
/* 169 */     return ClassUtil.qzlKeO("W\002I\036E&I\031T");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String permission() {
/* 196 */     return Page.qzlKeO("S`BuF~tmQ|\r{KeWioePx");
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\command\player\WhiteListCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */