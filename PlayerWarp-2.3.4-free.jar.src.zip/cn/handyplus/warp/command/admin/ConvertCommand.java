/*     */ package cn.handyplus.warp.command.admin;
/*     */ import cn.handyplus.warp.enter.WarpPlayer;
/*     */ import cn.handyplus.warp.enter.WarpWhiteList;
/*     */ import cn.handyplus.warp.lib.BaseConstants;
/*     */ import cn.handyplus.warp.lib.BaseUtil;
/*     */ import cn.handyplus.warp.lib.Db;
/*     */ import cn.handyplus.warp.lib.DbTypeEnum;
/*     */ import cn.handyplus.warp.lib.HandyHttpUtil;
/*     */ import cn.handyplus.warp.lib.MessageUtil;
/*     */ import cn.handyplus.warp.service.WarpChannelService;
/*     */ import java.util.List;
/*     */ import org.bukkit.command.CommandSender;
/*     */ 
/*     */ public class ConvertCommand implements IHandyCommandEvent {
/*     */   public String command() {
/*  16 */     return HandyHttpUtil.qzlKeO("C,N5E1T");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAsync() {
/*  64 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String permission() {
/* 124 */     return WarpChannelService.qzlKeO("~EoPk[YH|Y JaGxL|]");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender commandSender, Command command, String str, String[] arrayOfString) {
/* 136 */     AssertUtil.notTrue((arrayOfString.length < 2), BaseUtil.getLangMsg(HandyHttpUtil.qzlKeO("P\"R\"M\005A*L6R&m0G")));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String str1 = arrayOfString[1];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     if (!DbTypeEnum.MySQL.getType().equalsIgnoreCase(str1) && !DbTypeEnum.SQLite.getType().equalsIgnoreCase(str1)) {
/* 178 */       MessageUtil.sendMessage(commandSender, BaseUtil.getLangMsg(WarpChannelService.qzlKeO("Yo[oDHHgE{[kd}N")));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 224 */     if (str1.equalsIgnoreCase(BaseConstants.STORAGE_CONFIG.getString("storage-method"))) {
/*     */       super();
/*     */       MessageUtil.sendMessage((CommandSender)new StringBuilder(), commandSender.append(HandyHttpUtil.qzlKeO("e\024秂歂輯捂ｂ县嚣Ｌ惫彳刎佟畫皤嬛傈旺弯嶱绯乹Ｚ")).append(str1).toString());
/*     */       return;
/*     */     } 
/*     */     List list1 = WarpChannelService.getInstance().findAll();
/*     */     List list2 = WarpCollectionService.getInstance().findAll();
/*     */     List list3 = WarpLikePlayerService.getInstance().findAll();
/*     */     List list4 = WarpPlayerService.getInstance().findAll();
/*     */     List list5 = WarpWhiteListService.getInstance().findAll(), list6 = WarpTpPlayerService.getInstance().findAll();
/*     */     HandyConfigUtil.setPath(BaseConstants.STORAGE_CONFIG, "storage-method", str1, Collections.singletonList(WarpChannelService.qzlKeO("孱傦斐泛\001CP]xB\005]xB@zL'诞夃刟拢叞冋皭籵垢\"两規臃巿冰")), HandyHttpUtil.qzlKeO("S7O1A$EmY.L"));
/*     */     SqlManagerUtil.getInstance().enableSql();
/*     */     Db.use(WarpChannel.class).createTable();
/*     */     Db.use(WarpCollection.class).createTable();
/*     */     Db.use(WarpLikePlayer.class).createTable();
/*     */     Db.use(WarpPlayer.class).createTable();
/*     */     Db.use(WarpWhiteList.class).createTable();
/*     */     Db.use(WarpTpPlayer.class).createTable();
/*     */     MessageUtil.sendMessage(commandSender, WarpChannelService.qzlKeO("\017:轅捬教捠宥戞Ｅ诹劈忋釤吡朤劯噁＂两焸朠叡胔伔凓玾會矫K{N"));
/*     */     Db.use(WarpTpPlayer.class).execution().insertBatch(list6);
/*     */     Db.use(WarpWhiteList.class).execution().insertBatch(list5);
/*     */     Db.use(WarpPlayer.class).execution().insertBatch(list4);
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\command\admin\ConvertCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */