/*     */ package cn.handyplus.warp.command.admin;
/*     */ import cn.handyplus.warp.lib.AssertUtil;
/*     */ import cn.handyplus.warp.lib.BaseUtil;
/*     */ import cn.handyplus.warp.service.WarpCollectionService;
/*     */ import org.bukkit.OfflinePlayer;
/*     */ 
/*     */ public class CreateCommand implements IHandyCommandEvent {
/*     */   public void onCommand(CommandSender commandSender, Command command, String str, String[] arrayOfString) {
/*   9 */     AssertUtil.notTrue((arrayOfString.length < 4), BaseUtil.getLangMsg(HandyHttpUtil.qzlKeO("P\"R\"M\005A*L6R&m0G")));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     OfflinePlayer offlinePlayer = BaseUtil.getOfflinePlayer(arrayOfString[1]); Integer integer = AssertUtil.isPositiveToInt(arrayOfString[3], BaseUtil.getLangMsg(WarpCollectionService.qzlKeO("&[(C)B\001W.Z2D\"{4Q")));
/*     */     WarpUtil.addWarp(offlinePlayer.getPlayer(), arrayOfString[2], integer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String permission() {
/*     */     return WarpCollectionService.qzlKeO("F+W>S5a&D7\030$D\"W3S");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String command() {
/* 150 */     return HandyHttpUtil.qzlKeO(" R&A7E");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAsync() {
/* 183 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\command\admin\CreateCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */