/*     */ package cn.handyplus.warp.command.admin;
/*     */ 
/*     */ import cn.handyplus.warp.constants.WarpTypeEnum;
/*     */ import cn.handyplus.warp.inventory.CreateGui;
/*     */ import cn.handyplus.warp.lib.AssertUtil;
/*     */ import cn.handyplus.warp.lib.BaseUtil;
/*     */ import cn.handyplus.warp.lib.IHandyCommandEvent;
/*     */ import cn.handyplus.warp.lib.InventoryViewUtil;
/*     */ import cn.handyplus.warp.lib.Page;
/*     */ import cn.handyplus.warp.lib.PlayerSchedulerUtil;
/*     */ import cn.handyplus.warp.param.OpenParam;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CreateGuiCommand
/*     */   implements IHandyCommandEvent
/*     */ {
/*     */   public String command() {
/*  41 */     return Page.qzlKeO("oQiBxFKVe");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAsync() {
/* 101 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender commandSender, Command command, String str, String[] arrayOfString) {
/* 170 */     Player player = AssertUtil.notPlayer(commandSender, BaseUtil.getLangMsg(Page.qzlKeO("Mcs`BuF~emJ`V~FAPk")));
/*     */     OpenParam openParam = OpenParam.builder().isCollection(Boolean.valueOf(false)).searchType(WarpTypeEnum.ALL.getType()).build();
/*     */     Inventory inventory = CreateGui.getInstance().createGui(player, openParam);
/*     */     PlayerSchedulerUtil.syncOpenInventory(player, inventory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String permission() {
/* 183 */     return InventoryViewUtil.qzlKeO("l\004}\021y\032K\tn\0302\013n\r}\034y/i\001");
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\command\admin\CreateGuiCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */