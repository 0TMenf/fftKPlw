/*     */ package cn.handyplus.warp.command.function;
/*     */ 
/*     */ import cn.handyplus.warp.lib.IHandyCommandEvent;
/*     */ import cn.handyplus.warp.lib.InventoryViewUtil;
/*     */ import cn.handyplus.warp.lib.MessageUtil;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandSender;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetLogoCommand
/*     */   implements IHandyCommandEvent
/*     */ {
/*     */   public boolean isAsync() {
/*  26 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onCommand(CommandSender commandSender, Command command, String str, String[] arrayOfString) {
/*     */     // Byte code:
/*     */     //   0: aload #4
/*     */     //   2: arraylength
/*     */     //   3: iconst_2
/*     */     //   4: if_icmpge -> 12
/*     */     //   7: iconst_1
/*     */     //   8: goto -> 13
/*     */     //   11: athrow
/*     */     //   12: iconst_0
/*     */     //   13: ldc 'w^u^jyfVkJuZJL`'
/*     */     //   15: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   18: invokestatic getLangMsg : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   21: invokestatic notTrue : (ZLjava/lang/String;)V
/*     */     //   24: aload #4
/*     */     //   26: iconst_1
/*     */     //   27: aaload
/*     */     //   28: ldc '}srZ\\tuiy%o'
/*     */     //   30: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   33: invokestatic getLangMsg : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   36: invokestatic isPositiveToInt : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Integer;
/*     */     //   39: astore_2
/*     */     //   40: aload_1
/*     */     //   41: ldc 'Qhok^~ZuyfVkJuZJL`'
/*     */     //   43: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   46: invokestatic getLangMsg : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   49: invokestatic notPlayer : (Lorg/bukkit/command/CommandSender;Ljava/lang/String;)Lorg/bukkit/entity/Player;
/*     */     //   52: dup
/*     */     //   53: astore_3
/*     */     //   54: invokeinterface getInventory : ()Lorg/bukkit/inventory/PlayerInventory;
/*     */     //   59: invokestatic getItemInMainHand : (Lorg/bukkit/inventory/PlayerInventory;)Lorg/bukkit/inventory/ItemStack;
/*     */     //   62: dup
/*     */     //   63: astore #4
/*     */     //   65: ifnull -> 82
/*     */     //   68: getstatic org/bukkit/Material.AIR : Lorg/bukkit/Material;
/*     */     //   71: aload #4
/*     */     //   73: invokevirtual getType : ()Lorg/bukkit/Material;
/*     */     //   76: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   79: ifeq -> 144
/*     */     //   82: getstatic cn/handyplus/warp/lib/BaseConstants.CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   85: ldc 'o\\rh,y}pP{'
/*     */     //   87: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   90: ldc 'WsFfBmXwB~C'
/*     */     //   92: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   95: invokevirtual getString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   98: dup
/*     */     //   99: astore #5
/*     */     //   101: invokestatic getItemStack : (Ljava/lang/String;)Lorg/bukkit/inventory/ItemStack;
/*     */     //   104: dup
/*     */     //   105: astore #4
/*     */     //   107: invokevirtual getItemMeta : ()Lorg/bukkit/inventory/meta/ItemMeta;
/*     */     //   110: dup
/*     */     //   111: astore #6
/*     */     //   113: instanceof org/bukkit/inventory/meta/SkullMeta
/*     */     //   116: ifeq -> 144
/*     */     //   119: aload #6
/*     */     //   121: checkcast org/bukkit/inventory/meta/SkullMeta
/*     */     //   124: astore #7
/*     */     //   126: aload #4
/*     */     //   128: aload #7
/*     */     //   130: dup
/*     */     //   131: aload_3
/*     */     //   132: invokeinterface getName : ()Ljava/lang/String;
/*     */     //   137: invokestatic setOwner : (Lorg/bukkit/inventory/meta/SkullMeta;Ljava/lang/String;)V
/*     */     //   140: invokevirtual setItemMeta : (Lorg/bukkit/inventory/meta/ItemMeta;)Z
/*     */     //   143: pop
/*     */     //   144: aload #4
/*     */     //   146: invokevirtual clone : ()Lorg/bukkit/inventory/ItemStack;
/*     */     //   149: dup
/*     */     //   150: astore #5
/*     */     //   152: dup
/*     */     //   153: iconst_1
/*     */     //   154: invokevirtual setAmount : (I)V
/*     */     //   157: invokestatic itemStackSerialize : (Lorg/bukkit/inventory/ItemStack;)Ljava/lang/String;
/*     */     //   160: astore #6
/*     */     //   162: invokestatic getInstance : ()Lcn/handyplus/warp/service/WarpPlayerService;
/*     */     //   165: aload_2
/*     */     //   166: invokevirtual findById : (Ljava/lang/Integer;)Ljava/util/Optional;
/*     */     //   169: dup
/*     */     //   170: astore #7
/*     */     //   172: invokevirtual isPresent : ()Z
/*     */     //   175: ifne -> 180
/*     */     //   178: return
/*     */     //   179: athrow
/*     */     //   180: aload #7
/*     */     //   182: invokevirtual get : ()Ljava/lang/Object;
/*     */     //   185: checkcast cn/handyplus/warp/enter/WarpPlayer
/*     */     //   188: astore_2
/*     */     //   189: aload_3
/*     */     //   190: invokeinterface isOp : ()Z
/*     */     //   195: ifne -> 227
/*     */     //   198: aload_2
/*     */     //   199: invokevirtual getPlayerUuid : ()Ljava/util/UUID;
/*     */     //   202: aload_3
/*     */     //   203: invokeinterface getUniqueId : ()Ljava/util/UUID;
/*     */     //   208: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   211: ifne -> 227
/*     */     //   214: aload_1
/*     */     //   215: ldc 'rK\\tnSr\\rn%o'
/*     */     //   217: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   220: invokestatic getLangMsg : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   223: invokestatic sendMessage : (Lorg/bukkit/command/CommandSender;Ljava/lang/String;)V
/*     */     //   226: return
/*     */     //   227: aload_2
/*     */     //   228: aload #6
/*     */     //   230: invokevirtual setLogoName : (Ljava/lang/String;)V
/*     */     //   233: invokestatic getInstance : ()Lcn/handyplus/warp/service/WarpPlayerService;
/*     */     //   236: aload_2
/*     */     //   237: invokevirtual update : (Lcn/handyplus/warp/enter/WarpPlayer;)V
/*     */     //   240: aload_3
/*     */     //   241: getstatic cn/handyplus/warp/util/ConfigUtil.ADMIN_CONFIG : Lorg/bukkit/configuration/file/FileConfiguration;
/*     */     //   244: ldc 'PlshXh}rKsPi'
/*     */     //   246: invokestatic qzlKeO : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   249: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   252: invokestatic sendMessage : (Lorg/bukkit/entity/Player;Ljava/lang/String;)V
/*     */     //   255: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #31	-> 0
/*     */     //   #64	-> 24
/*     */     //   #86	-> 40
/*     */     //   #210	-> 54
/*     */     //   #228	-> 65
/*     */     //   #136	-> 82
/*     */     //   #109	-> 101
/*     */     //   #94	-> 107
/*     */     //   #178	-> 113
/*     */     //   #48	-> 119
/*     */     //   #224	-> 140
/*     */     //   #1	-> 144
/*     */     //   #201	-> 152
/*     */     //   #223	-> 157
/*     */     //   #218	-> 162
/*     */     //   #89	-> 172
/*     */     //   #79	-> 178
/*     */     //   #121	-> 189
/*     */     //   #225	-> 214
/*     */     //   #191	-> 226
/*     */     //   #152	-> 227
/*     */     //   #47	-> 233
/*     */     //   #208	-> 240
/*     */     //   #34	-> 255
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	256	0	a	Lcn/handyplus/warp/command/function/SetLogoCommand;
/*     */     //   0	256	1	a	Lorg/bukkit/command/CommandSender;
/*     */     //   0	256	2	a	Lorg/bukkit/command/Command;
/*     */     //   0	256	3	a	Ljava/lang/String;
/*     */     //   0	256	4	a	[Ljava/lang/String;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String permission() {
/* 134 */     return InventoryViewUtil.qzlKeO("l\004}\021y\032K\tn\0302\033y\034P\007{\007");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String command() {
/* 142 */     return MessageUtil.qzlKeO("tZsshXh");
/*     */   }
/*     */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\command\function\SetLogoCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */