/*    */ package cn.handyplus.warp.enter;
/*    */ 
/*    */ import cn.handyplus.warp.lib.TableField;
/*    */ import java.util.Date;
/*    */ import java.util.UUID;
/*    */ import lombok.Generated;
/*    */ 
/*    */ @TableName(value = "warp_tp_player", comment = "玩家地标传送记录")
/*    */ public class WarpTpPlayer {
/*    */   @TableField(value = "id", comment = "ID")
/*    */   private Integer id;
/*    */   @TableField(value = "player_name", comment = "玩家名称", notNull = true)
/*    */   private String playerName;
/*    */   
/*    */   @Generated
/* 16 */   public void setId(Integer id) { this.id = id; } @TableField(value = "player_uuid", comment = "玩家uuid", notNull = true) private UUID playerUuid; @TableField(value = "warp_player_id", comment = "地标id", notNull = true, indexEnum = IndexEnum.INDEX) private Integer warpPlayerId; @TableField(value = "tp_time", comment = "传送时间") private Date tpTime; @Generated public void setPlayerName(String playerName) { this.playerName = playerName; } @Generated public void setPlayerUuid(UUID playerUuid) { this.playerUuid = playerUuid; } @Generated public void setWarpPlayerId(Integer warpPlayerId) { this.warpPlayerId = warpPlayerId; } @Generated public void setTpTime(Date tpTime) { this.tpTime = tpTime; } @Generated public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof WarpTpPlayer)) return false;  WarpTpPlayer other = (WarpTpPlayer)o; if (!other.canEqual(this)) return false;  Object this$id = getId(), other$id = other.getId(); if ((this$id == null) ? (other$id != null) : !this$id.equals(other$id)) return false;  Object this$warpPlayerId = getWarpPlayerId(), other$warpPlayerId = other.getWarpPlayerId(); if ((this$warpPlayerId == null) ? (other$warpPlayerId != null) : !this$warpPlayerId.equals(other$warpPlayerId)) return false;  Object this$playerName = getPlayerName(), other$playerName = other.getPlayerName(); if ((this$playerName == null) ? (other$playerName != null) : !this$playerName.equals(other$playerName)) return false;  Object this$playerUuid = getPlayerUuid(), other$playerUuid = other.getPlayerUuid(); if ((this$playerUuid == null) ? (other$playerUuid != null) : !this$playerUuid.equals(other$playerUuid)) return false;  Object this$tpTime = getTpTime(), other$tpTime = other.getTpTime(); return !((this$tpTime == null) ? (other$tpTime != null) : !this$tpTime.equals(other$tpTime)); } @Generated protected boolean canEqual(Object other) { return other instanceof WarpTpPlayer; } @Generated public int hashCode() { int PRIME = 59; result = 1; Object $id = getId(); result = result * 59 + (($id == null) ? 43 : $id.hashCode()); Object $warpPlayerId = getWarpPlayerId(); result = result * 59 + (($warpPlayerId == null) ? 43 : $warpPlayerId.hashCode()); Object $playerName = getPlayerName(); result = result * 59 + (($playerName == null) ? 43 : $playerName.hashCode()); Object $playerUuid = getPlayerUuid(); result = result * 59 + (($playerUuid == null) ? 43 : $playerUuid.hashCode()); Object $tpTime = getTpTime(); return result * 59 + (($tpTime == null) ? 43 : $tpTime.hashCode()); } @Generated public String toString() { return "WarpTpPlayer(id=" + getId() + ", playerName=" + getPlayerName() + ", playerUuid=" + getPlayerUuid() + ", warpPlayerId=" + getWarpPlayerId() + ", tpTime=" + getTpTime() + ")"; }
/*    */ 
/*    */   
/*    */   @Generated
/*    */   public Integer getId() {
/* 21 */     return this.id;
/*    */   } @Generated
/*    */   public String getPlayerName() {
/* 24 */     return this.playerName;
/*    */   } @Generated
/*    */   public UUID getPlayerUuid() {
/* 27 */     return this.playerUuid;
/*    */   } @Generated
/*    */   public Integer getWarpPlayerId() {
/* 30 */     return this.warpPlayerId;
/*    */   } @Generated
/*    */   public Date getTpTime() {
/* 33 */     return this.tpTime;
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\enter\WarpTpPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */