/*    */ package cn.handyplus.warp.enter;
/*    */ 
/*    */ import lombok.Generated;
/*    */ 
/*    */ @TableName(value = "warp_channel", comment = "玩家渠道")
/*    */ public class WarpChannel {
/*    */   @TableField(value = "id", comment = "ID")
/*    */   private Integer id;
/*    */   @TableField(value = "player_name", comment = "玩家名称", notNull = true)
/*    */   private String playerName;
/*    */   @TableField(value = "player_uuid", comment = "玩家uuid", notNull = true, indexEnum = IndexEnum.INDEX)
/*    */   private UUID playerUuid;
/*    */   
/*    */   @Generated
/* 15 */   public void setId(Integer id) { this.id = id; } @TableField(value = "warp_name", comment = "地标名称", length = 255) private String warpName; @TableField(value = "server_name", comment = "服务器名称", notNull = true) private String serverName; @TableField(value = "warp_location", comment = "地标坐标", length = 2000) private String warpLocation; @TableField(value = "warp_offset", comment = "地标偏移") private String warpOffset; @Generated public void setPlayerName(String playerName) { this.playerName = playerName; } @Generated public void setPlayerUuid(UUID playerUuid) { this.playerUuid = playerUuid; } @Generated public void setWarpName(String warpName) { this.warpName = warpName; } @Generated public void setServerName(String serverName) { this.serverName = serverName; } @Generated public void setWarpLocation(String warpLocation) { this.warpLocation = warpLocation; } @Generated public void setWarpOffset(String warpOffset) { this.warpOffset = warpOffset; } @Generated public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof WarpChannel)) return false;  WarpChannel other = (WarpChannel)o; if (!other.canEqual(this)) return false;  Object this$id = getId(), other$id = other.getId(); if ((this$id == null) ? (other$id != null) : !this$id.equals(other$id)) return false;  Object this$playerName = getPlayerName(), other$playerName = other.getPlayerName(); if ((this$playerName == null) ? (other$playerName != null) : !this$playerName.equals(other$playerName)) return false;  Object this$playerUuid = getPlayerUuid(), other$playerUuid = other.getPlayerUuid(); if ((this$playerUuid == null) ? (other$playerUuid != null) : !this$playerUuid.equals(other$playerUuid)) return false;  Object this$warpName = getWarpName(), other$warpName = other.getWarpName(); if ((this$warpName == null) ? (other$warpName != null) : !this$warpName.equals(other$warpName)) return false;  Object this$serverName = getServerName(), other$serverName = other.getServerName(); if ((this$serverName == null) ? (other$serverName != null) : !this$serverName.equals(other$serverName)) return false;  Object this$warpLocation = getWarpLocation(), other$warpLocation = other.getWarpLocation(); if ((this$warpLocation == null) ? (other$warpLocation != null) : !this$warpLocation.equals(other$warpLocation)) return false;  Object this$warpOffset = getWarpOffset(), other$warpOffset = other.getWarpOffset(); return !((this$warpOffset == null) ? (other$warpOffset != null) : !this$warpOffset.equals(other$warpOffset)); } @Generated protected boolean canEqual(Object other) { return other instanceof WarpChannel; } @Generated public int hashCode() { int PRIME = 59; result = 1; Object $id = getId(); result = result * 59 + (($id == null) ? 43 : $id.hashCode()); Object $playerName = getPlayerName(); result = result * 59 + (($playerName == null) ? 43 : $playerName.hashCode()); Object $playerUuid = getPlayerUuid(); result = result * 59 + (($playerUuid == null) ? 43 : $playerUuid.hashCode()); Object $warpName = getWarpName(); result = result * 59 + (($warpName == null) ? 43 : $warpName.hashCode()); Object $serverName = getServerName(); result = result * 59 + (($serverName == null) ? 43 : $serverName.hashCode()); Object $warpLocation = getWarpLocation(); result = result * 59 + (($warpLocation == null) ? 43 : $warpLocation.hashCode()); Object $warpOffset = getWarpOffset(); return result * 59 + (($warpOffset == null) ? 43 : $warpOffset.hashCode()); } @Generated public String toString() { return "WarpChannel(id=" + getId() + ", playerName=" + getPlayerName() + ", playerUuid=" + getPlayerUuid() + ", warpName=" + getWarpName() + ", serverName=" + getServerName() + ", warpLocation=" + getWarpLocation() + ", warpOffset=" + getWarpOffset() + ")"; }
/*    */ 
/*    */   
/*    */   @Generated
/*    */   public Integer getId() {
/* 20 */     return this.id;
/*    */   } @Generated
/*    */   public String getPlayerName() {
/* 23 */     return this.playerName;
/*    */   } @Generated
/*    */   public UUID getPlayerUuid() {
/* 26 */     return this.playerUuid;
/*    */   } @Generated
/*    */   public String getWarpName() {
/* 29 */     return this.warpName;
/*    */   } @Generated
/*    */   public String getServerName() {
/* 32 */     return this.serverName;
/*    */   } @Generated
/*    */   public String getWarpLocation() {
/* 35 */     return this.warpLocation;
/*    */   } @Generated
/*    */   public String getWarpOffset() {
/* 38 */     return this.warpOffset;
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\enter\WarpChannel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */