/*    */ package cn.handyplus.warp.enter;
/*    */ 
/*    */ import cn.handyplus.warp.lib.TableField;
/*    */ import java.util.UUID;
/*    */ import lombok.Generated;
/*    */ 
/*    */ @TableName(value = "warp_like_player", comment = "玩家地标")
/*    */ public class WarpLikePlayer {
/*    */   @TableField(value = "id", comment = "ID")
/*    */   private Integer id;
/*    */   @TableField(value = "warp_player_id", comment = "地标id", notNull = true, indexEnum = IndexEnum.INDEX)
/*    */   private Integer warpPlayerId;
/*    */   
/*    */   @Generated
/* 15 */   public void setId(Integer id) { this.id = id; } @TableField(value = "player_name", comment = "玩家名称", notNull = true) private String playerName; @TableField(value = "player_uuid", comment = "玩家uuid", notNull = true) private UUID playerUuid; @TableField(value = "like", comment = "评分", notNull = true, fieldDefault = "0") private Integer like; @Generated public void setWarpPlayerId(Integer warpPlayerId) { this.warpPlayerId = warpPlayerId; } @Generated public void setPlayerName(String playerName) { this.playerName = playerName; } @Generated public void setPlayerUuid(UUID playerUuid) { this.playerUuid = playerUuid; } @Generated public void setLike(Integer like) { this.like = like; } @Generated public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof WarpLikePlayer)) return false;  WarpLikePlayer other = (WarpLikePlayer)o; if (!other.canEqual(this)) return false;  Object this$id = getId(), other$id = other.getId(); if ((this$id == null) ? (other$id != null) : !this$id.equals(other$id)) return false;  Object this$warpPlayerId = getWarpPlayerId(), other$warpPlayerId = other.getWarpPlayerId(); if ((this$warpPlayerId == null) ? (other$warpPlayerId != null) : !this$warpPlayerId.equals(other$warpPlayerId)) return false;  Object this$like = getLike(), other$like = other.getLike(); if ((this$like == null) ? (other$like != null) : !this$like.equals(other$like)) return false;  Object this$playerName = getPlayerName(), other$playerName = other.getPlayerName(); if ((this$playerName == null) ? (other$playerName != null) : !this$playerName.equals(other$playerName)) return false;  Object this$playerUuid = getPlayerUuid(), other$playerUuid = other.getPlayerUuid(); return !((this$playerUuid == null) ? (other$playerUuid != null) : !this$playerUuid.equals(other$playerUuid)); } @Generated protected boolean canEqual(Object other) { return other instanceof WarpLikePlayer; } @Generated public int hashCode() { int PRIME = 59; result = 1; Object $id = getId(); result = result * 59 + (($id == null) ? 43 : $id.hashCode()); Object $warpPlayerId = getWarpPlayerId(); result = result * 59 + (($warpPlayerId == null) ? 43 : $warpPlayerId.hashCode()); Object $like = getLike(); result = result * 59 + (($like == null) ? 43 : $like.hashCode()); Object $playerName = getPlayerName(); result = result * 59 + (($playerName == null) ? 43 : $playerName.hashCode()); Object $playerUuid = getPlayerUuid(); return result * 59 + (($playerUuid == null) ? 43 : $playerUuid.hashCode()); } @Generated public String toString() { return "WarpLikePlayer(id=" + getId() + ", warpPlayerId=" + getWarpPlayerId() + ", playerName=" + getPlayerName() + ", playerUuid=" + getPlayerUuid() + ", like=" + getLike() + ")"; }
/*    */   
/*    */   @Generated
/*    */   public Integer getId() {
/* 19 */     return this.id;
/*    */   } @Generated
/*    */   public Integer getWarpPlayerId() {
/* 22 */     return this.warpPlayerId;
/*    */   } @Generated
/*    */   public String getPlayerName() {
/* 25 */     return this.playerName;
/*    */   } @Generated
/*    */   public UUID getPlayerUuid() {
/* 28 */     return this.playerUuid;
/*    */   } @Generated
/*    */   public Integer getLike() {
/* 31 */     return this.like;
/*    */   }
/*    */ }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\enter\WarpLikePlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */