/*    */ package cn.handyplus.warp.enter;
/*    */ @TableName(value = "warp_player", comment = "玩家地标")
/*    */ public class WarpPlayer { @TableField(value = "id", comment = "ID")
/*    */   private Integer id; @TableField(value = "player_name", comment = "玩家名称", notNull = true)
/*    */   private String playerName; @TableField(value = "player_uuid", comment = "玩家uuid", notNull = true)
/*    */   private UUID playerUuid; @TableField(value = "name", comment = "地标名称", length = 255)
/*    */   private String name; @TableField(value = "type", comment = "地标类型")
/*    */   private String type; @TableField(value = "description", comment = "地标描述", length = 255)
/*    */   private String description; @TableField(value = "logo_id", comment = "logoId")
/*    */   private Integer logoId; @TableField(value = "logo_name", comment = "logo", length = 10000, notNull = true)
/*    */   private String logoName; @TableField(value = "price", comment = "价格", notNull = true, fieldDefault = "0")
/*    */   private Integer price; @TableField(value = "tp_number", comment = "地标流量", notNull = true, fieldDefault = "0")
/*    */   private Integer tpNumber;
/*    */   @Generated
/* 15 */   public void setId(Integer id) { this.id = id; } @TableField(value = "server_name", comment = "服务器名称", notNull = true) private String serverName; @TableField(value = "world_name", comment = "地标所在世界", notNull = true, length = 255) private String worldName; @TableField(value = "warp_location", comment = "地标坐标", length = 2000) private String warpLocation; @TableField(value = "warp_offset", comment = "地标偏移") private String warpOffset; @TableField(value = "thermal_value", comment = "热力值", notNull = true, fieldDefault = "0") private Integer thermalValue; @TableField(value = "display", comment = "true显示", notNull = true) private Boolean display; @TableField(value = "create_time", comment = "创建时间") private Date createTime; @TableField(value = "expiration_time", comment = "到期时间") private Date expirationTime; @TableField(value = "top_index", comment = "置顶坐标") private Integer topIndex; @TableField(value = "top_time", comment = "置顶到期时间") private Date topTime; @Generated public void setPlayerName(String playerName) { this.playerName = playerName; } @Generated public void setPlayerUuid(UUID playerUuid) { this.playerUuid = playerUuid; } @Generated public void setName(String name) { this.name = name; } @Generated public void setType(String type) { this.type = type; } @Generated public void setDescription(String description) { this.description = description; } @Generated public void setLogoId(Integer logoId) { this.logoId = logoId; } @Generated public void setLogoName(String logoName) { this.logoName = logoName; } @Generated public void setPrice(Integer price) { this.price = price; } @Generated public void setTpNumber(Integer tpNumber) { this.tpNumber = tpNumber; } @Generated public void setServerName(String serverName) { this.serverName = serverName; } @Generated public void setWorldName(String worldName) { this.worldName = worldName; } @Generated public void setWarpLocation(String warpLocation) { this.warpLocation = warpLocation; } @Generated public void setWarpOffset(String warpOffset) { this.warpOffset = warpOffset; } @Generated public void setThermalValue(Integer thermalValue) { this.thermalValue = thermalValue; } @Generated public void setDisplay(Boolean display) { this.display = display; } @Generated public void setCreateTime(Date createTime) { this.createTime = createTime; } @Generated public void setExpirationTime(Date expirationTime) { this.expirationTime = expirationTime; } @Generated public void setTopIndex(Integer topIndex) { this.topIndex = topIndex; } @Generated public void setTopTime(Date topTime) { this.topTime = topTime; } @Generated public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof WarpPlayer)) return false;  WarpPlayer other = (WarpPlayer)o; if (!other.canEqual(this)) return false;  Object this$id = getId(), other$id = other.getId(); if ((this$id == null) ? (other$id != null) : !this$id.equals(other$id)) return false;  Object this$logoId = getLogoId(), other$logoId = other.getLogoId(); if ((this$logoId == null) ? (other$logoId != null) : !this$logoId.equals(other$logoId)) return false;  Object this$price = getPrice(), other$price = other.getPrice(); if ((this$price == null) ? (other$price != null) : !this$price.equals(other$price)) return false;  Object this$tpNumber = getTpNumber(), other$tpNumber = other.getTpNumber(); if ((this$tpNumber == null) ? (other$tpNumber != null) : !this$tpNumber.equals(other$tpNumber)) return false;  Object this$thermalValue = getThermalValue(), other$thermalValue = other.getThermalValue(); if ((this$thermalValue == null) ? (other$thermalValue != null) : !this$thermalValue.equals(other$thermalValue)) return false;  Object this$display = getDisplay(), other$display = other.getDisplay(); if ((this$display == null) ? (other$display != null) : !this$display.equals(other$display)) return false;  Object this$topIndex = getTopIndex(), other$topIndex = other.getTopIndex(); if ((this$topIndex == null) ? (other$topIndex != null) : !this$topIndex.equals(other$topIndex)) return false;  Object this$playerName = getPlayerName(), other$playerName = other.getPlayerName(); if ((this$playerName == null) ? (other$playerName != null) : !this$playerName.equals(other$playerName)) return false;  Object this$playerUuid = getPlayerUuid(), other$playerUuid = other.getPlayerUuid(); if ((this$playerUuid == null) ? (other$playerUuid != null) : !this$playerUuid.equals(other$playerUuid)) return false;  Object this$name = getName(), other$name = other.getName(); if ((this$name == null) ? (other$name != null) : !this$name.equals(other$name)) return false;  Object this$type = getType(), other$type = other.getType(); if ((this$type == null) ? (other$type != null) : !this$type.equals(other$type)) return false;  Object this$description = getDescription(), other$description = other.getDescription(); if ((this$description == null) ? (other$description != null) : !this$description.equals(other$description)) return false;  Object this$logoName = getLogoName(), other$logoName = other.getLogoName(); if ((this$logoName == null) ? (other$logoName != null) : !this$logoName.equals(other$logoName)) return false;  Object this$serverName = getServerName(), other$serverName = other.getServerName(); if ((this$serverName == null) ? (other$serverName != null) : !this$serverName.equals(other$serverName)) return false;  Object this$worldName = getWorldName(), other$worldName = other.getWorldName(); if ((this$worldName == null) ? (other$worldName != null) : !this$worldName.equals(other$worldName)) return false;  Object this$warpLocation = getWarpLocation(), other$warpLocation = other.getWarpLocation(); if ((this$warpLocation == null) ? (other$warpLocation != null) : !this$warpLocation.equals(other$warpLocation)) return false;  Object this$warpOffset = getWarpOffset(), other$warpOffset = other.getWarpOffset(); if ((this$warpOffset == null) ? (other$warpOffset != null) : !this$warpOffset.equals(other$warpOffset)) return false;  Object this$createTime = getCreateTime(), other$createTime = other.getCreateTime(); if ((this$createTime == null) ? (other$createTime != null) : !this$createTime.equals(other$createTime)) return false;  Object this$expirationTime = getExpirationTime(), other$expirationTime = other.getExpirationTime(); if ((this$expirationTime == null) ? (other$expirationTime != null) : !this$expirationTime.equals(other$expirationTime)) return false;  Object this$topTime = getTopTime(), other$topTime = other.getTopTime(); return !((this$topTime == null) ? (other$topTime != null) : !this$topTime.equals(other$topTime)); } @Generated protected boolean canEqual(Object other) { return other instanceof WarpPlayer; } @Generated public int hashCode() { int PRIME = 59; result = 1; Object $id = getId(); result = result * 59 + (($id == null) ? 43 : $id.hashCode()); Object $logoId = getLogoId(); result = result * 59 + (($logoId == null) ? 43 : $logoId.hashCode()); Object $price = getPrice(); result = result * 59 + (($price == null) ? 43 : $price.hashCode()); Object $tpNumber = getTpNumber(); result = result * 59 + (($tpNumber == null) ? 43 : $tpNumber.hashCode()); Object $thermalValue = getThermalValue(); result = result * 59 + (($thermalValue == null) ? 43 : $thermalValue.hashCode()); Object $display = getDisplay(); result = result * 59 + (($display == null) ? 43 : $display.hashCode()); Object $topIndex = getTopIndex(); result = result * 59 + (($topIndex == null) ? 43 : $topIndex.hashCode()); Object $playerName = getPlayerName(); result = result * 59 + (($playerName == null) ? 43 : $playerName.hashCode()); Object $playerUuid = getPlayerUuid(); result = result * 59 + (($playerUuid == null) ? 43 : $playerUuid.hashCode()); Object $name = getName(); result = result * 59 + (($name == null) ? 43 : $name.hashCode()); Object $type = getType(); result = result * 59 + (($type == null) ? 43 : $type.hashCode()); Object $description = getDescription(); result = result * 59 + (($description == null) ? 43 : $description.hashCode()); Object $logoName = getLogoName(); result = result * 59 + (($logoName == null) ? 43 : $logoName.hashCode()); Object $serverName = getServerName(); result = result * 59 + (($serverName == null) ? 43 : $serverName.hashCode()); Object $worldName = getWorldName(); result = result * 59 + (($worldName == null) ? 43 : $worldName.hashCode()); Object $warpLocation = getWarpLocation(); result = result * 59 + (($warpLocation == null) ? 43 : $warpLocation.hashCode()); Object $warpOffset = getWarpOffset(); result = result * 59 + (($warpOffset == null) ? 43 : $warpOffset.hashCode()); Object $createTime = getCreateTime(); result = result * 59 + (($createTime == null) ? 43 : $createTime.hashCode()); Object $expirationTime = getExpirationTime(); result = result * 59 + (($expirationTime == null) ? 43 : $expirationTime.hashCode()); Object $topTime = getTopTime(); return result * 59 + (($topTime == null) ? 43 : $topTime.hashCode()); } @Generated public String toString() { return "WarpPlayer(id=" + getId() + ", playerName=" + getPlayerName() + ", playerUuid=" + getPlayerUuid() + ", name=" + getName() + ", type=" + getType() + ", description=" + getDescription() + ", logoId=" + getLogoId() + ", logoName=" + getLogoName() + ", price=" + getPrice() + ", tpNumber=" + getTpNumber() + ", serverName=" + getServerName() + ", worldName=" + getWorldName() + ", warpLocation=" + getWarpLocation() + ", warpOffset=" + getWarpOffset() + ", thermalValue=" + getThermalValue() + ", display=" + getDisplay() + ", createTime=" + getCreateTime() + ", expirationTime=" + getExpirationTime() + ", topIndex=" + getTopIndex() + ", topTime=" + getTopTime() + ")"; }
/*    */ 
/*    */   
/*    */   @Generated
/*    */   public Integer getId() {
/* 20 */     return this.id;
/*    */   } @Generated
/*    */   public String getPlayerName() {
/* 23 */     return this.playerName;
/*    */   } @Generated
/*    */   public UUID getPlayerUuid() {
/* 26 */     return this.playerUuid;
/*    */   } @Generated
/*    */   public String getName() {
/* 29 */     return this.name;
/*    */   } @Generated
/*    */   public String getType() {
/* 32 */     return this.type;
/*    */   } @Generated
/*    */   public String getDescription() {
/* 35 */     return this.description;
/*    */   } @Generated
/*    */   public Integer getLogoId() {
/* 38 */     return this.logoId;
/*    */   } @Generated
/*    */   public String getLogoName() {
/* 41 */     return this.logoName;
/*    */   } @Generated
/*    */   public Integer getPrice() {
/* 44 */     return this.price;
/*    */   } @Generated
/*    */   public Integer getTpNumber() {
/* 47 */     return this.tpNumber;
/*    */   } @Generated
/*    */   public String getServerName() {
/* 50 */     return this.serverName;
/*    */   } @Generated
/*    */   public String getWorldName() {
/* 53 */     return this.worldName;
/*    */   } @Generated
/*    */   public String getWarpLocation() {
/* 56 */     return this.warpLocation;
/*    */   } @Generated
/*    */   public String getWarpOffset() {
/* 59 */     return this.warpOffset;
/*    */   } @Generated
/*    */   public Integer getThermalValue() {
/* 62 */     return this.thermalValue;
/*    */   } @Generated
/*    */   public Boolean getDisplay() {
/* 65 */     return this.display;
/*    */   } @Generated
/*    */   public Date getCreateTime() {
/* 68 */     return this.createTime;
/*    */   } @Generated
/*    */   public Date getExpirationTime() {
/* 71 */     return this.expirationTime;
/*    */   } @Generated
/*    */   public Integer getTopIndex() {
/* 74 */     return this.topIndex;
/*    */   } @Generated
/*    */   public Date getTopTime() {
/* 77 */     return this.topTime;
/*    */   } }


/* Location:              E:\Meu\PlayerWarp-2.3.4-free.jar!\cn\handyplus\warp\enter\WarpPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */